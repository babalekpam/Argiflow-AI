# ARGILETTE + Instantly Features — Integration Guide

## What This Adds

17 Instantly.ai features merged into your existing ArgiFlow TypeScript/Drizzle/Express stack:

- Email Account Management (Google/Microsoft/SMTP)
- Email Warmup Engine (multi-tier pools, reputation scoring)
- Campaign Builder (sequences, A/Z testing, spintax, inbox rotation)
- Unified Inbox — Unibox (AI auto-labels, sentiment)
- Website Visitor Identification (pixel tracking, company resolution)
- Done-For-You Email Setup (domain provisioning, DNS config)
- Email Verification (waterfall + catch-all recovery)
- Inbox Placement Testing (Gmail/Outlook/Yahoo pre-send check)
- AI Copilot (sequence generation, subject lines, campaign ideas)
- Email Templates Library
- Campaign Analytics Dashboard
- Spam Word Checker
- ESP Matching
- Inbox Rotation

---

## Files to Add

Copy these 3 files into your project:

```
shared/instantly-schema.ts    → Database schema (15 new tables)
server/instantly-routes.ts    → API routes (50+ endpoints)
server/instantly-engine.ts    → Core logic (warmup, classification, verification, etc.)
```

---

## Step 1: Add Schema Export

Open `shared/schema.ts` and add this line at the bottom (next to your existing workflow export):

```typescript
export * from "./instantly-schema";
```

Your file already has `export * from "./workflow-schema";` — just add the new line right after it.

---

## Step 2: Mount Routes

Open `server/routes.ts` and add these imports + mount:

```typescript
// At the top, add:
import instantlyRoutes, { handlePixelTrack } from "./instantly-routes";

// Inside your route registration function, add:
app.use("/api/instantly", instantlyRoutes);

// Public pixel tracking endpoint (no auth required):
app.post("/api/pixel/t", handlePixelTrack);
```

If your routes.ts uses a function like `registerRoutes(app)`, add those two lines inside it.

---

## Step 3: Push Database Schema

Run this in your Replit shell:

```bash
npm run db:push
```

This will create all 15 new tables via Drizzle. Your existing tables are untouched.

---

## Step 4: Verify

Restart your server and test:

```bash
# Check the instantly dashboard
curl -s http://localhost:5000/api/instantly/dashboard

# Check email accounts list
curl -s http://localhost:5000/api/instantly/email-accounts

# Test inbox placement
curl -s -X POST http://localhost:5000/api/instantly/inbox-test \
  -H "Content-Type: application/json" \
  -d '{"subject":"Test email","body":"Hi there, just checking deliverability"}'
```

---

## Step 5 (Optional): Add Warmup Cron Job

To run the warmup engine automatically, add this to your `server/index.ts` (or wherever your server starts):

```typescript
import { instantlyEngine } from "./instantly-engine";

// Run warmup every 15 minutes
setInterval(() => {
  instantlyEngine.runWarmupCycle().catch(console.error);
}, 15 * 60 * 1000);
```

---

## API Endpoint Map

All endpoints are prefixed with `/api/instantly/`

### Email Accounts
- `GET    /email-accounts`                    — List accounts
- `POST   /email-accounts/connect/smtp`       — Connect SMTP/IMAP
- `POST   /email-accounts/connect/google`     — Connect Google OAuth
- `POST   /email-accounts/connect/microsoft`  — Connect Microsoft OAuth
- `POST   /email-accounts/:id/warmup/toggle`  — Toggle warmup
- `GET    /email-accounts/:id/health`         — Account health + DNS
- `DELETE /email-accounts/:id`                — Delete account

### Warmup
- `GET    /warmup/dashboard`                  — Overview stats
- `GET    /warmup/stats/:accountId`           — Per-account stats
- `PUT    /warmup/settings/:accountId`        — Configure warmup

### Campaigns
- `GET    /campaigns`                         — List campaigns
- `POST   /campaigns`                         — Create campaign
- `GET    /campaigns/:id`                     — Campaign + sequences
- `PUT    /campaigns/:id`                     — Update campaign
- `DELETE /campaigns/:id`                     — Delete campaign (cascades)
- `POST   /campaigns/:id/sequences`           — Add sequence step
- `PUT    /campaigns/:cid/sequences/:sid`     — Update sequence
- `DELETE /campaigns/:cid/sequences/:sid`     — Delete sequence
- `POST   /campaigns/:id/accounts`            — Assign sending accounts
- `POST   /campaigns/:id/leads`               — Add leads
- `POST   /campaigns/:id/status`              — Launch/Pause/Stop
- `GET    /campaigns/:id/analytics`           — Campaign analytics
- `POST   /campaigns/:id/preview`             — Preview with spintax

### Unibox
- `GET    /unibox`                            — Inbox (filter by label/account/read)
- `PUT    /unibox/:id/read`                   — Mark read/unread
- `PUT    /unibox/:id/star`                   — Star/unstar
- `PUT    /unibox/:id/label`                  — Change AI label
- `PUT    /unibox/:id/archive`                — Archive
- `POST   /unibox/bulk`                       — Bulk actions
- `POST   /unibox/incoming`                   — Incoming email webhook

### Website Visitors
- `POST   /visitors/pixel`                    — Create tracking pixel
- `GET    /visitors/pixels`                   — List pixels
- `GET    /visitors/dashboard`                — Visitor analytics
- `POST   /visitors/:id/to-lead`              — Push visitor to lead

### DFY Email Setup
- `POST   /dfy/order`                         — Create DFY order
- `GET    /dfy/orders`                        — List orders
- `POST   /dfy/check-domain`                  — Check availability

### Email Verification
- `POST   /verification/bulk`                 — Bulk verify emails
- `POST   /verification/single`               — Single verify
- `GET    /verification/jobs`                 — List jobs
- `GET    /verification/jobs/:id/results`     — Job results
- `POST   /verification/jobs/:id/catch-all`   — Catch-all recovery

### Inbox Placement Testing
- `POST   /inbox-test`                        — Run placement test
- `GET    /inbox-tests`                       — Past tests

### AI Copilot
- `GET    /copilot/memory`                    — Get business context
- `POST   /copilot/memory`                    — Save business context
- `POST   /copilot/generate`                  — Generate content
- `GET    /copilot/tasks`                     — Past generations

### Email Templates
- `GET    /email-templates`                   — List templates
- `POST   /email-templates`                   — Create template
- `DELETE /email-templates/:id`               — Delete template

### Dashboard
- `GET    /instantly/dashboard`               — Full analytics overview

### Public (no auth)
- `POST   /api/pixel/t`                       — Pixel tracking endpoint

---

## New Database Tables (15)

| Table | Purpose |
|-------|---------|
| email_accounts | Connected email accounts (SMTP/OAuth) |
| warmup_stats | Daily warmup metrics per account |
| warmup_conversations | Simulated warmup email threads |
| campaigns | Campaign definitions + settings |
| campaign_sequences | Multi-step email sequences per campaign |
| campaign_sending_accounts | Accounts assigned to campaigns |
| campaign_leads | Leads assigned to campaigns + status |
| inbox_messages | Unified inbox with AI labels |
| website_pixels | Tracking pixel configurations |
| website_visitors | De-anonymized visitor records |
| dfy_orders | Done-for-you provisioning orders |
| dfy_domains | Domains in DFY orders + DNS records |
| verification_jobs | Bulk verification jobs |
| verification_results | Per-email verification results |
| inbox_placement_tests | Pre-send deliverability tests |
| copilot_memories | Business context for AI copilot |
| copilot_tasks | Generated content history |
| email_templates | Reusable email templates |
| campaign_daily_analytics | Aggregated daily campaign stats |

---

## What's NOT Touched

These files are unchanged — zero risk to existing functionality:
- shared/schema.ts (only adding 1 export line)
- shared/models/auth.ts
- shared/workflow-schema.ts
- server/routes.ts (only adding 2 mount lines)
- server/workflow-engine.ts
- server/workflow-routes.ts
- server/agents/*
- client/* (all frontend pages)

---

## Production Upgrades (When Ready)

1. **Real email sending**: Replace simulated sends with `nodemailer` (already in your package.json)
2. **Real IMAP sync**: Use `imapflow` (already installed) to poll for replies
3. **Real verification**: Connect ZeroBounce/NeverBounce APIs in waterfall
4. **Real visitor resolution**: Connect Clearbit Reveal / RB2B API
5. **Real AI copilot**: Use `@anthropic-ai/sdk` (already installed) instead of templates
6. **Real OAuth**: Implement Google/Microsoft OAuth flows with `openid-client` (already installed)
