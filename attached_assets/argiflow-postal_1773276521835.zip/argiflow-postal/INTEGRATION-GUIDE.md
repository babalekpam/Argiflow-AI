# Postal Integration Guide — ArgiFlow

## Overview
This adds Postal as the email sending engine for ArgiFlow.
- Mail server: https://mail.argilette.co
- API key: L8vbfObAPZr9rFQnrFM3TFCC
- Sending domain: argilette.co (SPF ✅ DKIM ✅ Return Path ✅)

---

## Files to Add to Replit

Copy these 2 files into your ArgiFlow Replit project:

```
server/postal.ts         → Core email service (all send functions)
server/postal-routes.ts  → Express API routes
```

---

## Step 1 — Add Environment Variable

In Replit Secrets, add:
```
POSTAL_API_KEY = L8vbfObAPZr9rFQnrFM3TFCC
```

---

## Step 2 — Mount Routes in server/routes.ts

Add these 2 lines to your routes.ts:

```typescript
// At the top imports:
import postalRoutes from "./postal-routes";

// Inside registerRoutes(app) or wherever you mount routes:
app.use("/api/postal", postalRoutes);
```

---

## Step 3 — Replace Email Sending in Sequence Engine

Find wherever ArgiFlow currently sends emails (nodemailer/SMTP calls).
Replace with:

```typescript
import postalService from "./postal";

// Before (nodemailer):
await transporter.sendMail({
  from: "partnerships@argilette.co",
  to: lead.email,
  subject: processedSubject,
  html: processedBody,
});

// After (Postal):
await postalService.sendSequenceEmail({
  to: lead.email,
  firstName: lead.name?.split(" ")[0],
  company: lead.company,
  subject: sequence.subject,
  htmlBody: sequence.body,
  fromName: "Abel Nkawula",
  sequenceName: campaign.name,
  stepNumber: currentStep,
});
```

---

## Step 4 — Replace Welcome/Transactional Emails

Find any nodemailer welcome or password reset sends and replace:

```typescript
// Welcome email
await postalService.sendWelcomeEmail(user.email, user.name);

// Password reset
await postalService.sendPasswordResetEmail(user.email, resetLink);

// New lead alert to yourself
await postalService.sendLeadNotificationEmail(
  "partnerships@argilette.co",
  lead.name,
  lead.email,
  lead.company
);
```

---

## API Endpoints (after mounting)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | /api/postal/send | Send a single email |
| POST | /api/postal/sequence | Send with variable substitution |
| POST | /api/postal/bulk | Send up to 100 emails |
| POST | /api/postal/welcome | Send welcome email |
| POST | /api/postal/lead-notification | Alert yourself of new lead |
| POST | /api/postal/test | Test that sending works |
| GET | /api/postal/status/:id | Check message delivery status |

---

## Test After Deploying

From Replit shell or terminal:
```bash
curl -X POST https://argilette.co/api/postal/test \
  -H "Content-Type: application/json" \
  -d '{"to":"partnerships@argilette.co"}'
```

Should return: `{"success":true,"messageId":"...","token":"..."}`

---

## Variable Substitution in Sequences

Use these placeholders in subject/body templates:

```
{{firstName}}   or   {firstName}
{{lastName}}    or   {lastName}
{{company}}     or   {company}
{{fullName}}    or   {fullName}
```

## Spintax Support

Use pipe-separated variants in curly braces:
```
{Hi|Hello|Hey} {{firstName}}, I noticed {your team|you} at {{company}}...
```

Each send picks a random variant.
