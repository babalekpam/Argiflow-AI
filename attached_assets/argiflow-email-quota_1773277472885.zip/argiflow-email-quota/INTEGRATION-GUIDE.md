# ArgiFlow Email Quota System — Integration Guide

## What This Builds
Every ArgiFlow client gets a monthly email sending quota.
All emails route through your Postal server at mail.argilette.co.
No SendGrid, no Mailgun — you control everything.

---

## Files to Add

```
shared/email-quota-schema.ts     → Database schema (2 new tables)
server/email-quota-engine.ts     → Core quota + send logic
server/email-quota-routes.ts     → API endpoints
client/email-dashboard.tsx       → Client-facing UI page
```

---

## Step 1 — Add Schema to shared/schema.ts

Add this line at the bottom of shared/schema.ts:
```typescript
export * from "./email-quota-schema";
```

---

## Step 2 — Push Database

Run in Replit shell:
```bash
npm run db:push
```
Creates 2 new tables: email_quotas, email_sends_log

---

## Step 3 — Mount Routes in server/routes.ts

```typescript
import emailQuotaRoutes from "./email-quota-routes";

// Inside registerRoutes(app):
app.use("/api/email", emailQuotaRoutes);
```

---

## Step 4 — Add Dashboard Page

Copy client/email-dashboard.tsx to:
client/src/pages/email-dashboard.tsx

Add route in App.tsx:
```typescript
import EmailDashboard from "@/pages/email-dashboard";
// Inside your router:
<Route path="/dashboard/email" component={EmailDashboard} />
```

Add to sidebar navigation:
```typescript
{ title: "Email Service", href: "/dashboard/email", icon: Mail }
```

---

## Step 5 — Add Env Variable to Replit Secrets

```
POSTAL_API_KEY = L8vbfObAPZr9rFQnrFM3TFCC
```

---

## Step 6 — Wire Into Sequence Engine

In your existing campaign/sequence send loop, replace the email send call:

```typescript
// Import at top of file:
import quotaEngine from "./email-quota-engine";

// Replace old send with:
const result = await quotaEngine.sendEmailWithQuota({
  userId: campaign.userId,
  to: lead.email,
  firstName: lead.name?.split(" ")[0],
  company: lead.company,
  subject: sequence.subject,
  htmlBody: sequence.body,
  tag: `campaign-${campaign.id}`,
});

if (result.quotaError) {
  // Pause campaign — quota exceeded
  await db.update(campaigns)
    .set({ status: "paused" })
    .where(eq(campaigns.id, campaign.id));
  break;
}
```

---

## API Endpoints

| Method | Endpoint | What It Does |
|--------|----------|--------------|
| GET | /api/email/quota | Get current usage + plan |
| POST | /api/email/send | Send single email |
| POST | /api/email/bulk | Send up to 500 emails |
| POST | /api/email/upgrade | Change plan |
| GET | /api/email/history | Last 50 sent emails |
| GET | /api/email/plans | All available plans |
| GET | /api/email/admin/stats | All users usage (admin) |

---

## Plan Tiers

| Plan | Emails/Month | Price |
|------|-------------|-------|
| Starter | 2,500 | Included |
| Growth | 10,000 | +$47/mo |
| Pro | 50,000 | +$97/mo |
| Agency | 150,000 | +$197/mo |

---

## Revenue Potential

10 clients on Growth = $470/mo
10 clients on Pro    = $970/mo
5 clients on Agency  = $985/mo

Your Postal server on Hetzner costs $4/mo regardless of volume.
