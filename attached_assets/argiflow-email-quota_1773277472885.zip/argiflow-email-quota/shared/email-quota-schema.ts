// ============================================================
// EMAIL QUOTA SCHEMA — ArgiFlow Mailing Service
// Add this to shared/schema.ts or import in your main schema
// ============================================================

import { pgTable, varchar, integer, timestamp, boolean, text, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// ── EMAIL PLAN ENUM ───────────────────────────────────────────
export const emailPlanEnum = pgEnum("email_plan", [
  "starter",   // 2,500/mo — included in base ArgiFlow plan
  "growth",    // 10,000/mo — +$47/mo
  "pro",       // 50,000/mo — +$97/mo
  "agency",    // 150,000/mo — +$197/mo
]);

// ── EMAIL QUOTAS TABLE ────────────────────────────────────────
// One row per user — tracks their plan + usage
export const emailQuotas = pgTable("email_quotas", {
  id:              varchar("id", { length: 36 }).primaryKey().$defaultFn(() => crypto.randomUUID()),
  userId:          varchar("user_id", { length: 36 }).notNull().unique(), // FK to users.id
  plan:            emailPlanEnum("plan").notNull().default("starter"),
  monthlyLimit:    integer("monthly_limit").notNull().default(2500),
  sentThisMonth:   integer("sent_this_month").notNull().default(0),
  sentAllTime:     integer("sent_all_time").notNull().default(0),
  resetDate:       timestamp("reset_date").notNull(), // When quota resets (1st of each month)
  isActive:        boolean("is_active").notNull().default(true),
  createdAt:       timestamp("created_at").defaultNow(),
  updatedAt:       timestamp("updated_at").defaultNow(),
});

// ── EMAIL SENDS LOG ───────────────────────────────────────────
// Every email sent is logged here for tracking + billing
export const emailSendsLog = pgTable("email_sends_log", {
  id:          varchar("id", { length: 36 }).primaryKey().$defaultFn(() => crypto.randomUUID()),
  userId:      varchar("user_id", { length: 36 }).notNull(),
  to:          text("to").notNull(),
  subject:     varchar("subject", { length: 500 }).notNull(),
  tag:         varchar("tag", { length: 100 }),          // e.g. "sequence", "campaign"
  postalMsgId: varchar("postal_msg_id", { length: 200 }), // Postal message ID for tracking
  postalToken: varchar("postal_token", { length: 100 }),
  status:      varchar("status", { length: 50 }).notNull().default("sent"), // sent | failed | bounced
  errorMsg:    text("error_msg"),
  sentAt:      timestamp("sent_at").defaultNow(),
});

// ── ZOD SCHEMAS ───────────────────────────────────────────────
export const insertEmailQuotaSchema = createInsertSchema(emailQuotas);
export const selectEmailQuotaSchema = createSelectSchema(emailQuotas);
export const insertEmailSendLogSchema = createInsertSchema(emailSendsLog);

export type EmailQuota = typeof emailQuotas.$inferSelect;
export type EmailSendLog = typeof emailSendsLog.$inferSelect;

// ── PLAN LIMITS MAP ───────────────────────────────────────────
export const EMAIL_PLAN_LIMITS: Record<string, number> = {
  starter: 2500,
  growth:  10000,
  pro:     50000,
  agency:  150000,
};

export const EMAIL_PLAN_PRICES: Record<string, number> = {
  starter: 0,
  growth:  47,
  pro:     97,
  agency:  197,
};
