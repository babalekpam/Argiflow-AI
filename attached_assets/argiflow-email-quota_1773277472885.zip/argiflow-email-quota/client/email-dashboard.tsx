// ============================================================
// EMAIL QUOTA DASHBOARD — ArgiFlow Client UI
// Add to: client/src/pages/email-dashboard.tsx
// Route: /dashboard/email
// ============================================================

import { useState, useEffect } from "react";

interface QuotaStatus {
  plan: string;
  used: number;
  limit: number;
  remaining: number;
  percentUsed: number;
  allowed: boolean;
  planPrice: number;
  resetDateFormatted: string;
}

interface EmailLog {
  id: string;
  to: string;
  subject: string;
  status: string;
  tag: string;
  sentAt: string;
}

interface Plan {
  id: string;
  name: string;
  emails: number;
  price: number;
  priceLabel: string;
}

export default function EmailDashboard() {
  const [quota, setQuota] = useState<QuotaStatus | null>(null);
  const [history, setHistory] = useState<EmailLog[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [sendForm, setSendForm] = useState({ to: "", subject: "", body: "" });
  const [sending, setSending] = useState(false);
  const [sendResult, setSendResult] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      fetch("/api/email/quota").then(r => r.json()),
      fetch("/api/email/history?limit=20").then(r => r.json()),
      fetch("/api/email/plans").then(r => r.json()),
    ]).then(([q, h, p]) => {
      setQuota(q);
      setHistory(h.emails || []);
      setPlans(p.plans || []);
      setLoading(false);
    });
  }, []);

  async function handleSendTest() {
    if (!sendForm.to || !sendForm.subject || !sendForm.body) return;
    setSending(true);
    setSendResult(null);

    const res = await fetch("/api/email/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: sendForm.to,
        subject: sendForm.subject,
        htmlBody: `<p>${sendForm.body}</p>`,
      }),
    });
    const data = await res.json();
    setSendResult(data.success ? "✓ Email sent successfully!" : `✗ ${data.error}`);
    setSending(false);

    // Refresh quota
    const q = await fetch("/api/email/quota").then(r => r.json());
    setQuota(q);
  }

  async function handleUpgrade(planId: string) {
    const res = await fetch("/api/email/upgrade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan: planId }),
    });
    const data = await res.json();
    if (data.success) {
      const q = await fetch("/api/email/quota").then(r => r.json());
      setQuota(q);
    }
  }

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "300px" }}>
      <div style={{ color: "#6366f1", fontSize: "18px" }}>Loading...</div>
    </div>
  );

  const barColor = quota!.percentUsed > 90 ? "#ef4444" : quota!.percentUsed > 70 ? "#f59e0b" : "#6366f1";

  return (
    <div style={{ fontFamily: "Inter, Arial, sans-serif", maxWidth: "900px", margin: "0 auto", padding: "24px", color: "#1a1a2e" }}>
      <h1 style={{ fontSize: "24px", fontWeight: 700, marginBottom: "4px" }}>📧 Email Service</h1>
      <p style={{ color: "#666", marginBottom: "32px" }}>Send emails to your leads and clients — no SendGrid needed.</p>

      {/* Quota Card */}
      <div style={{ background: "white", borderRadius: "12px", padding: "24px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", marginBottom: "24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
          <div>
            <span style={{ background: "#ede9fe", color: "#6366f1", padding: "4px 12px", borderRadius: "20px", fontSize: "13px", fontWeight: 600, textTransform: "capitalize" }}>
              {quota!.plan} Plan
            </span>
            <h2 style={{ fontSize: "32px", fontWeight: 700, margin: "8px 0 0" }}>
              {quota!.used.toLocaleString()} <span style={{ fontSize: "18px", color: "#666", fontWeight: 400 }}>/ {quota!.limit.toLocaleString()} emails</span>
            </h2>
            <p style={{ color: "#666", margin: "4px 0 0", fontSize: "14px" }}>Resets {quota!.resetDateFormatted}</p>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "28px", fontWeight: 700, color: barColor }}>{quota!.percentUsed}%</div>
            <div style={{ fontSize: "13px", color: "#666" }}>used</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div style={{ background: "#f3f4f6", borderRadius: "8px", height: "12px", overflow: "hidden" }}>
          <div style={{
            width: `${Math.min(quota!.percentUsed, 100)}%`,
            height: "100%",
            background: barColor,
            borderRadius: "8px",
            transition: "width 0.5s ease"
          }} />
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", marginTop: "8px" }}>
          <span style={{ fontSize: "13px", color: "#666" }}>{quota!.remaining.toLocaleString()} remaining</span>
          {quota!.percentUsed > 80 && (
            <span style={{ fontSize: "13px", color: "#ef4444", fontWeight: 600 }}>⚠ Running low — upgrade soon</span>
          )}
        </div>
      </div>

      {/* Send Test Email */}
      <div style={{ background: "white", borderRadius: "12px", padding: "24px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", marginBottom: "24px" }}>
        <h3 style={{ fontSize: "16px", fontWeight: 600, marginBottom: "16px" }}>Send Email</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          <input
            placeholder="To: recipient@example.com"
            value={sendForm.to}
            onChange={e => setSendForm(p => ({ ...p, to: e.target.value }))}
            style={{ padding: "10px 14px", borderRadius: "8px", border: "1px solid #e5e7eb", fontSize: "14px", outline: "none" }}
          />
          <input
            placeholder="Subject"
            value={sendForm.subject}
            onChange={e => setSendForm(p => ({ ...p, subject: e.target.value }))}
            style={{ padding: "10px 14px", borderRadius: "8px", border: "1px solid #e5e7eb", fontSize: "14px", outline: "none" }}
          />
          <textarea
            placeholder="Message body..."
            value={sendForm.body}
            onChange={e => setSendForm(p => ({ ...p, body: e.target.value }))}
            rows={4}
            style={{ padding: "10px 14px", borderRadius: "8px", border: "1px solid #e5e7eb", fontSize: "14px", resize: "vertical", outline: "none" }}
          />
          <button
            onClick={handleSendTest}
            disabled={sending || !quota?.allowed}
            style={{
              background: sending ? "#9ca3af" : "#6366f1",
              color: "white", border: "none", borderRadius: "8px",
              padding: "12px 24px", fontSize: "14px", fontWeight: 600,
              cursor: sending ? "not-allowed" : "pointer", alignSelf: "flex-start"
            }}
          >
            {sending ? "Sending..." : "Send Email"}
          </button>
          {sendResult && (
            <div style={{ color: sendResult.startsWith("✓") ? "#16a34a" : "#ef4444", fontSize: "14px", fontWeight: 500 }}>
              {sendResult}
            </div>
          )}
          {!quota?.allowed && (
            <div style={{ color: "#ef4444", fontSize: "14px" }}>Monthly quota reached — upgrade to continue sending.</div>
          )}
        </div>
      </div>

      {/* Upgrade Plans */}
      <div style={{ background: "white", borderRadius: "12px", padding: "24px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", marginBottom: "24px" }}>
        <h3 style={{ fontSize: "16px", fontWeight: 600, marginBottom: "16px" }}>Upgrade Your Email Plan</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "12px" }}>
          {plans.map(plan => {
            const isCurrent = quota?.plan === plan.id;
            return (
              <div key={plan.id} style={{
                border: isCurrent ? "2px solid #6366f1" : "1px solid #e5e7eb",
                borderRadius: "10px", padding: "16px", textAlign: "center",
                background: isCurrent ? "#faf5ff" : "white"
              }}>
                <div style={{ fontSize: "15px", fontWeight: 700 }}>{plan.name}</div>
                <div style={{ fontSize: "22px", fontWeight: 700, color: "#6366f1", margin: "6px 0" }}>
                  {plan.emails.toLocaleString()}
                </div>
                <div style={{ fontSize: "12px", color: "#666", marginBottom: "12px" }}>emails/month</div>
                <div style={{ fontSize: "16px", fontWeight: 600, marginBottom: "12px" }}>{plan.priceLabel}</div>
                {isCurrent ? (
                  <div style={{ background: "#6366f1", color: "white", borderRadius: "6px", padding: "6px", fontSize: "13px" }}>Current Plan</div>
                ) : (
                  <button
                    onClick={() => handleUpgrade(plan.id)}
                    style={{
                      background: "#6366f1", color: "white", border: "none",
                      borderRadius: "6px", padding: "8px 16px", fontSize: "13px",
                      cursor: "pointer", width: "100%", fontWeight: 600
                    }}
                  >
                    Upgrade
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Email History */}
      <div style={{ background: "white", borderRadius: "12px", padding: "24px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)" }}>
        <h3 style={{ fontSize: "16px", fontWeight: 600, marginBottom: "16px" }}>Recent Sends</h3>
        {history.length === 0 ? (
          <p style={{ color: "#666", fontSize: "14px" }}>No emails sent yet.</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "14px" }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #f3f4f6" }}>
                <th style={{ padding: "8px", textAlign: "left", color: "#666", fontWeight: 600 }}>To</th>
                <th style={{ padding: "8px", textAlign: "left", color: "#666", fontWeight: 600 }}>Subject</th>
                <th style={{ padding: "8px", textAlign: "left", color: "#666", fontWeight: 600 }}>Status</th>
                <th style={{ padding: "8px", textAlign: "left", color: "#666", fontWeight: 600 }}>Sent</th>
              </tr>
            </thead>
            <tbody>
              {history.map(email => (
                <tr key={email.id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                  <td style={{ padding: "10px 8px" }}>{email.to}</td>
                  <td style={{ padding: "10px 8px", color: "#444" }}>{email.subject}</td>
                  <td style={{ padding: "10px 8px" }}>
                    <span style={{
                      background: email.status === "sent" ? "#dcfce7" : "#fee2e2",
                      color: email.status === "sent" ? "#16a34a" : "#ef4444",
                      padding: "2px 8px", borderRadius: "4px", fontSize: "12px", fontWeight: 600
                    }}>
                      {email.status}
                    </span>
                  </td>
                  <td style={{ padding: "10px 8px", color: "#666", fontSize: "13px" }}>
                    {new Date(email.sentAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
