export { MetaDMsPage as default } from './AllPages';
