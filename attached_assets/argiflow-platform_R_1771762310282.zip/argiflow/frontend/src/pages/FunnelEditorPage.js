import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export default function FunnelEditorPage() {
  const { id } = useParams();
  return (
    <div className="h-screen flex flex-col bg-gray-950">
      <div className="h-14 bg-gray-900 border-b border-gray-800 flex items-center px-4 gap-3">
        <Link to="/funnels" className="text-gray-400 hover:text-white"><ChevronLeft size={18} /></Link>
        <span className="text-white font-medium">Funnel Editor</span>
        <div className="ml-auto flex gap-2">
          <button className="px-3 py-1.5 bg-gray-800 text-gray-300 text-sm rounded-lg hover:bg-gray-700">Preview</button>
          <button className="px-3 py-1.5 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-500">Publish</button>
        </div>
      </div>
      <div className="flex-1 flex">
        <div className="w-64 bg-gray-900 border-r border-gray-800 p-4">
          <p className="text-xs font-semibold text-gray-500 uppercase mb-3">Elements</p>
          {['Heading', 'Text', 'Button', 'Image', 'Video', 'Form', 'Countdown', 'Testimonial', 'Pricing Table'].map(el => (
            <div key={el} className="p-2.5 bg-gray-800 border border-gray-700 rounded-lg mb-2 text-sm text-gray-300 cursor-grab hover:bg-gray-700 transition-colors">{el}</div>
          ))}
        </div>
        <div className="flex-1 bg-gray-950 flex items-center justify-center">
          <div className="bg-white rounded-xl w-full max-w-3xl h-4/5 shadow-2xl flex items-center justify-center">
            <p className="text-gray-400 text-sm">Page canvas - drop elements here</p>
          </div>
        </div>
        <div className="w-64 bg-gray-900 border-l border-gray-800 p-4">
          <p className="text-xs font-semibold text-gray-500 uppercase mb-3">Properties</p>
          <p className="text-gray-600 text-sm">Select an element to edit its properties</p>
        </div>
      </div>
    </div>
  );
}
