export { CalendarPage as default } from './AllPages';
