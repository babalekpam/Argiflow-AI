export { ContactsPage as default } from './AllPages';
