export { DocumentsPage as default } from './AllPages';
