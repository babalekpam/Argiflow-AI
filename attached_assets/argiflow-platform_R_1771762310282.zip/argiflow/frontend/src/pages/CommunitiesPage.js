export { CommunitiesPage as default } from './AllPages';
