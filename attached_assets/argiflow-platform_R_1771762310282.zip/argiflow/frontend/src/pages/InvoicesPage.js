import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { invoicesApi, contactsApi } from '../utils/api';
import toast from 'react-hot-toast';
import { Plus, Search, Eye, Trash2, CreditCard, CheckCircle, Clock, AlertCircle, FileText, Send } from 'lucide-react';

const statusConfig = {
  draft: { color: 'text-gray-400 bg-gray-800' },
  sent: { color: 'text-blue-400 bg-blue-900/30' },
  paid: { color: 'text-emerald-400 bg-emerald-900/30' },
  partial: { color: 'text-amber-400 bg-amber-900/30' },
  overdue: { color: 'text-red-400 bg-red-900/30' },
};

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">{children}</div>
    </div>
  );
};

export default function InvoicesPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [viewInvoice, setViewInvoice] = useState(null);

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ['invoices', statusFilter],
    queryFn: () => invoicesApi.list({ status: statusFilter || undefined }).then(r => r.data),
  });
  const { data: stats } = useQuery({ queryKey: ['invoice-stats'], queryFn: () => invoicesApi.stats().then(r => r.data) });
  const { data: contacts = [] } = useQuery({ queryKey: ['contacts-list'], queryFn: () => contactsApi.list({ limit: 200 }).then(r => r.data.contacts || r.data) });

  const deleteMutation = useMutation({
    mutationFn: invoicesApi.delete,
    onSuccess: () => { qc.invalidateQueries(['invoices']); toast.success('Deleted'); },
  });
  const payLinkMutation = useMutation({
    mutationFn: invoicesApi.createPaymentLink,
    onSuccess: res => { navigator.clipboard.writeText(res.data.url); toast.success('Payment link copied!'); },
  });

  const filtered = invoices.filter(inv => {
    if (!search) return true;
    const s = search.toLowerCase();
    return [inv.invoice_number, inv.first_name, inv.last_name, inv.company].some(v => v?.toLowerCase().includes(s));
  });

  const fmt = (n) => `$${(parseFloat(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Invoices & Payments</h1>
          <p className="text-gray-400 text-sm mt-1">Create, send, and track invoices</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-medium transition-colors">
          <Plus size={16} /> New Invoice
        </button>
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Invoiced', value: fmt(stats.total_invoiced), color: 'text-white' },
            { label: 'Collected', value: fmt(stats.total_collected), color: 'text-emerald-400' },
            { label: 'Outstanding', value: fmt(stats.total_outstanding), color: 'text-amber-400' },
            { label: 'Overdue Count', value: stats.overdue_count || 0, color: 'text-red-400' },
          ].map(s => (
            <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
              <p className="text-xs text-gray-500">{s.label}</p>
              <p className={`text-xl font-bold mt-1 ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} className="w-full bg-gray-900 border border-gray-800 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="Search invoices..." />
        </div>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 focus:outline-none focus:border-indigo-500">
          <option value="">All Status</option>
          {Object.keys(statusConfig).map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
        </select>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead><tr className="border-b border-gray-800">
            {['Invoice #', 'Client', 'Amount', 'Balance Due', 'Due Date', 'Status', 'Actions'].map(h =>
              <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
            )}
          </tr></thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={7} className="text-center py-12 text-gray-500">Loading...</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-16 text-gray-500">
                <FileText size={40} className="mx-auto mb-3 opacity-30" />
                <p>No invoices yet. Create your first one!</p>
              </td></tr>
            ) : filtered.map(inv => (
              <tr key={inv.id} className="border-b border-gray-800/50 hover:bg-gray-800/20 transition-colors">
                <td className="px-4 py-3 text-sm font-mono text-indigo-400">{inv.invoice_number}</td>
                <td className="px-4 py-3">
                  <p className="text-sm text-white">{inv.first_name} {inv.last_name}</p>
                  {inv.company && <p className="text-xs text-gray-500">{inv.company}</p>}
                </td>
                <td className="px-4 py-3 text-sm text-white">{fmt(inv.total)}</td>
                <td className="px-4 py-3 text-sm text-amber-400">{fmt(inv.balance_due)}</td>
                <td className="px-4 py-3 text-sm text-gray-400">{inv.due_date ? new Date(inv.due_date).toLocaleDateString() : '—'}</td>
                <td className="px-4 py-3">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusConfig[inv.status]?.color}`}>{inv.status}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button onClick={() => setViewInvoice(inv)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors"><Eye size={14} /></button>
                    <button onClick={() => payLinkMutation.mutate(inv.id)} className="p-1.5 text-gray-400 hover:text-emerald-400 hover:bg-gray-700 rounded transition-colors"><CreditCard size={14} /></button>
                    {inv.status === 'draft' && (
                      <button onClick={() => window.confirm('Delete invoice?') && deleteMutation.mutate(inv.id)} className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-gray-700 rounded transition-colors"><Trash2 size={14} /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <CreateInvoiceModal show={showCreate} onClose={() => setShowCreate(false)} contacts={contacts}
        onCreated={() => { qc.invalidateQueries(['invoices', 'invoice-stats']); setShowCreate(false); }} />
      <ViewInvoiceModal show={!!viewInvoice} invoice={viewInvoice} onClose={() => setViewInvoice(null)} onUpdate={() => qc.invalidateQueries(['invoices', 'invoice-stats'])} />
    </div>
  );
}

function CreateInvoiceModal({ show, onClose, contacts, onCreated }) {
  const [form, setForm] = useState({ contact_id: '', due_date: '', line_items: [{ description: '', quantity: 1, unit_price: 0 }], tax_rate: 0, notes: '' });
  const [loading, setLoading] = useState(false);

  const addLine = () => setForm(f => ({ ...f, line_items: [...f.line_items, { description: '', quantity: 1, unit_price: 0 }] }));
  const removeLine = (i) => setForm(f => ({ ...f, line_items: f.line_items.filter((_, idx) => idx !== i) }));
  const updateLine = (i, field, val) => setForm(f => ({ ...f, line_items: f.line_items.map((l, idx) => idx === i ? { ...l, [field]: val } : l) }));
  const subtotal = form.line_items.reduce((s, l) => s + (parseFloat(l.quantity || 0) * parseFloat(l.unit_price || 0)), 0);
  const tax = subtotal * (parseFloat(form.tax_rate || 0) / 100);
  const total = subtotal + tax;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await invoicesApi.create({ ...form, issue_date: new Date().toISOString().split('T')[0] });
      toast.success('Invoice created!');
      setForm({ contact_id: '', due_date: '', line_items: [{ description: '', quantity: 1, unit_price: 0 }], tax_rate: 0, notes: '' });
      onCreated();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed');
    } finally { setLoading(false); }
  };

  return (
    <Modal show={show} onClose={onClose}>
      <div className="p-6">
        <h2 className="text-lg font-semibold text-white mb-5">Create Invoice</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">Client</label>
              <select value={form.contact_id} onChange={e => setForm(f => ({ ...f, contact_id: e.target.value }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500">
                <option value="">Select contact...</option>
                {contacts.map(c => <option key={c.id} value={c.id}>{c.first_name} {c.last_name}{c.company ? ` - ${c.company}` : ''}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">Due Date</label>
              <input type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500" />
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Line Items</label>
            <div className="space-y-2">
              {form.line_items.map((line, i) => (
                <div key={i} className="grid grid-cols-12 gap-2">
                  <input value={line.description} onChange={e => updateLine(i, 'description', e.target.value)} placeholder="Description" className="col-span-6 bg-gray-800 border border-gray-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                  <input type="number" value={line.quantity} onChange={e => updateLine(i, 'quantity', e.target.value)} min="1" className="col-span-2 bg-gray-800 border border-gray-700 rounded px-2 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 text-center" />
                  <input type="number" value={line.unit_price} onChange={e => updateLine(i, 'unit_price', e.target.value)} step="0.01" min="0" placeholder="$0.00" className="col-span-3 bg-gray-800 border border-gray-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                  <button type="button" onClick={() => removeLine(i)} className="col-span-1 text-red-400 hover:text-red-300 text-lg leading-none">×</button>
                </div>
              ))}
              <button type="button" onClick={addLine} className="text-sm text-indigo-400 hover:text-indigo-300">+ Add line</button>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4 space-y-1.5 text-sm">
            <div className="flex justify-between text-gray-400"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="flex items-center justify-between text-gray-400">
              <span>Tax (%)</span>
              <div className="flex items-center gap-2">
                <input type="number" value={form.tax_rate} onChange={e => setForm(f => ({ ...f, tax_rate: e.target.value }))} min="0" max="100" step="0.1" className="w-16 bg-gray-700 border border-gray-600 rounded px-2 py-1 text-white text-xs text-center" />
                <span>${tax.toFixed(2)}</span>
              </div>
            </div>
            <div className="flex justify-between text-white font-semibold border-t border-gray-700 pt-2"><span>Total</span><span>${total.toFixed(2)}</span></div>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500 resize-none" placeholder="Payment terms, notes..." />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg text-sm font-medium">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white rounded-lg text-sm font-medium">
              {loading ? 'Creating...' : 'Create Invoice'}
            </button>
          </div>
        </form>
      </div>
    </Modal>
  );
}

function ViewInvoiceModal({ show, invoice, onClose, onUpdate }) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('cash');
  const [loading, setLoading] = useState(false);
  if (!invoice) return null;

  const recordPayment = async () => {
    if (!amount) return;
    setLoading(true);
    try {
      await invoicesApi.recordPayment(invoice.id, { amount: parseFloat(amount), method });
      toast.success('Payment recorded!');
      onUpdate(); onClose();
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <Modal show={show} onClose={onClose}>
      <div className="p-6 space-y-5">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">{invoice.invoice_number}</h2>
            <p className="text-sm text-gray-400">{invoice.first_name} {invoice.last_name}{invoice.company ? ` • ${invoice.company}` : ''}</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusConfig[invoice.status]?.color}`}>{invoice.status}</span>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4">
          <table className="w-full text-sm">
            <thead><tr className="text-gray-500 border-b border-gray-700 text-xs">
              <th className="text-left pb-2">Description</th>
              <th className="text-right pb-2">Qty</th>
              <th className="text-right pb-2">Unit Price</th>
              <th className="text-right pb-2">Total</th>
            </tr></thead>
            <tbody>
              {(invoice.line_items || []).map((item, i) => (
                <tr key={i} className="border-b border-gray-800/50 text-gray-300">
                  <td className="py-2">{item.description}</td>
                  <td className="py-2 text-right">{item.quantity}</td>
                  <td className="py-2 text-right">${parseFloat(item.unit_price || 0).toFixed(2)}</td>
                  <td className="py-2 text-right">${(item.quantity * item.unit_price).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 space-y-1 text-sm text-right border-t border-gray-700 pt-3">
            <p className="text-gray-400">Tax ({invoice.tax_rate}%): ${parseFloat(invoice.tax_amount || 0).toFixed(2)}</p>
            <p className="text-white font-bold text-base">Total: ${parseFloat(invoice.total || 0).toFixed(2)}</p>
            <p className="text-amber-400">Balance Due: ${parseFloat(invoice.balance_due || 0).toFixed(2)}</p>
          </div>
        </div>
        {invoice.status !== 'paid' && (
          <div className="border border-gray-700 rounded-lg p-4">
            <p className="text-sm font-medium text-white mb-3">Record Manual Payment</p>
            <div className="flex gap-2">
              <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" max={invoice.balance_due} min="0.01" step="0.01"
                className="flex-1 bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500" />
              <select value={method} onChange={e => setMethod(e.target.value)} className="bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500">
                <option value="cash">Cash</option>
                <option value="check">Check</option>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="other">Other</option>
              </select>
              <button onClick={recordPayment} disabled={loading || !amount} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-700 text-white text-sm rounded font-medium transition-colors">
                {loading ? '...' : 'Record'}
              </button>
            </div>
          </div>
        )}
        <button onClick={onClose} className="w-full px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg text-sm font-medium">Close</button>
      </div>
    </Modal>
  );
}
