import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { dashboardApi } from '../utils/api';
import { Users, MessageSquare, DollarSign, FileText, Share2, TrendingUp, ArrowRight, Zap } from 'lucide-react';

const StatCard = ({ label, value, icon: Icon, color, trend, link, navigate }) => (
  <div
    className={`bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-all cursor-pointer group ${link ? '' : ''}`}
    onClick={() => link && navigate(link)}
  >
    <div className="flex items-start justify-between mb-3">
      <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center`}>
        <Icon size={18} className="text-white" />
      </div>
      {trend && (
        <span className="flex items-center gap-1 text-xs text-emerald-400">
          <TrendingUp size={12} /> {trend}
        </span>
      )}
    </div>
    <p className="text-2xl font-bold text-white mb-0.5">{value ?? '—'}</p>
    <p className="text-sm text-gray-500">{label}</p>
    {link && (
      <div className="flex items-center gap-1 mt-3 text-xs text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity">
        View all <ArrowRight size={12} />
      </div>
    )}
  </div>
);

const quickActions = [
  { label: 'Create Invoice', icon: FileText, color: 'bg-amber-500/10 text-amber-400 border-amber-500/20', path: '/invoices' },
  { label: 'New Funnel', icon: Zap, color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20', path: '/funnels' },
  { label: 'Live Chat', icon: MessageSquare, color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', path: '/chat' },
  { label: 'Schedule Post', icon: Share2, color: 'bg-pink-500/10 text-pink-400 border-pink-500/20', path: '/social' },
];

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data: stats, isLoading } = useQuery({ queryKey: ['dashboard-stats'], queryFn: () => dashboardApi.stats().then(r => r.data) });

  const statCards = [
    { label: 'Total Contacts', value: stats?.totalContacts?.toLocaleString(), icon: Users, color: 'bg-blue-600', link: '/contacts' },
    { label: 'Open Chats', value: stats?.openChats, icon: MessageSquare, color: 'bg-emerald-600', link: '/chat' },
    { label: 'Revenue (MTD)', value: stats?.revenueMtd ? `$${stats.revenueMtd.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '$0.00', icon: DollarSign, color: 'bg-amber-600', link: '/invoices' },
    { label: 'Form Submissions', value: stats?.formSubmissions, icon: FileText, color: 'bg-violet-600', link: '/forms' },
    { label: 'Published Posts', value: stats?.publishedPosts, icon: Share2, color: 'bg-pink-600', link: '/social' },
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* Welcome */}
      <div>
        <h1 className="text-2xl font-bold text-white">
          Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, {user?.firstName} 👋
        </h1>
        <p className="text-gray-400 mt-1">Here's what's happening with your business today.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {statCards.map(card => (
          <StatCard key={card.label} {...card} navigate={navigate} isLoading={isLoading} />
        ))}
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {quickActions.map(action => (
            <button
              key={action.label}
              onClick={() => navigate(action.path)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl border ${action.color} hover:opacity-80 transition-all text-sm font-medium text-left`}
            >
              <action.icon size={16} />
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Module overview */}
      <div>
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">All Modules</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {[
            { label: 'Funnels & Pages', desc: 'Build landing pages & funnels', path: '/funnels', color: 'from-indigo-500/10' },
            { label: 'Forms & Surveys', desc: 'Capture leads with forms', path: '/forms', color: 'from-violet-500/10' },
            { label: 'Live Chat', desc: 'Real-time visitor chat', path: '/chat', color: 'from-emerald-500/10' },
            { label: 'Invoices', desc: 'Billing & payments', path: '/invoices', color: 'from-amber-500/10' },
            { label: 'Social Media', desc: 'Schedule & publish posts', path: '/social', color: 'from-pink-500/10' },
            { label: 'Reputation', desc: 'Monitor & respond to reviews', path: '/reputation', color: 'from-yellow-500/10' },
            { label: 'WhatsApp', desc: 'Two-way WhatsApp messaging', path: '/whatsapp', color: 'from-green-500/10' },
            { label: 'Facebook/IG DMs', desc: 'Meta platform messaging', path: '/meta-dms', color: 'from-blue-500/10' },
            { label: 'Calendar', desc: 'Events & booking pages', path: '/calendar', color: 'from-cyan-500/10' },
            { label: 'Documents', desc: 'Docs & e-signatures', path: '/documents', color: 'from-orange-500/10' },
            { label: 'Google Business', desc: 'GBP posts & updates', path: '/gbp', color: 'from-red-500/10' },
            { label: 'Courses', desc: 'Membership & course builder', path: '/membership', color: 'from-purple-500/10' },
            { label: 'A/B Testing', desc: 'Split test everything', path: '/ab-testing', color: 'from-teal-500/10' },
            { label: 'Proposals', desc: 'Quotes & e-sign proposals', path: '/proposals', color: 'from-sky-500/10' },
            { label: 'Affiliates', desc: 'Referral & commission tracking', path: '/affiliates', color: 'from-lime-500/10' },
            { label: 'Blog Builder', desc: 'SEO content publishing', path: '/blog', color: 'from-fuchsia-500/10' },
            { label: 'Communities', desc: 'Forums & community spaces', path: '/communities', color: 'from-rose-500/10' },
          ].map(mod => (
            <button
              key={mod.label}
              onClick={() => navigate(mod.path)}
              className={`text-left p-4 bg-gradient-to-br ${mod.color} to-transparent bg-gray-900 border border-gray-800 rounded-xl hover:border-gray-600 transition-all group`}
            >
              <p className="font-medium text-white text-sm">{mod.label}</p>
              <p className="text-xs text-gray-500 mt-0.5">{mod.desc}</p>
              <ArrowRight size={12} className="text-gray-600 group-hover:text-indigo-400 mt-2 transition-colors" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
