export { ProposalsPage as default } from './AllPages';
