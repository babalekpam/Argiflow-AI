export { BlogPage as default } from './AllPages';
