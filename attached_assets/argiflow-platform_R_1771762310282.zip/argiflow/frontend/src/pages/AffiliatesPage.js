export { AffiliatesPage as default } from './AllPages';
