export { FormsPage as default } from './AllPages';
