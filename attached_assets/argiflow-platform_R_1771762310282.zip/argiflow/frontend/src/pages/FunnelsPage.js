export { FunnelsPage as default } from './AllPages';
