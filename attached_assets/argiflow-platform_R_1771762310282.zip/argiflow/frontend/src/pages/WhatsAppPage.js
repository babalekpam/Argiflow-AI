export { WhatsAppPage as default } from './AllPages';
