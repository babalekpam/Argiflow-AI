export { SocialPage as default } from './AllPages';
