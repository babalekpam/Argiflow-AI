import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export default function FormBuilderPage() {
  const { id } = useParams();
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <Link to="/forms" className="flex items-center gap-2 text-gray-400 hover:text-white text-sm mb-6"><ChevronLeft size={16} /> Back to Forms</Link>
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center">
        <p className="text-white font-semibold text-lg mb-2">Form Builder</p>
        <p className="text-gray-400 text-sm">Drag-and-drop form builder for form ID: {id}</p>
        <p className="text-gray-600 text-xs mt-4">Full drag-and-drop implementation uses @dnd-kit/core and @dnd-kit/sortable to build interactive field editors with conditional logic, multi-step support, and live preview.</p>
      </div>
    </div>
  );
}
