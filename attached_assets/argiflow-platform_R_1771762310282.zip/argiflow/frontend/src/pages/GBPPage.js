export { GBPPage as default } from './AllPages';
