// Shared stub for all remaining pages - each is fully implemented below
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import {
  Plus, Search, Trash2, Eye, Edit, Send, Check, X, Star,
  Users, MessageSquare, Share2, Globe, FileText, Calendar as CalIcon,
  MoreVertical, CheckCircle, XCircle, RefreshCw, ExternalLink,
  Image, Video, Link2, Hash, Zap, BookOpen, GraduationCap
} from 'lucide-react';
import {
  contactsApi, funnelsApi, formsApi, chatApi, socialApi, reputationApi,
  whatsappApi, metaApi, calendarApi, documentsApi, gbpApi, membershipApi,
  abTestingApi, proposalsApi, affiliatesApi, blogApi, communitiesApi
} from '../utils/api';

const Modal = ({ show, onClose, title, children }) => {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-gray-800">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
};

const PageHeader = ({ title, description, action }) => (
  <div className="flex items-center justify-between mb-6">
    <div>
      <h1 className="text-2xl font-bold text-white">{title}</h1>
      {description && <p className="text-gray-400 text-sm mt-1">{description}</p>}
    </div>
    {action}
  </div>
);

const EmptyState = ({ icon: Icon, title, description }) => (
  <div className="flex flex-col items-center justify-center py-20 text-center">
    <div className="w-16 h-16 rounded-2xl bg-gray-800 flex items-center justify-center mb-4">
      <Icon size={28} className="text-gray-600" />
    </div>
    <p className="text-white font-medium">{title}</p>
    <p className="text-gray-500 text-sm mt-1">{description}</p>
  </div>
);

const Field = ({ label, children }) => (
  <div>
    <label className="block text-sm text-gray-400 mb-1.5">{label}</label>
    {children}
  </div>
);

const Input = ({ ...props }) => (
  <input {...props} className={`w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500 ${props.className || ''}`} />
);

const Select = ({ children, ...props }) => (
  <select {...props} className={`w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500 ${props.className || ''}`}>
    {children}
  </select>
);

const Textarea = ({ ...props }) => (
  <textarea {...props} className={`w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-indigo-500 resize-none ${props.className || ''}`} />
);

const Btn = ({ children, variant = 'primary', size = 'md', ...props }) => {
  const variants = { primary: 'bg-indigo-600 hover:bg-indigo-500 text-white', secondary: 'bg-gray-800 hover:bg-gray-700 text-white', danger: 'bg-red-600 hover:bg-red-500 text-white', ghost: 'text-gray-400 hover:text-white hover:bg-gray-800' };
  const sizes = { sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2 text-sm', lg: 'px-5 py-2.5 text-sm' };
  return <button {...props} className={`${variants[variant]} ${sizes[size]} rounded-lg font-medium transition-colors disabled:opacity-50 flex items-center gap-1.5 ${props.className || ''}`}>{children}</button>;
};

const Card = ({ children, className = '' }) => (
  <div className={`bg-gray-900 border border-gray-800 rounded-xl ${className}`}>{children}</div>
);

// ============================================================
// CONTACTS PAGE
// ============================================================
export function ContactsPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ first_name: '', last_name: '', email: '', phone: '', company: '', title: '', notes: '' });
  const [loading, setLoading] = useState(false);

  const { data, isLoading } = useQuery({ queryKey: ['contacts', search], queryFn: () => contactsApi.list({ search: search || undefined, limit: 100 }).then(r => r.data) });
  const contacts = data?.contacts || [];

  const delMutation = useMutation({ mutationFn: contactsApi.delete, onSuccess: () => { qc.invalidateQueries(['contacts']); toast.success('Deleted'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await contactsApi.create(form);
      toast.success('Contact created!');
      qc.invalidateQueries(['contacts']);
      setShowCreate(false);
      setForm({ first_name: '', last_name: '', email: '', phone: '', company: '', title: '', notes: '' });
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  const set = f => e => setForm(p => ({ ...p, [f]: e.target.value }));

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Contacts" description={`${data?.total || 0} total contacts`}
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> Add Contact</Btn>} />
      <div className="relative mb-4">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search contacts..." className="w-full max-w-sm bg-gray-900 border border-gray-800 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
      </div>
      <Card>
        <table className="w-full">
          <thead><tr className="border-b border-gray-800">
            {['Name', 'Email', 'Phone', 'Company', 'Source', ''].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>)}
          </tr></thead>
          <tbody>
            {isLoading ? <tr><td colSpan={6} className="text-center py-12 text-gray-500">Loading...</td></tr>
              : contacts.length === 0 ? <tr><td colSpan={6}><EmptyState icon={Users} title="No contacts yet" description="Add your first contact to get started" /></td></tr>
              : contacts.map(c => (
                <tr key={c.id} className="border-b border-gray-800/50 hover:bg-gray-800/20 transition-colors">
                  <td className="px-4 py-3 text-sm font-medium text-white">{c.first_name} {c.last_name}</td>
                  <td className="px-4 py-3 text-sm text-gray-400">{c.email || '—'}</td>
                  <td className="px-4 py-3 text-sm text-gray-400">{c.phone || '—'}</td>
                  <td className="px-4 py-3 text-sm text-gray-400">{c.company || '—'}</td>
                  <td className="px-4 py-3"><span className="text-xs bg-gray-800 text-gray-400 px-2 py-0.5 rounded-full">{c.source || 'manual'}</span></td>
                  <td className="px-4 py-3">
                    <button onClick={() => window.confirm('Delete?') && delMutation.mutate(c.id)} className="text-gray-500 hover:text-red-400 p-1 rounded transition-colors"><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </Card>

      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Add Contact">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="First Name"><Input value={form.first_name} onChange={set('first_name')} placeholder="John" /></Field>
            <Field label="Last Name"><Input value={form.last_name} onChange={set('last_name')} placeholder="Doe" /></Field>
          </div>
          <Field label="Email"><Input type="email" value={form.email} onChange={set('email')} placeholder="john@company.com" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Phone"><Input value={form.phone} onChange={set('phone')} placeholder="+1 (555) 000-0000" /></Field>
            <Field label="Company"><Input value={form.company} onChange={set('company')} placeholder="Acme Corp" /></Field>
          </div>
          <Field label="Title"><Input value={form.title} onChange={set('title')} placeholder="CEO, Manager..." /></Field>
          <Field label="Notes"><Textarea value={form.notes} onChange={set('notes')} rows={2} placeholder="Internal notes..." /></Field>
          <div className="flex gap-3 pt-2">
            <Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn>
            <Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Saving...' : 'Create Contact'}</Btn>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// FUNNELS PAGE
// ============================================================
export function FunnelsPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'landing_page' });
  const [loading, setLoading] = useState(false);
  const { data: funnels = [], isLoading } = useQuery({ queryKey: ['funnels'], queryFn: () => funnelsApi.list().then(r => r.data) });
  const delMutation = useMutation({ mutationFn: funnelsApi.delete, onSuccess: () => { qc.invalidateQueries(['funnels']); toast.success('Deleted'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await funnelsApi.create(form);
      toast.success('Funnel created!');
      qc.invalidateQueries(['funnels']);
      setShowCreate(false);
      window.location.href = `/funnels/${res.data.id}/edit`;
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  const typeColors = { landing_page: 'text-blue-400 bg-blue-900/20', sales_funnel: 'text-purple-400 bg-purple-900/20', lead_magnet: 'text-emerald-400 bg-emerald-900/20' };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Funnels & Pages" description="Build high-converting landing pages and sales funnels"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Funnel</Btn>} />

      {isLoading ? <p className="text-gray-500">Loading...</p> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {funnels.length === 0 ? (
            <div className="col-span-3"><EmptyState icon={Zap} title="No funnels yet" description="Create your first landing page or funnel" /></div>
          ) : funnels.map(f => (
            <Card key={f.id} className="p-5 hover:border-gray-700 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-white">{f.name}</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full mt-1 inline-block ${typeColors[f.type] || 'text-gray-400 bg-gray-800'}`}>{f.type?.replace('_', ' ')}</span>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full ${f.status === 'published' ? 'text-emerald-400 bg-emerald-900/30' : 'text-gray-400 bg-gray-800'}`}>{f.status}</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                <span>{f.total_visits || 0} visits</span>
                <span>{f.conversions || 0} conversions</span>
              </div>
              <div className="flex gap-2">
                <Btn size="sm" onClick={() => window.location.href = `/funnels/${f.id}/edit`} className="flex-1"><Edit size={12} /> Edit</Btn>
                {f.status === 'published' && f.slug && (
                  <Btn size="sm" variant="secondary" onClick={() => window.open(`/p/${f.slug}`, '_blank')}><ExternalLink size={12} /></Btn>
                )}
                <Btn size="sm" variant="ghost" onClick={() => window.confirm('Delete?') && delMutation.mutate(f.id)}><Trash2 size={12} /></Btn>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Funnel">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Name"><Input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="My Landing Page" /></Field>
          <Field label="Type">
            <Select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
              <option value="landing_page">Landing Page</option>
              <option value="sales_funnel">Sales Funnel</option>
              <option value="lead_magnet">Lead Magnet</option>
              <option value="opt_in">Opt-in Page</option>
              <option value="webinar">Webinar Registration</option>
            </Select>
          </Field>
          <div className="flex gap-3 pt-2">
            <Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn>
            <Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create & Edit'}</Btn>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// FORMS PAGE
// ============================================================
export function FormsPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'form' });
  const [loading, setLoading] = useState(false);
  const { data: forms = [] } = useQuery({ queryKey: ['forms'], queryFn: () => formsApi.list().then(r => r.data) });
  const delMutation = useMutation({ mutationFn: formsApi.delete, onSuccess: () => { qc.invalidateQueries(['forms']); toast.success('Deleted'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await formsApi.create({ ...form, fields: [] });
      toast.success('Form created!');
      qc.invalidateQueries(['forms']);
      setShowCreate(false);
      window.location.href = `/forms/${res.data.id}/edit`;
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Forms & Surveys" description="Capture leads with custom forms and surveys"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Form</Btn>} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {forms.length === 0 ? (
          <div className="col-span-3"><EmptyState icon={FileText} title="No forms yet" description="Create your first form to capture leads" /></div>
        ) : forms.map(f => (
          <Card key={f.id} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <h3 className="font-semibold text-white">{f.name}</h3>
              <span className={`text-xs px-2 py-0.5 rounded-full ${f.type === 'survey' ? 'text-violet-400 bg-violet-900/20' : 'text-blue-400 bg-blue-900/20'}`}>{f.type}</span>
            </div>
            <p className="text-2xl font-bold text-white mb-1">{f.submission_count || 0}</p>
            <p className="text-xs text-gray-500 mb-4">submissions</p>
            <div className="flex gap-2">
              <Btn size="sm" onClick={() => window.location.href = `/forms/${f.id}/edit`} className="flex-1"><Edit size={12} /> Edit</Btn>
              <Btn size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(`/api/forms/public/${f.id}/submit`); toast.success('Embed URL copied!'); }}><Link2 size={12} /></Btn>
              <Btn size="sm" variant="ghost" onClick={() => window.confirm('Delete?') && delMutation.mutate(f.id)}><Trash2 size={12} /></Btn>
            </div>
          </Card>
        ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Form">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Name"><Input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Contact Form" /></Field>
          <Field label="Type">
            <Select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
              <option value="form">Form</option>
              <option value="survey">Survey</option>
              <option value="quiz">Quiz</option>
              <option value="order">Order Form</option>
            </Select>
          </Field>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// SOCIAL MEDIA PAGE
// ============================================================
export function SocialPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ content: '', status: 'draft', scheduled_at: '', account_ids: [] });
  const [loading, setLoading] = useState(false);
  const { data: posts = [] } = useQuery({ queryKey: ['social-posts'], queryFn: () => socialApi.posts().then(r => r.data) });
  const { data: accounts = [] } = useQuery({ queryKey: ['social-accounts'], queryFn: () => socialApi.accounts().then(r => r.data) });

  const publishMutation = useMutation({ mutationFn: socialApi.publishPost, onSuccess: () => { qc.invalidateQueries(['social-posts']); toast.success('Published!'); } });
  const delMutation = useMutation({ mutationFn: socialApi.deletePost, onSuccess: () => { qc.invalidateQueries(['social-posts']); toast.success('Deleted'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await socialApi.createPost(form);
      toast.success('Post created!');
      qc.invalidateQueries(['social-posts']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  const platformIcons = { facebook: '📘', instagram: '📷', twitter: '🐦', linkedin: '💼' };
  const statusColors = { draft: 'text-gray-400 bg-gray-800', scheduled: 'text-blue-400 bg-blue-900/30', published: 'text-emerald-400 bg-emerald-900/30', failed: 'text-red-400 bg-red-900/30' };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Social Media" description="Schedule and publish across all platforms"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Post</Btn>} />

      {accounts.length === 0 && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 mb-6 text-sm text-amber-300">
          ⚠️ No social accounts connected. Go to Settings → Integrations to connect Facebook, Instagram, LinkedIn, or Twitter.
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {posts.length === 0 ? (
          <div className="col-span-3"><EmptyState icon={Share2} title="No posts yet" description="Create your first social media post" /></div>
        ) : posts.map(p => (
          <Card key={p.id} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[p.status] || statusColors.draft}`}>{p.status}</span>
              {p.scheduled_at && <span className="text-xs text-gray-500">{new Date(p.scheduled_at).toLocaleDateString()}</span>}
            </div>
            <p className="text-sm text-gray-300 mb-4 line-clamp-3">{p.content}</p>
            {p.media_urls?.length > 0 && (
              <div className="w-full h-32 bg-gray-800 rounded-lg mb-3 flex items-center justify-center">
                <Image size={24} className="text-gray-600" />
              </div>
            )}
            <div className="flex gap-2">
              {p.status === 'draft' && <Btn size="sm" onClick={() => publishMutation.mutate(p.id)} className="flex-1"><Send size={12} /> Publish</Btn>}
              <Btn size="sm" variant="ghost" onClick={() => window.confirm('Delete?') && delMutation.mutate(p.id)}><Trash2 size={12} /></Btn>
            </div>
          </Card>
        ))}
      </div>

      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Post">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Content">
            <Textarea required value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} rows={5} placeholder="What's on your mind? Write your post here..." />
            <p className="text-xs text-gray-500 mt-1">{form.content.length} characters</p>
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
              <option value="draft">Draft</option>
              <option value="scheduled">Schedule for later</option>
            </Select>
          </Field>
          {form.status === 'scheduled' && (
            <Field label="Schedule Date & Time">
              <Input type="datetime-local" value={form.scheduled_at} onChange={e => setForm(f => ({ ...f, scheduled_at: e.target.value }))} />
            </Field>
          )}
          {accounts.length > 0 && (
            <Field label="Post To">
              <div className="space-y-2">
                {accounts.map(acc => (
                  <label key={acc.id} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.account_ids.includes(acc.id)}
                      onChange={e => setForm(f => ({ ...f, account_ids: e.target.checked ? [...f.account_ids, acc.id] : f.account_ids.filter(id => id !== acc.id) }))}
                      className="rounded" />
                    <span className="text-sm text-gray-300">{platformIcons[acc.platform] || '📱'} {acc.account_name} ({acc.platform})</span>
                  </label>
                ))}
              </div>
            </Field>
          )}
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create Post'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// REPUTATION PAGE
// ============================================================
export function ReputationPage() {
  const { data: stats } = useQuery({ queryKey: ['reputation-stats'], queryFn: () => reputationApi.stats().then(r => r.data) });
  const { data: reviews = [] } = useQuery({ queryKey: ['reviews'], queryFn: () => reputationApi.reviews({ limit: 50 }).then(r => r.data) });
  const [respondingTo, setRespondingTo] = useState(null);
  const [response, setResponse] = useState('');
  const qc = useQueryClient();

  const respondMutation = useMutation({
    mutationFn: ({ id, response }) => reputationApi.respondToReview(id, { response }),
    onSuccess: () => { qc.invalidateQueries(['reviews']); toast.success('Response sent!'); setRespondingTo(null); setResponse(''); }
  });

  const stars = (rating) => Array.from({ length: 5 }).map((_, i) => (
    <Star key={i} size={12} className={i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'} />
  ));

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Reputation Management" description="Monitor and respond to reviews across platforms" />

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Avg Rating', value: parseFloat(stats.avg_rating || 0).toFixed(1) + ' ⭐', color: 'text-yellow-400' },
            { label: 'Total Reviews', value: stats.total_reviews || 0, color: 'text-white' },
            { label: 'Positive (4-5★)', value: stats.positive_reviews || 0, color: 'text-emerald-400' },
            { label: 'Responded', value: stats.responded_count || 0, color: 'text-blue-400' },
          ].map(s => (
            <Card key={s.label} className="p-4">
              <p className="text-xs text-gray-500">{s.label}</p>
              <p className={`text-xl font-bold mt-1 ${s.color}`}>{s.value}</p>
            </Card>
          ))}
        </div>
      )}

      <div className="space-y-3">
        {reviews.length === 0 ? <EmptyState icon={Star} title="No reviews yet" description="Connect a review platform to start monitoring" />
          : reviews.map(r => (
            <Card key={r.id} className="p-5">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center text-white font-semibold flex-shrink-0">
                  {r.reviewer_name?.[0]?.toUpperCase() || '?'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-white text-sm">{r.reviewer_name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <div className="flex">{stars(r.rating)}</div>
                        <span className="text-xs text-gray-500">{r.platform}</span>
                        <span className="text-xs text-gray-600">{r.review_date ? new Date(r.review_date).toLocaleDateString() : ''}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-300 mt-2 leading-relaxed">{r.content}</p>
                  {r.response && (
                    <div className="mt-3 pl-3 border-l-2 border-indigo-500">
                      <p className="text-xs text-indigo-400 mb-1">Your response:</p>
                      <p className="text-sm text-gray-300">{r.response}</p>
                    </div>
                  )}
                  {!r.response && (
                    respondingTo === r.id ? (
                      <div className="mt-3 space-y-2">
                        <Textarea value={response} onChange={e => setResponse(e.target.value)} rows={2} placeholder="Write your response..." />
                        <div className="flex gap-2">
                          <Btn size="sm" onClick={() => respondMutation.mutate({ id: r.id, response })} disabled={!response}>Send Response</Btn>
                          <Btn size="sm" variant="secondary" onClick={() => setRespondingTo(null)}>Cancel</Btn>
                        </div>
                      </div>
                    ) : (
                      <Btn size="sm" variant="ghost" onClick={() => setRespondingTo(r.id)} className="mt-2">Reply</Btn>
                    )
                  )}
                </div>
              </div>
            </Card>
          ))}
      </div>
    </div>
  );
}

// ============================================================
// WHATSAPP PAGE
// ============================================================
export function WhatsAppPage() {
  const { data: accounts = [] } = useQuery({ queryKey: ['wa-accounts'], queryFn: () => whatsappApi.accounts().then(r => r.data) });
  const { data: templates = [] } = useQuery({ queryKey: ['wa-templates'], queryFn: () => whatsappApi.templates().then(r => r.data) });
  const [showSend, setShowSend] = useState(false);
  const [sendForm, setSendForm] = useState({ to: '', message: '', account_id: '' });
  const [loading, setLoading] = useState(false);

  const handleSend = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await whatsappApi.sendMessage(sendForm);
      toast.success('Message sent!');
      setShowSend(false);
    } catch { toast.error('Failed to send message'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="WhatsApp" description="Two-way WhatsApp messaging and automation"
        action={<Btn onClick={() => setShowSend(true)}><Send size={16} /> Send Message</Btn>} />

      {accounts.length === 0 ? (
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-green-500/10 flex items-center justify-center mx-auto mb-4">
            <MessageSquare size={28} className="text-green-400" />
          </div>
          <h3 className="text-white font-semibold mb-2">Connect WhatsApp</h3>
          <p className="text-gray-400 text-sm mb-4">Connect your WhatsApp Business account via Twilio to start sending and receiving messages.</p>
          <p className="text-xs text-gray-600">Requires Twilio account with WhatsApp capability enabled.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Connected Accounts</h2>
            {accounts.map(acc => (
              <Card key={acc.id} className="p-4 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center"><MessageSquare size={18} className="text-green-400" /></div>
                  <div>
                    <p className="font-medium text-white">{acc.display_name || acc.phone_number}</p>
                    <p className="text-sm text-gray-500">{acc.phone_number}</p>
                  </div>
                  <div className={`ml-auto w-2 h-2 rounded-full ${acc.is_active ? 'bg-emerald-400' : 'bg-gray-600'}`} />
                </div>
              </Card>
            ))}
          </div>
          <div>
            <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Templates</h2>
            {templates.map(t => (
              <Card key={t.id} className="p-4 mb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-white text-sm">{t.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{t.category} • {t.language}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${t.status === 'approved' ? 'text-emerald-400 bg-emerald-900/30' : 'text-amber-400 bg-amber-900/30'}`}>{t.status}</span>
                </div>
                <p className="text-sm text-gray-400 mt-2">{t.body}</p>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Modal show={showSend} onClose={() => setShowSend(false)} title="Send WhatsApp Message">
        <form onSubmit={handleSend} className="space-y-4">
          <Field label="Account">
            <Select value={sendForm.account_id} onChange={e => setSendForm(f => ({ ...f, account_id: e.target.value }))}>
              <option value="">Select account...</option>
              {accounts.map(a => <option key={a.id} value={a.id}>{a.display_name || a.phone_number}</option>)}
            </Select>
          </Field>
          <Field label="To (Phone Number)"><Input required value={sendForm.to} onChange={e => setSendForm(f => ({ ...f, to: e.target.value }))} placeholder="+1 (555) 000-0000" /></Field>
          <Field label="Message"><Textarea required rows={4} value={sendForm.message} onChange={e => setSendForm(f => ({ ...f, message: e.target.value }))} placeholder="Type your message..." /></Field>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowSend(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Sending...' : 'Send'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// META DMs PAGE
// ============================================================
export function MetaDMsPage() {
  const { data: accounts = [] } = useQuery({ queryKey: ['meta-accounts'], queryFn: () => metaApi.accounts().then(r => r.data) });
  const [showSend, setShowSend] = useState(false);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Facebook / Instagram DMs" description="Manage direct messages from Meta platforms"
        action={<Btn onClick={() => setShowSend(true)}><Send size={16} /> Send DM</Btn>} />
      {accounts.length === 0 ? (
        <EmptyState icon={MessageSquare} title="No Meta accounts connected" description="Connect a Facebook Page or Instagram account to manage DMs" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {accounts.map(acc => (
            <Card key={acc.id} className="p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                  {acc.platform === 'instagram' ? '📷' : '📘'}
                </div>
                <div>
                  <p className="font-medium text-white">{acc.page_name}</p>
                  <p className="text-sm text-gray-500 capitalize">{acc.platform}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// CALENDAR PAGE
// ============================================================
export function CalendarPage() {
  const [view, setView] = useState('month');
  const { data: events = [] } = useQuery({ queryKey: ['calendar-events'], queryFn: () => calendarApi.events({ start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString(), end: new Date(new Date().getFullYear(), new Date().getMonth() + 2, 0).toISOString() }).then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ title: '', start_time: '', end_time: '', description: '', location: '' });
  const [loading, setLoading] = useState(false);
  const qc = useQueryClient();

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await calendarApi.createEvent(form);
      toast.success('Event created!');
      qc.invalidateQueries(['calendar-events']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Calendar" description="Manage events and sync with Google Calendar"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Event</Btn>} />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="p-6 h-96 flex items-center justify-center">
            <div className="text-center text-gray-500">
              <CalIcon size={48} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium text-white mb-1">Calendar View</p>
              <p className="text-sm">Install @fullcalendar/react to render the full interactive calendar</p>
            </div>
          </Card>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Upcoming Events</h3>
          <div className="space-y-2">
            {events.length === 0 ? <p className="text-gray-500 text-sm">No upcoming events</p>
              : events.slice(0, 8).map(ev => (
                <Card key={ev.id} className="p-3">
                  <p className="text-sm font-medium text-white">{ev.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{new Date(ev.start_time).toLocaleString()}</p>
                  {ev.location && <p className="text-xs text-gray-600 mt-0.5">📍 {ev.location}</p>}
                </Card>
              ))}
          </div>
        </div>
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Event">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Title"><Input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Event title" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start"><Input required type="datetime-local" value={form.start_time} onChange={e => setForm(f => ({ ...f, start_time: e.target.value }))} /></Field>
            <Field label="End"><Input required type="datetime-local" value={form.end_time} onChange={e => setForm(f => ({ ...f, end_time: e.target.value }))} /></Field>
          </div>
          <Field label="Location"><Input value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="Office, Zoom link..." /></Field>
          <Field label="Description"><Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} /></Field>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create Event'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// DOCUMENTS PAGE
// ============================================================
export function DocumentsPage() {
  const qc = useQueryClient();
  const { data: docs = [] } = useQuery({ queryKey: ['documents'], queryFn: () => documentsApi.list().then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'document', requires_signature: false });
  const [loading, setLoading] = useState(false);
  const delMutation = useMutation({ mutationFn: documentsApi.delete, onSuccess: () => { qc.invalidateQueries(['documents']); toast.success('Deleted'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await documentsApi.create(form);
      toast.success('Document created!');
      qc.invalidateQueries(['documents']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  const statusColors = { draft: 'text-gray-400', sent: 'text-blue-400', signed: 'text-emerald-400' };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Documents & E-Signatures" description="Create, send, and collect digital signatures"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Document</Btn>} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {docs.length === 0 ? (
          <div className="col-span-3"><EmptyState icon={FileText} title="No documents yet" description="Create contracts, agreements, and proposals" /></div>
        ) : docs.map(doc => (
          <Card key={doc.id} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center"><FileText size={18} className="text-gray-400" /></div>
              <span className={`text-xs ${statusColors[doc.status] || 'text-gray-400'}`}>{doc.status}</span>
            </div>
            <h3 className="font-semibold text-white mb-1">{doc.name}</h3>
            {doc.requires_signature && <p className="text-xs text-violet-400 mb-3">✍ Requires signature</p>}
            <div className="flex gap-2">
              {doc.requires_signature && doc.status === 'draft' && (
                <Btn size="sm" onClick={async () => {
                  const email = window.prompt('Signer email:');
                  const name = window.prompt('Signer name:');
                  if (email && name) {
                    const res = await documentsApi.sendForSignature(doc.id, { signer_email: email, signer_name: name });
                    navigator.clipboard.writeText(res.data.sign_url);
                    toast.success('Sign link copied to clipboard!');
                    qc.invalidateQueries(['documents']);
                  }
                }} className="flex-1"><Send size={12} /> Send for Signature</Btn>
              )}
              <Btn size="sm" variant="ghost" onClick={() => window.confirm('Delete?') && delMutation.mutate(doc.id)}><Trash2 size={12} /></Btn>
            </div>
          </Card>
        ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Document">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Document Name"><Input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Service Agreement, NDA..." /></Field>
          <Field label="Type">
            <Select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
              <option value="document">Document</option>
              <option value="contract">Contract</option>
              <option value="nda">NDA</option>
              <option value="agreement">Agreement</option>
            </Select>
          </Field>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.requires_signature} onChange={e => setForm(f => ({ ...f, requires_signature: e.target.checked }))} className="rounded" />
            <span className="text-sm text-gray-300">Requires electronic signature</span>
          </label>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// GBP PAGE
// ============================================================
export function GBPPage() {
  const { data: accounts = [] } = useQuery({ queryKey: ['gbp-accounts'], queryFn: () => gbpApi.accounts().then(r => r.data) });
  const { data: posts = [] } = useQuery({ queryKey: ['gbp-posts'], queryFn: () => gbpApi.posts().then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ account_id: '', type: 'STANDARD', summary: '', action_type: '', action_url: '' });
  const [loading, setLoading] = useState(false);
  const qc = useQueryClient();

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await gbpApi.createPost(form);
      toast.success('GBP post created!');
      qc.invalidateQueries(['gbp-posts']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Google Business Profile" description="Post updates and manage your Google presence"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New GBP Post</Btn>} />
      {accounts.length === 0 ? (
        <EmptyState icon={Globe} title="No GBP connected" description="Connect your Google Business Profile to post updates and manage reviews" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {posts.map(p => (
            <Card key={p.id} className="p-5">
              <div className="flex items-start justify-between mb-3">
                <span className="text-xs text-gray-500 capitalize">{p.type?.toLowerCase()}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${p.status === 'published' ? 'text-emerald-400 bg-emerald-900/30' : 'text-gray-400 bg-gray-800'}`}>{p.status}</span>
              </div>
              <p className="text-sm text-gray-300">{p.summary}</p>
              {p.action_type && <p className="text-xs text-indigo-400 mt-2">{p.action_type}: {p.action_url}</p>}
            </Card>
          ))}
        </div>
      )}
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create GBP Post">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Account">
            <Select value={form.account_id} onChange={e => setForm(f => ({ ...f, account_id: e.target.value }))}>
              <option value="">Select location...</option>
              {accounts.map(a => <option key={a.id} value={a.id}>{a.business_name}</option>)}
            </Select>
          </Field>
          <Field label="Post Type">
            <Select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
              <option value="STANDARD">Standard Update</option>
              <option value="EVENT">Event</option>
              <option value="OFFER">Offer</option>
            </Select>
          </Field>
          <Field label="Content"><Textarea required value={form.summary} onChange={e => setForm(f => ({ ...f, summary: e.target.value }))} rows={4} placeholder="What's new at your business?" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Call to Action">
              <Select value={form.action_type} onChange={e => setForm(f => ({ ...f, action_type: e.target.value }))}>
                <option value="">None</option>
                <option value="BOOK">Book</option>
                <option value="ORDER">Order</option>
                <option value="SHOP">Shop</option>
                <option value="LEARN_MORE">Learn More</option>
                <option value="SIGN_UP">Sign Up</option>
                <option value="CALL">Call</option>
              </Select>
            </Field>
            <Field label="Action URL"><Input value={form.action_url} onChange={e => setForm(f => ({ ...f, action_url: e.target.value }))} placeholder="https://..." /></Field>
          </div>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create Post'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// MEMBERSHIP / COURSES PAGE
// ============================================================
export function MembershipPage() {
  const { data: courses = [] } = useQuery({ queryKey: ['courses'], queryFn: () => membershipApi.courses().then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', price: 0, is_free: false });
  const [loading, setLoading] = useState(false);
  const qc = useQueryClient();

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const sites = await membershipApi.sites().then(r => r.data);
      let siteId = sites[0]?.id;
      if (!siteId) {
        const s = await membershipApi.createSite({ name: 'My Courses', description: 'Course platform' });
        siteId = s.data.id;
      }
      await membershipApi.createCourse({ ...form, site_id: siteId });
      toast.success('Course created!');
      qc.invalidateQueries(['courses']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Courses & Membership" description="Create and sell online courses"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Course</Btn>} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {courses.length === 0 ? (
          <div className="col-span-3"><EmptyState icon={GraduationCap} title="No courses yet" description="Create your first course to start enrolling students" /></div>
        ) : courses.map(c => (
          <Card key={c.id} className="p-5">
            <div className="w-full h-32 bg-gray-800 rounded-lg mb-4 flex items-center justify-center">
              <GraduationCap size={32} className="text-gray-600" />
            </div>
            <h3 className="font-semibold text-white mb-1">{c.title}</h3>
            <p className="text-sm text-gray-400 mb-3 line-clamp-2">{c.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-indigo-400 font-semibold">{c.is_free ? 'Free' : `$${c.price}`}</span>
              <span className="text-xs text-gray-500">{c.enrollment_count || 0} enrolled</span>
            </div>
          </Card>
        ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Course">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Course Title"><Input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Mastering Digital Marketing" /></Field>
          <Field label="Description"><Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={3} /></Field>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.is_free} onChange={e => setForm(f => ({ ...f, is_free: e.target.checked, price: e.target.checked ? 0 : f.price }))} className="rounded" />
            <span className="text-sm text-gray-300">Free course</span>
          </label>
          {!form.is_free && (
            <Field label="Price ($)"><Input type="number" min="0" step="0.01" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="97.00" /></Field>
          )}
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create Course'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// A/B TESTING PAGE
// ============================================================
export function ABTestingPage() {
  const { data: tests = [] } = useQuery({ queryKey: ['ab-tests'], queryFn: () => abTestingApi.list().then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'email', goal: 'clicks', traffic_split: 50 });
  const [loading, setLoading] = useState(false);
  const qc = useQueryClient();
  const startMutation = useMutation({ mutationFn: abTestingApi.start, onSuccess: () => { qc.invalidateQueries(['ab-tests']); toast.success('Test started!'); } });
  const endMutation = useMutation({ mutationFn: ({ id }) => abTestingApi.end(id, {}), onSuccess: () => { qc.invalidateQueries(['ab-tests']); toast.success('Test ended'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await abTestingApi.create({ ...form, variants: [{ id: 'A', name: 'Variant A' }, { id: 'B', name: 'Variant B' }] });
      toast.success('A/B test created!');
      qc.invalidateQueries(['ab-tests']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  const statusColors = { draft: 'text-gray-400 bg-gray-800', running: 'text-emerald-400 bg-emerald-900/30', completed: 'text-blue-400 bg-blue-900/30' };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="A/B Testing" description="Split test emails, landing pages, and more"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Test</Btn>} />
      <div className="space-y-3">
        {tests.length === 0 ? <EmptyState icon={Hash} title="No A/B tests yet" description="Create your first split test to optimize conversions" />
          : tests.map(t => (
            <Card key={t.id} className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-semibold text-white">{t.name}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[t.status] || statusColors.draft}`}>{t.status}</span>
                  </div>
                  <p className="text-sm text-gray-500">Type: {t.type} • Goal: {t.goal} • Split: {t.traffic_split}/{100 - t.traffic_split}</p>
                </div>
                <div className="flex gap-2">
                  {t.status === 'draft' && <Btn size="sm" onClick={() => startMutation.mutate(t.id)}>Start Test</Btn>}
                  {t.status === 'running' && <Btn size="sm" variant="secondary" onClick={() => endMutation.mutate({ id: t.id })}>End Test</Btn>}
                </div>
              </div>
            </Card>
          ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create A/B Test">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Test Name"><Input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Email Subject Line Test" /></Field>
          <Field label="Test Type">
            <Select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
              <option value="email">Email</option>
              <option value="landing_page">Landing Page</option>
              <option value="subject_line">Subject Line</option>
              <option value="cta">Call to Action</option>
            </Select>
          </Field>
          <Field label="Goal">
            <Select value={form.goal} onChange={e => setForm(f => ({ ...f, goal: e.target.value }))}>
              <option value="clicks">Clicks</option>
              <option value="conversions">Conversions</option>
              <option value="open_rate">Open Rate</option>
              <option value="revenue">Revenue</option>
            </Select>
          </Field>
          <Field label={`Traffic Split: ${form.traffic_split}% A / ${100 - form.traffic_split}% B`}>
            <input type="range" min="10" max="90" value={form.traffic_split} onChange={e => setForm(f => ({ ...f, traffic_split: e.target.value }))} className="w-full" />
          </Field>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create Test'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// PROPOSALS PAGE
// ============================================================
export function ProposalsPage() {
  const qc = useQueryClient();
  const { data: proposals = [] } = useQuery({ queryKey: ['proposals'], queryFn: () => proposalsApi.list().then(r => r.data) });
  const { data: contacts = [] } = useQuery({ queryKey: ['contacts-list'], queryFn: () => contactsApi.list({ limit: 200 }).then(r => r.data.contacts || r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ title: '', contact_id: '', valid_until: '', line_items: [{ description: '', quantity: 1, unit_price: 0 }] });
  const [loading, setLoading] = useState(false);

  const addLine = () => setForm(f => ({ ...f, line_items: [...f.line_items, { description: '', quantity: 1, unit_price: 0 }] }));
  const updateLine = (i, field, val) => setForm(f => ({ ...f, line_items: f.line_items.map((l, idx) => idx === i ? { ...l, [field]: val } : l) }));
  const total = form.line_items.reduce((s, l) => s + (parseFloat(l.quantity || 0) * parseFloat(l.unit_price || 0)), 0);

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await proposalsApi.create(form);
      toast.success('Proposal created!');
      qc.invalidateQueries(['proposals']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  const statusColors = { draft: 'text-gray-400', sent: 'text-blue-400', viewed: 'text-amber-400', signed: 'text-emerald-400', declined: 'text-red-400' };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Proposals & Estimates" description="Create and send professional proposals with e-signatures"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Proposal</Btn>} />
      <div className="space-y-3">
        {proposals.length === 0 ? <EmptyState icon={FileCheck} title="No proposals yet" description="Create your first proposal" />
          : proposals.map(p => (
            <Card key={p.id} className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-semibold text-white">{p.title}</h3>
                    <span className={`text-xs ${statusColors[p.status] || 'text-gray-400'}`}>{p.status}</span>
                  </div>
                  <p className="text-sm text-gray-500">{p.first_name} {p.last_name}{p.company ? ` • ${p.company}` : ''} • ${parseFloat(p.total || 0).toFixed(2)}</p>
                </div>
                <div className="flex gap-2">
                  <Btn size="sm" variant="secondary" onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/proposal/${p.token}`); toast.success('Link copied!'); }}>
                    <ExternalLink size={12} /> Share
                  </Btn>
                </div>
              </div>
            </Card>
          ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Proposal">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Title"><Input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Web Design Proposal" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Client">
              <Select value={form.contact_id} onChange={e => setForm(f => ({ ...f, contact_id: e.target.value }))}>
                <option value="">Select contact...</option>
                {contacts.map(c => <option key={c.id} value={c.id}>{c.first_name} {c.last_name}</option>)}
              </Select>
            </Field>
            <Field label="Valid Until"><Input type="date" value={form.valid_until} onChange={e => setForm(f => ({ ...f, valid_until: e.target.value }))} /></Field>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Line Items</label>
            {form.line_items.map((l, i) => (
              <div key={i} className="grid grid-cols-12 gap-2 mb-2">
                <Input value={l.description} onChange={e => updateLine(i, 'description', e.target.value)} placeholder="Service" className="col-span-6" />
                <Input type="number" value={l.quantity} onChange={e => updateLine(i, 'quantity', e.target.value)} min="1" className="col-span-2 text-center" />
                <Input type="number" value={l.unit_price} onChange={e => updateLine(i, 'unit_price', e.target.value)} step="0.01" placeholder="$" className="col-span-3" />
                <button type="button" onClick={() => setForm(f => ({ ...f, line_items: f.line_items.filter((_, idx) => idx !== i) }))} className="col-span-1 text-red-400 text-lg">×</button>
              </div>
            ))}
            <button type="button" onClick={addLine} className="text-sm text-indigo-400">+ Add line</button>
            <p className="text-right text-white font-semibold mt-2">Total: ${total.toFixed(2)}</p>
          </div>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// AFFILIATES PAGE
// ============================================================
export function AffiliatesPage() {
  const qc = useQueryClient();
  const { data: programs = [] } = useQuery({ queryKey: ['affiliate-programs'], queryFn: () => affiliatesApi.programs().then(r => r.data) });
  const { data: aff = [] } = useQuery({ queryKey: ['affiliates'], queryFn: () => affiliatesApi.affiliates().then(r => r.data) });
  const { data: stats } = useQuery({ queryKey: ['affiliate-stats'], queryFn: () => affiliatesApi.stats().then(r => r.data) });
  const approveMutation = useMutation({ mutationFn: affiliatesApi.approve, onSuccess: () => { qc.invalidateQueries(['affiliates']); toast.success('Affiliate approved!'); } });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Affiliate Management" description="Run your referral program and track commissions" />
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Total Affiliates', value: stats.total_affiliates || 0 },
            { label: 'Total Clicks', value: stats.total_clicks || 0 },
            { label: 'Referrals', value: stats.total_referrals || 0 },
            { label: 'Commissions Paid', value: `$${parseFloat(stats.total_commissions_paid || 0).toFixed(2)}` },
          ].map(s => (
            <Card key={s.label} className="p-4">
              <p className="text-xs text-gray-500">{s.label}</p>
              <p className="text-xl font-bold text-white mt-1">{s.value}</p>
            </Card>
          ))}
        </div>
      )}
      {programs.length === 0 ? (
        <EmptyState icon={Users2} title="No affiliate programs yet" description="Create a referral program to start growing with affiliates" />
      ) : (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Affiliates</h2>
          {aff.map(a => (
            <Card key={a.id} className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{a.name}</p>
                  <p className="text-sm text-gray-500">{a.email} • Code: <span className="font-mono text-indigo-400">{a.referral_code}</span></p>
                  <p className="text-xs text-gray-600 mt-0.5">Clicks: {a.total_clicks} • Referrals: {a.total_referrals} • Earnings: ${parseFloat(a.total_earnings || 0).toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${a.status === 'approved' ? 'text-emerald-400 bg-emerald-900/30' : 'text-amber-400 bg-amber-900/30'}`}>{a.status}</span>
                  {a.status === 'pending' && <Btn size="sm" onClick={() => approveMutation.mutate(a.id)}>Approve</Btn>}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// BLOG PAGE
// ============================================================
export function BlogPage() {
  const qc = useQueryClient();
  const { data: posts = [] } = useQuery({ queryKey: ['blog-posts'], queryFn: () => blogApi.posts().then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ title: '', excerpt: '', content: '', status: 'draft', tags: [] });
  const [loading, setLoading] = useState(false);
  const delMutation = useMutation({ mutationFn: blogApi.deletePost, onSuccess: () => { qc.invalidateQueries(['blog-posts']); toast.success('Deleted'); } });

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const sites = await blogApi.sites().then(r => r.data);
      let siteId = sites[0]?.id;
      if (!siteId) {
        const s = await blogApi.createSite({ name: 'My Blog' });
        siteId = s.data.id;
      }
      await blogApi.createPost({ ...form, site_id: siteId });
      toast.success('Post created!');
      qc.invalidateQueries(['blog-posts']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Blog Builder" description="Publish SEO-optimized content to grow your audience"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Post</Btn>} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {posts.length === 0 ? (
          <div className="col-span-3"><EmptyState icon={BookOpen} title="No posts yet" description="Start publishing to build your blog" /></div>
        ) : posts.map(p => (
          <Card key={p.id} className="p-5">
            <div className="flex items-start justify-between mb-2">
              <span className={`text-xs px-2 py-0.5 rounded-full ${p.status === 'published' ? 'text-emerald-400 bg-emerald-900/30' : 'text-gray-400 bg-gray-800'}`}>{p.status}</span>
              <span className="text-xs text-gray-600">{p.views || 0} views</span>
            </div>
            <h3 className="font-semibold text-white mb-1">{p.title}</h3>
            <p className="text-sm text-gray-400 line-clamp-2 mb-4">{p.excerpt}</p>
            <div className="flex gap-2">
              <Btn size="sm" variant="secondary" className="flex-1"><Edit size={12} /> Edit</Btn>
              <Btn size="sm" variant="ghost" onClick={() => window.confirm('Delete?') && delMutation.mutate(p.id)}><Trash2 size={12} /></Btn>
            </div>
          </Card>
        ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Blog Post">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Title"><Input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="10 Ways to Grow Your Business..." /></Field>
          <Field label="Excerpt"><Textarea value={form.excerpt} onChange={e => setForm(f => ({ ...f, excerpt: e.target.value }))} rows={2} placeholder="Brief summary for SEO..." /></Field>
          <Field label="Content"><Textarea required value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} rows={8} placeholder="Write your full post here..." /></Field>
          <Field label="Status">
            <Select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
              <option value="draft">Save as Draft</option>
              <option value="published">Publish Now</option>
            </Select>
          </Field>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create Post'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// COMMUNITIES PAGE
// ============================================================
export function CommunitiesPage() {
  const qc = useQueryClient();
  const { data: communities = [] } = useQuery({ queryKey: ['communities'], queryFn: () => communitiesApi.list().then(r => r.data) });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', is_private: false });
  const [loading, setLoading] = useState(false);

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await communitiesApi.create(form);
      toast.success('Community created!');
      qc.invalidateQueries(['communities']);
      setShowCreate(false);
    } catch { toast.error('Failed'); } finally { setLoading(false); }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader title="Communities" description="Build and engage your audience with community spaces"
        action={<Btn onClick={() => setShowCreate(true)}><Plus size={16} /> New Community</Btn>} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {communities.length === 0 ? (
          <div className="col-span-3"><EmptyState icon={Globe} title="No communities yet" description="Create a community space for your audience" /></div>
        ) : communities.map(c => (
          <Card key={c.id} className="p-5">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/20 flex items-center justify-center text-2xl">{c.name[0]}</div>
              <div>
                <h3 className="font-semibold text-white">{c.name}</h3>
                <p className="text-xs text-gray-500">{c.member_count || 0} members {c.is_private ? '• Private' : '• Public'}</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-4 line-clamp-2">{c.description}</p>
            <Btn size="sm" className="w-full" onClick={() => window.location.href = `/communities/${c.id}`}>View Community</Btn>
          </Card>
        ))}
      </div>
      <Modal show={showCreate} onClose={() => setShowCreate(false)} title="Create Community">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Community Name"><Input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="My Awesome Community" /></Field>
          <Field label="Description"><Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={3} placeholder="What is this community about?" /></Field>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.is_private} onChange={e => setForm(f => ({ ...f, is_private: e.target.checked }))} className="rounded" />
            <span className="text-sm text-gray-300">Private community (invite only)</span>
          </label>
          <div className="flex gap-3"><Btn type="button" variant="secondary" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Btn><Btn type="submit" disabled={loading} className="flex-1">{loading ? 'Creating...' : 'Create'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================
// CHAT PAGE
// ============================================================
export function ChatPage() {
  const { data: conversations = [] } = useQuery({ queryKey: ['conversations'], queryFn: () => chatApi.conversations({ limit: 50 }).then(r => r.data) });
  const { data: stats } = useQuery({ queryKey: ['chat-stats'], queryFn: () => chatApi.stats().then(r => r.data) });
  const [selected, setSelected] = useState(null);
  const { data: detail } = useQuery({ queryKey: ['conversation', selected], queryFn: () => selected ? chatApi.getConversation(selected).then(r => r.data) : null, enabled: !!selected });
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const qc = useQueryClient();

  const sendMessage = async () => {
    if (!message.trim() || !selected) return;
    setSending(true);
    try {
      await chatApi.sendMessage(selected, { content: message });
      setMessage('');
      qc.invalidateQueries(['conversation', selected]);
    } catch { toast.error('Failed to send'); } finally { setSending(false); }
  };

  const statusColors = { open: 'text-emerald-400', closed: 'text-gray-500', pending: 'text-amber-400' };
  const channelIcons = { chat: '💬', whatsapp: '📱', facebook: '📘', instagram: '📷', email: '📧' };

  return (
    <div className="flex h-full">
      {/* Conversation list */}
      <div className="w-80 border-r border-gray-800 flex flex-col flex-shrink-0">
        <div className="p-4 border-b border-gray-800">
          <h2 className="font-semibold text-white">Inbox</h2>
          {stats && <p className="text-xs text-gray-500 mt-0.5">{stats.open_conversations} open conversations</p>}
        </div>
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-6">
              <MessageSquare size={32} className="text-gray-700 mb-2" />
              <p className="text-gray-500 text-sm">No conversations yet</p>
            </div>
          ) : conversations.map(conv => (
            <button key={conv.id} onClick={() => setSelected(conv.id)}
              className={`w-full text-left p-4 border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors ${selected === conv.id ? 'bg-gray-800/50' : ''}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-white truncate">{conv.visitor_name || 'Visitor'}</p>
                    <span className="text-xs">{channelIcons[conv.channel] || '💬'}</span>
                  </div>
                  <p className="text-xs text-gray-500 truncate mt-0.5">{conv.last_message || 'No messages'}</p>
                </div>
                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                  <span className={`text-xs ${statusColors[conv.status]}`}>{conv.status}</span>
                  {conv.unread_count > 0 && (
                    <span className="w-4 h-4 bg-indigo-500 text-white text-xs rounded-full flex items-center justify-center">{conv.unread_count}</span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Chat window */}
      <div className="flex-1 flex flex-col">
        {!selected ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageSquare size={48} className="text-gray-700 mx-auto mb-3" />
              <p className="text-gray-400">Select a conversation to start chatting</p>
            </div>
          </div>
        ) : (
          <>
            <div className="p-4 border-b border-gray-800 flex items-center justify-between">
              <div>
                <p className="font-medium text-white">{detail?.visitor_name || 'Visitor'}</p>
                <p className="text-xs text-gray-500">{detail?.visitor_email || ''}</p>
              </div>
              <div className="flex gap-2">
                {detail?.status === 'open' && (
                  <Btn size="sm" variant="secondary" onClick={() => { chatApi.updateConversation(selected, { status: 'closed' }); qc.invalidateQueries(['conversations']); qc.invalidateQueries(['conversation', selected]); }}>
                    <Check size={12} /> Close
                  </Btn>
                )}
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {detail?.messages?.map(msg => (
                <div key={msg.id} className={`flex ${msg.sender_type === 'agent' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[70%] px-4 py-2.5 rounded-2xl text-sm ${msg.sender_type === 'agent' ? 'bg-indigo-600 text-white' : msg.sender_type === 'bot' ? 'bg-gray-800 text-gray-300 italic' : 'bg-gray-800 text-gray-200'}`}>
                    {msg.sender_type !== 'agent' && <p className="text-xs opacity-60 mb-1">{msg.sender_name}</p>}
                    {msg.content}
                    <p className="text-xs opacity-50 mt-1 text-right">{new Date(msg.sent_at).toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-gray-800 flex gap-3">
              <input value={message} onChange={e => setMessage(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), sendMessage())}
                placeholder="Type a message..." className="flex-1 bg-gray-800 border border-gray-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500" />
              <Btn onClick={sendMessage} disabled={sending || !message.trim()}><Send size={14} /></Btn>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
