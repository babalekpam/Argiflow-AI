import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { proposalsApi } from '../../utils/api';
import toast from 'react-hot-toast';

export default function ProposalPage() {
  const { token } = useParams();
  const [proposal, setProposal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [signature, setSignature] = useState('');
  const [signed, setSigned] = useState(false);

  useEffect(() => {
    proposalsApi.getPublic(token).then(r => setProposal(r.data)).finally(() => setLoading(false));
  }, [token]);

  const handleSign = async () => {
    if (!signature) return toast.error('Please enter your name');
    try {
      await proposalsApi.sign(token, { signature, name: signature });
      setSigned(true);
      toast.success('Proposal accepted!');
    } catch { toast.error('Failed'); }
  };

  if (loading) return <div className="min-h-screen bg-gray-950 flex items-center justify-center"><div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" /></div>;
  if (!proposal) return <div className="min-h-screen bg-gray-950 flex items-center justify-center text-white">Proposal not found</div>;

  return (
    <div className="min-h-screen bg-gray-950 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">{proposal.title}</h1>
          <p className="text-gray-400">Prepared for: {proposal.first_name} {proposal.last_name}</p>
          {proposal.valid_until && <p className="text-gray-400 text-sm">Valid until: {new Date(proposal.valid_until).toLocaleDateString()}</p>}
        </div>
        {(proposal.line_items || []).length > 0 && (
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 mb-6">
            <h2 className="text-lg font-semibold text-white mb-4">Investment Summary</h2>
            <table className="w-full text-sm">
              <thead><tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                <th className="text-left pb-2">Description</th>
                <th className="text-right pb-2">Qty</th>
                <th className="text-right pb-2">Unit</th>
                <th className="text-right pb-2">Total</th>
              </tr></thead>
              <tbody>
                {proposal.line_items.map((l, i) => (
                  <tr key={i} className="border-b border-gray-800/50 text-gray-300">
                    <td className="py-3">{l.description}</td>
                    <td className="py-3 text-right">{l.quantity}</td>
                    <td className="py-3 text-right">${parseFloat(l.unit_price).toFixed(2)}</td>
                    <td className="py-3 text-right">${(l.quantity * l.unit_price).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="text-right mt-4">
              <p className="text-2xl font-bold text-white">Total: ${parseFloat(proposal.total || 0).toFixed(2)}</p>
            </div>
          </div>
        )}
        {!signed && !proposal.client_signed_at ? (
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8">
            <h2 className="text-lg font-semibold text-white mb-4">Accept & Sign</h2>
            <input value={signature} onChange={e => setSignature(e.target.value)} placeholder="Type your full name to sign"
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-lg italic focus:outline-none focus:border-indigo-500 mb-4" />
            <button onClick={handleSign} disabled={!signature} className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-semibold py-3 rounded-lg transition-colors">
              Accept Proposal
            </button>
          </div>
        ) : (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-8 text-center">
            <p className="text-emerald-400 text-lg font-semibold">✅ Proposal Accepted</p>
            <p className="text-gray-400 text-sm mt-1">Signed on {proposal.client_signed_at ? new Date(proposal.client_signed_at).toLocaleDateString() : 'today'}</p>
          </div>
        )}
      </div>
    </div>
  );
}
