import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';

export default function SignPage() {
  const { token } = useParams();
  const [doc, setDoc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [signature, setSignature] = useState('');
  const [signed, setSigned] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    // Fetch document details (if public endpoint exists)
    setLoading(false);
  }, [token]);

  const handleSign = async () => {
    if (!signature) return toast.error('Please enter your signature');
    setSubmitting(true);
    try {
      await axios.post(`/api/documents/public/sign/${token}`, { signature_data: signature });
      setSigned(true);
      toast.success('Document signed successfully!');
    } catch { toast.error('Failed to sign document'); } finally { setSubmitting(false); }
  };

  if (signed) return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-4xl">✅</span>
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">Document Signed!</h1>
        <p className="text-gray-400">Your signature has been recorded. You can close this page.</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 max-w-lg w-full">
        <h1 className="text-xl font-bold text-white mb-2">Sign Document</h1>
        <p className="text-gray-400 text-sm mb-6">Please type your full legal name to sign this document electronically.</p>
        <div className="mb-4">
          <label className="block text-sm text-gray-400 mb-1.5">Full Name (Electronic Signature)</label>
          <input value={signature} onChange={e => setSignature(e.target.value)}
            placeholder="Type your full name" className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-lg italic focus:outline-none focus:border-indigo-500" />
        </div>
        <p className="text-xs text-gray-600 mb-6">By clicking "Sign Document", you agree that your typed name constitutes your legal electronic signature.</p>
        <button onClick={handleSign} disabled={submitting || !signature} className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-semibold py-3 rounded-lg transition-colors">
          {submitting ? 'Signing...' : 'Sign Document'}
        </button>
      </div>
    </div>
  );
}
