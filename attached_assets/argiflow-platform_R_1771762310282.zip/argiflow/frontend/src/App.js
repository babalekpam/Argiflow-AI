import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';

// Layout
import DashboardLayout from './components/shared/DashboardLayout';

// Auth pages
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

// Module pages
import DashboardPage from './pages/DashboardPage';
import ContactsPage from './pages/ContactsPage';
import FunnelsPage from './pages/FunnelsPage';
import FunnelEditorPage from './pages/FunnelEditorPage';
import FormsPage from './pages/FormsPage';
import FormBuilderPage from './pages/FormBuilderPage';
import ChatPage from './pages/ChatPage';
import InvoicesPage from './pages/InvoicesPage';
import InvoiceEditorPage from './pages/InvoiceEditorPage';
import SocialPage from './pages/SocialPage';
import ReputationPage from './pages/ReputationPage';
import WhatsAppPage from './pages/WhatsAppPage';
import MetaDMsPage from './pages/MetaDMsPage';
import CalendarPage from './pages/CalendarPage';
import DocumentsPage from './pages/DocumentsPage';
import GBPPage from './pages/GBPPage';
import MembershipPage from './pages/MembershipPage';
import ABTestingPage from './pages/ABTestingPage';
import ProposalsPage from './pages/ProposalsPage';
import AffiliatesPage from './pages/AffiliatesPage';
import BlogPage from './pages/BlogPage';
import CommunitiesPage from './pages/CommunitiesPage';

// Public pages
import PublicSignPage from './pages/public/SignPage';
import PublicProposalPage from './pages/public/ProposalPage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30000, refetchOnWindowFocus: false },
  },
});

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-gray-400 text-sm">Loading ArgiFlow...</p>
      </div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  return children;
};

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <BrowserRouter>
          <Toaster
            position="top-right"
            toastOptions={{
              style: { background: '#1f2937', color: '#f9fafb', border: '1px solid #374151' },
              success: { iconTheme: { primary: '#10b981', secondary: '#fff' } },
              error: { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
            }}
          />
          <Routes>
            {/* Public */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/sign/:token" element={<PublicSignPage />} />
            <Route path="/proposal/:token" element={<PublicProposalPage />} />

            {/* Protected */}
            <Route path="/" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<DashboardPage />} />
              <Route path="contacts" element={<ContactsPage />} />
              <Route path="funnels" element={<FunnelsPage />} />
              <Route path="funnels/:id/edit" element={<FunnelEditorPage />} />
              <Route path="forms" element={<FormsPage />} />
              <Route path="forms/:id/edit" element={<FormBuilderPage />} />
              <Route path="chat" element={<ChatPage />} />
              <Route path="invoices" element={<InvoicesPage />} />
              <Route path="invoices/:id/edit" element={<InvoiceEditorPage />} />
              <Route path="social" element={<SocialPage />} />
              <Route path="reputation" element={<ReputationPage />} />
              <Route path="whatsapp" element={<WhatsAppPage />} />
              <Route path="meta-dms" element={<MetaDMsPage />} />
              <Route path="calendar" element={<CalendarPage />} />
              <Route path="documents" element={<DocumentsPage />} />
              <Route path="gbp" element={<GBPPage />} />
              <Route path="membership" element={<MembershipPage />} />
              <Route path="ab-testing" element={<ABTestingPage />} />
              <Route path="proposals" element={<ProposalsPage />} />
              <Route path="affiliates" element={<AffiliatesPage />} />
              <Route path="blog" element={<BlogPage />} />
              <Route path="communities" element={<CommunitiesPage />} />
            </Route>

            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
