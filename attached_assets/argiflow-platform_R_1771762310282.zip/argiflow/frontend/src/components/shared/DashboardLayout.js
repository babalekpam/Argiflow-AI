import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard, Users, Funnel, FileText, MessageSquare, Receipt,
  Share2, Star, MessageCircle, Facebook, Calendar, File, MapPin,
  GraduationCap, TestTube, FileCheck, Users2, BookOpen, Globe,
  ChevronLeft, ChevronRight, Bell, Settings, LogOut, ChevronDown,
  Zap, Menu, X
} from 'lucide-react';

const navGroups = [
  {
    label: 'Main',
    items: [
      { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
      { path: '/contacts', icon: Users, label: 'Contacts' },
    ]
  },
  {
    label: 'Capture',
    items: [
      { path: '/funnels', icon: Funnel, label: 'Funnels & Pages' },
      { path: '/forms', icon: FileText, label: 'Forms & Surveys' },
      { path: '/chat', icon: MessageSquare, label: 'Live Chat' },
    ]
  },
  {
    label: 'Revenue',
    items: [
      { path: '/invoices', icon: Receipt, label: 'Invoices & Payments' },
      { path: '/proposals', icon: FileCheck, label: 'Proposals' },
      { path: '/affiliates', icon: Users2, label: 'Affiliates' },
    ]
  },
  {
    label: 'Publish',
    items: [
      { path: '/social', icon: Share2, label: 'Social Media' },
      { path: '/blog', icon: BookOpen, label: 'Blog Builder' },
      { path: '/gbp', icon: MapPin, label: 'Google Business' },
    ]
  },
  {
    label: 'Messaging',
    items: [
      { path: '/whatsapp', icon: MessageCircle, label: 'WhatsApp' },
      { path: '/meta-dms', icon: Facebook, label: 'FB / IG DMs' },
    ]
  },
  {
    label: 'Manage',
    items: [
      { path: '/reputation', icon: Star, label: 'Reputation' },
      { path: '/calendar', icon: Calendar, label: 'Calendar' },
      { path: '/documents', icon: File, label: 'Documents' },
    ]
  },
  {
    label: 'Grow',
    items: [
      { path: '/membership', icon: GraduationCap, label: 'Courses & Members' },
      { path: '/communities', icon: Globe, label: 'Communities' },
      { path: '/ab-testing', icon: TestTube, label: 'A/B Testing' },
    ]
  }
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-gray-900 border-r border-gray-800">
      {/* Logo */}
      <div className={`flex items-center gap-3 px-4 h-16 border-b border-gray-800 flex-shrink-0 ${collapsed ? 'justify-center' : ''}`}>
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center flex-shrink-0">
          <Zap size={16} className="text-white" />
        </div>
        {!collapsed && (
          <div>
            <span className="font-bold text-white text-lg tracking-tight">ArgiFlow</span>
            <p className="text-xs text-gray-500 leading-none">{user?.workspaceName}</p>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-6 scrollbar-thin scrollbar-thumb-gray-700">
        {navGroups.map(group => (
          <div key={group.label}>
            {!collapsed && (
              <p className="px-3 mb-1 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                {group.label}
              </p>
            )}
            <div className="space-y-0.5">
              {group.items.map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 group ${
                      isActive
                        ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                        : 'text-gray-400 hover:text-white hover:bg-gray-800'
                    } ${collapsed ? 'justify-center' : ''}`
                  }
                  title={collapsed ? item.label : undefined}
                >
                  <item.icon size={16} className="flex-shrink-0" />
                  {!collapsed && <span>{item.label}</span>}
                </NavLink>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* User */}
      <div className={`border-t border-gray-800 p-3 flex-shrink-0 ${collapsed ? 'flex flex-col items-center gap-2' : ''}`}>
        {!collapsed ? (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
              {user?.firstName?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.firstName} {user?.lastName}</p>
              <p className="text-xs text-gray-500 truncate">{user?.role}</p>
            </div>
            <button onClick={handleLogout} className="text-gray-500 hover:text-red-400 transition-colors" title="Logout">
              <LogOut size={14} />
            </button>
          </div>
        ) : (
          <>
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-sm font-semibold">
              {user?.firstName?.[0]?.toUpperCase() || 'U'}
            </div>
            <button onClick={handleLogout} className="text-gray-500 hover:text-red-400 transition-colors" title="Logout">
              <LogOut size={14} />
            </button>
          </>
        )}
      </div>

      {/* Collapse toggle - desktop */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 bg-gray-800 border border-gray-700 rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-gray-700 transition-colors z-10 hidden lg:flex"
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-950 text-white overflow-hidden">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar - mobile */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 lg:hidden transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <SidebarContent />
      </div>

      {/* Sidebar - desktop */}
      <div className={`relative hidden lg:flex flex-col flex-shrink-0 transition-all duration-300 ${collapsed ? 'w-16' : 'w-60'}`}>
        <SidebarContent />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-16 border-b border-gray-800 flex items-center px-4 md:px-6 gap-4 flex-shrink-0 bg-gray-900">
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden text-gray-400 hover:text-white"
          >
            <Menu size={20} />
          </button>
          <div className="flex-1" />
          <button className="relative text-gray-400 hover:text-white p-2 rounded-lg hover:bg-gray-800 transition-colors">
            <Bell size={18} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-indigo-500 rounded-full" />
          </button>
          <button
            onClick={() => navigate('/settings')}
            className="text-gray-400 hover:text-white p-2 rounded-lg hover:bg-gray-800 transition-colors"
          >
            <Settings size={18} />
          </button>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto bg-gray-950">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
