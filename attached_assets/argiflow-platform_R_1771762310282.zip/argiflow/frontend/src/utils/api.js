import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor - attach token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('argiflow_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Response interceptor - handle 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('argiflow_token');
      localStorage.removeItem('argiflow_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ===== AUTH =====
export const authApi = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (data) => api.post('/auth/register', data),
  me: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/profile', data),
  changePassword: (data) => api.put('/auth/password', data),
};

// ===== CONTACTS =====
export const contactsApi = {
  list: (params) => api.get('/contacts', { params }),
  create: (data) => api.post('/contacts', data),
  get: (id) => api.get(`/contacts/${id}`),
  update: (id, data) => api.put(`/contacts/${id}`, data),
  delete: (id) => api.delete(`/contacts/${id}`),
  import: (contacts) => api.post('/contacts/import', { contacts }),
};

// ===== FUNNELS =====
export const funnelsApi = {
  list: (params) => api.get('/funnels', { params }),
  create: (data) => api.post('/funnels', data),
  get: (id) => api.get(`/funnels/${id}`),
  update: (id, data) => api.put(`/funnels/${id}`, data),
  delete: (id) => api.delete(`/funnels/${id}`),
  createStep: (id, data) => api.post(`/funnels/${id}/steps`, data),
  updateStep: (id, stepId, data) => api.put(`/funnels/${id}/steps/${stepId}`, data),
  deleteStep: (id, stepId) => api.delete(`/funnels/${id}/steps/${stepId}`),
  getTemplates: () => api.get('/funnels/templates/all'),
  createTemplate: (data) => api.post('/funnels/templates', data),
  analytics: (id) => api.get(`/funnels/${id}/analytics`),
};

// ===== FORMS =====
export const formsApi = {
  list: () => api.get('/forms'),
  create: (data) => api.post('/forms', data),
  get: (id) => api.get(`/forms/${id}`),
  update: (id, data) => api.put(`/forms/${id}`, data),
  delete: (id) => api.delete(`/forms/${id}`),
  submissions: (id, params) => api.get(`/forms/${id}/submissions`, { params }),
  analytics: (id) => api.get(`/forms/${id}/analytics`),
};

// ===== CHAT =====
export const chatApi = {
  widgets: () => api.get('/chat/widgets'),
  createWidget: (data) => api.post('/chat/widgets', data),
  updateWidget: (id, data) => api.put(`/chat/widgets/${id}`, data),
  deleteWidget: (id) => api.delete(`/chat/widgets/${id}`),
  conversations: (params) => api.get('/chat/conversations', { params }),
  getConversation: (id) => api.get(`/chat/conversations/${id}`),
  updateConversation: (id, data) => api.put(`/chat/conversations/${id}`, data),
  sendMessage: (id, data) => api.post(`/chat/conversations/${id}/messages`, data),
  stats: () => api.get('/chat/stats/overview'),
};

// ===== INVOICES =====
export const invoicesApi = {
  list: (params) => api.get('/invoices', { params }),
  create: (data) => api.post('/invoices', data),
  get: (id) => api.get(`/invoices/${id}`),
  update: (id, data) => api.put(`/invoices/${id}`, data),
  delete: (id) => api.delete(`/invoices/${id}`),
  recordPayment: (id, data) => api.post(`/invoices/${id}/payments`, data),
  createPaymentLink: (id) => api.post(`/invoices/${id}/payment-link`),
  stats: () => api.get('/invoices/stats/overview'),
  getSettings: () => api.get('/invoices/settings'),
  updateSettings: (data) => api.put('/invoices/settings', data),
};

// ===== SOCIAL =====
export const socialApi = {
  accounts: () => api.get('/social/accounts'),
  connectAccount: (data) => api.post('/social/accounts/connect', data),
  removeAccount: (id) => api.delete(`/social/accounts/${id}`),
  posts: (params) => api.get('/social/posts', { params }),
  createPost: (data) => api.post('/social/posts', data),
  updatePost: (id, data) => api.put(`/social/posts/${id}`, data),
  deletePost: (id) => api.delete(`/social/posts/${id}`),
  publishPost: (id) => api.post(`/social/posts/${id}/publish`),
  calendar: (params) => api.get('/social/calendar', { params }),
  analytics: () => api.get('/social/analytics'),
};

// ===== REPUTATION =====
export const reputationApi = {
  platforms: () => api.get('/reputation/platforms'),
  addPlatform: (data) => api.post('/reputation/platforms', data),
  reviews: (params) => api.get('/reputation/reviews', { params }),
  respondToReview: (id, data) => api.post(`/reputation/reviews/${id}/respond`, data),
  sendReviewRequest: (data) => api.post('/reputation/review-requests', data),
  stats: () => api.get('/reputation/stats'),
};

// ===== WHATSAPP =====
export const whatsappApi = {
  accounts: () => api.get('/whatsapp/accounts'),
  addAccount: (data) => api.post('/whatsapp/accounts', data),
  sendMessage: (data) => api.post('/whatsapp/send', data),
  templates: () => api.get('/whatsapp/templates'),
  createTemplate: (data) => api.post('/whatsapp/templates', data),
};

// ===== META (FB/IG) =====
export const metaApi = {
  accounts: () => api.get('/meta/accounts'),
  addAccount: (data) => api.post('/meta/accounts', data),
  sendDM: (data) => api.post('/meta/send', data),
};

// ===== CALENDAR =====
export const calendarApi = {
  calendars: () => api.get('/calendar/calendars'),
  addCalendar: (data) => api.post('/calendar/calendars', data),
  events: (params) => api.get('/calendar/events', { params }),
  createEvent: (data) => api.post('/calendar/events', data),
  updateEvent: (id, data) => api.put(`/calendar/events/${id}`, data),
  deleteEvent: (id) => api.delete(`/calendar/events/${id}`),
  bookingPages: () => api.get('/calendar/booking-pages'),
  createBookingPage: (data) => api.post('/calendar/booking-pages', data),
};

// ===== DOCUMENTS =====
export const documentsApi = {
  list: (params) => api.get('/documents', { params }),
  create: (data) => api.post('/documents', data),
  update: (id, data) => api.put(`/documents/${id}`, data),
  delete: (id) => api.delete(`/documents/${id}`),
  sendForSignature: (id, data) => api.post(`/documents/${id}/send-for-signature`, data),
};

// ===== BLOG =====
export const blogApi = {
  sites: () => api.get('/blog/sites'),
  createSite: (data) => api.post('/blog/sites', data),
  posts: (params) => api.get('/blog/posts', { params }),
  createPost: (data) => api.post('/blog/posts', data),
  updatePost: (id, data) => api.put(`/blog/posts/${id}`, data),
  deletePost: (id) => api.delete(`/blog/posts/${id}`),
  categories: (siteId) => api.get(`/blog/categories/${siteId}`),
  createCategory: (data) => api.post('/blog/categories', data),
};

// ===== COMMUNITIES =====
export const communitiesApi = {
  list: () => api.get('/communities'),
  create: (data) => api.post('/communities', data),
  get: (id) => api.get(`/communities/${id}`),
  posts: (id, channelId) => api.get(`/communities/${id}/channels/${channelId}/posts`),
  createPost: (id, channelId, data) => api.post(`/communities/${id}/channels/${channelId}/posts`, data),
};

// ===== A/B TESTING =====
export const abTestingApi = {
  list: () => api.get('/ab-tests'),
  create: (data) => api.post('/ab-tests', data),
  start: (id) => api.put(`/ab-tests/${id}/start`),
  end: (id, data) => api.put(`/ab-tests/${id}/end`, data),
  results: (id) => api.get(`/ab-tests/${id}/results`),
};

// ===== PROPOSALS =====
export const proposalsApi = {
  list: () => api.get('/proposals'),
  create: (data) => api.post('/proposals', data),
  update: (id, data) => api.put(`/proposals/${id}`, data),
  getPublic: (token) => api.get(`/proposals/public/${token}`),
  sign: (token, data) => api.post(`/proposals/public/${token}/sign`, data),
};

// ===== AFFILIATES =====
export const affiliatesApi = {
  programs: () => api.get('/affiliates/programs'),
  createProgram: (data) => api.post('/affiliates/programs', data),
  affiliates: () => api.get('/affiliates/affiliates'),
  addAffiliate: (data) => api.post('/affiliates/affiliates', data),
  approve: (id) => api.put(`/affiliates/affiliates/${id}/approve`),
  stats: () => api.get('/affiliates/stats'),
};

// ===== MEMBERSHIP =====
export const membershipApi = {
  sites: () => api.get('/membership/sites'),
  createSite: (data) => api.post('/membership/sites', data),
  courses: (params) => api.get('/membership/courses', { params }),
  createCourse: (data) => api.post('/membership/courses', data),
  getCourse: (id) => api.get(`/membership/courses/${id}`),
  addSection: (courseId, data) => api.post(`/membership/courses/${courseId}/sections`, data),
  addLesson: (sectionId, data) => api.post(`/membership/sections/${sectionId}/lessons`, data),
};

// ===== GBP =====
export const gbpApi = {
  accounts: () => api.get('/gbp/accounts'),
  addAccount: (data) => api.post('/gbp/accounts', data),
  posts: () => api.get('/gbp/posts'),
  createPost: (data) => api.post('/gbp/posts', data),
};

// ===== DASHBOARD =====
export const dashboardApi = {
  stats: () => api.get('/dashboard/stats'),
};

export default api;
