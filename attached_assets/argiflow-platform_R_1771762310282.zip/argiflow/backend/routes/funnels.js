const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

// ===== FUNNELS =====
router.get('/', authenticate, async (req, res) => {
  try {
    const { type, status } = req.query;
    let sql = 'SELECT f.*, COUNT(fv.id) as total_visits, COUNT(DISTINCT CASE WHEN fv.converted THEN fv.visitor_id END) as conversions FROM funnels f LEFT JOIN funnel_steps fs ON fs.funnel_id = f.id LEFT JOIN page_visits fv ON fv.funnel_step_id = fs.id WHERE f.workspace_id = $1';
    const params = [req.workspaceId];
    if (type) { sql += ` AND f.type = $${params.length + 1}`; params.push(type); }
    if (status) { sql += ` AND f.status = $${params.length + 1}`; params.push(status); }
    sql += ' GROUP BY f.id ORDER BY f.created_at DESC';
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', authenticate, async (req, res) => {
  try {
    const { name, type = 'landing_page', settings = {}, seo = {} } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO funnels (workspace_id, name, type, slug, settings, seo) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [req.workspaceId, name, type, slug, JSON.stringify(settings), JSON.stringify(seo)]
    );
    // Create default first step
    await query(
      'INSERT INTO funnel_steps (funnel_id, name, path, page_content, order_index) VALUES ($1,$2,$3,$4,$5)',
      [result.rows[0].id, 'Main Page', '/', JSON.stringify({ sections: [], theme: { primaryColor: '#6366f1', fontFamily: 'Inter' } }), 0]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', authenticate, async (req, res) => {
  try {
    const funnel = await query('SELECT * FROM funnels WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    if (!funnel.rows[0]) return res.status(404).json({ error: 'Not found' });
    const steps = await query('SELECT * FROM funnel_steps WHERE funnel_id=$1 ORDER BY order_index', [req.params.id]);
    res.json({ ...funnel.rows[0], steps: steps.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticate, async (req, res) => {
  try {
    const { name, status, settings, seo, custom_domain } = req.body;
    const result = await query(
      'UPDATE funnels SET name=COALESCE($1,name), status=COALESCE($2,status), settings=COALESCE($3,settings), seo=COALESCE($4,seo), custom_domain=COALESCE($5,custom_domain), updated_at=NOW() WHERE id=$6 AND workspace_id=$7 RETURNING *',
      [name, status, settings ? JSON.stringify(settings) : null, seo ? JSON.stringify(seo) : null, custom_domain, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM funnels WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== FUNNEL STEPS =====
router.post('/:id/steps', authenticate, async (req, res) => {
  try {
    const { name, path, page_content = {}, order_index = 0 } = req.body;
    const result = await query(
      'INSERT INTO funnel_steps (funnel_id, name, path, page_content, order_index) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [req.params.id, name, path, JSON.stringify(page_content), order_index]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id/steps/:stepId', authenticate, async (req, res) => {
  try {
    const { name, page_content, order_index } = req.body;
    const result = await query(
      'UPDATE funnel_steps SET name=COALESCE($1,name), page_content=COALESCE($2,page_content), order_index=COALESCE($3,order_index), updated_at=NOW() WHERE id=$4 AND funnel_id=$5 RETURNING *',
      [name, page_content ? JSON.stringify(page_content) : null, order_index, req.params.stepId, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id/steps/:stepId', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM funnel_steps WHERE id=$1 AND funnel_id=$2', [req.params.stepId, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== TEMPLATES =====
router.get('/templates/all', authenticate, async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM funnel_templates WHERE workspace_id=$1 OR is_global=true ORDER BY created_at DESC',
      [req.workspaceId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/templates', authenticate, async (req, res) => {
  try {
    const { name, category, content } = req.body;
    const result = await query(
      'INSERT INTO funnel_templates (workspace_id, name, category, content) VALUES ($1,$2,$3,$4) RETURNING *',
      [req.workspaceId, name, category, JSON.stringify(content)]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== ANALYTICS =====
router.get('/:id/analytics', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT fs.id, fs.name, fs.path,
        COUNT(pv.id) as visits,
        COUNT(DISTINCT pv.visitor_id) as unique_visitors,
        COUNT(CASE WHEN pv.converted THEN 1 END) as conversions,
        ROUND(100.0 * COUNT(CASE WHEN pv.converted THEN 1 END) / NULLIF(COUNT(pv.id),0), 2) as conversion_rate
       FROM funnel_steps fs
       LEFT JOIN page_visits pv ON pv.funnel_step_id = fs.id
       WHERE fs.funnel_id = $1
       GROUP BY fs.id ORDER BY fs.order_index`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Public tracking endpoint (no auth)
router.post('/public/track', async (req, res) => {
  try {
    const { stepId, visitorId, converted, utm_source, utm_medium, utm_campaign } = req.body;
    await query(
      'INSERT INTO page_visits (funnel_step_id, visitor_id, ip_address, converted, utm_source, utm_medium, utm_campaign) VALUES ($1,$2,$3,$4,$5,$6,$7)',
      [stepId, visitorId, req.ip, converted || false, utm_source, utm_medium, utm_campaign]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
