const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');

router.get('/', authenticate, async (req, res) => {
  try {
    const { search, tags, source, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT * FROM contacts WHERE workspace_id=$1';
    const params = [req.workspaceId];
    if (search) {
      sql += ` AND (first_name ILIKE $${params.length+1} OR last_name ILIKE $${params.length+1} OR email ILIKE $${params.length+1} OR company ILIKE $${params.length+1})`;
      params.push(`%${search}%`);
    }
    if (source) { sql += ` AND source=$${params.length+1}`; params.push(source); }
    sql += ` ORDER BY created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(sql, params);
    const count = await query('SELECT COUNT(*) FROM contacts WHERE workspace_id=$1', [req.workspaceId]);
    res.json({ contacts: result.rows, total: parseInt(count.rows[0].count) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', authenticate, async (req, res) => {
  try {
    const { first_name, last_name, email, phone, company, title, address, city, state, country, zip, tags, source, custom_fields, notes } = req.body;
    const result = await query(
      `INSERT INTO contacts (workspace_id, first_name, last_name, email, phone, company, title, address, city, state, country, zip, tags, source, custom_fields, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
      [req.workspaceId, first_name, last_name, email, phone, company, title, address, city, state, country, zip, tags||[], source, JSON.stringify(custom_fields||{}), notes]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', authenticate, async (req, res) => {
  try {
    const contact = await query('SELECT * FROM contacts WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    if (!contact.rows[0]) return res.status(404).json({ error: 'Not found' });
    // Get activity across modules
    const invoices = await query('SELECT id, invoice_number, total, status, created_at FROM invoices WHERE contact_id=$1 ORDER BY created_at DESC LIMIT 5', [req.params.id]);
    const forms = await query('SELECT fs.form_id, f.name, fs.submitted_at FROM form_submissions fs JOIN forms f ON f.id=fs.form_id WHERE fs.contact_id=$1 ORDER BY fs.submitted_at DESC LIMIT 5', [req.params.id]);
    res.json({ ...contact.rows[0], invoices: invoices.rows, formSubmissions: forms.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticate, async (req, res) => {
  try {
    const { first_name, last_name, email, phone, company, title, tags, notes, custom_fields } = req.body;
    const result = await query(
      `UPDATE contacts SET first_name=COALESCE($1,first_name), last_name=COALESCE($2,last_name), email=COALESCE($3,email), phone=COALESCE($4,phone), company=COALESCE($5,company), title=COALESCE($6,title), tags=COALESCE($7,tags), notes=COALESCE($8,notes), custom_fields=COALESCE($9,custom_fields), updated_at=NOW() WHERE id=$10 AND workspace_id=$11 RETURNING *`,
      [first_name, last_name, email, phone, company, title, tags, notes, custom_fields?JSON.stringify(custom_fields):null, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM contacts WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Bulk import
router.post('/import', authenticate, async (req, res) => {
  try {
    const { contacts } = req.body;
    let imported = 0;
    for (const c of contacts) {
      try {
        await query(
          `INSERT INTO contacts (workspace_id, first_name, last_name, email, phone, company, source) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`,
          [req.workspaceId, c.first_name||'', c.last_name||'', c.email, c.phone||'', c.company||'', 'import']
        );
        imported++;
      } catch (e) { /* skip */ }
    }
    res.json({ imported, total: contacts.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
