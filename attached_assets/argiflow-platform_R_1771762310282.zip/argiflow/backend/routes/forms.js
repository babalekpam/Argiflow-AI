const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');

router.get('/', authenticate, async (req, res) => {
  try {
    const result = await query(
      'SELECT f.*, COUNT(fs.id) as submission_count FROM forms f LEFT JOIN form_submissions fs ON fs.form_id = f.id WHERE f.workspace_id=$1 GROUP BY f.id ORDER BY f.created_at DESC',
      [req.workspaceId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', authenticate, async (req, res) => {
  try {
    const { name, type = 'form', fields = [], settings = {}, styling = {}, redirect_url, success_message, notifications = [] } = req.body;
    const result = await query(
      'INSERT INTO forms (workspace_id, name, type, fields, settings, styling, redirect_url, success_message, notifications) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *',
      [req.workspaceId, name, type, JSON.stringify(fields), JSON.stringify(settings), JSON.stringify(styling), redirect_url, success_message, JSON.stringify(notifications)]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM forms WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticate, async (req, res) => {
  try {
    const { name, fields, settings, styling, redirect_url, success_message, notifications, status } = req.body;
    const result = await query(
      `UPDATE forms SET 
        name=COALESCE($1,name), fields=COALESCE($2,fields), settings=COALESCE($3,settings),
        styling=COALESCE($4,styling), redirect_url=COALESCE($5,redirect_url),
        success_message=COALESCE($6,success_message), notifications=COALESCE($7,notifications),
        status=COALESCE($8,status), updated_at=NOW()
       WHERE id=$9 AND workspace_id=$10 RETURNING *`,
      [name, fields?JSON.stringify(fields):null, settings?JSON.stringify(settings):null,
       styling?JSON.stringify(styling):null, redirect_url, success_message,
       notifications?JSON.stringify(notifications):null, status, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM forms WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Submissions
router.get('/:id/submissions', authenticate, async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    const result = await query(
      'SELECT fs.*, c.first_name, c.last_name, c.email as contact_email FROM form_submissions fs LEFT JOIN contacts c ON c.id=fs.contact_id WHERE fs.form_id=$1 ORDER BY fs.submitted_at DESC LIMIT $2 OFFSET $3',
      [req.params.id, limit, offset]
    );
    const count = await query('SELECT COUNT(*) FROM form_submissions WHERE form_id=$1', [req.params.id]);
    res.json({ submissions: result.rows, total: parseInt(count.rows[0].count) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Public submit (no auth)
router.post('/public/:id/submit', async (req, res) => {
  try {
    const form = await query('SELECT * FROM forms WHERE id=$1 AND status=$2', [req.params.id, 'active']);
    if (!form.rows[0]) return res.status(404).json({ error: 'Form not found' });

    const { data, source_url } = req.body;

    // Create/update contact if email present
    let contactId = null;
    if (data.email) {
      const existing = await query('SELECT id FROM contacts WHERE email=$1 AND workspace_id=$2', [data.email, form.rows[0].workspace_id]);
      if (existing.rows[0]) {
        contactId = existing.rows[0].id;
      } else {
        const newContact = await query(
          'INSERT INTO contacts (workspace_id, email, first_name, last_name, phone, source) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
          [form.rows[0].workspace_id, data.email, data.firstName || data.first_name || '', data.lastName || data.last_name || '', data.phone || '', 'form']
        );
        contactId = newContact.rows[0].id;
      }
    }

    await query(
      'INSERT INTO form_submissions (form_id, contact_id, data, ip_address, source_url) VALUES ($1,$2,$3,$4,$5)',
      [req.params.id, contactId, JSON.stringify(data), req.ip, source_url]
    );

    const f = form.rows[0];
    res.json({
      success: true,
      redirect_url: f.redirect_url,
      success_message: f.success_message || 'Thank you for your submission!'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Analytics
router.get('/:id/analytics', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT 
        DATE_TRUNC('day', submitted_at) as date,
        COUNT(*) as submissions
       FROM form_submissions WHERE form_id=$1
       AND submitted_at >= NOW() - INTERVAL '30 days'
       GROUP BY 1 ORDER BY 1`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
