const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, workspaceName } = req.body;

    if (!email || !password || !workspaceName) {
      return res.status(400).json({ error: 'Email, password, and workspace name are required' });
    }

    // Check if email exists
    const existingUser = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existingUser.rows[0]) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const slug = workspaceName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + uuidv4().substring(0, 6);

    // Create workspace
    const wsResult = await query(
      'INSERT INTO workspaces (name, slug) VALUES ($1, $2) RETURNING *',
      [workspaceName, slug]
    );
    const workspace = wsResult.rows[0];

    // Create user
    const userResult = await query(
      'INSERT INTO users (workspace_id, email, password_hash, first_name, last_name, role) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [workspace.id, email.toLowerCase(), passwordHash, firstName || '', lastName || '', 'owner']
    );
    const user = userResult.rows[0];

    // Create invoice settings defaults
    await query(
      'INSERT INTO invoice_settings (workspace_id, business_name) VALUES ($1, $2)',
      [workspace.id, workspaceName]
    );

    const token = jwt.sign({ userId: user.id, workspaceId: workspace.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

    res.status(201).json({
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        workspaceId: workspace.id,
        workspaceName: workspace.name,
        workspaceSlug: workspace.slug,
      }
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const result = await query(
      'SELECT u.*, w.name as workspace_name, w.slug as workspace_slug, w.plan FROM users u JOIN workspaces w ON u.workspace_id = w.id WHERE u.email = $1 AND u.is_active = true',
      [email.toLowerCase()]
    );

    const user = result.rows[0];
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    await query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

    const token = jwt.sign({ userId: user.id, workspaceId: user.workspace_id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        avatarUrl: user.avatar_url,
        workspaceId: user.workspace_id,
        workspaceName: user.workspace_name,
        workspaceSlug: user.workspace_slug,
        plan: user.plan,
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// GET /api/auth/me
router.get('/me', authenticate, async (req, res) => {
  res.json({
    id: req.user.id,
    email: req.user.email,
    firstName: req.user.first_name,
    lastName: req.user.last_name,
    role: req.user.role,
    avatarUrl: req.user.avatar_url,
    workspaceId: req.user.workspace_id,
    workspaceName: req.user.workspace_name,
    workspaceSlug: req.user.workspace_slug,
    plan: req.user.plan,
  });
});

// PUT /api/auth/profile
router.put('/profile', authenticate, async (req, res) => {
  try {
    const { firstName, lastName, avatarUrl } = req.body;
    const result = await query(
      'UPDATE users SET first_name=$1, last_name=$2, avatar_url=$3, updated_at=NOW() WHERE id=$4 RETURNING *',
      [firstName, lastName, avatarUrl, req.user.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Profile update failed' });
  }
});

// PUT /api/auth/password
router.put('/password', authenticate, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
    const valid = await bcrypt.compare(currentPassword, user.rows[0].password_hash);
    if (!valid) return res.status(400).json({ error: 'Current password incorrect' });
    const hash = await bcrypt.hash(newPassword, 12);
    await query('UPDATE users SET password_hash=$1, updated_at=NOW() WHERE id=$2', [hash, req.user.id]);
    res.json({ message: 'Password updated' });
  } catch (err) {
    res.status(500).json({ error: 'Password update failed' });
  }
});

module.exports = router;
