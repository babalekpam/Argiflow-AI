const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const twilio = require('twilio');
const axios = require('axios');

// ============================================================
// REPUTATION MANAGEMENT
// ============================================================
const reputation = express.Router();

reputation.get('/platforms', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM review_platforms WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

reputation.post('/platforms', authenticate, async (req, res) => {
  try {
    const { platform, location_id, access_token, place_id, business_name } = req.body;
    const result = await query(
      'INSERT INTO review_platforms (workspace_id, platform, location_id, access_token, place_id, business_name) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [req.workspaceId, platform, location_id, access_token, place_id, business_name]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

reputation.get('/reviews', authenticate, async (req, res) => {
  try {
    const { platform_id, rating, limit = 50, offset = 0 } = req.query;
    let sql = `SELECT r.*, rp.platform, rp.business_name FROM reviews r JOIN review_platforms rp ON rp.id=r.platform_id WHERE rp.workspace_id=$1`;
    const params = [req.workspaceId];
    if (platform_id) { sql += ` AND r.platform_id=$${params.length+1}`; params.push(platform_id); }
    if (rating) { sql += ` AND r.rating=$${params.length+1}`; params.push(rating); }
    sql += ` ORDER BY r.review_date DESC NULLS LAST LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

reputation.post('/reviews/:id/respond', authenticate, async (req, res) => {
  try {
    const { response } = req.body;
    await query('UPDATE reviews SET response=$1, responded_at=NOW() WHERE id=$2', [response, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

reputation.post('/review-requests', authenticate, async (req, res) => {
  try {
    const { contact_id, channel = 'email', platform, review_link } = req.body;
    const result = await query(
      'INSERT INTO review_requests (workspace_id, contact_id, channel, platform, review_link) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [req.workspaceId, contact_id, channel, platform, review_link]
    );
    // In production, trigger email/SMS send here
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

reputation.get('/stats', authenticate, async (req, res) => {
  try {
    const stats = await query(
      `SELECT 
        AVG(rating) as avg_rating,
        COUNT(*) as total_reviews,
        COUNT(*) FILTER (WHERE rating >= 4) as positive_reviews,
        COUNT(*) FILTER (WHERE rating <= 2) as negative_reviews,
        COUNT(*) FILTER (WHERE response IS NOT NULL) as responded_count
       FROM reviews r JOIN review_platforms rp ON rp.id=r.platform_id WHERE rp.workspace_id=$1`,
      [req.workspaceId]
    );
    res.json(stats.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// WHATSAPP
// ============================================================
const whatsapp = express.Router();

whatsapp.get('/accounts', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT id, phone_number, display_name, business_id, webhook_verified, is_active FROM whatsapp_accounts WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

whatsapp.post('/accounts', authenticate, async (req, res) => {
  try {
    const { phone_number, display_name, business_id, access_token } = req.body;
    const result = await query(
      'INSERT INTO whatsapp_accounts (workspace_id, phone_number, display_name, business_id, access_token) VALUES ($1,$2,$3,$4,$5) RETURNING id, phone_number, display_name, is_active',
      [req.workspaceId, phone_number, display_name, business_id, access_token]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

whatsapp.post('/send', authenticate, async (req, res) => {
  try {
    const { to, message, account_id } = req.body;
    const account = await query('SELECT * FROM whatsapp_accounts WHERE id=$1 AND workspace_id=$2', [account_id, req.workspaceId]);
    if (!account.rows[0]) return res.status(404).json({ error: 'Account not found' });

    // Use Twilio WhatsApp sandbox or Business API
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    const msg = await client.messages.create({
      from: process.env.TWILIO_WHATSAPP_NUMBER,
      to: `whatsapp:${to}`,
      body: message,
    });

    // Save to chat conversations
    let conv = await query('SELECT id FROM chat_conversations WHERE visitor_email=$1 AND channel=$2 AND workspace_id=$3', [to, 'whatsapp', req.workspaceId]);
    if (!conv.rows[0]) {
      conv = await query(
        'INSERT INTO chat_conversations (workspace_id, visitor_name, visitor_email, channel, status) VALUES ($1,$2,$3,$4,$5) RETURNING id',
        [req.workspaceId, to, to, 'whatsapp', 'open']
      );
    }
    await query(
      'INSERT INTO chat_messages (conversation_id, sender_type, sender_id, content) VALUES ($1,$2,$3,$4)',
      [conv.rows[0].id, 'agent', req.user.id, message]
    );

    res.json({ success: true, sid: msg.sid });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

whatsapp.get('/templates', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM whatsapp_templates WHERE workspace_id=$1 ORDER BY created_at DESC', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

whatsapp.post('/templates', authenticate, async (req, res) => {
  try {
    const { name, category, language = 'en', header, body, footer, buttons = [] } = req.body;
    const result = await query(
      'INSERT INTO whatsapp_templates (workspace_id, name, category, language, header, body, footer, buttons) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.workspaceId, name, category, language, JSON.stringify(header), body, footer, JSON.stringify(buttons)]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Twilio webhook for incoming WhatsApp
whatsapp.post('/webhook/incoming', async (req, res) => {
  try {
    const { From, To, Body, WorkspaceId } = req.body;
    const phone = From.replace('whatsapp:', '');

    let conv = await query('SELECT id FROM chat_conversations WHERE visitor_email=$1 AND channel=$2 AND workspace_id=$3', [phone, 'whatsapp', WorkspaceId]);
    if (!conv.rows[0]) {
      conv = await query(
        'INSERT INTO chat_conversations (workspace_id, visitor_name, visitor_email, channel, status) VALUES ($1,$2,$3,$4,$5) RETURNING id',
        [WorkspaceId, phone, phone, 'whatsapp', 'open']
      );
    }
    await query(
      'INSERT INTO chat_messages (conversation_id, sender_type, sender_name, content) VALUES ($1,$2,$3,$4)',
      [conv.rows[0].id, 'visitor', phone, Body]
    );

    res.status(200).send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
  } catch (err) {
    res.status(500).send('Error');
  }
});

// ============================================================
// FACEBOOK / INSTAGRAM DMs
// ============================================================
const meta = express.Router();

meta.get('/accounts', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT id, platform, page_id, page_name, instagram_id, is_active FROM meta_accounts WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

meta.post('/accounts', authenticate, async (req, res) => {
  try {
    const { platform, page_id, page_name, access_token, instagram_id } = req.body;
    const result = await query(
      'INSERT INTO meta_accounts (workspace_id, platform, page_id, page_name, access_token, instagram_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, platform, page_name, is_active',
      [req.workspaceId, platform, page_id, page_name, access_token, instagram_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

meta.post('/send', authenticate, async (req, res) => {
  try {
    const { recipient_id, message, account_id } = req.body;
    const account = await query('SELECT * FROM meta_accounts WHERE id=$1 AND workspace_id=$2', [account_id, req.workspaceId]);
    if (!account.rows[0]) return res.status(404).json({ error: 'Account not found' });

    const endpoint = account.rows[0].platform === 'instagram'
      ? `https://graph.facebook.com/v18.0/${account.rows[0].instagram_id}/messages`
      : `https://graph.facebook.com/v18.0/${account.rows[0].page_id}/messages`;

    await axios.post(endpoint, {
      recipient: { id: recipient_id },
      message: { text: message },
      access_token: account.rows[0].access_token,
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Meta webhook verification
meta.get('/webhook', (req, res) => {
  const verify_token = process.env.META_WEBHOOK_VERIFY_TOKEN;
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === verify_token) {
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

meta.post('/webhook', async (req, res) => {
  try {
    const { object, entry } = req.body;
    if (object === 'page' || object === 'instagram') {
      for (const ent of entry) {
        const messaging = ent.messaging || ent.changes?.[0]?.value?.messages;
        if (messaging) {
          for (const msg of messaging) {
            if (msg.message) {
              // Store incoming DM
              console.log('Incoming Meta DM:', msg);
            }
          }
        }
      }
    }
    res.sendStatus(200);
  } catch (err) {
    res.sendStatus(500);
  }
});

module.exports = { reputation, whatsapp, meta };
