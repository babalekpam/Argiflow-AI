const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const axios = require('axios');

// ===== ACCOUNTS =====
router.get('/accounts', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT id, platform, account_name, account_id, profile_image, is_active, created_at FROM social_accounts WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/accounts/connect', authenticate, async (req, res) => {
  try {
    const { platform, account_name, account_id, access_token, refresh_token, profile_image } = req.body;
    const result = await query(
      `INSERT INTO social_accounts (workspace_id, platform, account_name, account_id, access_token, refresh_token, profile_image)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT DO NOTHING RETURNING *`,
      [req.workspaceId, platform, account_name, account_id, access_token, refresh_token, profile_image]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/accounts/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM social_accounts WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== POSTS =====
router.get('/posts', authenticate, async (req, res) => {
  try {
    const { status, limit = 50, offset = 0 } = req.query;
    let sql = `SELECT sp.*, u.first_name, u.last_name FROM social_posts sp LEFT JOIN users u ON u.id=sp.created_by WHERE sp.workspace_id=$1`;
    const params = [req.workspaceId];
    if (status) { sql += ` AND sp.status=$${params.length+1}`; params.push(status); }
    sql += ` ORDER BY sp.scheduled_at DESC NULLS LAST, sp.created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/posts', authenticate, async (req, res) => {
  try {
    const { account_ids, content, media_urls = [], status = 'draft', scheduled_at, tags = [] } = req.body;
    const result = await query(
      'INSERT INTO social_posts (workspace_id, account_ids, content, media_urls, status, scheduled_at, tags, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.workspaceId, account_ids, content, media_urls, status, scheduled_at || null, tags, req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/posts/:id', authenticate, async (req, res) => {
  try {
    const { content, media_urls, status, scheduled_at, tags } = req.body;
    const result = await query(
      `UPDATE social_posts SET
        content=COALESCE($1,content), media_urls=COALESCE($2,media_urls),
        status=COALESCE($3,status), scheduled_at=COALESCE($4,scheduled_at),
        tags=COALESCE($5,tags), updated_at=NOW()
       WHERE id=$6 AND workspace_id=$7 RETURNING *`,
      [content, media_urls, status, scheduled_at, tags, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/posts/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM social_posts WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Publish now
router.post('/posts/:id/publish', authenticate, async (req, res) => {
  try {
    const post = await query(
      'SELECT sp.*, sa.access_token, sa.platform, sa.account_id FROM social_posts sp JOIN UNNEST(sp.account_ids) aid ON true JOIN social_accounts sa ON sa.id=aid WHERE sp.id=$1 AND sp.workspace_id=$2',
      [req.params.id, req.workspaceId]
    );
    if (!post.rows[0]) return res.status(404).json({ error: 'Post not found' });

    const platformPostIds = {};
    const errors = [];

    for (const row of post.rows) {
      try {
        if (row.platform === 'facebook') {
          const fbRes = await axios.post(
            `https://graph.facebook.com/${row.account_id}/feed`,
            { message: row.content, access_token: row.access_token }
          );
          platformPostIds[row.platform] = fbRes.data.id;
        } else if (row.platform === 'instagram') {
          // Instagram Graph API - two step process
          const createRes = await axios.post(
            `https://graph.facebook.com/${row.account_id}/media`,
            { caption: row.content, image_url: row.media_urls?.[0], access_token: row.access_token }
          );
          const publishRes = await axios.post(
            `https://graph.facebook.com/${row.account_id}/media_publish`,
            { creation_id: createRes.data.id, access_token: row.access_token }
          );
          platformPostIds[row.platform] = publishRes.data.id;
        }
        // Additional platforms can be added here
      } catch (platformErr) {
        errors.push({ platform: row.platform, error: platformErr.message });
      }
    }

    await query(
      'UPDATE social_posts SET status=$1, published_at=NOW(), platform_post_ids=$2, updated_at=NOW() WHERE id=$3',
      ['published', JSON.stringify(platformPostIds), req.params.id]
    );

    res.json({ success: true, platformPostIds, errors });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Calendar view
router.get('/calendar', authenticate, async (req, res) => {
  try {
    const { start, end } = req.query;
    const result = await query(
      'SELECT * FROM social_posts WHERE workspace_id=$1 AND scheduled_at BETWEEN $2 AND $3 ORDER BY scheduled_at',
      [req.workspaceId, start, end]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Analytics
router.get('/analytics', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT 
        COUNT(*) FILTER (WHERE status='published') as total_published,
        COUNT(*) FILTER (WHERE status='scheduled') as scheduled,
        SUM((analytics->>'likes')::integer) as total_likes,
        SUM((analytics->>'impressions')::integer) as total_impressions
       FROM social_posts WHERE workspace_id=$1 AND created_at >= NOW() - INTERVAL '30 days'`,
      [req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
