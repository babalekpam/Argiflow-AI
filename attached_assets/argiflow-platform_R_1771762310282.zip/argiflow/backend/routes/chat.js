const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');

// ===== WIDGETS =====
router.get('/widgets', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM chat_widgets WHERE workspace_id=$1 ORDER BY created_at DESC', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/widgets', authenticate, async (req, res) => {
  try {
    const { name, settings = {}, welcome_message, offline_message, allowed_domains = [], bot_enabled = false, bot_flows = [] } = req.body;
    const result = await query(
      'INSERT INTO chat_widgets (workspace_id, name, settings, welcome_message, offline_message, allowed_domains, bot_enabled, bot_flows) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.workspaceId, name, JSON.stringify(settings), welcome_message, offline_message, allowed_domains, bot_enabled, JSON.stringify(bot_flows)]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/widgets/:id', authenticate, async (req, res) => {
  try {
    const { name, settings, welcome_message, offline_message, allowed_domains, bot_enabled, bot_flows, status } = req.body;
    const result = await query(
      `UPDATE chat_widgets SET
        name=COALESCE($1,name), settings=COALESCE($2,settings),
        welcome_message=COALESCE($3,welcome_message), offline_message=COALESCE($4,offline_message),
        allowed_domains=COALESCE($5,allowed_domains), bot_enabled=COALESCE($6,bot_enabled),
        bot_flows=COALESCE($7,bot_flows), status=COALESCE($8,status), updated_at=NOW()
       WHERE id=$9 AND workspace_id=$10 RETURNING *`,
      [name, settings?JSON.stringify(settings):null, welcome_message, offline_message, allowed_domains,
       bot_enabled, bot_flows?JSON.stringify(bot_flows):null, status, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/widgets/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM chat_widgets WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== CONVERSATIONS =====
router.get('/conversations', authenticate, async (req, res) => {
  try {
    const { status, assigned_to, limit = 50, offset = 0 } = req.query;
    let sql = `SELECT cc.*, u.first_name as agent_first, u.last_name as agent_last,
                 (SELECT content FROM chat_messages WHERE conversation_id=cc.id ORDER BY sent_at DESC LIMIT 1) as last_message,
                 (SELECT sent_at FROM chat_messages WHERE conversation_id=cc.id ORDER BY sent_at DESC LIMIT 1) as last_message_at,
                 COUNT(cm.id) FILTER (WHERE cm.is_read=false AND cm.sender_type='visitor') as unread_count
               FROM chat_conversations cc
               LEFT JOIN users u ON u.id=cc.assigned_to
               LEFT JOIN chat_messages cm ON cm.conversation_id=cc.id
               WHERE cc.workspace_id=$1`;
    const params = [req.workspaceId];
    if (status) { sql += ` AND cc.status=$${params.length+1}`; params.push(status); }
    if (assigned_to) { sql += ` AND cc.assigned_to=$${params.length+1}`; params.push(assigned_to); }
    sql += ` GROUP BY cc.id, u.first_name, u.last_name ORDER BY last_message_at DESC NULLS LAST LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/conversations/:id', authenticate, async (req, res) => {
  try {
    const conv = await query(
      'SELECT cc.*, u.first_name as agent_first, u.last_name as agent_last FROM chat_conversations cc LEFT JOIN users u ON u.id=cc.assigned_to WHERE cc.id=$1 AND cc.workspace_id=$2',
      [req.params.id, req.workspaceId]
    );
    if (!conv.rows[0]) return res.status(404).json({ error: 'Not found' });
    const messages = await query('SELECT * FROM chat_messages WHERE conversation_id=$1 ORDER BY sent_at ASC', [req.params.id]);
    // Mark messages as read
    await query('UPDATE chat_messages SET is_read=true WHERE conversation_id=$1 AND sender_type=$2 AND is_read=false', [req.params.id, 'visitor']);
    res.json({ ...conv.rows[0], messages: messages.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/conversations/:id', authenticate, async (req, res) => {
  try {
    const { status, assigned_to, tags } = req.body;
    const result = await query(
      'UPDATE chat_conversations SET status=COALESCE($1,status), assigned_to=COALESCE($2,assigned_to), tags=COALESCE($3,tags), updated_at=NOW() WHERE id=$4 AND workspace_id=$5 RETURNING *',
      [status, assigned_to, tags, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Send message (agent)
router.post('/conversations/:id/messages', authenticate, async (req, res) => {
  try {
    const { content, attachments = [] } = req.body;
    const result = await query(
      'INSERT INTO chat_messages (conversation_id, sender_type, sender_id, sender_name, content, attachments) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [req.params.id, 'agent', req.user.id, `${req.user.first_name} ${req.user.last_name}`, content, JSON.stringify(attachments)]
    );
    // Update conversation updated_at
    await query('UPDATE chat_conversations SET updated_at=NOW() WHERE id=$1', [req.params.id]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== PUBLIC: Start conversation from widget =====
router.post('/public/start', async (req, res) => {
  try {
    const { widgetId, visitorName, visitorEmail, message } = req.body;
    const widget = await query('SELECT * FROM chat_widgets WHERE id=$1 AND status=$2', [widgetId, 'active']);
    if (!widget.rows[0]) return res.status(404).json({ error: 'Widget not found' });

    const w = widget.rows[0];
    let contactId = null;
    if (visitorEmail) {
      const existing = await query('SELECT id FROM contacts WHERE email=$1 AND workspace_id=$2', [visitorEmail, w.workspace_id]);
      contactId = existing.rows[0]?.id;
      if (!contactId) {
        const newC = await query(
          'INSERT INTO contacts (workspace_id, email, first_name, source) VALUES ($1,$2,$3,$4) RETURNING id',
          [w.workspace_id, visitorEmail, visitorName || '', 'chat']
        );
        contactId = newC.rows[0].id;
      }
    }

    const conv = await query(
      'INSERT INTO chat_conversations (workspace_id, widget_id, contact_id, visitor_name, visitor_email, channel) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [w.workspace_id, widgetId, contactId, visitorName, visitorEmail, 'chat']
    );

    if (message) {
      await query(
        'INSERT INTO chat_messages (conversation_id, sender_type, sender_name, content) VALUES ($1,$2,$3,$4)',
        [conv.rows[0].id, 'visitor', visitorName || 'Visitor', message]
      );
    }

    // Auto welcome message
    if (w.welcome_message) {
      await query(
        'INSERT INTO chat_messages (conversation_id, sender_type, sender_name, content) VALUES ($1,$2,$3,$4)',
        [conv.rows[0].id, 'bot', w.name, w.welcome_message]
      );
    }

    res.status(201).json({ conversationId: conv.rows[0].id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Public: get widget config
router.get('/public/widget/:id', async (req, res) => {
  try {
    const result = await query(
      'SELECT id, name, settings, welcome_message, offline_message, bot_enabled FROM chat_widgets WHERE id=$1 AND status=$2',
      [req.params.id, 'active']
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Stats
router.get('/stats/overview', authenticate, async (req, res) => {
  try {
    const stats = await query(
      `SELECT
        COUNT(*) FILTER (WHERE status='open') as open_conversations,
        COUNT(*) FILTER (WHERE status='closed') as closed_conversations,
        COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '24 hours') as new_today,
        AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/60) FILTER (WHERE status='closed') as avg_response_minutes
       FROM chat_conversations WHERE workspace_id=$1`,
      [req.workspaceId]
    );
    res.json(stats.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
