const express = require('express');
const router = express.Router();
const { query, transaction } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// ===== SETTINGS =====
router.get('/settings', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM invoice_settings WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows[0] || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/settings', authenticate, async (req, res) => {
  try {
    const { business_name, business_address, business_phone, business_email, logo_url, default_notes, default_terms, invoice_prefix, tax_rate, currency } = req.body;
    const result = await query(
      `INSERT INTO invoice_settings (workspace_id, business_name, business_address, business_phone, business_email, logo_url, default_notes, default_terms, invoice_prefix, tax_rate, currency)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       ON CONFLICT (workspace_id) DO UPDATE SET
         business_name=EXCLUDED.business_name, business_address=EXCLUDED.business_address,
         business_phone=EXCLUDED.business_phone, business_email=EXCLUDED.business_email,
         logo_url=EXCLUDED.logo_url, default_notes=EXCLUDED.default_notes,
         default_terms=EXCLUDED.default_terms, invoice_prefix=EXCLUDED.invoice_prefix,
         tax_rate=EXCLUDED.tax_rate, currency=EXCLUDED.currency
       RETURNING *`,
      [req.workspaceId, business_name, business_address, business_phone, business_email, logo_url, default_notes, default_terms, invoice_prefix || 'INV', tax_rate || 0, currency || 'USD']
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== INVOICES =====
router.get('/', authenticate, async (req, res) => {
  try {
    const { status, type, limit = 50, offset = 0 } = req.query;
    let sql = `SELECT i.*, c.first_name, c.last_name, c.email as contact_email, c.company
               FROM invoices i LEFT JOIN contacts c ON c.id=i.contact_id
               WHERE i.workspace_id=$1`;
    const params = [req.workspaceId];
    if (status) { sql += ` AND i.status=$${params.length+1}`; params.push(status); }
    if (type) { sql += ` AND i.type=$${params.length+1}`; params.push(type); }
    sql += ` ORDER BY i.created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', authenticate, async (req, res) => {
  try {
    const settings = await query('SELECT * FROM invoice_settings WHERE workspace_id=$1', [req.workspaceId]);
    const s = settings.rows[0] || {};

    const nextNum = s.next_invoice_number || 1001;
    const prefix = s.invoice_prefix || 'INV';
    const invoiceNumber = `${prefix}-${nextNum}`;

    await query('UPDATE invoice_settings SET next_invoice_number=next_invoice_number+1 WHERE workspace_id=$1', [req.workspaceId]);

    const { contact_id, type = 'invoice', issue_date, due_date, line_items = [], tax_rate = 0, discount_amount = 0, notes, terms, recurring } = req.body;

    const subtotal = line_items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
    const taxAmount = subtotal * (tax_rate / 100);
    const total = subtotal + taxAmount - discount_amount;

    const result = await query(
      `INSERT INTO invoices (workspace_id, contact_id, invoice_number, type, issue_date, due_date, line_items, subtotal, tax_rate, tax_amount, discount_amount, total, balance_due, notes, terms, recurring)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
      [req.workspaceId, contact_id, invoiceNumber, type, issue_date, due_date, JSON.stringify(line_items), subtotal, tax_rate, taxAmount, discount_amount, total, total, notes, terms, recurring?JSON.stringify(recurring):null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', authenticate, async (req, res) => {
  try {
    const result = await query(
      'SELECT i.*, c.first_name, c.last_name, c.email as contact_email, c.company, c.phone as contact_phone FROM invoices i LEFT JOIN contacts c ON c.id=i.contact_id WHERE i.id=$1 AND i.workspace_id=$2',
      [req.params.id, req.workspaceId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Not found' });
    const payments = await query('SELECT * FROM payments WHERE invoice_id=$1 ORDER BY paid_at DESC', [req.params.id]);
    res.json({ ...result.rows[0], payments: payments.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticate, async (req, res) => {
  try {
    const { status, line_items, tax_rate, discount_amount, due_date, notes, terms } = req.body;
    let subtotal, taxAmount, total;
    if (line_items) {
      subtotal = line_items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
      taxAmount = subtotal * ((tax_rate || 0) / 100);
      total = subtotal + taxAmount - (discount_amount || 0);
    }
    const result = await query(
      `UPDATE invoices SET
        status=COALESCE($1,status),
        line_items=COALESCE($2,line_items),
        subtotal=COALESCE($3,subtotal),
        tax_rate=COALESCE($4,tax_rate),
        tax_amount=COALESCE($5,tax_amount),
        discount_amount=COALESCE($6,discount_amount),
        total=COALESCE($7,total),
        balance_due=COALESCE($8,balance_due),
        due_date=COALESCE($9,due_date),
        notes=COALESCE($10,notes),
        terms=COALESCE($11,terms),
        updated_at=NOW()
       WHERE id=$12 AND workspace_id=$13 RETURNING *`,
      [status, line_items?JSON.stringify(line_items):null, subtotal, tax_rate, taxAmount, discount_amount, total, total, due_date, notes, terms, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM invoices WHERE id=$1 AND workspace_id=$2 AND status=$3', [req.params.id, req.workspaceId, 'draft']);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Record manual payment
router.post('/:id/payments', authenticate, async (req, res) => {
  try {
    const { amount, method = 'manual', notes } = req.body;
    await transaction(async (client) => {
      await client.query(
        'INSERT INTO payments (workspace_id, invoice_id, amount, method, notes) VALUES ($1,$2,$3,$4,$5)',
        [req.workspaceId, req.params.id, amount, method, notes]
      );
      const inv = await client.query('SELECT total, amount_paid FROM invoices WHERE id=$1', [req.params.id]);
      const newPaid = parseFloat(inv.rows[0].amount_paid) + parseFloat(amount);
      const newBalance = parseFloat(inv.rows[0].total) - newPaid;
      const newStatus = newBalance <= 0 ? 'paid' : 'partial';
      await client.query(
        'UPDATE invoices SET amount_paid=$1, balance_due=$2, status=$3, paid_at=CASE WHEN $4 <= 0 THEN NOW() ELSE paid_at END, updated_at=NOW() WHERE id=$5',
        [newPaid, newBalance, newStatus, newBalance, req.params.id]
      );
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create Stripe payment link
router.post('/:id/payment-link', authenticate, async (req, res) => {
  try {
    const inv = await query(
      'SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id=i.contact_id WHERE i.id=$1 AND i.workspace_id=$2',
      [req.params.id, req.workspaceId]
    );
    if (!inv.rows[0]) return res.status(404).json({ error: 'Not found' });
    const invoice = inv.rows[0];

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: `Invoice ${invoice.invoice_number}` },
          unit_amount: Math.round(invoice.balance_due * 100),
        },
        quantity: 1,
      }],
      mode: 'payment',
      customer_email: invoice.email,
      success_url: `${process.env.FRONTEND_URL}/invoices/${invoice.id}?payment=success`,
      cancel_url: `${process.env.FRONTEND_URL}/invoices/${invoice.id}?payment=cancelled`,
      metadata: { invoiceId: invoice.id, workspaceId: req.workspaceId },
    });

    await query('UPDATE invoices SET payment_link=$1, status=$2, sent_at=NOW(), updated_at=NOW() WHERE id=$3', [session.url, 'sent', req.params.id]);
    res.json({ url: session.url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Dashboard stats
router.get('/stats/overview', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT
        SUM(total) as total_invoiced,
        SUM(amount_paid) as total_collected,
        SUM(balance_due) as total_outstanding,
        COUNT(*) FILTER (WHERE status='overdue') as overdue_count,
        COUNT(*) FILTER (WHERE status='paid' AND paid_at >= NOW() - INTERVAL '30 days') as paid_this_month,
        SUM(amount_paid) FILTER (WHERE paid_at >= NOW() - INTERVAL '30 days') as revenue_this_month
       FROM invoices WHERE workspace_id=$1`,
      [req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
