const express = require('express');
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');
const axios = require('axios');

// ============================================================
// CALENDAR SYNC
// ============================================================
const calendar = express.Router();

calendar.get('/calendars', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT id, provider, name, color, sync_enabled, last_synced FROM calendars WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

calendar.post('/calendars', authenticate, async (req, res) => {
  try {
    const { provider, calendar_id, name, color, access_token, refresh_token, token_expires } = req.body;
    const result = await query(
      'INSERT INTO calendars (workspace_id, user_id, provider, calendar_id, name, color, access_token, refresh_token, token_expires) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, provider, name, color, sync_enabled',
      [req.workspaceId, req.user.id, provider, calendar_id, name, color, access_token, refresh_token, token_expires]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

calendar.get('/events', authenticate, async (req, res) => {
  try {
    const { start, end, calendar_id } = req.query;
    let sql = `SELECT ce.*, c.first_name as contact_first, c.last_name as contact_last FROM calendar_events ce LEFT JOIN contacts c ON c.id=ce.contact_id WHERE ce.workspace_id=$1`;
    const params = [req.workspaceId];
    if (start) { sql += ` AND ce.start_time >= $${params.length+1}`; params.push(start); }
    if (end) { sql += ` AND ce.end_time <= $${params.length+1}`; params.push(end); }
    if (calendar_id) { sql += ` AND ce.calendar_id=$${params.length+1}`; params.push(calendar_id); }
    sql += ' ORDER BY ce.start_time';
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

calendar.post('/events', authenticate, async (req, res) => {
  try {
    const { calendar_id, title, description, location, start_time, end_time, all_day, attendees, contact_id, meeting_link, recurrence } = req.body;
    const result = await query(
      'INSERT INTO calendar_events (workspace_id, calendar_id, title, description, location, start_time, end_time, all_day, attendees, contact_id, meeting_link, recurrence) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *',
      [req.workspaceId, calendar_id, title, description, location, start_time, end_time, all_day || false, JSON.stringify(attendees || []), contact_id, meeting_link, recurrence ? JSON.stringify(recurrence) : null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

calendar.put('/events/:id', authenticate, async (req, res) => {
  try {
    const { title, description, location, start_time, end_time, status } = req.body;
    const result = await query(
      'UPDATE calendar_events SET title=COALESCE($1,title), description=COALESCE($2,description), location=COALESCE($3,location), start_time=COALESCE($4,start_time), end_time=COALESCE($5,end_time), status=COALESCE($6,status), updated_at=NOW() WHERE id=$7 AND workspace_id=$8 RETURNING *',
      [title, description, location, start_time, end_time, status, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

calendar.delete('/events/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM calendar_events WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Booking pages
calendar.get('/booking-pages', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM booking_pages WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

calendar.post('/booking-pages', authenticate, async (req, res) => {
  try {
    const { name, duration_minutes, buffer_before, buffer_after, availability, questions, settings } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO booking_pages (workspace_id, user_id, name, slug, duration_minutes, buffer_before, buffer_after, availability, questions, settings) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *',
      [req.workspaceId, req.user.id, name, slug, duration_minutes || 30, buffer_before || 0, buffer_after || 0, JSON.stringify(availability || {}), JSON.stringify(questions || []), JSON.stringify(settings || {})]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// DOCUMENTS & E-SIGNATURES
// ============================================================
const documents = express.Router();

documents.get('/', authenticate, async (req, res) => {
  try {
    const { type, status } = req.query;
    let sql = `SELECT d.*, c.first_name, c.last_name, c.email as contact_email, u.first_name as creator_first, u.last_name as creator_last FROM documents d LEFT JOIN contacts c ON c.id=d.contact_id LEFT JOIN users u ON u.id=d.created_by WHERE d.workspace_id=$1`;
    const params = [req.workspaceId];
    if (type) { sql += ` AND d.type=$${params.length+1}`; params.push(type); }
    if (status) { sql += ` AND d.status=$${params.length+1}`; params.push(status); }
    sql += ' ORDER BY d.created_at DESC';
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

documents.post('/', authenticate, async (req, res) => {
  try {
    const { name, type, category, content, contact_id, requires_signature, expires_at, tags } = req.body;
    const result = await query(
      'INSERT INTO documents (workspace_id, contact_id, name, type, category, content, requires_signature, expires_at, tags, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *',
      [req.workspaceId, contact_id, name, type || 'document', category, JSON.stringify(content || {}), requires_signature || false, expires_at, tags || [], req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

documents.put('/:id', authenticate, async (req, res) => {
  try {
    const { name, content, status, tags } = req.body;
    const result = await query(
      'UPDATE documents SET name=COALESCE($1,name), content=COALESCE($2,content), status=COALESCE($3,status), tags=COALESCE($4,tags), updated_at=NOW() WHERE id=$5 AND workspace_id=$6 RETURNING *',
      [name, content?JSON.stringify(content):null, status, tags, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

documents.delete('/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM documents WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

documents.post('/:id/send-for-signature', authenticate, async (req, res) => {
  try {
    const { signer_name, signer_email } = req.body;
    const token = uuidv4();
    await query(
      'INSERT INTO document_signatures (document_id, signer_name, signer_email, token) VALUES ($1,$2,$3,$4)',
      [req.params.id, signer_name, signer_email, token]
    );
    await query('UPDATE documents SET status=$1 WHERE id=$2', ['sent', req.params.id]);
    const signUrl = `${process.env.FRONTEND_URL}/sign/${token}`;
    res.json({ success: true, sign_url: signUrl, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Public: sign document
documents.post('/public/sign/:token', async (req, res) => {
  try {
    const { signature_data } = req.body;
    const sig = await query('SELECT * FROM document_signatures WHERE token=$1 AND status=$2', [req.params.token, 'pending']);
    if (!sig.rows[0]) return res.status(404).json({ error: 'Invalid or expired signature link' });
    await query('UPDATE document_signatures SET signature_data=$1, ip_address=$2, signed_at=NOW(), status=$3 WHERE token=$4',
      [signature_data, req.ip, 'signed', req.params.token]);
    await query('UPDATE documents SET status=$1, signed_at=NOW() WHERE id=$2', ['signed', sig.rows[0].document_id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// BLOG BUILDER
// ============================================================
const blog = express.Router();

blog.get('/sites', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM blog_sites WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

blog.post('/sites', authenticate, async (req, res) => {
  try {
    const { name, description, settings, seo } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO blog_sites (workspace_id, name, slug, description, settings, seo) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [req.workspaceId, name, slug, description, JSON.stringify(settings||{}), JSON.stringify(seo||{})]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

blog.get('/posts', authenticate, async (req, res) => {
  try {
    const { site_id, status, limit = 20, offset = 0 } = req.query;
    let sql = `SELECT bp.*, bc.name as category_name, u.first_name, u.last_name FROM blog_posts bp LEFT JOIN blog_categories bc ON bc.id=bp.category_id LEFT JOIN users u ON u.id=bp.author_id WHERE bs.workspace_id=$1`;
    // Join blog_sites for workspace filter
    const fullSql = `SELECT bp.*, bc.name as category_name, u.first_name, u.last_name 
                     FROM blog_posts bp 
                     JOIN blog_sites bs ON bs.id=bp.site_id 
                     LEFT JOIN blog_categories bc ON bc.id=bp.category_id 
                     LEFT JOIN users u ON u.id=bp.author_id
                     WHERE bs.workspace_id=$1`;
    const params = [req.workspaceId];
    let whereSql = fullSql;
    if (site_id) { whereSql += ` AND bp.site_id=$${params.length+1}`; params.push(site_id); }
    if (status) { whereSql += ` AND bp.status=$${params.length+1}`; params.push(status); }
    whereSql += ` ORDER BY bp.created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`;
    params.push(limit, offset);
    const result = await query(whereSql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

blog.post('/posts', authenticate, async (req, res) => {
  try {
    const { site_id, title, excerpt, content, featured_image, tags, status, category_id, seo } = req.body;
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').substring(0, 80) + '-' + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO blog_posts (site_id, author_id, title, slug, excerpt, content, featured_image, tags, status, category_id, seo, published_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *',
      [site_id, req.user.id, title, slug, excerpt, content, featured_image, tags||[], status||'draft', category_id, JSON.stringify(seo||{}), status === 'published' ? new Date() : null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

blog.put('/posts/:id', authenticate, async (req, res) => {
  try {
    const { title, excerpt, content, featured_image, tags, status, seo } = req.body;
    const result = await query(
      `UPDATE blog_posts SET 
        title=COALESCE($1,title), excerpt=COALESCE($2,excerpt), content=COALESCE($3,content),
        featured_image=COALESCE($4,featured_image), tags=COALESCE($5,tags), status=COALESCE($6,status),
        seo=COALESCE($7,seo), published_at=CASE WHEN $6='published' AND published_at IS NULL THEN NOW() ELSE published_at END, updated_at=NOW()
       WHERE id=$8 RETURNING *`,
      [title, excerpt, content, featured_image, tags, status, seo?JSON.stringify(seo):null, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

blog.delete('/posts/:id', authenticate, async (req, res) => {
  try {
    await query('DELETE FROM blog_posts WHERE id=$1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Categories
blog.get('/categories/:siteId', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM blog_categories WHERE site_id=$1', [req.params.siteId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

blog.post('/categories', authenticate, async (req, res) => {
  try {
    const { site_id, name, description } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const result = await query(
      'INSERT INTO blog_categories (site_id, name, slug, description) VALUES ($1,$2,$3,$4) RETURNING *',
      [site_id, name, slug, description]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// COMMUNITIES
// ============================================================
const communities = express.Router();

communities.get('/', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM communities WHERE workspace_id=$1 ORDER BY created_at DESC', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

communities.post('/', authenticate, async (req, res) => {
  try {
    const { name, description, is_private, cover_image, settings } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO communities (workspace_id, name, slug, description, is_private, cover_image, settings) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
      [req.workspaceId, name, slug, description, is_private||false, cover_image, JSON.stringify(settings||{})]
    );
    // Create default general channel
    await query('INSERT INTO community_channels (community_id, name, type, order_index) VALUES ($1,$2,$3,$4)', [result.rows[0].id, 'General', 'discussion', 0]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

communities.get('/:id', authenticate, async (req, res) => {
  try {
    const comm = await query('SELECT * FROM communities WHERE id=$1 AND workspace_id=$2', [req.params.id, req.workspaceId]);
    if (!comm.rows[0]) return res.status(404).json({ error: 'Not found' });
    const channels = await query('SELECT * FROM community_channels WHERE community_id=$1 ORDER BY order_index', [req.params.id]);
    const members = await query('SELECT * FROM community_members WHERE community_id=$1 ORDER BY joined_at DESC LIMIT 20', [req.params.id]);
    res.json({ ...comm.rows[0], channels: channels.rows, members: members.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

communities.get('/:id/channels/:channelId/posts', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT cp.*, cm.member_name, cm.member_email, (SELECT COUNT(*) FROM community_replies WHERE post_id=cp.id) as reply_count
       FROM community_posts cp JOIN community_members cm ON cm.id=cp.author_id
       WHERE cp.channel_id=$1 ORDER BY cp.is_pinned DESC, cp.created_at DESC LIMIT 50`,
      [req.params.channelId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

communities.post('/:id/channels/:channelId/posts', authenticate, async (req, res) => {
  try {
    const { title, content, member_id } = req.body;
    const result = await query(
      'INSERT INTO community_posts (channel_id, author_id, title, content) VALUES ($1,$2,$3,$4) RETURNING *',
      [req.params.channelId, member_id, title, content]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// A/B TESTING
// ============================================================
const abTesting = express.Router();

abTesting.get('/', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM ab_tests WHERE workspace_id=$1 ORDER BY created_at DESC', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

abTesting.post('/', authenticate, async (req, res) => {
  try {
    const { name, type, target_id, goal, traffic_split, variants } = req.body;
    const result = await query(
      'INSERT INTO ab_tests (workspace_id, name, type, target_id, goal, traffic_split, variants) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
      [req.workspaceId, name, type, target_id, goal, traffic_split||50, JSON.stringify(variants||[])]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

abTesting.put('/:id/start', authenticate, async (req, res) => {
  try {
    const result = await query('UPDATE ab_tests SET status=$1, started_at=NOW() WHERE id=$2 AND workspace_id=$3 RETURNING *', ['running', req.params.id, req.workspaceId]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

abTesting.put('/:id/end', authenticate, async (req, res) => {
  try {
    const { winner_variant } = req.body;
    const result = await query('UPDATE ab_tests SET status=$1, ended_at=NOW(), winner_variant=$2 WHERE id=$3 AND workspace_id=$4 RETURNING *', ['completed', winner_variant, req.params.id, req.workspaceId]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

abTesting.get('/:id/results', authenticate, async (req, res) => {
  try {
    const events = await query(
      `SELECT variant, event_type, COUNT(*) as count FROM ab_test_events WHERE test_id=$1 GROUP BY variant, event_type`,
      [req.params.id]
    );
    res.json(events.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// PROPOSALS & ESTIMATES
// ============================================================
const proposals = express.Router();

proposals.get('/', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT p.*, c.first_name, c.last_name, c.email as contact_email, c.company FROM proposals p LEFT JOIN contacts c ON c.id=p.contact_id WHERE p.workspace_id=$1 ORDER BY p.created_at DESC`,
      [req.workspaceId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

proposals.post('/', authenticate, async (req, res) => {
  try {
    const { contact_id, title, valid_until, sections, line_items, notes } = req.body;
    const proposalNumber = 'PRO-' + Date.now().toString().substring(7);
    const token = uuidv4();
    const lineItems = line_items || [];
    const subtotal = lineItems.reduce((s, i) => s + (i.quantity * i.unit_price), 0);
    const result = await query(
      'INSERT INTO proposals (workspace_id, contact_id, title, proposal_number, valid_until, sections, line_items, subtotal, total, notes, token, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *',
      [req.workspaceId, contact_id, title, proposalNumber, valid_until, JSON.stringify(sections||[]), JSON.stringify(lineItems), subtotal, subtotal, notes, token, req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

proposals.put('/:id', authenticate, async (req, res) => {
  try {
    const { title, status, sections, line_items, notes, valid_until } = req.body;
    const lineItems = line_items || null;
    const subtotal = lineItems ? lineItems.reduce((s, i) => s + (i.quantity * i.unit_price), 0) : null;
    const result = await query(
      `UPDATE proposals SET title=COALESCE($1,title), status=COALESCE($2,status), sections=COALESCE($3,sections), line_items=COALESCE($4,line_items), subtotal=COALESCE($5,subtotal), total=COALESCE($5,total), notes=COALESCE($6,notes), valid_until=COALESCE($7,valid_until), updated_at=NOW() WHERE id=$8 AND workspace_id=$9 RETURNING *`,
      [title, status, sections?JSON.stringify(sections):null, lineItems?JSON.stringify(lineItems):null, subtotal, notes, valid_until, req.params.id, req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

proposals.get('/public/:token', async (req, res) => {
  try {
    const result = await query(
      'SELECT p.*, c.first_name, c.last_name, c.email, c.company FROM proposals p LEFT JOIN contacts c ON c.id=p.contact_id WHERE p.token=$1',
      [req.params.token]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Not found' });
    await query('UPDATE proposals SET viewed_at=COALESCE(viewed_at,NOW()) WHERE token=$1', [req.params.token]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

proposals.post('/public/:token/sign', async (req, res) => {
  try {
    const { signature, name } = req.body;
    await query('UPDATE proposals SET client_signature=$1, client_signed_at=NOW(), status=$2 WHERE token=$3', [signature, 'signed', req.params.token]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// AFFILIATE MANAGEMENT
// ============================================================
const affiliates = express.Router();

affiliates.get('/programs', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM affiliate_programs WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

affiliates.post('/programs', authenticate, async (req, res) => {
  try {
    const { name, commission_type, commission_value, cookie_days, min_payout, payout_schedule, terms } = req.body;
    const result = await query(
      'INSERT INTO affiliate_programs (workspace_id, name, commission_type, commission_value, cookie_days, min_payout, payout_schedule, terms) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.workspaceId, name, commission_type||'percentage', commission_value, cookie_days||30, min_payout||50, payout_schedule||'monthly', terms]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

affiliates.get('/affiliates', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT a.*, ap.name as program_name FROM affiliates a JOIN affiliate_programs ap ON ap.id=a.program_id WHERE ap.workspace_id=$1 ORDER BY a.created_at DESC`,
      [req.workspaceId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

affiliates.post('/affiliates', authenticate, async (req, res) => {
  try {
    const { program_id, name, email, contact_id } = req.body;
    const code = name.toLowerCase().replace(/[^a-z0-9]/g, '') + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO affiliates (program_id, contact_id, name, email, referral_code) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [program_id, contact_id, name, email, code]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

affiliates.put('/affiliates/:id/approve', authenticate, async (req, res) => {
  try {
    const result = await query('UPDATE affiliates SET status=$1, approved_at=NOW() WHERE id=$2 RETURNING *', ['approved', req.params.id]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

affiliates.get('/stats', authenticate, async (req, res) => {
  try {
    const result = await query(
      `SELECT 
        COUNT(DISTINCT a.id) as total_affiliates,
        SUM(a.total_clicks) as total_clicks,
        SUM(a.total_referrals) as total_referrals,
        SUM(a.total_earnings) as total_commissions_paid
       FROM affiliates a JOIN affiliate_programs ap ON ap.id=a.program_id WHERE ap.workspace_id=$1 AND a.status='approved'`,
      [req.workspaceId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// MEMBERSHIP / COURSES
// ============================================================
const membership = express.Router();

membership.get('/sites', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT * FROM membership_sites WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

membership.post('/sites', authenticate, async (req, res) => {
  try {
    const { name, description, logo_url, theme } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + uuidv4().substring(0, 6);
    const result = await query(
      'INSERT INTO membership_sites (workspace_id, name, slug, description, logo_url, theme) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [req.workspaceId, name, slug, description, logo_url, JSON.stringify(theme||{})]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

membership.get('/courses', authenticate, async (req, res) => {
  try {
    const { site_id } = req.query;
    let sql = `SELECT c.*, ms.name as site_name, COUNT(ce.id) as enrollment_count FROM courses c JOIN membership_sites ms ON ms.id=c.site_id LEFT JOIN course_enrollments ce ON ce.course_id=c.id WHERE ms.workspace_id=$1`;
    const params = [req.workspaceId];
    if (site_id) { sql += ` AND c.site_id=$${params.length+1}`; params.push(site_id); }
    sql += ' GROUP BY c.id, ms.name ORDER BY c.created_at DESC';
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

membership.post('/courses', authenticate, async (req, res) => {
  try {
    const { site_id, title, description, thumbnail_url, price, is_free } = req.body;
    const result = await query(
      'INSERT INTO courses (site_id, title, description, thumbnail_url, price, is_free) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [site_id, title, description, thumbnail_url, price||0, is_free||false]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

membership.get('/courses/:id', authenticate, async (req, res) => {
  try {
    const course = await query('SELECT * FROM courses WHERE id=$1', [req.params.id]);
    const sections = await query('SELECT * FROM course_sections WHERE course_id=$1 ORDER BY order_index', [req.params.id]);
    const lessons = await query(`SELECT cl.* FROM course_lessons cl JOIN course_sections cs ON cs.id=cl.section_id WHERE cs.course_id=$1 ORDER BY cs.order_index, cl.order_index`, [req.params.id]);
    res.json({ ...course.rows[0], sections: sections.rows.map(s => ({ ...s, lessons: lessons.rows.filter(l => l.section_id === s.id) })) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

membership.post('/courses/:id/sections', authenticate, async (req, res) => {
  try {
    const { title, order_index } = req.body;
    const result = await query('INSERT INTO course_sections (course_id, title, order_index) VALUES ($1,$2,$3) RETURNING *', [req.params.id, title, order_index||0]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

membership.post('/sections/:id/lessons', authenticate, async (req, res) => {
  try {
    const { title, type, content, video_url, duration_seconds, is_preview, order_index } = req.body;
    const result = await query(
      'INSERT INTO course_lessons (section_id, title, type, content, video_url, duration_seconds, is_preview, order_index) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.params.id, title, type||'video', JSON.stringify(content||{}), video_url, duration_seconds, is_preview||false, order_index||0]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GBP (Google Business Profile)
const gbp = express.Router();

gbp.get('/accounts', authenticate, async (req, res) => {
  try {
    const result = await query('SELECT id, location_id, business_name, address, phone, website, avg_rating, total_reviews FROM gbp_accounts WHERE workspace_id=$1', [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

gbp.post('/accounts', authenticate, async (req, res) => {
  try {
    const { location_id, business_name, address, phone, website, access_token, refresh_token } = req.body;
    const result = await query(
      'INSERT INTO gbp_accounts (workspace_id, location_id, business_name, address, phone, website, access_token, refresh_token) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, location_id, business_name',
      [req.workspaceId, location_id, business_name, address, phone, website, access_token, refresh_token]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

gbp.get('/posts', authenticate, async (req, res) => {
  try {
    const result = await query(`SELECT gp.*, ga.business_name FROM gbp_posts gp JOIN gbp_accounts ga ON ga.id=gp.account_id WHERE ga.workspace_id=$1 ORDER BY gp.created_at DESC`, [req.workspaceId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

gbp.post('/posts', authenticate, async (req, res) => {
  try {
    const { account_id, type, summary, media_url, action_type, action_url, event, scheduled_at } = req.body;
    const result = await query(
      'INSERT INTO gbp_posts (workspace_id, account_id, type, summary, media_url, action_type, action_url, event, status, scheduled_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *',
      [req.workspaceId, account_id, type||'STANDARD', summary, media_url, action_type, action_url, event?JSON.stringify(event):null, scheduled_at?'scheduled':'draft', scheduled_at]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = { calendar, documents, blog, communities, abTesting, proposals, affiliates, membership, gbp };
