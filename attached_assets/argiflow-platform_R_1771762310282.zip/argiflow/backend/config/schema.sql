-- ArgiFlow Platform - Complete Database Schema
-- Run: psql -d argiflow_db -f schema.sql

-- ============================================================
-- CORE / AUTH
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE workspaces (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  logo_url TEXT,
  plan VARCHAR(50) DEFAULT 'starter',
  stripe_customer_id VARCHAR(255),
  stripe_subscription_id VARCHAR(255),
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  avatar_url TEXT,
  role VARCHAR(50) DEFAULT 'member',
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMP,
  email_verified BOOLEAN DEFAULT false,
  verification_token VARCHAR(255),
  reset_token VARCHAR(255),
  reset_expires TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE api_keys (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  key_hash VARCHAR(255) UNIQUE NOT NULL,
  key_prefix VARCHAR(10) NOT NULL,
  last_used TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- CONTACTS / CRM (shared across modules)
-- ============================================================
CREATE TABLE contacts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  email VARCHAR(255),
  phone VARCHAR(50),
  company VARCHAR(255),
  title VARCHAR(100),
  address TEXT,
  city VARCHAR(100),
  state VARCHAR(100),
  country VARCHAR(100),
  zip VARCHAR(20),
  tags TEXT[],
  source VARCHAR(100),
  custom_fields JSONB DEFAULT '{}',
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 1: LANDING PAGE / FUNNEL BUILDER
-- ============================================================
CREATE TABLE funnels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) DEFAULT 'landing_page',
  slug VARCHAR(255) UNIQUE,
  custom_domain VARCHAR(255),
  status VARCHAR(50) DEFAULT 'draft',
  settings JSONB DEFAULT '{}',
  seo JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE funnel_steps (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  funnel_id UUID REFERENCES funnels(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  path VARCHAR(255),
  page_content JSONB DEFAULT '{}',
  split_tests JSONB DEFAULT '[]',
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE funnel_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  thumbnail_url TEXT,
  content JSONB DEFAULT '{}',
  is_global BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE page_visits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  funnel_step_id UUID REFERENCES funnel_steps(id) ON DELETE CASCADE,
  visitor_id VARCHAR(255),
  ip_address VARCHAR(50),
  user_agent TEXT,
  referrer TEXT,
  utm_source VARCHAR(100),
  utm_medium VARCHAR(100),
  utm_campaign VARCHAR(100),
  converted BOOLEAN DEFAULT false,
  visited_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 2: FORMS & SURVEYS BUILDER
-- ============================================================
CREATE TABLE forms (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) DEFAULT 'form',
  fields JSONB DEFAULT '[]',
  settings JSONB DEFAULT '{}',
  styling JSONB DEFAULT '{}',
  redirect_url TEXT,
  success_message TEXT,
  notifications JSONB DEFAULT '[]',
  status VARCHAR(50) DEFAULT 'active',
  embed_code TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE form_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  form_id UUID REFERENCES forms(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  data JSONB NOT NULL,
  ip_address VARCHAR(50),
  user_agent TEXT,
  source_url TEXT,
  submitted_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 3: CHAT WIDGET / LIVE CHAT
-- ============================================================
CREATE TABLE chat_widgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  settings JSONB DEFAULT '{}',
  welcome_message TEXT,
  offline_message TEXT,
  allowed_domains TEXT[],
  auto_rules JSONB DEFAULT '[]',
  bot_enabled BOOLEAN DEFAULT false,
  bot_flows JSONB DEFAULT '[]',
  status VARCHAR(50) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chat_conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  widget_id UUID REFERENCES chat_widgets(id),
  contact_id UUID REFERENCES contacts(id),
  assigned_to UUID REFERENCES users(id),
  visitor_name VARCHAR(255),
  visitor_email VARCHAR(255),
  status VARCHAR(50) DEFAULT 'open',
  channel VARCHAR(50) DEFAULT 'chat',
  tags TEXT[],
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID REFERENCES chat_conversations(id) ON DELETE CASCADE,
  sender_type VARCHAR(20) NOT NULL,
  sender_id VARCHAR(255),
  sender_name VARCHAR(255),
  content TEXT,
  attachments JSONB DEFAULT '[]',
  is_read BOOLEAN DEFAULT false,
  sent_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 4: INVOICING & PAYMENTS
-- ============================================================
CREATE TABLE invoice_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE UNIQUE,
  business_name VARCHAR(255),
  business_address TEXT,
  business_phone VARCHAR(50),
  business_email VARCHAR(255),
  logo_url TEXT,
  default_notes TEXT,
  default_terms TEXT,
  invoice_prefix VARCHAR(20) DEFAULT 'INV',
  next_invoice_number INTEGER DEFAULT 1001,
  tax_rate DECIMAL(5,2) DEFAULT 0,
  currency VARCHAR(10) DEFAULT 'USD',
  stripe_connect_id VARCHAR(255)
);

CREATE TABLE invoices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  invoice_number VARCHAR(50) NOT NULL,
  type VARCHAR(20) DEFAULT 'invoice',
  status VARCHAR(50) DEFAULT 'draft',
  issue_date DATE,
  due_date DATE,
  line_items JSONB DEFAULT '[]',
  subtotal DECIMAL(12,2) DEFAULT 0,
  tax_rate DECIMAL(5,2) DEFAULT 0,
  tax_amount DECIMAL(12,2) DEFAULT 0,
  discount_amount DECIMAL(12,2) DEFAULT 0,
  total DECIMAL(12,2) DEFAULT 0,
  amount_paid DECIMAL(12,2) DEFAULT 0,
  balance_due DECIMAL(12,2) DEFAULT 0,
  notes TEXT,
  terms TEXT,
  stripe_payment_intent_id VARCHAR(255),
  payment_link TEXT,
  recurring JSONB,
  sent_at TIMESTAMP,
  paid_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  invoice_id UUID REFERENCES invoices(id),
  amount DECIMAL(12,2) NOT NULL,
  method VARCHAR(50),
  stripe_charge_id VARCHAR(255),
  notes TEXT,
  paid_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 5: SOCIAL MEDIA MANAGEMENT
-- ============================================================
CREATE TABLE social_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  platform VARCHAR(50) NOT NULL,
  account_name VARCHAR(255),
  account_id VARCHAR(255),
  access_token TEXT,
  refresh_token TEXT,
  token_expires TIMESTAMP,
  profile_image TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE social_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  account_ids UUID[],
  content TEXT,
  media_urls TEXT[],
  status VARCHAR(50) DEFAULT 'draft',
  scheduled_at TIMESTAMP,
  published_at TIMESTAMP,
  platform_post_ids JSONB DEFAULT '{}',
  analytics JSONB DEFAULT '{}',
  tags TEXT[],
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE social_analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID REFERENCES social_posts(id) ON DELETE CASCADE,
  platform VARCHAR(50),
  impressions INTEGER DEFAULT 0,
  reach INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  fetched_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 6: REPUTATION MANAGEMENT
-- ============================================================
CREATE TABLE review_platforms (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  platform VARCHAR(50) NOT NULL,
  location_id VARCHAR(255),
  access_token TEXT,
  place_id VARCHAR(255),
  business_name VARCHAR(255),
  avg_rating DECIMAL(3,2),
  total_reviews INTEGER DEFAULT 0,
  last_synced TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  platform_id UUID REFERENCES review_platforms(id),
  external_id VARCHAR(255),
  reviewer_name VARCHAR(255),
  reviewer_avatar TEXT,
  rating INTEGER,
  content TEXT,
  response TEXT,
  responded_at TIMESTAMP,
  is_flagged BOOLEAN DEFAULT false,
  review_date TIMESTAMP,
  fetched_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE review_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  channel VARCHAR(20) DEFAULT 'email',
  platform VARCHAR(50),
  review_link TEXT,
  status VARCHAR(50) DEFAULT 'pending',
  sent_at TIMESTAMP DEFAULT NOW(),
  clicked_at TIMESTAMP
);

-- ============================================================
-- MODULE 7: WHATSAPP INTEGRATION
-- ============================================================
CREATE TABLE whatsapp_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  phone_number VARCHAR(50) NOT NULL,
  display_name VARCHAR(255),
  business_id VARCHAR(255),
  access_token TEXT,
  webhook_verified BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE whatsapp_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(50),
  language VARCHAR(10) DEFAULT 'en',
  header JSONB,
  body TEXT NOT NULL,
  footer TEXT,
  buttons JSONB DEFAULT '[]',
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 8: FACEBOOK / INSTAGRAM DMs
-- ============================================================
CREATE TABLE meta_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  platform VARCHAR(20) NOT NULL,
  page_id VARCHAR(255),
  page_name VARCHAR(255),
  access_token TEXT,
  instagram_id VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 9: CALENDAR SYNC
-- ============================================================
CREATE TABLE calendars (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  provider VARCHAR(50) NOT NULL,
  calendar_id VARCHAR(255),
  name VARCHAR(255),
  color VARCHAR(20),
  access_token TEXT,
  refresh_token TEXT,
  token_expires TIMESTAMP,
  sync_enabled BOOLEAN DEFAULT true,
  last_synced TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE calendar_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  calendar_id UUID REFERENCES calendars(id),
  external_id VARCHAR(255),
  title VARCHAR(500) NOT NULL,
  description TEXT,
  location VARCHAR(500),
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP NOT NULL,
  all_day BOOLEAN DEFAULT false,
  attendees JSONB DEFAULT '[]',
  status VARCHAR(50) DEFAULT 'confirmed',
  recurrence JSONB,
  contact_id UUID REFERENCES contacts(id),
  meeting_link TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE booking_pages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE,
  duration_minutes INTEGER DEFAULT 30,
  buffer_before INTEGER DEFAULT 0,
  buffer_after INTEGER DEFAULT 0,
  availability JSONB DEFAULT '{}',
  questions JSONB DEFAULT '[]',
  settings JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 10: DOCUMENT MANAGEMENT & E-SIGNATURES
-- ============================================================
CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) DEFAULT 'document',
  category VARCHAR(100),
  content JSONB DEFAULT '{}',
  file_url TEXT,
  status VARCHAR(50) DEFAULT 'draft',
  requires_signature BOOLEAN DEFAULT false,
  signed_at TIMESTAMP,
  expires_at TIMESTAMP,
  tags TEXT[],
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE document_signatures (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  signer_name VARCHAR(255),
  signer_email VARCHAR(255),
  signature_data TEXT,
  ip_address VARCHAR(50),
  signed_at TIMESTAMP,
  token VARCHAR(255) UNIQUE,
  status VARCHAR(50) DEFAULT 'pending'
);

CREATE TABLE document_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  content JSONB DEFAULT '{}',
  variables JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 11: GOOGLE BUSINESS PROFILE
-- ============================================================
CREATE TABLE gbp_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  location_id VARCHAR(255),
  business_name VARCHAR(255),
  address TEXT,
  phone VARCHAR(50),
  website VARCHAR(255),
  access_token TEXT,
  refresh_token TEXT,
  avg_rating DECIMAL(3,2),
  total_reviews INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE gbp_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  account_id UUID REFERENCES gbp_accounts(id),
  type VARCHAR(50) DEFAULT 'STANDARD',
  summary TEXT,
  media_url TEXT,
  action_type VARCHAR(50),
  action_url TEXT,
  event JSONB,
  status VARCHAR(50) DEFAULT 'draft',
  scheduled_at TIMESTAMP,
  published_at TIMESTAMP,
  external_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 12: MEMBERSHIP / COURSE PLATFORM
-- ============================================================
CREATE TABLE membership_sites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE,
  description TEXT,
  logo_url TEXT,
  theme JSONB DEFAULT '{}',
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  site_id UUID REFERENCES membership_sites(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  price DECIMAL(10,2) DEFAULT 0,
  is_free BOOLEAN DEFAULT false,
  status VARCHAR(50) DEFAULT 'draft',
  order_index INTEGER DEFAULT 0,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE course_sections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_id UUID REFERENCES courses(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE course_lessons (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  section_id UUID REFERENCES course_sections(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  type VARCHAR(50) DEFAULT 'video',
  content JSONB DEFAULT '{}',
  video_url TEXT,
  duration_seconds INTEGER,
  is_preview BOOLEAN DEFAULT false,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE course_enrollments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_id UUID REFERENCES courses(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  member_email VARCHAR(255),
  member_name VARCHAR(255),
  status VARCHAR(50) DEFAULT 'active',
  progress JSONB DEFAULT '{}',
  enrolled_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP
);

-- ============================================================
-- MODULE 13: A/B TESTING
-- ============================================================
CREATE TABLE ab_tests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL,
  target_id UUID,
  status VARCHAR(50) DEFAULT 'draft',
  goal VARCHAR(100),
  traffic_split INTEGER DEFAULT 50,
  variants JSONB DEFAULT '[]',
  results JSONB DEFAULT '{}',
  winner_variant VARCHAR(50),
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE ab_test_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  test_id UUID REFERENCES ab_tests(id) ON DELETE CASCADE,
  variant VARCHAR(50),
  event_type VARCHAR(50),
  visitor_id VARCHAR(255),
  metadata JSONB,
  recorded_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 14: PROPOSALS & ESTIMATES
-- ============================================================
CREATE TABLE proposals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  title VARCHAR(255) NOT NULL,
  proposal_number VARCHAR(50),
  status VARCHAR(50) DEFAULT 'draft',
  valid_until DATE,
  sections JSONB DEFAULT '[]',
  line_items JSONB DEFAULT '[]',
  subtotal DECIMAL(12,2) DEFAULT 0,
  discount DECIMAL(12,2) DEFAULT 0,
  tax DECIMAL(12,2) DEFAULT 0,
  total DECIMAL(12,2) DEFAULT 0,
  signature_required BOOLEAN DEFAULT true,
  client_signature TEXT,
  client_signed_at TIMESTAMP,
  notes TEXT,
  token VARCHAR(255) UNIQUE,
  viewed_at TIMESTAMP,
  sent_at TIMESTAMP,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 15: AFFILIATE MANAGEMENT
-- ============================================================
CREATE TABLE affiliate_programs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  commission_type VARCHAR(20) DEFAULT 'percentage',
  commission_value DECIMAL(10,2) NOT NULL,
  cookie_days INTEGER DEFAULT 30,
  min_payout DECIMAL(10,2) DEFAULT 50,
  payout_schedule VARCHAR(50) DEFAULT 'monthly',
  terms TEXT,
  status VARCHAR(50) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE affiliates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  program_id UUID REFERENCES affiliate_programs(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  name VARCHAR(255),
  email VARCHAR(255),
  referral_code VARCHAR(50) UNIQUE,
  status VARCHAR(50) DEFAULT 'pending',
  total_clicks INTEGER DEFAULT 0,
  total_referrals INTEGER DEFAULT 0,
  total_earnings DECIMAL(12,2) DEFAULT 0,
  balance DECIMAL(12,2) DEFAULT 0,
  payout_method JSONB,
  approved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE affiliate_referrals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  affiliate_id UUID REFERENCES affiliates(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  order_value DECIMAL(12,2),
  commission_amount DECIMAL(12,2),
  status VARCHAR(50) DEFAULT 'pending',
  converted_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE affiliate_payouts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  affiliate_id UUID REFERENCES affiliates(id) ON DELETE CASCADE,
  amount DECIMAL(12,2) NOT NULL,
  method VARCHAR(50),
  reference VARCHAR(255),
  status VARCHAR(50) DEFAULT 'pending',
  processed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 16: BLOG BUILDER
-- ============================================================
CREATE TABLE blog_sites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE,
  description TEXT,
  settings JSONB DEFAULT '{}',
  seo JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE blog_categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  site_id UUID REFERENCES blog_sites(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100),
  description TEXT
);

CREATE TABLE blog_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  site_id UUID REFERENCES blog_sites(id) ON DELETE CASCADE,
  category_id UUID REFERENCES blog_categories(id),
  author_id UUID REFERENCES users(id),
  title VARCHAR(500) NOT NULL,
  slug VARCHAR(500),
  excerpt TEXT,
  content TEXT,
  featured_image TEXT,
  tags TEXT[],
  status VARCHAR(50) DEFAULT 'draft',
  seo JSONB DEFAULT '{}',
  views INTEGER DEFAULT 0,
  published_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- MODULE 17: COMMUNITIES
-- ============================================================
CREATE TABLE communities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE,
  description TEXT,
  cover_image TEXT,
  is_private BOOLEAN DEFAULT false,
  settings JSONB DEFAULT '{}',
  member_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE community_channels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  community_id UUID REFERENCES communities(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  type VARCHAR(50) DEFAULT 'discussion',
  description TEXT,
  order_index INTEGER DEFAULT 0,
  is_private BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE community_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  community_id UUID REFERENCES communities(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  member_email VARCHAR(255),
  member_name VARCHAR(255),
  role VARCHAR(50) DEFAULT 'member',
  joined_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE community_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id UUID REFERENCES community_channels(id) ON DELETE CASCADE,
  author_id UUID REFERENCES community_members(id),
  title VARCHAR(500),
  content TEXT NOT NULL,
  media_urls TEXT[],
  likes INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  is_pinned BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE community_replies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID REFERENCES community_posts(id) ON DELETE CASCADE,
  author_id UUID REFERENCES community_members(id),
  content TEXT NOT NULL,
  likes INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- AUTOMATION / WORKFLOWS (cross-module)
-- ============================================================
CREATE TABLE workflows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  trigger JSONB NOT NULL,
  actions JSONB DEFAULT '[]',
  conditions JSONB DEFAULT '[]',
  status VARCHAR(50) DEFAULT 'active',
  run_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE workflow_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  status VARCHAR(50),
  data JSONB,
  error TEXT,
  executed_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  type VARCHAR(100) NOT NULL,
  title VARCHAR(255),
  message TEXT,
  link TEXT,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_contacts_workspace ON contacts(workspace_id);
CREATE INDEX idx_contacts_email ON contacts(email);
CREATE INDEX idx_invoices_workspace ON invoices(workspace_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_blog_posts_site ON blog_posts(site_id);
CREATE INDEX idx_blog_posts_status ON blog_posts(status);
CREATE INDEX idx_chat_conversations_workspace ON chat_conversations(workspace_id);
CREATE INDEX idx_chat_messages_conversation ON chat_messages(conversation_id);
CREATE INDEX idx_social_posts_workspace ON social_posts(workspace_id);
CREATE INDEX idx_social_posts_status ON social_posts(status);
CREATE INDEX idx_reviews_workspace ON reviews(workspace_id);
CREATE INDEX idx_community_posts_channel ON community_posts(channel_id);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
