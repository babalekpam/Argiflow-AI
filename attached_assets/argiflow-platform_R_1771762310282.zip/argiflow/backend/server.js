require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');
const cron = require('node-cron');

const app = express();
const server = http.createServer(app);

// ============================================================
// SOCKET.IO - Real-time chat
// ============================================================
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true,
  }
});

const connectedAgents = new Map();
const connectedVisitors = new Map();

io.on('connection', (socket) => {
  console.log(`Socket connected: ${socket.id}`);

  socket.on('agent:join', (data) => {
    const { workspaceId, userId } = data;
    socket.join(`workspace:${workspaceId}`);
    connectedAgents.set(socket.id, { workspaceId, userId });
    io.to(`workspace:${workspaceId}`).emit('agent:online', { userId, socketId: socket.id });
  });

  socket.on('visitor:join', (data) => {
    const { conversationId, widgetId } = data;
    socket.join(`conversation:${conversationId}`);
    connectedVisitors.set(socket.id, { conversationId, widgetId });
  });

  socket.on('message:send', async (data) => {
    const { conversationId, content, senderType, senderName } = data;
    const message = {
      id: Date.now().toString(),
      conversation_id: conversationId,
      sender_type: senderType,
      sender_name: senderName,
      content,
      sent_at: new Date().toISOString(),
    };
    // Broadcast to all in conversation room
    io.to(`conversation:${conversationId}`).emit('message:new', message);
  });

  socket.on('typing:start', (data) => {
    const { conversationId, name } = data;
    socket.to(`conversation:${conversationId}`).emit('typing:start', { name });
  });

  socket.on('typing:stop', (data) => {
    const { conversationId } = data;
    socket.to(`conversation:${conversationId}`).emit('typing:stop');
  });

  socket.on('disconnect', () => {
    const agent = connectedAgents.get(socket.id);
    if (agent) {
      io.to(`workspace:${agent.workspaceId}`).emit('agent:offline', { userId: agent.userId });
      connectedAgents.delete(socket.id);
    }
    connectedVisitors.delete(socket.id);
  });
});

// Make io available to routes
app.set('io', io);

// ============================================================
// MIDDLEWARE
// ============================================================
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 500,
  message: { error: 'Too many requests, please try again later' }
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Too many auth attempts' }
});
app.use('/api/', apiLimiter);

// ============================================================
// ROUTES
// ============================================================
const authRoutes = require('./routes/auth');
const funnelRoutes = require('./routes/funnels');
const formRoutes = require('./routes/forms');
const chatRoutes = require('./routes/chat');
const invoiceRoutes = require('./routes/invoices');
const socialRoutes = require('./routes/social');
const contactRoutes = require('./routes/contacts');
const { reputation, whatsapp, meta } = require('./routes/messaging');
const { calendar, documents, blog, communities, abTesting, proposals, affiliates, membership, gbp } = require('./routes/modules');

app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/contacts', contactRoutes);
app.use('/api/funnels', funnelRoutes);
app.use('/api/forms', formRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/social', socialRoutes);
app.use('/api/reputation', reputation);
app.use('/api/whatsapp', whatsapp);
app.use('/api/meta', meta);
app.use('/api/calendar', calendar);
app.use('/api/documents', documents);
app.use('/api/blog', blog);
app.use('/api/communities', communities);
app.use('/api/ab-tests', abTesting);
app.use('/api/proposals', proposals);
app.use('/api/affiliates', affiliates);
app.use('/api/membership', membership);
app.use('/api/gbp', gbp);

// Dashboard stats
app.get('/api/dashboard/stats', require('./middleware/auth').authenticate, async (req, res) => {
  try {
    const { query } = require('./config/database');
    const [contacts, invoices, conversations, formSubs, socialPosts] = await Promise.all([
      query('SELECT COUNT(*) FROM contacts WHERE workspace_id=$1', [req.workspaceId]),
      query('SELECT COUNT(*) FILTER (WHERE status=\'paid\') as paid, SUM(amount_paid) FILTER (WHERE paid_at >= NOW() - INTERVAL \'30 days\') as revenue_mtd FROM invoices WHERE workspace_id=$1', [req.workspaceId]),
      query('SELECT COUNT(*) FILTER (WHERE status=\'open\') as open FROM chat_conversations WHERE workspace_id=$1', [req.workspaceId]),
      query('SELECT COUNT(*) FROM form_submissions fs JOIN forms f ON f.id=fs.form_id WHERE f.workspace_id=$1 AND fs.submitted_at >= NOW() - INTERVAL \'30 days\'', [req.workspaceId]),
      query('SELECT COUNT(*) FROM social_posts WHERE workspace_id=$1 AND status=\'published\'', [req.workspaceId]),
    ]);
    res.json({
      totalContacts: parseInt(contacts.rows[0].count),
      openChats: parseInt(conversations.rows[0].open),
      revenueMtd: parseFloat(invoices.rows[0].revenue_mtd) || 0,
      formSubmissions: parseInt(formSubs.rows[0].count),
      publishedPosts: parseInt(socialPosts.rows[0].count),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0', timestamp: new Date().toISOString() });
});

// ============================================================
// CRON JOBS
// ============================================================
// Publish scheduled social posts every 5 minutes
cron.schedule('*/5 * * * *', async () => {
  try {
    const { query } = require('./config/database');
    const posts = await query(
      "SELECT * FROM social_posts WHERE status='scheduled' AND scheduled_at <= NOW()",
    );
    for (const post of posts.rows) {
      await query("UPDATE social_posts SET status='published', published_at=NOW() WHERE id=$1", [post.id]);
      console.log(`Auto-published social post: ${post.id}`);
    }
  } catch (err) {
    console.error('Cron - social posts:', err.message);
  }
});

// Mark overdue invoices daily at midnight
cron.schedule('0 0 * * *', async () => {
  try {
    const { query } = require('./config/database');
    await query("UPDATE invoices SET status='overdue' WHERE due_date < CURRENT_DATE AND status IN ('sent','partial') AND balance_due > 0");
    console.log('Updated overdue invoices');
  } catch (err) {
    console.error('Cron - invoices:', err.message);
  }
});

// ============================================================
// ERROR HANDLING
// ============================================================
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
});

app.use('*', (req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// ============================================================
// START SERVER
// ============================================================
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`
🚀 ArgiFlow Server running on port ${PORT}
📡 Environment: ${process.env.NODE_ENV || 'development'}
🔌 WebSocket: enabled
🗄️  Database: ${process.env.DATABASE_URL ? 'configured' : 'NOT CONFIGURED'}
  `);
});

module.exports = { app, server, io };
