# ArgiFlow Platform

A complete all-in-one business platform with 18 integrated modules built on Node.js/Express + React + PostgreSQL.

## 🚀 Modules Included

### Core
- **Contacts CRM** - Central contact database shared across all modules
- **Dashboard** - Real-time stats and quick actions

### Lead Capture
- **Landing Page / Funnel Builder** - Drag-and-drop page builder with analytics
- **Forms & Surveys Builder** - Multi-step forms with conditional logic
- **Chat Widget / Live Chat** - Real-time visitor chat with Socket.io

### Revenue
- **Invoicing & Payments** - Stripe-integrated invoicing and payment tracking
- **Proposals & Estimates** - E-signature-enabled quote builder
- **Affiliate Management** - Referral tracking and commission management

### Publishing
- **Social Media Management** - Multi-platform post scheduling
- **Blog Builder** - SEO-optimized content platform
- **Google Business Profile** - GBP post management

### Messaging
- **WhatsApp Integration** - Two-way WhatsApp via Twilio
- **Facebook / Instagram DMs** - Meta platform direct messaging

### Operations
- **Reputation Management** - Review monitoring and response
- **Calendar Sync** - Events and booking pages
- **Document Management & E-Signatures** - Contract builder with digital signatures

### Growth
- **Membership / Course Platform** - Course creation and enrollment
- **Communities** - Forum and community spaces
- **A/B Testing** - Split testing for emails and pages

---

## ⚡ Quick Start (Docker)

```bash
# 1. Clone and configure
cp backend/.env.example backend/.env
# Edit backend/.env with your keys

# 2. Start everything
docker-compose up -d

# App will be at:
# Frontend: http://localhost:3000
# Backend API: http://localhost:5000
# Database: localhost:5432
```

## 🔧 Local Development

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- npm or yarn

### Setup

```bash
# 1. Install dependencies
npm run install:all

# 2. Setup database
createdb argiflow_db
psql argiflow_db < backend/config/schema.sql

# 3. Configure environment
cp backend/.env.example backend/.env
# Edit .env with your values

# 4. Run development servers
npm run dev
# Backend: http://localhost:5000
# Frontend: http://localhost:3000
```

## 🔑 Environment Variables

```env
# Required
DATABASE_URL=postgresql://user:pass@localhost:5432/argiflow_db
JWT_SECRET=your_secret_key

# Payments (Stripe)
STRIPE_SECRET_KEY=sk_live_...

# WhatsApp (Twilio)
TWILIO_ACCOUNT_SID=ACxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxx
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886

# Email (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@email.com
SMTP_PASS=your_app_password

# Meta (Facebook/Instagram)
META_APP_ID=xxxxxxx
META_APP_SECRET=xxxxxxx
META_WEBHOOK_VERIFY_TOKEN=your_token
```

## 📁 Project Structure

```
argiflow/
├── backend/
│   ├── config/
│   │   ├── database.js      # PostgreSQL connection
│   │   └── schema.sql       # Complete DB schema
│   ├── middleware/
│   │   └── auth.js          # JWT authentication
│   ├── routes/
│   │   ├── auth.js          # Auth endpoints
│   │   ├── contacts.js      # Contacts CRUD
│   │   ├── funnels.js       # Funnel builder API
│   │   ├── forms.js         # Forms & submissions
│   │   ├── chat.js          # Live chat API
│   │   ├── invoices.js      # Invoicing & Stripe
│   │   ├── social.js        # Social media
│   │   ├── messaging.js     # WhatsApp, Meta DMs, Reputation
│   │   └── modules.js       # Calendar, Docs, Blog, Communities, A/B, Proposals, Affiliates, Membership, GBP
│   ├── server.js            # Express + Socket.io server
│   └── .env.example
├── frontend/
│   └── src/
│       ├── context/
│       │   └── AuthContext.js
│       ├── pages/           # 18+ page components
│       ├── components/
│       │   └── shared/
│       │       └── DashboardLayout.js
│       └── utils/
│           └── api.js       # All API calls
├── docker-compose.yml
└── README.md
```

## 🔌 API Endpoints

All endpoints are prefixed with `/api/`

| Module | Base Path |
|--------|-----------|
| Auth | `/api/auth` |
| Contacts | `/api/contacts` |
| Funnels | `/api/funnels` |
| Forms | `/api/forms` |
| Chat | `/api/chat` |
| Invoices | `/api/invoices` |
| Social | `/api/social` |
| Reputation | `/api/reputation` |
| WhatsApp | `/api/whatsapp` |
| Meta DMs | `/api/meta` |
| Calendar | `/api/calendar` |
| Documents | `/api/documents` |
| Blog | `/api/blog` |
| Communities | `/api/communities` |
| A/B Tests | `/api/ab-tests` |
| Proposals | `/api/proposals` |
| Affiliates | `/api/affiliates` |
| Membership | `/api/membership` |
| GBP | `/api/gbp` |
| Dashboard | `/api/dashboard/stats` |

## 🏗️ Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, React Router 6, TanStack Query, Tailwind CSS |
| Backend | Node.js, Express 4, Socket.io |
| Database | PostgreSQL 15 |
| Auth | JWT (jsonwebtoken + bcryptjs) |
| Payments | Stripe |
| Messaging | Twilio (WhatsApp/SMS) |
| Real-time | Socket.io |
| Scheduling | node-cron |
| Deployment | Docker + Docker Compose |

## 🛡️ Security Features
- JWT authentication on all protected routes
- bcrypt password hashing (12 rounds)
- Rate limiting (500 req/15min general, 20 req/15min auth)
- CORS configured per-origin
- Helmet.js security headers
- SQL injection prevention via parameterized queries
- Input validation with Joi

## 📄 License
Proprietary - ARGILETTE LLC / ArgiFlow
