/**
 * ToolConnectors.js
 * Real integrations that actually DO things.
 * Each connector talks to a live API — not just drafting.
 *
 * Connectors:
 *   Gmail        — Read inbox, send emails, check for replies
 *   Google Cal   — Check availability, create events, send invites
 *   Stripe       — Read revenue, paid/overdue invoices, customer list
 *   Amazon SES   — Bulk outreach emails (ArgiFlow's existing setup)
 *   Twilio       — SMS the owner their daily briefing
 */

const https = require('https');
const http = require('http');

function post(url, headers, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const data = JSON.stringify(body);
    const req = lib.request({
      hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data), ...headers }
    }, res => {
      let raw = '';
      res.on('data', c => raw += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); } catch { resolve({ status: res.statusCode, body: raw }); } });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function get(url, headers) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request({
      hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search, method: 'GET', headers
    }, res => {
      let raw = '';
      res.on('data', c => raw += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); } catch { resolve({ status: res.statusCode, body: raw }); } });
    });
    req.on('error', reject);
    req.end();
  });
}

// ─── Gmail Connector ──────────────────────────────────────────────────────────
// Uses Gmail API with OAuth2 token stored per user

const Gmail = {
  async sendEmail(accessToken, { to, toName, subject, body, fromName }) {
    const emailLines = [
      `From: ${fromName || 'Your Business'} <me>`,
      `To: ${toName ? `${toName} <${to}>` : to}`,
      `Subject: ${subject}`,
      `Content-Type: text/plain; charset=utf-8`,
      '',
      body
    ];
    const raw = Buffer.from(emailLines.join('\r\n')).toString('base64url');

    const res = await post(
      'https://gmail.googleapis.com/gmail/v1/users/me/messages/send',
      { Authorization: `Bearer ${accessToken}` },
      { raw }
    );

    if (res.status !== 200) throw new Error(`Gmail send failed: ${JSON.stringify(res.body)}`);
    return { messageId: res.body.id, status: 'sent' };
  },

  async getUnreadReplies(accessToken, afterDate) {
    const query = `is:unread in:inbox after:${Math.floor(new Date(afterDate).getTime() / 1000)}`;
    const res = await get(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${encodeURIComponent(query)}&maxResults=20`,
      { Authorization: `Bearer ${accessToken}` }
    );
    return res.body?.messages || [];
  },

  async getMessageDetail(accessToken, messageId) {
    const res = await get(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}?format=full`,
      { Authorization: `Bearer ${accessToken}` }
    );
    const headers = res.body?.payload?.headers || [];
    const get_ = name => headers.find(h => h.name.toLowerCase() === name)?.value || '';
    const body = extractGmailBody(res.body?.payload);
    return { from: get_('from'), subject: get_('subject'), date: get_('date'), body };
  }
};

function extractGmailBody(payload) {
  if (!payload) return '';
  if (payload.body?.data) return Buffer.from(payload.body.data, 'base64').toString();
  if (payload.parts) {
    for (const part of payload.parts) {
      if (part.mimeType === 'text/plain' && part.body?.data) {
        return Buffer.from(part.body.data, 'base64').toString();
      }
    }
  }
  return '';
}

// ─── Google Calendar Connector ────────────────────────────────────────────────

const GoogleCal = {
  async getAvailability(accessToken, date) {
    const start = new Date(date); start.setHours(9, 0, 0, 0);
    const end = new Date(date); end.setHours(17, 0, 0, 0);

    const res = await post(
      'https://www.googleapis.com/calendar/v3/freeBusy',
      { Authorization: `Bearer ${accessToken}` },
      { timeMin: start.toISOString(), timeMax: end.toISOString(), items: [{ id: 'primary' }] }
    );
    const busy = res.body?.calendars?.primary?.busy || [];
    return { date, busy, available_slots: getFreeSlots(start, end, busy) };
  },

  async createEvent(accessToken, { title, startTime, endTime, attendeeEmail, attendeeName, description }) {
    const event = {
      summary: title,
      description,
      start: { dateTime: new Date(startTime).toISOString() },
      end: { dateTime: new Date(endTime).toISOString() },
      attendees: attendeeEmail ? [{ email: attendeeEmail, displayName: attendeeName }] : [],
      conferenceData: { createRequest: { requestId: Date.now().toString() } }
    };

    const res = await post(
      'https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1&sendUpdates=all',
      { Authorization: `Bearer ${accessToken}` },
      event
    );

    if (res.status !== 200) throw new Error(`Calendar event failed: ${JSON.stringify(res.body)}`);
    return { eventId: res.body.id, meetLink: res.body.conferenceData?.entryPoints?.[0]?.uri, status: 'created' };
  },

  async getTodaysMeetings(accessToken) {
    const start = new Date(); start.setHours(0,0,0,0);
    const end = new Date(); end.setHours(23,59,59,999);

    const res = await get(
      `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${start.toISOString()}&timeMax=${end.toISOString()}&singleEvents=true&orderBy=startTime`,
      { Authorization: `Bearer ${accessToken}` }
    );
    return res.body?.items || [];
  }
};

function getFreeSlots(start, end, busy) {
  const slots = [];
  const busyRanges = busy.map(b => ({ s: new Date(b.start), e: new Date(b.end) }));
  const step = 60 * 60 * 1000; // 1 hour slots

  for (let t = start.getTime(); t < end.getTime() - step; t += step) {
    const slotStart = new Date(t);
    const slotEnd = new Date(t + step);
    const isBusy = busyRanges.some(b => slotStart < b.e && slotEnd > b.s);
    if (!isBusy) slots.push({ start: slotStart.toISOString(), end: slotEnd.toISOString() });
  }
  return slots;
}

// ─── Stripe Connector ─────────────────────────────────────────────────────────

const Stripe = {
  async getRevenueMTD(apiKey) {
    const start = new Date(); start.setDate(1); start.setHours(0,0,0,0);

    const res = await get(
      `https://api.stripe.com/v1/charges?created[gte]=${Math.floor(start.getTime()/1000)}&limit=100`,
      { Authorization: `Basic ${Buffer.from(apiKey + ':').toString('base64')}` }
    );

    const charges = res.body?.data || [];
    const total = charges.filter(c => c.status === 'succeeded').reduce((sum, c) => sum + c.amount, 0);
    return { revenue_mtd: total / 100, charge_count: charges.length };
  },

  async getOverdueInvoices(apiKey) {
    const res = await get(
      `https://api.stripe.com/v1/invoices?status=open&limit=50`,
      { Authorization: `Basic ${Buffer.from(apiKey + ':').toString('base64')}` }
    );

    const now = Date.now() / 1000;
    const overdue = (res.body?.data || []).filter(inv => inv.due_date && inv.due_date < now);
    return overdue.map(inv => ({
      id: inv.id,
      amount: inv.amount_due / 100,
      customer_email: inv.customer_email,
      customer_name: inv.customer_name,
      due_date: new Date(inv.due_date * 1000).toLocaleDateString(),
      days_overdue: Math.floor((now - inv.due_date) / 86400)
    }));
  },

  async getRecentCustomers(apiKey, limit = 20) {
    const res = await get(
      `https://api.stripe.com/v1/customers?limit=${limit}`,
      { Authorization: `Basic ${Buffer.from(apiKey + ':').toString('base64')}` }
    );
    return (res.body?.data || []).map(c => ({
      id: c.id, name: c.name, email: c.email,
      created: new Date(c.created * 1000).toLocaleDateString()
    }));
  }
};

// ─── Amazon SES Connector (ArgiFlow's existing setup) ─────────────────────────

const SES = {
  async sendEmail({ from, to, toName, subject, body }) {
    const AWS = require('@aws-sdk/client-ses');
    const client = new AWS.SESClient({
      region: process.env.AWS_REGION || 'us-east-1',
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
      }
    });

    await client.send(new AWS.SendEmailCommand({
      Source: from,
      Destination: { ToAddresses: [toName ? `${toName} <${to}>` : to] },
      Message: {
        Subject: { Data: subject },
        Body: { Text: { Data: body } }
      }
    }));

    return { status: 'sent', to };
  },

  async sendBulk(emails) {
    const results = [];
    for (const email of emails) {
      try {
        const r = await SES.sendEmail(email);
        results.push({ ...r, email: email.to });
        await new Promise(res => setTimeout(res, 100)); // Rate limit
      } catch (err) {
        results.push({ status: 'failed', email: email.to, error: err.message });
      }
    }
    return results;
  }
};

// ─── Twilio SMS (daily briefing to owner) ─────────────────────────────────────

const Twilio = {
  async sendSMS(to, message) {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_PHONE;
    if (!sid || !token || !from) throw new Error('Twilio not configured');

    const res = await post(
      `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`,
      {
        Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString('base64')}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      null
    );
    // Twilio uses form encoding — handle separately
    return { status: 'sent', sid: res.body?.sid };
  }
};

// ─── Token storage helper (per user OAuth tokens) ────────────────────────────
// Store in your existing Postgres

const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const Tokens = {
  async save(userId, tool, tokenData) {
    await pool.query(
      `INSERT INTO aria_tokens (user_id, tool, token_data, updated_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (user_id, tool) DO UPDATE SET token_data = $3, updated_at = NOW()`,
      [userId, tool, JSON.stringify(tokenData)]
    );
  },

  async get(userId, tool) {
    const r = await pool.query(
      'SELECT token_data FROM aria_tokens WHERE user_id = $1 AND tool = $2',
      [userId, tool]
    );
    return r.rows[0]?.token_data || null;
  },

  async list(userId) {
    const r = await pool.query(
      'SELECT tool FROM aria_tokens WHERE user_id = $1',
      [userId]
    );
    return r.rows.map(r => r.tool);
  }
};

// Add token table to schema (run once)
async function ensureTokenTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS aria_tokens (
      id         SERIAL PRIMARY KEY,
      user_id    TEXT NOT NULL,
      tool       TEXT NOT NULL,
      token_data JSONB NOT NULL,
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE(user_id, tool)
    )
  `);
}
ensureTokenTable().catch(console.error);

module.exports = { Gmail, GoogleCal, Stripe, SES, Twilio, Tokens };
