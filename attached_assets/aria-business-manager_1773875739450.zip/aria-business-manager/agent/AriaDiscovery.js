/**
 * AriaDiscovery.js
 * Onboarding conversation — designed for non-technical small business owners.
 * No mention of APIs, databases, tech tools, or jargon.
 * Aria asks about the BUSINESS, not the software.
 */

const ai = require('../../argiflow-ai-adapter');
const db = require('./AriaMemory');

const SYSTEM = `You are Aria, a business manager AI. You're meeting a small business owner for the first time to learn about their business so you can manage it for them.

They are NOT technical. Do NOT mention:
- APIs, databases, software, code, tech tools
- How you work internally
- Integrations, connectors, webhooks

DO ask about:
- What their business does and who their customers are
- How they get new customers today
- What their biggest headaches are week to week
- How much a typical job/service costs
- How many customers they currently have
- What tools they use day to day (email, calendar, etc.) — in plain terms
- What they WISH they had more time for
- How hands-on they want to be — do they want to approve things or just see reports?

Your response ALWAYS has two parts:

PART 1 — Extract what you learned in this tag:
<learn>
{
  "name": null,
  "type": null,
  "owner_name": null,
  "owner_email": null,
  "owner_phone": null,
  "location": null,
  "website": null,
  "main_service": null,
  "price_range": null,
  "avg_job_value": null,
  "customer_type": null,
  "service_area": null,
  "autonomy": null,
  "briefing_via": null
}
</learn>
Only include fields mentioned in this message. Skip nulls.

PART 2 — Your reply (after the tag).

Conversation rules:
- ONE question at a time
- Sound like a friendly, confident business advisor — not a chatbot
- Mirror their language (if they say "jobs" don't say "engagements")
- Validate what they say: "Got it — so most of your customers come from word of mouth. That's common for local services."
- When you have enough info (score 70+), tell them you're ready to start and explain the 3-4 things you'll handle for them
- Keep replies short — 2-4 sentences then your question`;

async function onboardingTurn(userId, message) {
  let biz = await db.getBusiness(userId);
  if (!biz) biz = await db.createBusiness(userId);

  await db.saveDiscovery(userId, 'user', message);
  const history = await db.getDiscoveryHistory(userId);
  const messages = history.map(h => ({ role: h.role, content: h.content }));

  const score = biz.onboard_score || 0;
  const ctx = `[Current score: ${score}/100. What we know: name=${biz.name}, type=${biz.type}, service=${biz.main_service}, customers=${biz.customer_type}]`;

  const reply = await ai.chat(messages, {
    system: SYSTEM + '\n\n' + ctx,
    maxTokens: 350
  });

  // Extract learned data
  const learned = parseLearn(reply);
  const cleanReply = reply.replace(/<learn>[\s\S]*?<\/learn>\n?/, '').trim();

  // Update score
  const fields = ['name','type','main_service','customer_type','avg_job_value','owner_email','autonomy'];
  const merged = { ...biz, ...learned };
  const newScore = Math.round((fields.filter(f => merged[f]).length / fields.length) * 100);

  const updates = {
    ...learned,
    onboard_score: newScore,
    onboarded: newScore >= 70
  };
  // Flatten any top-level fields
  if (learned.name) updates.name = learned.name;
  if (learned.type) updates.type = learned.type;
  if (learned.owner_name) updates.owner_name = learned.owner_name;
  if (learned.owner_email) updates.owner_email = learned.owner_email;
  if (learned.main_service) updates.main_service = learned.main_service;
  if (learned.avg_job_value) updates.avg_job_value = parseFloat(learned.avg_job_value) || null;
  if (learned.customer_type) updates.customer_type = learned.customer_type;
  if (learned.autonomy) updates.autonomy = learned.autonomy;
  if (learned.briefing_via) updates.briefing_via = learned.briefing_via;

  await db.updateBusiness(userId, updates);
  await db.saveDiscovery(userId, 'assistant', cleanReply);

  return {
    reply: cleanReply,
    onboard_score: newScore,
    onboarded: newScore >= 70
  };
}

function parseLearn(text) {
  try {
    const match = text.match(/<learn>([\s\S]*?)<\/learn>/);
    if (!match) return {};
    const parsed = JSON.parse(match[1].trim());
    return Object.fromEntries(
      Object.entries(parsed).filter(([, v]) => v !== null && v !== '')
    );
  } catch { return {}; }
}

async function getOpening(userId) {
  if (!await db.getBusiness(userId)) await db.createBusiness(userId);

  const msg = `Hi! I'm Aria, your AI business manager. 👋

Here's how this works: I'm going to ask you a few questions about your business — nothing technical, just basics. Once I understand what you do and who your customers are, I'll start managing things for you automatically.

That means I'll send follow-up emails to leads, remind customers about unpaid invoices, book appointments, and send you a simple daily update on what's happening.

You just run your business. I handle the admin.

**Let's start — what's your name and what kind of business do you run?**`;

  await db.saveDiscovery(userId, 'assistant', msg);
  return { reply: msg, onboard_score: 0, onboarded: false };
}

module.exports = { onboardingTurn, getOpening };
