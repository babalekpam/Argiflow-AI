/**
 * AriaMemory.js — All database operations
 */

const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ─── Business ─────────────────────────────────────────────────────────────────

async function getBusiness(userId) {
  const r = await pool.query('SELECT * FROM aria_business WHERE user_id = $1', [userId]);
  return r.rows[0] || null;
}

async function createBusiness(userId) {
  const r = await pool.query(
    `INSERT INTO aria_business (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING RETURNING *`,
    [userId]
  );
  return r.rows[0] || await getBusiness(userId);
}

async function updateBusiness(userId, fields) {
  const keys = Object.keys(fields);
  if (!keys.length) return getBusiness(userId);
  const sets = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
  await pool.query(
    `UPDATE aria_business SET ${sets}, updated_at = NOW() WHERE user_id = $1`,
    [userId, ...Object.values(fields)]
  );
  return getBusiness(userId);
}

// ─── Leads ────────────────────────────────────────────────────────────────────

async function saveLead(userId, lead) {
  const r = await pool.query(
    `INSERT INTO aria_leads (user_id, name, email, phone, company, source, status, deal_value, notes, next_followup)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [userId, lead.name, lead.email, lead.phone, lead.company, lead.source,
     lead.status || 'new', lead.deal_value, lead.notes, lead.next_followup]
  );
  return r.rows[0];
}

async function updateLead(leadId, fields) {
  const keys = Object.keys(fields);
  const sets = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
  await pool.query(
    `UPDATE aria_leads SET ${sets}, updated_at = NOW() WHERE id = $1`,
    [leadId, ...Object.values(fields)]
  );
}

async function getAllLeads(userId) {
  const r = await pool.query(
    `SELECT * FROM aria_leads WHERE user_id = $1 ORDER BY updated_at DESC`,
    [userId]
  );
  return r.rows;
}

async function getLeadsDue(userId) {
  const r = await pool.query(
    `SELECT * FROM aria_leads WHERE user_id = $1
     AND status NOT IN ('won','lost')
     AND (next_followup IS NULL OR next_followup <= NOW())
     ORDER BY next_followup ASC LIMIT 20`,
    [userId]
  );
  return r.rows;
}

// ─── Actions ──────────────────────────────────────────────────────────────────

async function saveAction(userId, action) {
  const r = await pool.query(
    `INSERT INTO aria_actions (user_id, category, title, description, tool_used, tool_result, output_preview, status, lead_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [userId, action.category, action.title, action.description, action.tool_used,
     JSON.stringify(action.tool_result || {}), action.output_preview,
     action.status || 'completed', action.lead_id || null]
  );
  return r.rows[0];
}

async function updateAction(actionId, fields) {
  const keys = Object.keys(fields);
  const sets = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
  await pool.query(`UPDATE aria_actions SET ${sets} WHERE id = $1`, [actionId, ...Object.values(fields)]);
}

async function getAction(actionId, userId) {
  const r = await pool.query(
    'SELECT * FROM aria_actions WHERE id = $1 AND user_id = $2', [actionId, userId]
  );
  return r.rows[0] || null;
}

async function getRecentActions(userId, limit = 20) {
  const r = await pool.query(
    `SELECT * FROM aria_actions WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return r.rows;
}

async function getPendingActions(userId) {
  const r = await pool.query(
    `SELECT * FROM aria_actions WHERE user_id = $1 AND status = 'needs_approval' ORDER BY created_at DESC`,
    [userId]
  );
  return r.rows;
}

// ─── Emails ───────────────────────────────────────────────────────────────────

async function saveEmail(userId, email) {
  await pool.query(
    `INSERT INTO aria_emails (user_id, action_id, lead_id, to_email, to_name, subject, body, sent_at, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [userId, email.actionId || null, email.leadId || null, email.to, email.toName,
     email.subject, email.body, email.sent_at || null, email.status || 'draft']
  );
}

// ─── Snapshot ─────────────────────────────────────────────────────────────────

async function saveSnapshot(userId, data) {
  await pool.query(
    `INSERT INTO aria_snapshots (user_id, revenue_mtd, leads_total, emails_sent, meetings_booked, invoices_overdue, actions_taken)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [userId, data.revenue_mtd, data.leads_total, data.emails_sent, data.meetings_booked, data.invoices_overdue, data.actions_taken]
  );
}

async function getLatestSnapshot(userId) {
  const r = await pool.query(
    `SELECT * FROM aria_snapshots WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
    [userId]
  );
  return r.rows[0] || null;
}

// ─── Discovery ────────────────────────────────────────────────────────────────

async function saveDiscovery(userId, role, content) {
  await pool.query('INSERT INTO aria_discovery (user_id, role, content) VALUES ($1,$2,$3)', [userId, role, content]);
}

async function getDiscoveryHistory(userId) {
  const r = await pool.query('SELECT role, content FROM aria_discovery WHERE user_id = $1 ORDER BY created_at ASC', [userId]);
  return r.rows;
}

// ─── Chat ─────────────────────────────────────────────────────────────────────

async function saveChatMessage(userId, role, content) {
  await pool.query('INSERT INTO aria_chat (user_id, role, content) VALUES ($1,$2,$3)', [userId, role, content]);
}

async function getChatHistory(userId, limit = 15) {
  const r = await pool.query(
    `SELECT role, content FROM aria_chat WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return r.rows.reverse();
}

// ─── Briefings ────────────────────────────────────────────────────────────────

async function saveBriefing(userId, content) {
  await pool.query('INSERT INTO aria_briefings (user_id, content) VALUES ($1,$2)', [userId, content]);
}

async function getBriefings(userId, limit = 7) {
  const r = await pool.query(
    `SELECT * FROM aria_briefings WHERE user_id = $1 ORDER BY sent_at DESC LIMIT $2`,
    [userId, limit]
  );
  return r.rows;
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

async function getDashboard(userId) {
  const [biz, leads, actions, pending, snapshot, briefings] = await Promise.all([
    getBusiness(userId),
    getAllLeads(userId),
    getRecentActions(userId, 20),
    getPendingActions(userId),
    getLatestSnapshot(userId),
    getBriefings(userId, 3)
  ]);

  return { biz, leads, actions, pending, snapshot, briefings };
}

module.exports = {
  getBusiness, createBusiness, updateBusiness,
  saveLead, updateLead, getAllLeads, getLeadsDue,
  saveAction, updateAction, getAction, getRecentActions, getPendingActions,
  saveEmail, saveSnapshot, getLatestSnapshot,
  saveDiscovery, getDiscoveryHistory,
  saveChatMessage, getChatHistory,
  saveBriefing, getBriefings,
  getDashboard
};
