/**
 * AriaAgent.js
 * The autonomous business manager.
 *
 * Every morning Aria:
 *   1. Reads real data (Stripe revenue, Gmail replies, calendar)
 *   2. Decides what needs attention TODAY
 *   3. Takes real actions (sends emails, books meetings, follows up)
 *   4. Tells the owner what she did in plain English
 *
 * No tech knowledge required from the owner.
 * Aria handles everything and reports back.
 */

const ai = require('../../argiflow-ai-adapter');
const db = require('./AriaMemory');
const { Gmail, GoogleCal, Stripe, SES, Tokens } = require('../connectors/ToolConnectors');

// ─── The daily brain cycle ────────────────────────────────────────────────────

async function runDailyCycle(userId) {
  const biz = await db.getBusiness(userId);
  if (!biz?.onboarded) throw new Error('Onboarding not complete');

  const log = [];
  const connectedTools = await Tokens.list(userId);

  // ── 1. Read all available real data ───────────────────────────────────────

  const realData = { revenue: null, overdue: [], replies: [], todayMeetings: [], leads: [] };

  if (connectedTools.includes('stripe')) {
    try {
      const stripeKey = (await Tokens.get(userId, 'stripe'))?.secret_key;
      if (stripeKey) {
        realData.revenue = await Stripe.getRevenueMTD(stripeKey);
        realData.overdue = await Stripe.getOverdueInvoices(stripeKey);
      }
    } catch (e) { log.push(`⚠️ Stripe read failed: ${e.message}`); }
  }

  if (connectedTools.includes('gmail')) {
    try {
      const gmailToken = await Tokens.get(userId, 'gmail');
      if (gmailToken) {
        const yesterday = new Date(Date.now() - 86400000).toISOString();
        const unreadIds = await Gmail.getUnreadReplies(gmailToken.access_token, yesterday);
        for (const msg of unreadIds.slice(0, 10)) {
          const detail = await Gmail.getMessageDetail(gmailToken.access_token, msg.id);
          realData.replies.push(detail);
        }
      }
    } catch (e) { log.push(`⚠️ Gmail read failed: ${e.message}`); }
  }

  if (connectedTools.includes('google_calendar')) {
    try {
      const calToken = await Tokens.get(userId, 'google_calendar');
      if (calToken) {
        realData.todayMeetings = await GoogleCal.getTodaysMeetings(calToken.access_token);
      }
    } catch (e) { log.push(`⚠️ Calendar read failed: ${e.message}`); }
  }

  // Always read leads from our own DB
  realData.leads = await db.getLeadsDue(userId);

  // ── 2. Ask the AI what to do with this real data ──────────────────────────

  const decisions = await decideActions(biz, realData);

  // ── 3. Execute each decision ───────────────────────────────────────────────

  const results = [];

  for (const decision of decisions) {
    try {
      const result = await executeDecision(userId, biz, decision, connectedTools);
      results.push({ decision: decision.title, ...result });
    } catch (err) {
      results.push({ decision: decision.title, status: 'failed', error: err.message });
    }
    await new Promise(r => setTimeout(r, 500));
  }

  // ── 4. Take snapshot of today's numbers ───────────────────────────────────

  await db.saveSnapshot(userId, {
    revenue_mtd: realData.revenue?.revenue_mtd || 0,
    leads_total: (await db.getAllLeads(userId)).length,
    emails_sent: results.filter(r => r.type === 'email').length,
    meetings_booked: results.filter(r => r.type === 'meeting').length,
    invoices_overdue: realData.overdue.length,
    actions_taken: results.filter(r => r.status === 'completed').length
  });

  // ── 5. Write and send the daily briefing ─────────────────────────────────

  const briefing = await writeBriefing(biz, realData, results);
  await sendBriefing(userId, biz, briefing, connectedTools);
  await db.saveBriefing(userId, briefing);

  return { briefing, results, log };
}

// ─── AI decision maker ────────────────────────────────────────────────────────

async function decideActions(biz, realData) {
  const prompt = `You manage ${biz.name}, a ${biz.type} owned by ${biz.owner_name}.

## Real data from today:
- Revenue this month: $${realData.revenue?.revenue_mtd || 'unknown'}
- Overdue invoices: ${realData.overdue.length} (${realData.overdue.map(i => `$${i.amount} from ${i.customer_name || i.customer_email} - ${i.days_overdue} days late`).join('; ') || 'none'})
- Email replies to respond to: ${realData.replies.length} (${realData.replies.map(r => r.from).join(', ') || 'none'})
- Leads due for follow-up: ${realData.leads.length} (${realData.leads.map(l => l.name + ' - ' + l.status).join(', ') || 'none'})
- Meetings today: ${realData.todayMeetings.length}

## Business context:
- Main service: ${biz.main_service}
- Typical customer: ${biz.customer_type}
- Average job value: $${biz.avg_job_value || 'unknown'}

Decide what to do TODAY. Think like a business manager who handles everything for the owner.

Return JSON:
{
  "decisions": [
    {
      "title": "Short description",
      "type": "follow_up_email | invoice_reminder | new_lead_outreach | reply_to_lead | book_meeting | internal_report",
      "priority": 1,
      "why": "Why this matters today",
      "tool": "gmail | ses | gcal | none",
      "needs_approval": false,
      "data": { "any extra data needed to execute" }
    }
  ]
}

Be specific. Only create decisions you can actually execute. Max 8 decisions.`;

  const result = await ai.chatJSON(prompt, {
    system: `You are an autonomous business manager AI. You make practical decisions based on real business data and execute them. Focus on revenue, follow-ups, and keeping leads moving forward.`,
    maxTokens: 1500
  });

  return result.decisions || [];
}

// ─── Execute a single decision ────────────────────────────────────────────────

async function executeDecision(userId, biz, decision, connectedTools) {
  const needsApproval = decision.needs_approval ||
    biz.autonomy === 'supervised' ||
    (biz.autonomy === 'semi-auto' && ['book_meeting', 'invoice_reminder'].includes(decision.type));

  if (needsApproval) {
    // Generate the draft but queue for approval
    const draft = await generateDraft(biz, decision);
    await db.saveAction(userId, {
      category: decision.type,
      title: decision.title,
      description: decision.why,
      tool_used: decision.tool,
      output_preview: draft.slice(0, 300),
      status: 'needs_approval',
      tool_result: { draft, decision }
    });
    return { status: 'queued', type: decision.type, draft };
  }

  // Execute immediately
  switch (decision.type) {

    case 'follow_up_email':
    case 'reply_to_lead':
    case 'new_lead_outreach':
    case 'invoice_reminder': {
      const email = await generateEmail(biz, decision);
      let sendResult = { status: 'draft' };

      if (decision.tool === 'gmail' && connectedTools.includes('gmail')) {
        const token = await Tokens.get(userId, 'gmail');
        sendResult = await Gmail.sendEmail(token.access_token, {
          to: email.to,
          toName: email.toName,
          subject: email.subject,
          body: email.body,
          fromName: biz.owner_name || biz.name
        });
      } else if (decision.tool === 'ses' || connectedTools.includes('ses')) {
        sendResult = await SES.sendEmail({
          from: `${biz.owner_name || biz.name} <${process.env.SES_FROM_EMAIL}>`,
          to: email.to,
          toName: email.toName,
          subject: email.subject,
          body: email.body
        });
      }

      // Update lead status
      if (email.leadId) {
        const nextFollowup = new Date(Date.now() + 3 * 86400000); // 3 days
        await db.updateLead(email.leadId, {
          status: 'contacted',
          last_contact: new Date(),
          next_followup: nextFollowup
        });
      }

      // Save email record
      await db.saveEmail(userId, { ...email, sent_at: new Date(), status: sendResult.status === 'sent' ? 'sent' : 'draft' });

      await db.saveAction(userId, {
        category: decision.type,
        title: decision.title,
        description: `Sent to ${email.to}`,
        tool_used: decision.tool,
        output_preview: `Subject: ${email.subject}\n\n${email.body.slice(0, 200)}`,
        status: 'completed',
        tool_result: sendResult
      });

      return { status: 'completed', type: 'email', to: email.to, subject: email.subject };
    }

    case 'book_meeting': {
      if (!connectedTools.includes('google_calendar')) {
        return { status: 'skipped', reason: 'Google Calendar not connected' };
      }

      const token = await Tokens.get(userId, 'google_calendar');
      const tomorrow = new Date(Date.now() + 86400000);
      const avail = await GoogleCal.getAvailability(token.access_token, tomorrow);

      if (!avail.available_slots.length) {
        return { status: 'skipped', reason: 'No available slots tomorrow' };
      }

      const slot = avail.available_slots[0]; // Take first available
      const attendee = decision.data || {};

      const event = await GoogleCal.createEvent(token.access_token, {
        title: `${biz.name} — ${attendee.name || 'Discovery Call'}`,
        startTime: slot.start,
        endTime: slot.end,
        attendeeEmail: attendee.email,
        attendeeName: attendee.name,
        description: `Meeting with ${biz.name}. ${attendee.notes || ''}`
      });

      await db.saveAction(userId, {
        category: 'book_meeting',
        title: decision.title,
        description: `Booked with ${attendee.name || attendee.email}`,
        tool_used: 'google_calendar',
        output_preview: `Meeting at ${new Date(slot.start).toLocaleString()}`,
        status: 'completed',
        tool_result: event
      });

      return { status: 'completed', type: 'meeting', slot: slot.start, attendee: attendee.email };
    }

    case 'internal_report': {
      // No external tool — just generate and save
      const report = await generateDraft(biz, decision);
      await db.saveAction(userId, {
        category: 'internal_report',
        title: decision.title,
        description: decision.why,
        tool_used: 'none',
        output_preview: report.slice(0, 500),
        status: 'completed',
        tool_result: { report }
      });
      return { status: 'completed', type: 'report' };
    }

    default:
      return { status: 'skipped', reason: `Unknown type: ${decision.type}` };
  }
}

// ─── Generate email content ────────────────────────────────────────────────────

async function generateEmail(biz, decision) {
  const lead = decision.data?.lead || {};

  const email = await ai.chatJSON(
    `Write an email for this situation:
Business: ${biz.name} (${biz.type})
Owner: ${biz.owner_name}
Service: ${biz.main_service}
Situation: ${decision.why}
Recipient: ${lead.name || 'customer'} (${lead.email || 'their email'})
Goal: ${decision.title}

Return JSON: { "to": "${lead.email || ''}", "toName": "${lead.name || ''}", "subject": "...", "body": "..." , "leadId": ${lead.id || null} }

Rules for the email:
- Sound like a real person, not a robot
- Short — under 150 words
- Friendly and professional
- Clear single ask or next step
- Sign off as ${biz.owner_name || 'the owner'}`,
    { system: `You write emails for small business owners. Natural, warm, direct. No corporate speak.`, maxTokens: 600 }
  );

  return email;
}

async function generateDraft(biz, decision) {
  return ai.chatWithSystem(
    `You help ${biz.owner_name} run ${biz.name}. Write exactly what's needed — complete and ready to use. No placeholders.`,
    `Create this: ${decision.title}\nReason: ${decision.why}\nBusiness: ${biz.main_service} for ${biz.customer_type}`,
    { maxTokens: 800 }
  );
}

// ─── Daily briefing ───────────────────────────────────────────────────────────

async function writeBriefing(biz, realData, results) {
  const done = results.filter(r => r.status === 'completed');
  const queued = results.filter(r => r.status === 'queued');

  return ai.chatWithSystem(
    `You are Aria, the AI business manager for ${biz.name}. Write the owner's daily briefing. 
Sound like a real assistant reporting to their boss. Plain English. Bullet points. Under 200 words.
Never use jargon. The owner is not technical.`,
    `Here is what happened today:

Revenue this month: $${realData.revenue?.revenue_mtd || 'not connected'}
Overdue invoices: ${realData.overdue.length}
New email replies: ${realData.replies.length}
Leads followed up: ${done.filter(r => r.type === 'email').length}
Meetings booked: ${done.filter(r => r.type === 'meeting').length}
Things needing your approval: ${queued.length}

Actions I took:
${done.map(r => `✓ ${r.decision}`).join('\n') || 'None yet — first run'}

Needs your approval:
${queued.map(r => `• ${r.decision}`).join('\n') || 'Nothing'}

Write the briefing now.`,
    { maxTokens: 400 }
  );
}

async function sendBriefing(userId, biz, briefing, connectedTools) {
  // Send via Gmail if connected
  if (biz.owner_email && connectedTools.includes('gmail')) {
    try {
      const token = await Tokens.get(userId, 'gmail');
      await Gmail.sendEmail(token.access_token, {
        to: biz.owner_email,
        toName: biz.owner_name,
        subject: `Aria's Daily Report — ${new Date().toLocaleDateString()}`,
        body: briefing,
        fromName: 'Aria (Your Business Manager)'
      });
    } catch {}
  }
}

// ─── Owner chat ────────────────────────────────────────────────────────────────

async function chat(userId, message) {
  const biz = await db.getBusiness(userId);
  const history = await db.getChatHistory(userId, 10);
  const recentActions = await db.getRecentActions(userId, 10);
  const leads = await db.getAllLeads(userId);

  const system = `You are Aria, the AI business manager for ${biz?.name || 'this business'}.

About the business:
- Type: ${biz?.type}
- Owner: ${biz?.owner_name}
- Service: ${biz?.main_service}
- Customers: ${biz?.customer_type}

What you've done recently:
${recentActions.map(a => `• ${a.title} [${a.status}]`).join('\n') || 'Just getting started'}

Active leads (${leads.length} total):
${leads.slice(0, 5).map(l => `• ${l.name} — ${l.status}`).join('\n')}

How to talk to the owner:
- They are NOT technical. Never mention APIs, databases, code, or tech tools.
- Talk about business outcomes: "I sent follow-up emails to 5 customers" not "I called the Gmail API"
- Be direct, warm, and confident — like a trusted employee
- If they ask you to do something: confirm what you'll do in plain English
- If they ask what you did: summarize actions in plain language with results
- If you don't have access to do something: say "I'd need you to connect [tool name] for that"`;

  const messages = [
    ...history.map(h => ({ role: h.role, content: h.content })),
    { role: 'user', content: message }
  ];

  const reply = await ai.chat(messages, { system, maxTokens: 600 });

  await db.saveChatMessage(userId, 'user', message);
  await db.saveChatMessage(userId, 'assistant', reply);

  return reply;
}

// ─── Approve a queued action and actually execute it ─────────────────────────

async function executeApproved(userId, actionId) {
  const biz = await db.getBusiness(userId);
  const action = await db.getAction(actionId, userId);
  if (!action || action.status !== 'needs_approval') throw new Error('Action not found or not pending');

  const connectedTools = await Tokens.list(userId);
  const decision = action.tool_result?.decision;

  if (!decision) throw new Error('No decision data in action');

  // Force execute (bypass approval check)
  decision.needs_approval = false;
  const result = await executeDecision(userId, biz, decision, connectedTools);

  await db.updateAction(actionId, { status: 'completed', approved_at: new Date() });
  return result;
}

module.exports = { runDailyCycle, chat, executeApproved };
