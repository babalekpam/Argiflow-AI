-- ================================================================
-- Aria Business Manager — Real Business Schema
-- ================================================================

-- Business profile (what the owner tells Aria once)
CREATE TABLE IF NOT EXISTS aria_business (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL UNIQUE,
  -- The business
  name            TEXT,
  type            TEXT,  -- e.g. "dental practice", "plumbing company", "consulting firm"
  owner_name      TEXT,
  owner_phone     TEXT,
  location        TEXT,
  website         TEXT,
  -- What they sell
  main_service    TEXT,
  price_range     TEXT,  -- e.g. "$200-500 per job"
  avg_job_value   NUMERIC,
  -- Their customers
  customer_type   TEXT,  -- who typically hires them
  service_area    TEXT,  -- geographic area
  -- Business health (Aria reads from integrations, not from owner)
  monthly_revenue NUMERIC DEFAULT 0,
  active_leads    INTEGER DEFAULT 0,
  overdue_invoices INTEGER DEFAULT 0,
  -- Agent config
  autonomy        TEXT DEFAULT 'supervised', -- supervised | semi-auto | autopilot
  owner_email     TEXT,
  briefing_time   TEXT DEFAULT '08:00',
  briefing_via    TEXT DEFAULT 'email',  -- email | sms
  timezone        TEXT DEFAULT 'America/Chicago',
  -- State
  onboarded       BOOLEAN DEFAULT FALSE,
  onboard_score   INTEGER DEFAULT 0,
  status          TEXT DEFAULT 'onboarding',
  connected_tools JSONB DEFAULT '[]',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Leads / contacts (Aria builds and maintains this)
CREATE TABLE IF NOT EXISTS aria_leads (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL,
  name            TEXT NOT NULL,
  email           TEXT,
  phone           TEXT,
  company         TEXT,
  source          TEXT,  -- website | referral | cold_outreach | google | social
  status          TEXT DEFAULT 'new', -- new | contacted | replied | meeting_booked | proposal_sent | won | lost | nurturing
  last_contact    TIMESTAMPTZ,
  next_followup   TIMESTAMPTZ,
  notes           TEXT,
  deal_value      NUMERIC,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_leads_user ON aria_leads(user_id);
CREATE INDEX IF NOT EXISTS idx_leads_status ON aria_leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_followup ON aria_leads(next_followup);

-- Actions Aria actually took (with proof)
CREATE TABLE IF NOT EXISTS aria_actions (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL,
  category        TEXT NOT NULL,  -- email | followup | booking | invoice | social | report | crm
  title           TEXT NOT NULL,
  description     TEXT,
  -- What actually happened
  tool_used       TEXT,           -- gmail | ses | gcal | stripe | twilio
  tool_result     JSONB,          -- API response / proof it happened
  output_preview  TEXT,           -- first 300 chars of what was sent/created
  -- Metadata
  lead_id         INTEGER REFERENCES aria_leads(id),
  status          TEXT DEFAULT 'completed', -- completed | needs_approval | approved | rejected | failed
  approved_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_actions_user ON aria_actions(user_id);
CREATE INDEX IF NOT EXISTS idx_actions_status ON aria_actions(status);

-- Emails Aria sent or drafted (with full content stored)
CREATE TABLE IF NOT EXISTS aria_emails (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL,
  action_id       INTEGER REFERENCES aria_actions(id),
  lead_id         INTEGER REFERENCES aria_leads(id),
  to_email        TEXT NOT NULL,
  to_name         TEXT,
  subject         TEXT NOT NULL,
  body            TEXT NOT NULL,
  sent_at         TIMESTAMPTZ,
  opened_at       TIMESTAMPTZ,
  replied_at      TIMESTAMPTZ,
  status          TEXT DEFAULT 'draft', -- draft | sent | opened | replied | bounced
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Meetings booked by Aria
CREATE TABLE IF NOT EXISTS aria_meetings (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL,
  lead_id         INTEGER REFERENCES aria_leads(id),
  title           TEXT,
  start_time      TIMESTAMPTZ,
  end_time        TIMESTAMPTZ,
  attendee_email  TEXT,
  attendee_name   TEXT,
  gcal_event_id   TEXT,
  notes           TEXT,
  status          TEXT DEFAULT 'scheduled', -- scheduled | completed | cancelled | no_show
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Invoices Aria tracks (read from Stripe or manual)
CREATE TABLE IF NOT EXISTS aria_invoices (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL,
  lead_id         INTEGER REFERENCES aria_leads(id),
  invoice_number  TEXT,
  stripe_invoice_id TEXT,
  amount          NUMERIC,
  currency        TEXT DEFAULT 'USD',
  status          TEXT DEFAULT 'draft', -- draft | sent | paid | overdue | void
  due_date        DATE,
  paid_at         TIMESTAMPTZ,
  reminder_count  INTEGER DEFAULT 0,
  last_reminder   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Daily business snapshots (Aria's real numbers)
CREATE TABLE IF NOT EXISTS aria_snapshots (
  id              SERIAL PRIMARY KEY,
  user_id         TEXT NOT NULL,
  snapshot_date   DATE DEFAULT CURRENT_DATE,
  revenue_mtd     NUMERIC DEFAULT 0,
  leads_total     INTEGER DEFAULT 0,
  leads_new       INTEGER DEFAULT 0,
  emails_sent     INTEGER DEFAULT 0,
  meetings_booked INTEGER DEFAULT 0,
  invoices_paid   INTEGER DEFAULT 0,
  invoices_overdue INTEGER DEFAULT 0,
  actions_taken   INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Onboarding conversation
CREATE TABLE IF NOT EXISTS aria_discovery (
  id          SERIAL PRIMARY KEY,
  user_id     TEXT NOT NULL,
  role        TEXT NOT NULL,
  content     TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Owner chat (post-onboarding)
CREATE TABLE IF NOT EXISTS aria_chat (
  id          SERIAL PRIMARY KEY,
  user_id     TEXT NOT NULL,
  role        TEXT NOT NULL,
  content     TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Daily briefings sent to owner
CREATE TABLE IF NOT EXISTS aria_briefings (
  id          SERIAL PRIMARY KEY,
  user_id     TEXT NOT NULL,
  content     TEXT NOT NULL,
  sent_via    TEXT,  -- email | sms | dashboard
  sent_at     TIMESTAMPTZ DEFAULT NOW()
);
