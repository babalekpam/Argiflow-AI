/**
 * AriaDashboard.jsx
 * Designed for non-technical small business owners.
 * Zero jargon. Everything in plain English.
 *
 * Add to router:
 *   import AriaDashboard from './aria-business-manager/client/AriaDashboard';
 *   <Route path="/my-manager" element={<AriaDashboard />} />
 */

import { useState, useEffect, useRef } from 'react';

const CATEGORY_LABELS = {
  follow_up_email:    { label: 'Followed up with a customer', icon: '📧' },
  reply_to_lead:      { label: 'Replied to a message', icon: '💬' },
  new_lead_outreach:  { label: 'Reached out to a new lead', icon: '🤝' },
  invoice_reminder:   { label: 'Sent invoice reminder', icon: '💰' },
  book_meeting:       { label: 'Booked a meeting', icon: '📅' },
  internal_report:    { label: 'Prepared a report', icon: '📋' },
};

const LEAD_STATUS = {
  new:             { label: 'New',            color: 'bg-blue-500/10 text-blue-400' },
  contacted:       { label: 'Contacted',      color: 'bg-yellow-500/10 text-yellow-400' },
  replied:         { label: 'Replied',        color: 'bg-green-500/10 text-green-400' },
  meeting_booked:  { label: 'Meeting Set',    color: 'bg-violet-500/10 text-violet-400' },
  proposal_sent:   { label: 'Proposal Sent',  color: 'bg-orange-500/10 text-orange-400' },
  won:             { label: '✓ Won',          color: 'bg-green-500/20 text-green-300' },
  lost:            { label: 'Lost',           color: 'bg-gray-500/10 text-gray-400' },
  nurturing:       { label: 'Nurturing',      color: 'bg-cyan-500/10 text-cyan-400' },
};

export default function AriaDashboard() {
  const [tab, setTab] = useState('home');
  const [data, setData] = useState(null);
  const [tools, setTools] = useState([]);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [init, setInit] = useState(true);
  const [activating, setActivating] = useState(false);
  const [autonomy, setAutonomy] = useState('semi-auto');
  const [running, setRunning] = useState(false);
  const chatEnd = useRef(null);

  useEffect(() => { load(); }, []);
  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  async function load() {
    setInit(true);
    try {
      const [dash, toolsRes] = await Promise.all([
        fetch('/api/aria/dashboard').then(r => r.json()),
        fetch('/api/aria/tools').then(r => r.json())
      ]);
      setData(dash);
      setTools(toolsRes.tools || []);

      // Start onboarding if new user
      if (!dash.biz || !dash.biz.onboarded) {
        if (messages.length === 0) {
          const r = await fetch('/api/aria/start', { method: 'POST' }).then(r => r.json());
          if (r.reply) setMessages([{ role: 'assistant', content: r.reply }]);
        }
      }
    } finally { setInit(false); }
  }

  async function send() {
    if (!input.trim() || loading) return;
    const msg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: msg }]);
    setLoading(true);
    try {
      const r = await fetch('/api/aria/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg })
      }).then(r => r.json());

      setMessages(prev => [...prev, { role: 'assistant', content: r.reply, score: r.onboard_score }]);
      if (r.onboarded || r.mode === 'active') load();
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: "Sorry, something went wrong. Try again.", error: true }]);
    } finally { setLoading(false); }
  }

  async function activate() {
    setActivating(true);
    try {
      await fetch('/api/aria/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ autonomy })
      });
      await load();
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ I'm all set up and ready to work for you.\n\nHere's what I'll handle automatically:\n• Follow up with leads who haven't heard back\n• Send reminders for unpaid invoices\n• Book meetings when someone's interested\n• Send you a daily update every morning\n\nYou can always chat with me here. I'll let you know if anything needs your attention.`
      }]);
    } finally { setActivating(false); }
  }

  async function runNow() {
    setRunning(true);
    try {
      await fetch('/api/aria/run', { method: 'POST' });
      await load();
    } finally { setRunning(false); }
  }

  async function approveAction(id) {
    await fetch(`/api/aria/actions/${id}/approve`, { method: 'POST' });
    load();
  }

  async function rejectAction(id) {
    await fetch(`/api/aria/actions/${id}/reject`, { method: 'POST' });
    load();
  }

  if (init) return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="text-center">
        <div className="w-10 h-10 border-2 border-violet-500/30 border-t-violet-500 rounded-full animate-spin mx-auto mb-3" />
        <p className="text-gray-500 text-sm">Loading Aria...</p>
      </div>
    </div>
  );

  const biz = data?.biz;
  const isOnboarding = !biz?.onboarded;
  const isActive = ['active','autopilot'].includes(biz?.status);
  const pending = data?.pending || [];
  const leads = data?.leads || [];
  const actions = data?.actions || [];
  const snap = data?.snapshot;
  const briefings = data?.briefings || [];

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col">

      {/* Header */}
      <div className="border-b border-gray-800 px-5 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center font-bold text-sm">A</div>
            {isActive && <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-400 rounded-full border-2 border-gray-950" />}
          </div>
          <div>
            <p className="text-sm font-semibold text-white">Aria</p>
            <p className="text-xs text-gray-500">
              {isOnboarding ? 'Getting to know your business...' :
               isActive ? `Managing ${biz.name}` : 'Ready to help'}
            </p>
          </div>
        </div>

        {pending.length > 0 && (
          <button onClick={() => setTab('approve')}
            className="text-xs text-yellow-400 bg-yellow-500/10 border border-yellow-500/20 px-3 py-1.5 rounded-lg">
            ⚡ {pending.length} thing{pending.length > 1 ? 's' : ''} need your OK
          </button>
        )}

        {isActive && (
          <div className="flex gap-2">
            <button onClick={runNow} disabled={running}
              className="text-xs text-gray-400 border border-gray-700 px-3 py-1.5 rounded-lg hover:text-white hover:border-gray-500 disabled:opacity-40">
              {running ? 'Working...' : 'Run now'}
            </button>
            <button onClick={() => fetch('/api/aria/pause',{method:'POST'}).then(load)}
              className="text-xs text-gray-500 border border-gray-700 px-3 py-1.5 rounded-lg hover:text-white hover:border-gray-500">
              Pause
            </button>
          </div>
        )}
      </div>

      {/* Tabs — only when active */}
      {!isOnboarding && (
        <div className="border-b border-gray-800 px-5 flex gap-4">
          {[
            { id: 'home', label: 'Home' },
            { id: 'chat', label: 'Chat with Aria' },
            { id: 'leads', label: `Leads (${leads.length})` },
            { id: 'approve', label: `Approve ${pending.length > 0 ? `(${pending.length})` : ''}` },
            { id: 'tools', label: 'Connect Tools' },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`py-2.5 text-xs border-b-2 transition-colors ${tab === t.id ? 'border-violet-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}>
              {t.label}
            </button>
          ))}
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto">

        {/* ── Onboarding / Chat ── */}
        {(isOnboarding || tab === 'chat') && (
          <div className="max-w-xl mx-auto p-5 flex flex-col h-full">

            {isOnboarding && (
              <div className="mb-4">
                <div className="flex justify-between text-xs text-gray-500 mb-1">
                  <span>Setup progress</span>
                  <span>{biz?.onboard_score || 0}%</span>
                </div>
                <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-violet-500 to-blue-500 transition-all" style={{ width: `${biz?.onboard_score || 0}%` }} />
                </div>
              </div>
            )}

            {/* Messages */}
            <div className="flex-1 space-y-3 overflow-y-auto mb-4 max-h-[55vh]">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                    m.role === 'user' ? 'bg-violet-600 text-white rounded-tr-sm' :
                    m.error ? 'bg-red-900/30 border border-red-700/30 text-red-300 rounded-tl-sm' :
                    'bg-gray-800 border border-gray-700/50 text-gray-200 rounded-tl-sm'
                  }`}>{m.content}</div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-gray-800 border border-gray-700/50 rounded-2xl rounded-tl-sm px-4 py-3 flex gap-1">
                    {[0,150,300].map(d => <span key={d} className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
                  </div>
                </div>
              )}
              <div ref={chatEnd} />
            </div>

            {/* Activation */}
            {biz?.onboarded && biz?.status === 'onboarding' && (
              <div className="mb-3 bg-gradient-to-r from-violet-900/30 to-blue-900/30 border border-violet-500/30 rounded-xl p-4">
                <p className="text-white text-sm font-semibold mb-1">✅ I know enough to get started</p>
                <p className="text-gray-300 text-xs mb-3">How would you like me to work?</p>
                <div className="space-y-2 mb-3">
                  {[
                    { v: 'supervised', l: 'Check with me before doing anything', d: "I'll show you what I'm planning and wait for your OK" },
                    { v: 'semi-auto',  l: 'Handle routine things, ask about big ones', d: "I'll do follow-ups and reminders automatically, ask before booking meetings" },
                    { v: 'autopilot', l: 'Just handle everything and tell me', d: "I'll manage everything and send you a daily summary" },
                  ].map(o => (
                    <button key={o.v} onClick={() => setAutonomy(o.v)}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${autonomy === o.v ? 'border-violet-500 bg-violet-500/10' : 'border-gray-700 hover:border-gray-600'}`}>
                      <div className="text-sm text-white font-medium">{o.l}</div>
                      <div className="text-xs text-gray-400 mt-0.5">{o.d}</div>
                    </button>
                  ))}
                </div>
                <button onClick={activate} disabled={activating}
                  className="w-full bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white font-medium py-2.5 rounded-lg text-sm">
                  {activating ? 'Starting...' : "Let's go →"}
                </button>
              </div>
            )}

            {/* Quick questions */}
            {isActive && (
              <div className="flex flex-wrap gap-2 mb-2">
                {["What did you do today?", "Who needs follow up?", "How's business this month?", "Any unpaid invoices?"].map(q => (
                  <button key={q} onClick={() => setInput(q)}
                    className="text-xs text-gray-500 border border-gray-800 rounded-full px-3 py-1.5 hover:text-white hover:border-gray-600 transition-colors">{q}</button>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <input value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && send()}
                placeholder={isOnboarding ? "Type your answer..." : "Ask Aria anything about your business..."}
                className="flex-1 bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-violet-500" />
              <button onClick={send} disabled={loading || !input.trim()}
                className="bg-violet-600 hover:bg-violet-500 disabled:opacity-40 text-white px-5 py-3 rounded-xl transition-colors">→</button>
            </div>
          </div>
        )}

        {/* ── Home Tab ── */}
        {tab === 'home' && !isOnboarding && (
          <div className="max-w-3xl mx-auto p-5 space-y-5">

            {/* Daily briefing */}
            {briefings[0] && (
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-sm font-semibold text-white">📋 Today's Update from Aria</h2>
                  <span className="text-xs text-gray-500">{new Date(briefings[0].sent_at).toLocaleDateString()}</span>
                </div>
                <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">{briefings[0].content}</p>
              </div>
            )}

            {/* Numbers */}
            {snap && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: 'Revenue this month', value: `$${(snap.revenue_mtd || 0).toLocaleString()}`, icon: '💰', color: 'text-green-400' },
                  { label: 'Active leads', value: leads.filter(l => !['won','lost'].includes(l.status)).length, icon: '🤝', color: 'text-blue-400' },
                  { label: 'Emails sent today', value: snap.emails_sent || 0, icon: '📧', color: 'text-violet-400' },
                  { label: 'Overdue invoices', value: snap.invoices_overdue || 0, icon: '⚠️', color: snap.invoices_overdue > 0 ? 'text-red-400' : 'text-gray-400' },
                ].map(s => (
                  <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                    <div className="text-lg mb-1">{s.icon}</div>
                    <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
                    <div className="text-xs text-gray-500 mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            )}

            {/* What Aria did */}
            <div>
              <h2 className="text-sm font-semibold text-gray-400 mb-3">What Aria did recently</h2>
              <div className="space-y-2">
                {actions.filter(a => a.status === 'completed').slice(0, 8).map(a => {
                  const cat = CATEGORY_LABELS[a.category] || { label: a.title, icon: '⚡' };
                  return (
                    <div key={a.id} className="bg-gray-900 border border-gray-800 rounded-xl p-3.5 flex items-center gap-3">
                      <span className="text-lg shrink-0">{cat.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-200">{a.description || cat.label}</p>
                        {a.output_preview && (
                          <p className="text-xs text-gray-500 mt-0.5 truncate">{a.output_preview}</p>
                        )}
                      </div>
                      <span className="text-xs text-gray-500 shrink-0">{new Date(a.created_at).toLocaleDateString()}</span>
                    </div>
                  );
                })}
                {!actions.filter(a => a.status === 'completed').length && (
                  <div className="text-center py-8 text-gray-600 text-sm">
                    Aria hasn't run yet. Click "Run now" to start.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── Leads Tab ── */}
        {tab === 'leads' && !isOnboarding && (
          <div className="max-w-3xl mx-auto p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-white">Your Leads</h2>
              <button onClick={() => {
                const name = prompt('Lead name?');
                const email = prompt('Their email?');
                if (name) fetch('/api/aria/leads', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ name, email, source: 'manual' })
                }).then(load);
              }} className="text-xs text-violet-400 border border-violet-500/30 px-3 py-1.5 rounded-lg hover:bg-violet-500/10">
                + Add lead
              </button>
            </div>

            <div className="space-y-2">
              {leads.map(lead => {
                const s = LEAD_STATUS[lead.status] || { label: lead.status, color: 'bg-gray-500/10 text-gray-400' };
                return (
                  <div key={lead.id} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium text-white">{lead.name}</p>
                      <p className="text-xs text-gray-500">{lead.email || 'No email'} {lead.company ? `· ${lead.company}` : ''}</p>
                      {lead.next_followup && (
                        <p className="text-xs text-gray-600 mt-0.5">
                          Follow up: {new Date(lead.next_followup).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full shrink-0 ${s.color}`}>{s.label}</span>
                  </div>
                );
              })}
              {!leads.length && (
                <div className="text-center py-12 text-gray-600 text-sm">
                  No leads yet. Add your first one or Aria will build this list as she works.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Approve Tab ── */}
        {tab === 'approve' && !isOnboarding && (
          <div className="max-w-3xl mx-auto p-5">
            <h2 className="text-sm font-semibold text-white mb-4">Things Aria wants to do</h2>

            {pending.length === 0 && (
              <div className="text-center py-12 text-gray-600 text-sm">Nothing needs your approval right now.</div>
            )}

            <div className="space-y-4">
              {pending.map(action => (
                <div key={action.id} className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                  <p className="text-white font-medium text-sm mb-1">{action.title}</p>
                  <p className="text-gray-400 text-sm mb-3">{action.description}</p>
                  {action.output_preview && (
                    <div className="bg-gray-800 rounded-lg p-3 mb-3">
                      <p className="text-xs text-gray-500 mb-1">What Aria will send/do:</p>
                      <p className="text-gray-300 text-sm whitespace-pre-wrap">{action.output_preview}</p>
                    </div>
                  )}
                  <div className="flex gap-3">
                    <button onClick={() => approveAction(action.id)}
                      className="flex-1 bg-green-600 hover:bg-green-500 text-white text-sm font-medium py-2 rounded-lg transition-colors">
                      ✓ Yes, do it
                    </button>
                    <button onClick={() => rejectAction(action.id)}
                      className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm py-2 rounded-lg transition-colors border border-gray-700">
                      Skip this
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Tools Tab ── */}
        {tab === 'tools' && !isOnboarding && (
          <div className="max-w-2xl mx-auto p-5">
            <h2 className="text-sm font-semibold text-white mb-2">Connect your tools</h2>
            <p className="text-gray-400 text-sm mb-5">The more tools you connect, the more Aria can do for you automatically.</p>

            <div className="space-y-3">
              {tools.map(tool => (
                <div key={tool.id} className={`bg-gray-900 border rounded-xl p-4 flex items-center justify-between ${tool.connected ? 'border-green-500/20' : 'border-gray-800'}`}>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{tool.icon}</span>
                    <div>
                      <p className="text-sm font-medium text-white">{tool.name}</p>
                      <p className="text-xs text-gray-500">{tool.desc}</p>
                    </div>
                  </div>
                  {tool.connected
                    ? <span className="text-xs text-green-400 bg-green-500/10 px-2 py-1 rounded-full">✓ Connected</span>
                    : <button
                        onClick={() => {
                          if (tool.id === 'stripe') {
                            const key = prompt(`Enter your Stripe secret key (starts with sk_):`);
                            if (key) fetch(`/api/aria/tools/stripe/connect`, {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ secret_key: key })
                            }).then(() => load());
                          } else {
                            alert(`To connect ${tool.name}, ask your developer to set up OAuth and call POST /api/aria/tools/${tool.id}/connect with the access token.`);
                          }
                        }}
                        className="text-xs text-violet-400 border border-violet-500/30 px-3 py-1.5 rounded-lg hover:bg-violet-500/10">
                        Connect
                      </button>
                  }
                </div>
              ))}
            </div>

            <div className="mt-6 bg-gray-900 border border-gray-800 rounded-xl p-4">
              <p className="text-sm text-gray-300 font-medium mb-1">Don't see the tool you use?</p>
              <p className="text-xs text-gray-500">Ask in the chat — Aria can work with most business tools. New integrations are added regularly.</p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
