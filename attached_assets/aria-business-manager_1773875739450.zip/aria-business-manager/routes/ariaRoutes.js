/**
 * ariaRoutes.js
 * Mount: app.use('/api/aria', require('./aria-business-manager/routes/ariaRoutes'));
 */

const express = require('express');
const router = express.Router();
const db = require('../agent/AriaMemory');
const discovery = require('../agent/AriaDiscovery');
const agent = require('../agent/AriaAgent');
const { Tokens } = require('../connectors/ToolConnectors');

const uid = req => req.user?.id || req.session?.userId || req.headers['x-user-id'];

// Dashboard data
router.get('/dashboard', async (req, res) => {
  try { res.json({ success: true, ...(await db.getDashboard(uid(req))) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// Start onboarding
router.post('/start', async (req, res) => {
  try { res.json({ success: true, ...(await discovery.getOpening(uid(req))) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// Chat (handles both onboarding and active agent)
router.post('/chat', async (req, res) => {
  try {
    const userId = uid(req);
    const { message } = req.body;
    const biz = await db.getBusiness(userId);

    if (!biz?.onboarded) {
      const result = await discovery.onboardingTurn(userId, message);
      return res.json({ success: true, mode: 'onboarding', ...result });
    }

    const reply = await agent.chat(userId, message);
    res.json({ success: true, mode: 'active', reply });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Activate agent after onboarding
router.post('/activate', async (req, res) => {
  try {
    const userId = uid(req);
    const biz = await db.getBusiness(userId);
    if (!biz?.onboarded) return res.status(400).json({ error: 'Complete setup first', score: biz?.onboard_score });

    const { autonomy = 'semi-auto' } = req.body;
    await db.updateBusiness(userId, { autonomy, status: 'active' });
    res.json({ success: true, message: `Aria activated in ${autonomy} mode` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Run agent now
router.post('/run', async (req, res) => {
  try {
    const result = await agent.runDailyCycle(uid(req));
    res.json({ success: true, ...result });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Leads
router.get('/leads', async (req, res) => {
  try { res.json({ success: true, leads: await db.getAllLeads(uid(req)) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/leads', async (req, res) => {
  try { res.json({ success: true, lead: await db.saveLead(uid(req), req.body) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

router.patch('/leads/:id', async (req, res) => {
  try { await db.updateLead(req.params.id, req.body); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// Actions
router.get('/actions', async (req, res) => {
  try { res.json({ success: true, actions: await db.getRecentActions(uid(req), 30) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/actions/:id/approve', async (req, res) => {
  try {
    const result = await agent.executeApproved(uid(req), req.params.id);
    res.json({ success: true, ...result });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/actions/:id/reject', async (req, res) => {
  try { await db.updateAction(req.params.id, { status: 'rejected' }); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// Tool connections
router.get('/tools', async (req, res) => {
  try {
    const connected = await Tokens.list(uid(req));
    const tools = [
      { id: 'gmail', name: 'Gmail', icon: '📧', desc: 'Send emails and read replies', connected: connected.includes('gmail') },
      { id: 'google_calendar', name: 'Google Calendar', icon: '📅', desc: 'Book meetings and check availability', connected: connected.includes('google_calendar') },
      { id: 'stripe', name: 'Stripe', icon: '💳', desc: 'Track payments and overdue invoices', connected: connected.includes('stripe') },
      { id: 'ses', name: 'Email Outreach (SES)', icon: '📨', desc: 'Send bulk outreach emails', connected: !!process.env.AWS_ACCESS_KEY_ID },
    ];
    res.json({ success: true, tools });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Save tool token (called after OAuth or API key entry)
router.post('/tools/:tool/connect', async (req, res) => {
  try {
    await Tokens.save(uid(req), req.params.tool, req.body);
    res.json({ success: true, message: `${req.params.tool} connected` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Settings
router.patch('/settings', async (req, res) => {
  try { await db.updateBusiness(uid(req), req.body); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// Pause / resume
router.post('/pause', async (req, res) => {
  try { await db.updateBusiness(uid(req), { status: 'paused' }); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/resume', async (req, res) => {
  try { await db.updateBusiness(uid(req), { status: 'active' }); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
