# Aria Business Manager
## Replit Agent Integration Instructions

---

This package adds an autonomous AI business manager to ArgiFlow for small business owners.
After a plain-English onboarding conversation, Aria works every day without any input from the owner — sending follow-up emails, chasing invoices, booking meetings, and sending a plain-English daily briefing.

---

## Files

```
aria-business-manager/
├── agent/
│   ├── AriaDiscovery.js   — Plain-English onboarding conversation
│   ├── AriaAgent.js       — Core autonomous agent (reads real data, takes real actions)
│   └── AriaMemory.js      — All PostgreSQL operations
├── connectors/
│   └── ToolConnectors.js  — Gmail, Google Calendar, Stripe, Amazon SES, Twilio
├── routes/
│   └── ariaRoutes.js      — Express API routes
├── client/
│   └── AriaDashboard.jsx  — Owner-friendly React UI (zero jargon)
├── jobs/
│   └── ariaScheduler.js   — Daily cron at 8am CT
└── db/
    └── schema.sql         — PostgreSQL tables
```

---

## Step 1 — Run the database schema

Run `db/schema.sql` in the Replit PostgreSQL shell. Creates 9 tables:
`aria_business`, `aria_leads`, `aria_actions`, `aria_emails`, `aria_meetings`,
`aria_invoices`, `aria_snapshots`, `aria_discovery`, `aria_chat`, `aria_briefings`, `aria_tokens`

---

## Step 2 — Mount routes in server.js

```js
const ariaRoutes = require('./aria-business-manager/routes/ariaRoutes');
app.use('/api/aria', ariaRoutes);
```

API endpoints added:
- `POST /api/aria/start` — Start onboarding
- `POST /api/aria/chat` — Chat (handles onboarding + active agent)
- `POST /api/aria/activate` — Activate after onboarding (body: `{ autonomy }`)
- `POST /api/aria/run` — Run daily cycle now
- `GET  /api/aria/dashboard` — All dashboard data
- `GET  /api/aria/leads` — Get all leads
- `POST /api/aria/leads` — Add a lead
- `PATCH /api/aria/leads/:id` — Update a lead
- `GET  /api/aria/actions` — Get recent actions
- `POST /api/aria/actions/:id/approve` — Approve a queued action (executes it)
- `POST /api/aria/actions/:id/reject` — Reject a queued action
- `GET  /api/aria/tools` — List tools and connection status
- `POST /api/aria/tools/:tool/connect` — Save tool credentials (body: token data)
- `PATCH /api/aria/settings` — Update business settings
- `POST /api/aria/pause` — Pause agent
- `POST /api/aria/resume` — Resume agent

User ID is extracted from `req.user?.id || req.session?.userId || req.headers['x-user-id']`.
Adjust the `uid()` function in `ariaRoutes.js` to match ArgiFlow's auth system.

---

## Step 3 — Start the scheduler

```js
require('./aria-business-manager/jobs/ariaScheduler');
```

Runs daily at 8am CT for all active users. Requires `npm install node-cron`.

---

## Step 4 — Add the React page

```jsx
import AriaDashboard from './aria-business-manager/client/AriaDashboard';
<Route path="/my-manager" element={<AriaDashboard />} />
```

Add nav link:
```jsx
<NavLink to="/my-manager">🤖 My Business Manager</NavLink>
```

---

## Step 5 — Required Replit Secrets

The agent requires these secrets. Add whichever apply:

```
OPENAI_API_KEY          ← Required (already set from ai adapter)

# For email outreach (ArgiFlow already has these):
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_REGION
SES_FROM_EMAIL

# Optional — enables more features:
TWILIO_ACCOUNT_SID      ← For SMS briefings to owner
TWILIO_AUTH_TOKEN
TWILIO_PHONE
```

Gmail, Google Calendar, and Stripe credentials are saved **per user** via the
`/api/aria/tools/:tool/connect` endpoint after the user connects them in the UI.
They are stored encrypted in the `aria_tokens` table.

---

## How it works (plain English version for non-technical users)

**Setup (one time, 5-10 minutes):**
Aria asks the owner a few simple questions about their business — what they do, who their customers are, how much they charge. No technical questions. Just business questions.

**Every day automatically:**
1. Aria reads the owner's real data — who replied to emails, which invoices are overdue, which leads haven't heard back
2. Decides what to do based on that data
3. Takes action — sends follow-up emails, books meetings, sends invoice reminders
4. Sends the owner a plain English summary: "Here's what I did today"

**Owner interaction:**
- Chat with Aria anytime using the chat tab
- Approve or reject things before Aria does them (if in supervised mode)
- View leads, actions, and daily reports in the dashboard
- Connect tools (Gmail, Stripe, Google Calendar) to give Aria more capabilities

**Three operating modes:**
- Supervised — Aria proposes everything, owner approves each action
- Semi-auto — Aria handles routine tasks, asks about bigger decisions
- Autopilot — Aria handles everything and reports daily

---

## npm packages required

```
node-cron           ← npm install node-cron
@aws-sdk/client-ses ← npm install @aws-sdk/client-ses (for SES, already in ArgiFlow)
```

All other dependencies (pg, express) are already installed.
