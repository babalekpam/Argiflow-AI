/**
 * ariaScheduler.js
 * Add to server.js: require('./aria-business-manager/jobs/ariaScheduler');
 */

const { Pool } = require('pg');
const agent = require('../agent/AriaAgent');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

let cron; try { cron = require('node-cron'); } catch {}

async function runAll() {
  console.log('[Aria] Running daily cycles...');
  const { rows } = await pool.query(
    `SELECT user_id, briefing_time, timezone FROM aria_business WHERE status = 'active'`
  );
  for (const { user_id } of rows) {
    try {
      console.log(`[Aria] → ${user_id}`);
      await agent.runDailyCycle(user_id);
    } catch (e) { console.error(`[Aria] Failed ${user_id}:`, e.message); }
    await new Promise(r => setTimeout(r, 8000));
  }
}

if (cron) {
  cron.schedule('0 8 * * *', runAll, { timezone: 'America/Chicago' });
  console.log('[Aria] Scheduler running — daily at 8am CT');
} else {
  console.warn('[Aria] Install node-cron: npm install node-cron');
}

module.exports = { runAll };
