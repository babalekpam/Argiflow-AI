/**
 * ArgiFlow Marketing Suite — React Frontend
 * 
 * DROP INTO YOUR REACT APP:
 *   import MarketingSuite from './components/MarketingSuite';
 *   // Add route: <Route path="/marketing-suite" element={<MarketingSuite />} />
 * 
 * Uses Tailwind CSS (already in ArgiFlow)
 * API calls go to /api/marketing-suite/*
 */

import { useState } from 'react';

// ─── Tool definitions ─────────────────────────────────────────────────────────

const TOOLS = [
  {
    id: 'cold-email',
    name: 'Cold Email Builder',
    icon: '✉️',
    tag: 'OUTREACH',
    tagColor: 'bg-blue-500/20 text-blue-300',
    description: 'Generate a complete 4-touch sequence tailored to any prospect.',
    fields: [
      { key: 'target_role', label: 'Target Role / Title', placeholder: 'e.g. Office Manager, Medical Billing Director' },
      { key: 'company_name', label: 'Company / Industry', placeholder: 'e.g. dental practice, SaaS startup' },
      { key: 'industry', label: 'Industry', placeholder: 'e.g. Healthcare, B2B SaaS' },
      { key: 'pain_point', label: 'Their #1 Pain Point', placeholder: 'e.g. claim denials eating revenue, low reply rates' },
      { key: 'your_offer', label: 'Your Offer / Solution', placeholder: 'e.g. Track-Med handles your prior auth end-to-end' },
      { key: 'tone', label: 'Tone', placeholder: 'peer-level / warm / direct / consultative', optional: true }
    ],
    endpoint: '/cold-email'
  },
  {
    id: 'email-sequence',
    name: 'Email Sequence Designer',
    icon: '📧',
    tag: 'NURTURE',
    tagColor: 'bg-purple-500/20 text-purple-300',
    description: 'Build welcome, onboarding, re-engagement, or nurture sequences.',
    fields: [
      { key: 'sequence_type', label: 'Sequence Type', placeholder: 'welcome / onboarding / lead-nurture / re-engagement' },
      { key: 'audience', label: 'Who Enters This Sequence?', placeholder: 'e.g. Trial signups who haven\'t activated' },
      { key: 'goal', label: 'Conversion Goal', placeholder: 'e.g. Get them to book a demo, upgrade to paid' },
      { key: 'num_emails', label: 'Number of Emails', placeholder: '5', optional: true },
      { key: 'product_context', label: 'Extra Context', placeholder: 'Anything specific about your product/offer', optional: true }
    ],
    endpoint: '/email-sequence'
  },
  {
    id: 'page-audit',
    name: 'Landing Page Auditor',
    icon: '🔍',
    tag: 'CRO',
    tagColor: 'bg-yellow-500/20 text-yellow-300',
    description: 'Paste your page copy. Get a score, quick wins, and rewritten headlines.',
    fields: [
      { key: 'page_type', label: 'Page Type', placeholder: 'homepage / landing page / pricing / feature page' },
      { key: 'goal', label: 'Conversion Goal', placeholder: 'e.g. Free trial signup, book a demo' },
      { key: 'page_url', label: 'Page URL (optional)', placeholder: 'https://...', optional: true },
      { key: 'traffic_source', label: 'Main Traffic Source', placeholder: 'organic / paid / email / social', optional: true },
      { key: 'page_copy', label: 'Paste Page Copy or Key Sections', placeholder: 'Paste your headline, subhead, body copy, CTAs...', textarea: true }
    ],
    endpoint: '/page-audit'
  },
  {
    id: 'copy-writer',
    name: 'AI Copywriter',
    icon: '✍️',
    tag: 'COPY',
    tagColor: 'bg-green-500/20 text-green-300',
    description: 'Write headlines, taglines, CTAs, value props — polished and ready to publish.',
    fields: [
      { key: 'copy_type', label: 'What to Write', placeholder: 'homepage headline, email subject lines, ad copy, value prop...' },
      { key: 'audience', label: 'Target Audience', placeholder: 'e.g. Medical office managers at small practices' },
      { key: 'tone', label: 'Tone', placeholder: 'e.g. professional, urgent, peer-level, warm' },
      { key: 'key_points', label: 'Key Points to Hit', placeholder: 'e.g. saves 10hrs/week, no setup fee, instant results' },
      { key: 'existing_copy', label: 'Existing Copy to Improve (optional)', placeholder: 'Paste current copy here...', textarea: true, optional: true }
    ],
    endpoint: '/copy-writer'
  },
  {
    id: 'launch-planner',
    name: 'Launch Planner',
    icon: '🚀',
    tag: 'GTM',
    tagColor: 'bg-orange-500/20 text-orange-300',
    description: 'Full go-to-market plan: pre-launch checklist, launch day schedule, 30-day post-plan.',
    fields: [
      { key: 'launch_type', label: 'What Are You Launching?', placeholder: 'new feature / product launch / beta / major update' },
      { key: 'product_name', label: 'Product / Feature Name', placeholder: 'e.g. Marketing Suite, MedAuth v2' },
      { key: 'target_audience', label: 'Target Audience', placeholder: 'e.g. Medical billing companies, SMB founders' },
      { key: 'timeline', label: 'Launch Timeline', placeholder: 'e.g. 2 weeks, launching March 30' },
      { key: 'channels_available', label: 'Available Channels', placeholder: 'email list, LinkedIn, Twitter, Product Hunt, community...' }
    ],
    endpoint: '/launch-planner'
  },
  {
    id: 'pricing-advisor',
    name: 'Pricing Advisor',
    icon: '💰',
    tag: 'MONETIZATION',
    tagColor: 'bg-emerald-500/20 text-emerald-300',
    description: 'Get a full pricing structure recommendation with tiers, value metric, and psychology tactics.',
    fields: [
      { key: 'product_type', label: 'Product Type', placeholder: 'SaaS / service / marketplace / tool' },
      { key: 'current_pricing', label: 'Current Pricing (if any)', placeholder: 'e.g. $49/mo flat, or none yet', optional: true },
      { key: 'target_market', label: 'Target Market', placeholder: 'e.g. SMB healthcare practices, solo founders' },
      { key: 'competitors', label: 'Competitors + Their Prices', placeholder: 'e.g. Apollo $99/mo, ZoomInfo $15k/yr' },
      { key: 'goal', label: 'Pricing Goal', placeholder: 'e.g. maximize signups, move upmarket, increase ARPU' }
    ],
    endpoint: '/pricing-advisor'
  },
  {
    id: 'ad-creative',
    name: 'Ad Creative Generator',
    icon: '🎯',
    tag: 'PAID ADS',
    tagColor: 'bg-red-500/20 text-red-300',
    description: 'Headlines, body copy, and CTAs for Facebook, Google, LinkedIn ads.',
    fields: [
      { key: 'platform', label: 'Ad Platform', placeholder: 'Facebook/Meta / Google / LinkedIn / Twitter' },
      { key: 'audience', label: 'Target Audience', placeholder: 'e.g. dental office managers, 35-55, US' },
      { key: 'offer', label: 'The Offer', placeholder: 'e.g. Free 30-day trial of ArgiFlow, no credit card' },
      { key: 'goal', label: 'Campaign Goal', placeholder: 'e.g. click to landing page, app installs, lead gen' },
      { key: 'tone', label: 'Tone', placeholder: 'direct / professional / urgency / friendly', optional: true }
    ],
    endpoint: '/ad-creative'
  },
  {
    id: 'sequence-review',
    name: 'Sequence Reviewer',
    icon: '📊',
    tag: 'AI REVIEW',
    tagColor: 'bg-indigo-500/20 text-indigo-300',
    description: 'Paste an existing sequence. Get a quality score and specific rewrites before you hit send.',
    fields: [
      { key: 'sequence_name', label: 'Sequence Name', placeholder: 'e.g. Track-Med — Dental Offices Outreach' },
      { key: 'target_segment', label: 'Target Segment', placeholder: 'e.g. Dental office owners, 5-20 person practices' }
    ],
    emailsField: true,
    endpoint: '/sequence-review'
  }
];

// ─── Main Component ───────────────────────────────────────────────────────────

export default function MarketingSuite() {
  const [activeTool, setActiveTool] = useState(null);
  const [formData, setFormData] = useState({});
  const [emails, setEmails] = useState([{ subject: '', body: '' }]);
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const openTool = (tool) => {
    setActiveTool(tool);
    setFormData({});
    setEmails([{ subject: '', body: '' }]);
    setResult('');
    setError('');
  };

  const addEmail = () => setEmails([...emails, { subject: '', body: '' }]);
  const removeEmail = (i) => setEmails(emails.filter((_, idx) => idx !== i));
  const updateEmail = (i, field, value) => {
    const updated = [...emails];
    updated[i][field] = value;
    setEmails(updated);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setResult('');
    setError('');

    try {
      const payload = { ...formData };
      if (activeTool.emailsField) payload.emails = emails;

      const res = await fetch(`/api/marketing-suite${activeTool.endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (data.success) {
        setResult(data.result);
      } else {
        setError(data.error || 'Something went wrong.');
      }
    } catch (e) {
      setError('Network error: ' + e.message);
    } finally {
      setLoading(false);
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ── Tool Grid ──────────────────────────────────────────────────────────────

  if (!activeTool) {
    return (
      <div className="min-h-screen bg-gray-950 text-white p-6">
        {/* Header */}
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center text-sm font-bold">
                AF
              </div>
              <span className="text-gray-400 text-sm font-medium tracking-widest uppercase">ArgiFlow</span>
            </div>
            <h1 className="text-3xl font-bold text-white mb-1">Marketing Suite</h1>
            <p className="text-gray-400">AI-powered marketing tools. Built for outreach that actually converts.</p>
          </div>

          {/* Tool grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {TOOLS.map((tool) => (
              <button
                key={tool.id}
                onClick={() => openTool(tool)}
                className="group bg-gray-900 hover:bg-gray-800 border border-gray-800 hover:border-gray-600 rounded-xl p-5 text-left transition-all duration-200 hover:shadow-lg hover:shadow-black/30"
              >
                <div className="flex items-start justify-between mb-3">
                  <span className="text-2xl">{tool.icon}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${tool.tagColor}`}>
                    {tool.tag}
                  </span>
                </div>
                <h3 className="font-semibold text-white text-sm mb-1.5 group-hover:text-violet-300 transition-colors">
                  {tool.name}
                </h3>
                <p className="text-gray-500 text-xs leading-relaxed">{tool.description}</p>
              </button>
            ))}
          </div>

          {/* Footer */}
          <div className="mt-8 p-4 bg-gray-900 rounded-xl border border-gray-800 flex items-center gap-3">
            <span className="text-violet-400 text-lg">💡</span>
            <div>
              <p className="text-white text-sm font-medium">All tools are pre-loaded with ArgiFlow context</p>
              <p className="text-gray-500 text-xs mt-0.5">Your ICP, positioning, and offer are baked in — no need to re-explain your business every time.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Active Tool Form ───────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <div className="max-w-4xl mx-auto p-6">
        {/* Back + header */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => setActiveTool(null)}
            className="text-gray-400 hover:text-white transition-colors text-sm flex items-center gap-1"
          >
            ← Back
          </button>
          <div className="h-4 w-px bg-gray-700" />
          <div className="flex items-center gap-2">
            <span className="text-xl">{activeTool.icon}</span>
            <h2 className="text-lg font-semibold text-white">{activeTool.name}</h2>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeTool.tagColor}`}>
              {activeTool.tag}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left — Form */}
          <div className="space-y-4">
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
              <p className="text-gray-400 text-sm mb-4">{activeTool.description}</p>

              {activeTool.fields.map((field) => (
                <div key={field.key} className="mb-4">
                  <label className="block text-xs font-medium text-gray-300 mb-1.5">
                    {field.label}
                    {field.optional && <span className="text-gray-500 ml-1">(optional)</span>}
                  </label>
                  {field.textarea ? (
                    <textarea
                      rows={4}
                      placeholder={field.placeholder}
                      value={formData[field.key] || ''}
                      onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-violet-500 resize-none"
                    />
                  ) : (
                    <input
                      type="text"
                      placeholder={field.placeholder}
                      value={formData[field.key] || ''}
                      onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-violet-500"
                    />
                  )}
                </div>
              ))}

              {/* Emails field for sequence reviewer */}
              {activeTool.emailsField && (
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-medium text-gray-300">Emails to Review</label>
                    <button
                      onClick={addEmail}
                      className="text-xs text-violet-400 hover:text-violet-300"
                    >
                      + Add Email
                    </button>
                  </div>
                  {emails.map((email, i) => (
                    <div key={i} className="mb-3 bg-gray-800 rounded-lg p-3 border border-gray-700">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-400 font-medium">Email {i + 1}</span>
                        {emails.length > 1 && (
                          <button onClick={() => removeEmail(i)} className="text-xs text-red-400 hover:text-red-300">
                            Remove
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        placeholder="Subject line"
                        value={email.subject}
                        onChange={(e) => updateEmail(i, 'subject', e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded px-2.5 py-1.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-violet-500 mb-2"
                      />
                      <textarea
                        rows={3}
                        placeholder="Email body..."
                        value={email.body}
                        onChange={(e) => updateEmail(i, 'body', e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded px-2.5 py-1.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-violet-500 resize-none"
                      />
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={handleSubmit}
                disabled={loading}
                className="w-full mt-2 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg py-3 text-sm transition-colors flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Generating...
                  </>
                ) : (
                  `Generate with AI →`
                )}
              </button>
            </div>
          </div>

          {/* Right — Output */}
          <div>
            <div className="bg-gray-900 rounded-xl border border-gray-800 h-full min-h-[400px] flex flex-col">
              <div className="flex items-center justify-between px-5 py-3 border-b border-gray-800">
                <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">Output</span>
                {result && (
                  <button
                    onClick={copyResult}
                    className="text-xs text-gray-400 hover:text-white transition-colors flex items-center gap-1.5"
                  >
                    {copied ? '✓ Copied' : '⎘ Copy all'}
                  </button>
                )}
              </div>

              <div className="flex-1 p-5 overflow-y-auto">
                {error && (
                  <div className="bg-red-900/30 border border-red-700 rounded-lg p-3 text-red-300 text-sm">
                    {error}
                  </div>
                )}
                {!result && !error && !loading && (
                  <div className="flex flex-col items-center justify-center h-full text-center py-12">
                    <span className="text-4xl mb-3 opacity-30">{activeTool.icon}</span>
                    <p className="text-gray-600 text-sm">Fill in the form and click Generate</p>
                  </div>
                )}
                {result && (
                  <div className="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap font-mono">
                    {result}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
