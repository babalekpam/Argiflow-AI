# ArgiFlow Marketing Skills Integration Package

**AI-powered marketing suite built on 33 expert skills from github.com/coreyhaines31/marketingskills**

---

## What's in this package

```
argiflow-marketing-skills/
├── README.md                          ← This file
├── skills-data/
│   └── index.js                       ← All 33 SKILL.md files embedded as JS module
├── lib/
│   └── skillsLoader.js                ← Skill loader, intent detector, prompt builder
├── routes/
│   └── marketingSuite.js              ← 9 Express API routes (all marketing tools)
├── client/
│   └── MarketingSuite.jsx             ← React frontend (8-tool Marketing Suite page)
├── aria/
│   └── ariaWithSkills.js              ← Enhanced Aria with auto skill detection
└── context/
    └── argiflow-product-context.md    ← Pre-filled ArgiFlow product context
```

---

## Step 1 — Copy files into ArgiFlow on Replit

From the Replit file tree, create the following folders and upload/paste the files:

```
your-argiflow-project/
├── skills-data/index.js
├── lib/skillsLoader.js
├── routes/marketingSuite.js
├── client/components/MarketingSuite.jsx   (or wherever your components live)
├── aria/ariaWithSkills.js
└── context/argiflow-product-context.md
```

---

## Step 2 — Register the Marketing Suite routes

In your `server.js` or `index.js`, add:

```js
const marketingSuite = require('./routes/marketingSuite');
app.use('/api/marketing-suite', marketingSuite);
```

That's it. All 9 endpoints are live:

| Endpoint | Tool |
|---|---|
| POST /api/marketing-suite/cold-email | Cold Email Builder |
| POST /api/marketing-suite/email-sequence | Email Sequence Designer |
| POST /api/marketing-suite/page-audit | Landing Page Auditor |
| POST /api/marketing-suite/copy-writer | AI Copywriter |
| POST /api/marketing-suite/launch-planner | Launch Planner |
| POST /api/marketing-suite/pricing-advisor | Pricing Advisor |
| POST /api/marketing-suite/ad-creative | Ad Creative Generator |
| POST /api/marketing-suite/sequence-review | Sequence Reviewer |
| POST /api/marketing-suite/aria-enhanced | Aria (auto-skill) |
| GET /api/marketing-suite/skills | List all skills |

---

## Step 3 — Add the Marketing Suite page to your React app

In your router (React Router or similar):

```jsx
import MarketingSuite from './components/MarketingSuite';

// Add this route:
<Route path="/marketing-suite" element={<MarketingSuite />} />
```

Then add a nav link in your sidebar:

```jsx
<NavLink to="/marketing-suite">
  🎯 Marketing Suite
</NavLink>
```

---

## Step 4 — Upgrade Aria (optional but recommended)

Replace your existing Aria API handler:

```js
// BEFORE (your existing handler):
app.post('/api/aria/chat', async (req, res) => {
  // ... your existing code
});

// AFTER (drop-in replacement):
const { ariaRouteHandler } = require('./aria/ariaWithSkills');
app.post('/api/aria/chat', ariaRouteHandler);
```

Aria will now automatically detect the user's intent and inject the relevant skill (cold email, page CRO, pricing strategy, etc.) into her system prompt — making every response expert-level.

---

## Step 5 — Update your product context

Open `context/argiflow-product-context.md` and update any fields that have changed:
- Your current pricing tiers
- Active campaigns and segments
- Latest ICP insights
- New features

All 9 tools read this file automatically — so one update improves everything.

---

## Environment variables required

Make sure these are set in Replit Secrets:

```
ANTHROPIC_API_KEY=sk-ant-...
```

---

## Skills available (33 total)

| Category | Skills |
|---|---|
| Outreach | cold-email, email-sequence |
| CRO | page-cro, signup-flow-cro, onboarding-cro, form-cro, popup-cro, paywall-upgrade-cro |
| Content & Copy | copywriting, copy-editing, content-strategy, social-content, marketing-ideas |
| Paid & Measurement | paid-ads, ad-creative, ab-test-setup, analytics-tracking |
| Growth & Retention | referral-program, free-tool-strategy, churn-prevention, lead-magnets |
| Sales & GTM | cold-email, email-sequence, launch-strategy, pricing-strategy, competitor-alternatives, sales-enablement, revops |
| SEO | seo-audit, ai-seo, schema-markup, programmatic-seo, site-architecture |
| Foundation | product-marketing-context, marketing-psychology |

---

## Using skills directly in your own code

```js
const { getSkill, buildSkillPrompt, detectSkills } = require('./lib/skillsLoader');

// Get one skill
const skill = getSkill('cold-email');

// Detect relevant skills from a user message
const skills = detectSkills('help me write better cold emails for dental offices');
// → ['cold-email', 'marketing-psychology']

// Build a combined system prompt
const prompt = buildSkillPrompt(['cold-email', 'email-sequence'], myBaseContext);
```

---

## Revenue model integration

### Starter plan users
- Get: Aria with basic skill detection
- See: Marketing Suite (cold-email + email-sequence only)

### Growth plan users  
- Get: Full Marketing Suite (all 8 tools)
- Get: Sequence Reviewer (AI quality scoring before send)

### Agency/Pro plan users
- Get: Everything + white-label Marketing Suite
- Get: Unlimited skill calls, priority AI

### Gate by plan in routes:

```js
router.post('/launch-planner', requirePlan('growth'), async (req, res) => {
  // ...
});
```

---

## Questions / customization

All skills are plain markdown in `skills-data/index.js`.  
To modify a skill's behavior, find it in that file and edit the markdown content directly.

To add a new tool: add a route in `routes/marketingSuite.js` and a card in `client/MarketingSuite.jsx`.
