/**
 * ArgiFlow Aria — Enhanced with Marketing Skills
 *
 * DROP-IN REPLACEMENT for your existing Aria chat handler.
 * 
 * USAGE in your existing Aria route/handler:
 *   const { handleAriaMessage } = require('./aria/ariaWithSkills');
 *   const response = await handleAriaMessage(userMessage, conversationHistory, userContext);
 */

const Anthropic = require('@anthropic-ai/sdk');
const { buildAutoPrompt } = require('../lib/skillsLoader');
const fs = require('fs');
const path = require('path');

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Load product context
const ARGIFLOW_CONTEXT = (() => {
  try {
    return fs.readFileSync(path.join(__dirname, '../context/argiflow-product-context.md'), 'utf8');
  } catch {
    return '';
  }
})();

// Aria base personality — always present
const ARIA_BASE = `You are Aria, the AI sales and marketing assistant built into ArgiFlow by ARGILETTE LLC.

You are embedded directly in the ArgiFlow platform. Users are founders, business owners, and sales teams using ArgiFlow to run outreach campaigns.

## Your personality
- Sharp, confident, and direct — like a brilliant colleague who's done this a thousand times
- You give specific, actionable advice — never generic platitudes
- You speak in plain language, not marketing jargon
- You're honest: if something won't work, say so and explain why
- You root for the user and want them to succeed

## What you know about ArgiFlow
${ARGIFLOW_CONTEXT}

## Your job
- Help users write better cold emails, sequences, and campaigns
- Help them improve landing pages and conversion
- Help them think through pricing, launches, and growth
- Help them use ArgiFlow features effectively
- When they share copy, give honest feedback with specific rewrites
- When they're stuck, ask one clarifying question — then give a concrete recommendation

## Always
- Deliver complete, ready-to-use outputs (no [brackets] or placeholders)
- Be specific to their industry/situation when you know it
- End responses with a clear next step or question when helpful`;

/**
 * Main handler — auto-detects skill, builds system prompt, calls Claude
 *
 * @param {string} userMessage - The user's message
 * @param {Array} conversationHistory - Prior [{role, content}] messages
 * @param {Object} userContext - Optional: { company, industry, segment, plan }
 * @returns {Object} { reply, skills_used }
 */
async function handleAriaMessage(userMessage, conversationHistory = [], userContext = {}) {
  // Auto-detect relevant marketing skills
  const { skills, prompt: skillPrompt } = buildAutoPrompt(userMessage, '');

  // Build contextual enrichment from user data
  const userContextStr = Object.keys(userContext).length > 0
    ? `## Current User Context\n${Object.entries(userContext)
        .map(([k, v]) => `- ${k}: ${v}`)
        .join('\n')}`
    : '';

  // Assemble full system prompt
  const systemPrompt = [
    ARIA_BASE,
    userContextStr,
    skills.length > 0 ? skillPrompt : ''
  ].filter(Boolean).join('\n\n---\n\n');

  // Build message history
  const messages = [
    ...conversationHistory.slice(-10), // Keep last 10 turns for context
    { role: 'user', content: userMessage }
  ];

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1500,
    system: systemPrompt,
    messages
  });

  return {
    reply: response.content[0].text,
    skills_used: skills
  };
}

/**
 * Express route handler — drop into your existing Aria route
 * 
 * app.post('/api/aria/chat', ariaRouteHandler);
 */
async function ariaRouteHandler(req, res) {
  try {
    const { message, history = [], context = {} } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const { reply, skills_used } = await handleAriaMessage(message, history, context);

    res.json({
      success: true,
      reply,
      skills_used, // Useful for debugging / analytics
      timestamp: new Date().toISOString()
    });

  } catch (err) {
    console.error('[Aria Skills Error]', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { handleAriaMessage, ariaRouteHandler };
