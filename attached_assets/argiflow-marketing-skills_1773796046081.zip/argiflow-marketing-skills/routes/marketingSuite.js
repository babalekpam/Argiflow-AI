/**
 * ArgiFlow Marketing Suite — Express Routes
 * Mounts at: /api/marketing-suite
 *
 * ADD TO YOUR server.js / index.js:
 *   const marketingSuite = require('./routes/marketingSuite');
 *   app.use('/api/marketing-suite', marketingSuite);
 */

const express = require('express');
const router = express.Router();
const Anthropic = require('@anthropic-ai/sdk');
const { getSkill, buildSkillPrompt, buildAutoPrompt, listSkills } = require('../lib/skillsLoader');
const fs = require('fs');
const path = require('path');

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Load ArgiFlow product context once at startup
const ARGIFLOW_CONTEXT = (() => {
  try {
    return fs.readFileSync(
      path.join(__dirname, '../context/argiflow-product-context.md'), 'utf8'
    );
  } catch {
    return '';
  }
})();

// ─── Shared AI call helper ────────────────────────────────────────────────────

async function callWithSkill(skillName, userPrompt, extraContext = '') {
  const skillContent = getSkill(skillName);
  const systemPrompt = `You are Aria, ArgiFlow's AI marketing assistant — sharp, direct, and expert-level.

${ARGIFLOW_CONTEXT}

${extraContext ? `## Additional Context\n${extraContext}\n` : ''}

---

# ACTIVE SKILL: ${skillName}

${skillContent}

---

Always give complete, actionable, ready-to-use output. Be specific. Avoid generic advice.
When producing copy (emails, headlines, etc.), write final versions, not templates with [brackets].`;

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 2000,
    system: systemPrompt,
    messages: [{ role: 'user', content: userPrompt }]
  });

  return response.content[0].text;
}

// ─── GET /api/marketing-suite/skills — list all skills ───────────────────────

router.get('/skills', (req, res) => {
  res.json({ skills: listSkills() });
});

// ─── POST /api/marketing-suite/cold-email ────────────────────────────────────
/**
 * Body: { target_role, company_name, industry, pain_point, your_offer, tone? }
 */
router.post('/cold-email', async (req, res) => {
  try {
    const { target_role, company_name, industry, pain_point, your_offer, tone = 'peer-level' } = req.body;

    const userPrompt = `Write a complete 4-touch cold email sequence for this outreach:

Target: ${target_role} at ${company_name || `a ${industry} company`}
Industry: ${industry}
Their pain point: ${pain_point}
What we offer: ${your_offer}
Tone: ${tone}

Deliver:
1. Subject lines for all 4 emails
2. Full body copy for each email (ready to send, no brackets)
3. Send timing for each email
4. One-line note on what each email is designed to do`;

    const result = await callWithSkill('cold-email', userPrompt);
    res.json({ success: true, result, skill: 'cold-email' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/email-sequence ────────────────────────────────
/**
 * Body: { sequence_type, audience, goal, product_context?, num_emails? }
 */
router.post('/email-sequence', async (req, res) => {
  try {
    const { sequence_type, audience, goal, product_context = '', num_emails = 5 } = req.body;

    const userPrompt = `Design a complete ${sequence_type} email sequence:

Audience: ${audience}
Goal: ${goal}
Number of emails: ${num_emails}
${product_context ? `Product context: ${product_context}` : ''}

For each email provide:
- Email number and purpose
- Send timing
- Subject line
- Preview text
- Full body copy (ready to send)
- CTA (button text + destination)`;

    const result = await callWithSkill('email-sequence', userPrompt);
    res.json({ success: true, result, skill: 'email-sequence' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/page-audit ────────────────────────────────────
/**
 * Body: { page_url?, page_copy, page_type, goal, traffic_source? }
 */
router.post('/page-audit', async (req, res) => {
  try {
    const { page_url, page_copy, page_type, goal, traffic_source = 'organic' } = req.body;

    const userPrompt = `Audit this ${page_type} page for conversion optimization:

${page_url ? `URL: ${page_url}` : ''}
Page type: ${page_type}
Conversion goal: ${goal}
Traffic source: ${traffic_source}

Page content:
"""
${page_copy}
"""

Provide:
1. Overall conversion score (1-10) with reasoning
2. Quick wins (implement today)
3. High-impact changes (this sprint)
4. 3 headline alternatives with rationale
5. CTA copy alternatives
6. Key objection you're not addressing`;

    const result = await callWithSkill('page-cro', userPrompt);
    res.json({ success: true, result, skill: 'page-cro' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/copy-writer ───────────────────────────────────
/**
 * Body: { copy_type, audience, tone, key_points, existing_copy? }
 */
router.post('/copy-writer', async (req, res) => {
  try {
    const { copy_type, audience, tone, key_points, existing_copy = '' } = req.body;

    const systemSkills = buildSkillPrompt(['copywriting', 'marketing-psychology'], ARGIFLOW_CONTEXT);

    const userPrompt = `Write ${copy_type} for this situation:

Target audience: ${audience}
Tone: ${tone}
Key points to hit: ${key_points}
${existing_copy ? `Existing copy to improve:\n"""\n${existing_copy}\n"""` : ''}

Deliver final, polished copy — no placeholders or brackets.
Include 2 alternatives for the headline/hook.`;

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      system: systemSkills,
      messages: [{ role: 'user', content: userPrompt }]
    });

    res.json({ success: true, result: response.content[0].text, skill: 'copywriting+marketing-psychology' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/launch-planner ────────────────────────────────
/**
 * Body: { launch_type, product_name, target_audience, timeline, channels_available }
 */
router.post('/launch-planner', async (req, res) => {
  try {
    const { launch_type, product_name, target_audience, timeline, channels_available } = req.body;

    const userPrompt = `Create a complete launch plan:

What: ${launch_type} for "${product_name}"
Target audience: ${target_audience}
Timeline: ${timeline}
Available channels: ${channels_available}

Deliver:
1. Pre-launch checklist (with owners and deadlines)
2. Launch day play-by-play schedule
3. Post-launch 30-day plan
4. Top 3 owned + rented + borrowed channel moves
5. Email to existing audience (announcement copy)
6. Social post for launch day`;

    const result = await callWithSkill('launch-strategy', userPrompt);
    res.json({ success: true, result, skill: 'launch-strategy' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/pricing-advisor ───────────────────────────────
/**
 * Body: { product_type, current_pricing?, target_market, competitors, goal }
 */
router.post('/pricing-advisor', async (req, res) => {
  try {
    const { product_type, current_pricing = 'none set', target_market, competitors, goal } = req.body;

    const userPrompt = `Analyze and advise on pricing strategy:

Product type: ${product_type}
Current pricing: ${current_pricing}
Target market: ${target_market}
Competitors and their pricing: ${competitors}
Goal: ${goal}

Provide:
1. Recommended tier structure (3 tiers with names, prices, features)
2. Value metric recommendation with rationale
3. Pricing psychology tactics to apply
4. Annual vs monthly discount recommendation
5. What to test first
6. One-sentence recommended positioning for pricing page hero`;

    const result = await callWithSkill('pricing-strategy', userPrompt);
    res.json({ success: true, result, skill: 'pricing-strategy' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/ad-creative ───────────────────────────────────
/**
 * Body: { platform, audience, offer, goal, tone? }
 */
router.post('/ad-creative', async (req, res) => {
  try {
    const { platform, audience, offer, goal, tone = 'direct' } = req.body;

    const userPrompt = `Create ad creative for:

Platform: ${platform}
Audience: ${audience}
Offer: ${offer}
Goal: ${goal}
Tone: ${tone}

Deliver:
1. 3 headline variations (with character counts)
2. 2 body copy variations (platform-appropriate length)
3. 3 CTA options
4. Hook line for video/creative brief
5. Targeting suggestion for this audience`;

    const result = await callWithSkill('ad-creative', userPrompt);
    res.json({ success: true, result, skill: 'ad-creative' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/aria-enhanced ─────────────────────────────────
/**
 * Aria's enhanced endpoint — auto-detects skill from user message
 * Body: { message, conversation_history?, user_context? }
 */
router.post('/aria-enhanced', async (req, res) => {
  try {
    const { message, conversation_history = [], user_context = '' } = req.body;

    const { skills, prompt: systemPrompt } = buildAutoPrompt(message, ARGIFLOW_CONTEXT);

    const ariaBase = `You are Aria, ArgiFlow's AI sales and marketing assistant. You are embedded in the ArgiFlow platform and help users grow their business. You are sharp, direct, and give expert advice — not generic platitudes.

${systemPrompt}

${user_context ? `\n## User Context\n${user_context}` : ''}`;

    const messages = [
      ...conversation_history,
      { role: 'user', content: message }
    ];

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      system: ariaBase,
      messages
    });

    res.json({
      success: true,
      result: response.content[0].text,
      skills_used: skills,
      skill_count: skills.length
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/marketing-suite/sequence-review ───────────────────────────────
/**
 * Review an existing ArgiFlow sequence before sending
 * Body: { sequence_name, target_segment, emails: [{subject, body}] }
 */
router.post('/sequence-review', async (req, res) => {
  try {
    const { sequence_name, target_segment, emails } = req.body;

    const emailsFormatted = emails.map((e, i) =>
      `Email ${i + 1}:\nSubject: ${e.subject}\n\n${e.body}`
    ).join('\n\n---\n\n');

    const systemSkills = buildSkillPrompt(['cold-email', 'marketing-psychology'], ARGIFLOW_CONTEXT);

    const userPrompt = `Review this outreach sequence before it goes live:

Sequence: "${sequence_name}"
Target segment: ${target_segment}

${emailsFormatted}

For each email, provide:
1. Quality score (1-10)
2. What's working
3. What to fix (specific rewrite if needed)
4. Subject line alternatives (if weak)

Then overall sequence assessment:
- Does it flow logically?
- Does it escalate value correctly?
- Predicted reply rate vs. industry benchmark
- #1 change to make before sending`;

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2500,
      system: systemSkills,
      messages: [{ role: 'user', content: userPrompt }]
    });

    res.json({
      success: true,
      result: response.content[0].text,
      skill: 'cold-email+marketing-psychology'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
