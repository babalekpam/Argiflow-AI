/**
 * aiProviderRoutes.js
 * Lets users (or admins) switch AI provider and model from the UI.
 *
 * Mount in server.js:
 *   const aiRoutes = require('./argiflow-ai-adapter/aiProviderRoutes');
 *   app.use('/api/ai', aiRoutes);
 */

const express = require('express');
const router = express.Router();
const ai = require('./index');

// GET /api/ai/providers — list all supported providers + status
router.get('/providers', (req, res) => {
  res.json({
    active_provider: ai.getActiveProvider(),
    active_model: ai.getActiveModel(),
    providers: ai.listProviders()
  });
});

// POST /api/ai/test — test the current or specified provider
router.post('/test', async (req, res) => {
  const { provider, model } = req.body;
  try {
    const reply = await ai.chat(
      'Say "ArgiFlow AI adapter is working!" and nothing else.',
      { ...(provider ? { provider } : {}), ...(model ? { model } : {}), maxTokens: 50 }
    );
    res.json({ success: true, reply, provider: provider || ai.getActiveProvider() });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PATCH /api/ai/provider — switch provider (sets env var for session)
// NOTE: For persistent switching, save to your DB and load on startup
router.patch('/provider', (req, res) => {
  const { provider, model } = req.body;
  if (provider) process.env.AI_PROVIDER = provider;
  if (model) process.env.AI_MODEL = model;

  res.json({
    success: true,
    active_provider: ai.getActiveProvider(),
    active_model: ai.getActiveModel()
  });
});

module.exports = router;
