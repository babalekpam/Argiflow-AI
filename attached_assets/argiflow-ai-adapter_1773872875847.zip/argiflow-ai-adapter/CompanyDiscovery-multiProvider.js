/**
 * CompanyDiscovery.js — Multi-provider version
 * Replace your existing CompanyDiscovery.js with this.
 */

const ai = require('../../argiflow-ai-adapter');
const memory = require('./AgentMemory');

const DISCOVERY_SYSTEM = `You are ARIA, ArgiFlow's AI business strategist. You are having a warm onboarding conversation to learn about the user's company so you can run their marketing on autopilot.

Your response must always have TWO parts:

PART 1 — EXTRACT structured data in this block:
<extract>
{
  "company_name": null,
  "industry": null,
  "what_they_sell": null,
  "target_customers": null,
  "customer_pain_points": [],
  "key_differentiators": [],
  "biggest_challenge": null,
  "growth_goal": null,
  "tone_of_voice": null,
  "competitors": [],
  "monthly_revenue": null,
  "team_size": null,
  "current_tools": [],
  "avg_deal_size": null,
  "past_marketing": null,
  "location": null,
  "website": null
}
</extract>
Only include fields present in this message. Omit nulls and empty arrays.

PART 2 — Your conversational reply (after the extract block).

Rules:
- Warm, curious, like a smart consultant in a first meeting
- Ask ONE focused question per turn
- Progress: basics → customers → challenges → goals → preferences
- Keep responses short — this is a chat
- When score reaches 80+, tell them you're ready to take over`;

async function discoveryTurn(userId, userMessage) {
  let profile = await memory.getProfile(userId);
  if (!profile) profile = await memory.createProfile(userId);

  const currentProfile = profile.profile;
  await memory.saveDiscoveryMessage(userId, 'user', userMessage);

  const history = await memory.getDiscoveryHistory(userId);
  const messages = history.map(h => ({ role: h.role, content: h.content }));
  messages.push({ role: 'user', content: userMessage });

  const contextNote = `[System: Discovery score: ${currentProfile.discovery_score}/100. Turn: ${currentProfile.onboarding_turn + 1}. Known: ${JSON.stringify(currentProfile)}]`;

  const fullReply = await ai.chatWithSystem(
    DISCOVERY_SYSTEM + '\n\n' + contextNote,
    userMessage,
    { maxTokens: 600 }
  );

  // Actually pass full message history for multi-turn context
  const fullReply2 = await ai.chat(messages, {
    system: DISCOVERY_SYSTEM + '\n\n' + contextNote,
    maxTokens: 600
  });

  const extracted = parseExtract(fullReply2);
  await memory.updateProfile(userId, {
    ...extracted,
    onboarding_turn: (currentProfile.onboarding_turn || 0) + 1
  });

  const cleanReply = fullReply2.replace(/<extract>[\s\S]*?<\/extract>\n?/, '').trim();
  await memory.saveDiscoveryMessage(userId, 'assistant', cleanReply);

  const updated = await memory.getProfile(userId);
  return {
    reply: cleanReply,
    discovery_score: updated.profile.discovery_score,
    discovery_complete: updated.profile.discovery_complete,
    extracted_fields: Object.keys(extracted)
  };
}

function parseExtract(text) {
  try {
    const match = text.match(/<extract>([\s\S]*?)<\/extract>/);
    if (!match) return {};
    const parsed = JSON.parse(match[1].trim());
    return Object.fromEntries(
      Object.entries(parsed).filter(([, v]) =>
        v !== null && v !== '' && !(Array.isArray(v) && v.length === 0)
      )
    );
  } catch { return {}; }
}

async function getOpeningMessage(userId) {
  if (!await memory.getProfile(userId)) await memory.createProfile(userId);
  const opening = `Hey! I'm Aria — your AI marketing agent inside ArgiFlow. 🚀

I'm going to learn everything about your business so I can run your marketing and outreach on autopilot. No more figuring out what to write, who to target, or when to follow up — I handle all of that.

This will take about 5 minutes. Let's start:

**What's your company name, and what do you do?**`;

  await memory.saveDiscoveryMessage(userId, 'assistant', opening);
  return { reply: opening, discovery_score: 0, discovery_complete: false };
}

module.exports = { discoveryTurn, getOpeningMessage };
