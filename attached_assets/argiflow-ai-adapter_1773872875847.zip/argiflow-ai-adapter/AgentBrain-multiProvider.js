/**
 * AgentBrain.js — Multi-provider version
 * Replace your existing AgentBrain.js with this file.
 * Uses the universal AI adapter — works with any provider.
 */

const ai = require('../../argiflow-ai-adapter');
const memory = require('./AgentMemory');
const executor = require('./ActionExecutor');

const SKILLS = require('../../argiflow-marketing-skills/skills-data/index');

const CORE_SKILLS = [
  'cold-email', 'email-sequence', 'marketing-psychology',
  'copywriting', 'content-strategy', 'lead-magnets', 'churn-prevention'
].map(s => SKILLS[s] || '').join('\n\n---\n\n');

function buildBrainPrompt(profile) {
  return `You are an autonomous B2B marketing agent built into ArgiFlow. You manage the full marketing and outreach operation for a company. You think like a seasoned CMO and execute like a growth operator.

## Company Profile
${JSON.stringify(profile, null, 2)}

## Your responsibilities
You autonomously manage:
1. Cold outreach — prospect targeting, sequence creation, send scheduling
2. Lead nurturing — follow-up timing, sequence optimization, reply handling
3. Campaign strategy — what to run, who to target, what angle to use
4. Content & copy — email copy, landing page copy, sequence messaging
5. Reporting — what's working, what to change, weekly summaries

## Decision framework
Always ask: "What single action would most move the needle for this company right now?"

Priority order for a new company:
1. Get first leads into the pipeline (outreach sequence)
2. Qualify those leads (follow-up)
3. Convert leads to customers (demo booking, proposals)
4. Retain customers (onboarding, check-ins)
5. Grow (referrals, upsells)

## Autonomy rules
- autonomy_level: "${profile.autonomy_level}"
- supervised: Queue all actions for user approval before executing
- semi-auto: Execute low-risk actions (drafting, scheduling), queue high-risk (sending)
- autopilot: Execute everything, just log and report

## Marketing Skills
${CORE_SKILLS}`;
}

async function generateActionPlan(userId) {
  const profileRow = await memory.getProfile(userId);
  if (!profileRow?.profile?.discovery_complete) {
    throw new Error('Discovery not complete.');
  }

  const profile = profileRow.profile;

  const plan = await ai.chatJSON(
    `Based on everything you know about ${profile.company_name}, generate a prioritized action plan for the next 7 days.

Return ONLY valid JSON:
{
  "summary": "One sentence on the overall strategy",
  "priority_goal": "The #1 goal this week",
  "actions": [
    {
      "id": "action_001",
      "type": "create_sequence | send_emails | create_copy | create_lead_magnet | setup_campaign | analyze_results | write_report",
      "title": "Short title",
      "description": "What exactly needs to happen",
      "why": "Why this is the priority",
      "expected_result": "What success looks like",
      "inputs_needed": {},
      "priority": 1,
      "risk_level": "low | medium | high",
      "requires_approval": true
    }
  ]
}`,
    { system: buildBrainPrompt(profile) }
  );

  await memory.logAction(userId, {
    type: 'plan_generated',
    description: `Generated 7-day action plan: ${plan.summary}`,
    payload: plan,
    status: 'completed'
  });

  return plan;
}

async function executeAction(userId, action) {
  const profileRow = await memory.getProfile(userId);
  const profile = profileRow.profile;

  const needsApproval = action.requires_approval ||
    profile.autonomy_level === 'supervised' ||
    (profile.autonomy_level === 'semi-auto' && action.risk_level === 'high');

  if (needsApproval) {
    await memory.logAction(userId, {
      type: action.type,
      description: action.description,
      payload: { action },
      status: 'pending_approval'
    });
    return { status: 'queued', message: `Action "${action.title}" queued for approval.` };
  }

  try {
    const result = await executor.execute(action, profile, ai, SKILLS);
    await memory.logAction(userId, {
      type: action.type,
      description: action.description,
      payload: { action, result },
      status: 'completed'
    });
    return { status: 'completed', result };
  } catch (err) {
    await memory.logAction(userId, {
      type: action.type,
      description: action.description,
      payload: { error: err.message },
      status: 'failed'
    });
    return { status: 'failed', error: err.message };
  }
}

async function runAgentCycle(userId) {
  const plan = await generateActionPlan(userId);
  const results = [];

  for (const action of plan.actions) {
    const result = await executeAction(userId, action);
    results.push({ action: action.title, ...result });
    await new Promise(r => setTimeout(r, 1000));
  }

  const profileRow = await memory.getProfile(userId);
  const profile = profileRow.profile;

  const summary = await ai.chatWithSystem(
    `You are Aria, ArgiFlow's AI agent. Write a brief, warm update for ${profile.company_name}'s owner on what you did. Be specific. 3-4 sentences max.`,
    `Actions completed: ${results.filter(r => r.status === 'completed').length}. Pending: ${results.filter(r => r.status === 'queued').length}. Details: ${JSON.stringify(results)}`
  );

  return { plan, results, summary };
}

async function agentChat(userId, userMessage) {
  const profileRow = await memory.getProfile(userId);
  const profile = profileRow.profile;
  const recentActions = await memory.getRecentActions(userId, 10);

  const system = `${buildBrainPrompt(profile)}

## Recent actions:
${recentActions.map(a => `- [${a.status}] ${a.description}`).join('\n')}

The user is talking to you directly. Respond conversationally. Be confident and specific — you are their dedicated marketing agent.`;

  return ai.chatWithSystem(system, userMessage);
}

module.exports = { generateActionPlan, executeAction, runAgentCycle, agentChat };
