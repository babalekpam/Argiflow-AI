/**
 * ArgiFlow Universal AI Adapter
 * ─────────────────────────────────────────────────────────────────────────────
 * Drop-in AI client that works with ANY provider.
 * 
 * Supported providers:
 *   anthropic   — claude-sonnet-4-20250514, claude-opus-4, etc.
 *   openai      — gpt-4o, gpt-4-turbo, gpt-3.5-turbo, etc.
 *   gemini      — gemini-1.5-pro, gemini-1.5-flash, etc.
 *   mistral     — mistral-large, mistral-medium, mistral-small, etc.
 *   groq        — llama-3-70b, mixtral-8x7b (ultra fast inference)
 *   cohere      — command-r-plus, command-r, etc.
 *   together    — any model on together.ai (Llama, Qwen, DBRX...)
 *   ollama      — any local model (llama3, mistral, phi3...)
 *   openrouter  — unified gateway to 100+ models
 *
 * USAGE:
 *   const ai = require('./argiflow-ai-adapter');
 *
 *   // Use env default
 *   const reply = await ai.chat('Write a cold email for a dental clinic');
 *
 *   // Use specific provider
 *   const reply = await ai.chat('Analyze this campaign', { provider: 'openai', model: 'gpt-4o' });
 *
 *   // Full message array (for multi-turn)
 *   const reply = await ai.chat(messages, { system: 'You are Aria...' });
 *
 * ENV VARIABLES (set whichever you use in Replit Secrets):
 *   AI_PROVIDER         = anthropic | openai | gemini | mistral | groq | cohere | together | ollama | openrouter
 *   AI_MODEL            = (optional override — defaults per provider shown below)
 *   ANTHROPIC_API_KEY
 *   OPENAI_API_KEY
 *   GEMINI_API_KEY
 *   MISTRAL_API_KEY
 *   GROQ_API_KEY
 *   COHERE_API_KEY
 *   TOGETHER_API_KEY
 *   OPENROUTER_API_KEY
 *   OLLAMA_BASE_URL     = http://localhost:11434 (default)
 */

const https = require('https');
const http = require('http');

// ─── Provider defaults ────────────────────────────────────────────────────────

const PROVIDER_DEFAULTS = {
  openai:      { model: 'gpt-4o',                    maxTokens: 2000 },
  anthropic:   { model: 'claude-sonnet-4-20250514',  maxTokens: 2000 },
  gemini:      { model: 'gemini-1.5-pro',            maxTokens: 2000 },
  mistral:     { model: 'mistral-large-latest',      maxTokens: 2000 },
  groq:        { model: 'llama-3.3-70b-versatile',   maxTokens: 2000 },
  cohere:      { model: 'command-r-plus',            maxTokens: 2000 },
  together:    { model: 'meta-llama/Llama-3-70b-chat-hf', maxTokens: 2000 },
  ollama:      { model: 'llama3',                    maxTokens: 2000 },
  openrouter:  { model: 'anthropic/claude-sonnet-4', maxTokens: 2000 },
};

// ─── HTTP helper ──────────────────────────────────────────────────────────────

function httpPost(url, headers, body) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const lib = parsed.protocol === 'https:' ? https : http;
    const data = JSON.stringify(body);

    const req = lib.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
        ...headers
      }
    }, (res) => {
      let raw = '';
      res.on('data', chunk => raw += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(raw) });
        } catch {
          resolve({ status: res.statusCode, body: raw });
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// ─── Normalize input to message array ────────────────────────────────────────

function normalizeMessages(input) {
  if (typeof input === 'string') {
    return [{ role: 'user', content: input }];
  }
  if (Array.isArray(input)) return input;
  throw new Error('input must be a string or array of messages');
}

// ─── Provider implementations ─────────────────────────────────────────────────

const providers = {

  // ── Anthropic ──────────────────────────────────────────────────────────────
  async anthropic({ messages, system, model, maxTokens }) {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) throw new Error('ANTHROPIC_API_KEY not set');

    const res = await httpPost(
      'https://api.anthropic.com/v1/messages',
      {
        'x-api-key': key,
        'anthropic-version': '2023-06-01'
      },
      {
        model,
        max_tokens: maxTokens,
        ...(system ? { system } : {}),
        messages
      }
    );

    if (res.status !== 200) throw new Error(`Anthropic error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.content[0].text;
  },

  // ── OpenAI (also works for Azure OpenAI with OPENAI_BASE_URL) ─────────────
  async openai({ messages, system, model, maxTokens }) {
    const key = process.env.OPENAI_API_KEY;
    if (!key) throw new Error('OPENAI_API_KEY not set');
    const base = process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1';

    const allMessages = system
      ? [{ role: 'system', content: system }, ...messages]
      : messages;

    const res = await httpPost(
      `${base}/chat/completions`,
      { Authorization: `Bearer ${key}` },
      { model, max_tokens: maxTokens, messages: allMessages }
    );

    if (res.status !== 200) throw new Error(`OpenAI error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.choices[0].message.content;
  },

  // ── Google Gemini ──────────────────────────────────────────────────────────
  async gemini({ messages, system, model, maxTokens }) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) throw new Error('GEMINI_API_KEY not set');

    // Convert to Gemini format
    const contents = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const body = {
      contents,
      generationConfig: { maxOutputTokens: maxTokens }
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };

    const res = await httpPost(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
      {},
      body
    );

    if (res.status !== 200) throw new Error(`Gemini error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.candidates[0].content.parts[0].text;
  },

  // ── Mistral ────────────────────────────────────────────────────────────────
  async mistral({ messages, system, model, maxTokens }) {
    const key = process.env.MISTRAL_API_KEY;
    if (!key) throw new Error('MISTRAL_API_KEY not set');

    const allMessages = system
      ? [{ role: 'system', content: system }, ...messages]
      : messages;

    const res = await httpPost(
      'https://api.mistral.ai/v1/chat/completions',
      { Authorization: `Bearer ${key}` },
      { model, max_tokens: maxTokens, messages: allMessages }
    );

    if (res.status !== 200) throw new Error(`Mistral error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.choices[0].message.content;
  },

  // ── Groq (OpenAI-compatible, very fast) ───────────────────────────────────
  async groq({ messages, system, model, maxTokens }) {
    const key = process.env.GROQ_API_KEY;
    if (!key) throw new Error('GROQ_API_KEY not set');

    const allMessages = system
      ? [{ role: 'system', content: system }, ...messages]
      : messages;

    const res = await httpPost(
      'https://api.groq.com/openai/v1/chat/completions',
      { Authorization: `Bearer ${key}` },
      { model, max_tokens: maxTokens, messages: allMessages }
    );

    if (res.status !== 200) throw new Error(`Groq error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.choices[0].message.content;
  },

  // ── Cohere ─────────────────────────────────────────────────────────────────
  async cohere({ messages, system, model, maxTokens }) {
    const key = process.env.COHERE_API_KEY;
    if (!key) throw new Error('COHERE_API_KEY not set');

    // Convert to Cohere chat history format
    const chatHistory = messages.slice(0, -1).map(m => ({
      role: m.role === 'user' ? 'USER' : 'CHATBOT',
      message: m.content
    }));
    const lastMessage = messages[messages.length - 1].content;

    const res = await httpPost(
      'https://api.cohere.ai/v1/chat',
      { Authorization: `Bearer ${key}` },
      {
        model,
        message: lastMessage,
        chat_history: chatHistory,
        ...(system ? { preamble: system } : {}),
        max_tokens: maxTokens
      }
    );

    if (res.status !== 200) throw new Error(`Cohere error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.text;
  },

  // ── Together AI (100+ open source models) ─────────────────────────────────
  async together({ messages, system, model, maxTokens }) {
    const key = process.env.TOGETHER_API_KEY;
    if (!key) throw new Error('TOGETHER_API_KEY not set');

    const allMessages = system
      ? [{ role: 'system', content: system }, ...messages]
      : messages;

    const res = await httpPost(
      'https://api.together.xyz/v1/chat/completions',
      { Authorization: `Bearer ${key}` },
      { model, max_tokens: maxTokens, messages: allMessages }
    );

    if (res.status !== 200) throw new Error(`Together error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.choices[0].message.content;
  },

  // ── Ollama (local models, zero cost) ──────────────────────────────────────
  async ollama({ messages, system, model, maxTokens }) {
    const base = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';

    const allMessages = system
      ? [{ role: 'system', content: system }, ...messages]
      : messages;

    const res = await httpPost(
      `${base}/api/chat`,
      {},
      {
        model,
        messages: allMessages,
        stream: false,
        options: { num_predict: maxTokens }
      }
    );

    if (res.status !== 200) throw new Error(`Ollama error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.message.content;
  },

  // ── OpenRouter (100+ models via one API key) ───────────────────────────────
  async openrouter({ messages, system, model, maxTokens }) {
    const key = process.env.OPENROUTER_API_KEY;
    if (!key) throw new Error('OPENROUTER_API_KEY not set');

    const allMessages = system
      ? [{ role: 'system', content: system }, ...messages]
      : messages;

    const res = await httpPost(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        Authorization: `Bearer ${key}`,
        'HTTP-Referer': 'https://argilette.co',
        'X-Title': 'ArgiFlow'
      },
      { model, max_tokens: maxTokens, messages: allMessages }
    );

    if (res.status !== 200) throw new Error(`OpenRouter error ${res.status}: ${JSON.stringify(res.body)}`);
    return res.body.choices[0].message.content;
  }
};

// ─── Main chat function ───────────────────────────────────────────────────────

async function chat(input, options = {}) {
  const provider = options.provider || process.env.AI_PROVIDER || 'openai';
  const defaults = PROVIDER_DEFAULTS[provider] || PROVIDER_DEFAULTS.openai;
  const model = options.model || process.env.AI_MODEL || defaults.model;
  const maxTokens = options.maxTokens || defaults.maxTokens;
  const system = options.system || null;

  const messages = normalizeMessages(input);

  if (!providers[provider]) {
    throw new Error(`Unknown provider "${provider}". Supported: ${Object.keys(providers).join(', ')}`);
  }

  return providers[provider]({ messages, system, model, maxTokens });
}

// ─── Convenience helpers ──────────────────────────────────────────────────────

async function chatWithSystem(system, userMessage, options = {}) {
  return chat([{ role: 'user', content: userMessage }], { ...options, system });
}

async function chatJSON(input, options = {}) {
  const reply = await chat(input, options);
  const clean = reply.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}

function getActiveProvider() {
  return process.env.AI_PROVIDER || 'anthropic';
}

function getActiveModel() {
  const provider = getActiveProvider();
  return process.env.AI_MODEL || PROVIDER_DEFAULTS[provider]?.model || 'unknown';
}

function listProviders() {
  return Object.keys(providers).map(name => ({
    name,
    defaultModel: PROVIDER_DEFAULTS[name]?.model,
    envKey: `${name.toUpperCase()}_API_KEY`,
    configured: !!(
      process.env[`${name.toUpperCase()}_API_KEY`] ||
      name === 'ollama'
    )
  }));
}

module.exports = {
  chat,
  chatWithSystem,
  chatJSON,
  getActiveProvider,
  getActiveModel,
  listProviders,
  PROVIDER_DEFAULTS
};
