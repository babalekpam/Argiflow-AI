# ArgiFlow Universal AI Adapter

Works with any AI provider. Zero lock-in.

---

## Supported providers

| Provider | Key to set | Best for |
|---|---|---|
| `anthropic` | `ANTHROPIC_API_KEY` | Best reasoning, default |
| `openai` | `OPENAI_API_KEY` | GPT-4o, widely tested |
| `gemini` | `GEMINI_API_KEY` | Google's latest, fast |
| `mistral` | `MISTRAL_API_KEY` | European, strong on code |
| `groq` | `GROQ_API_KEY` | Ultra-fast inference (free tier) |
| `cohere` | `COHERE_API_KEY` | Good for enterprise RAG |
| `together` | `TOGETHER_API_KEY` | 100+ open-source models |
| `ollama` | none (local) | Free, private, on your server |
| `openrouter` | `OPENROUTER_API_KEY` | Gateway to 100+ models, one key |

---

## Setup (2 steps)

### 1. Set in Replit Secrets

Set the key for whichever provider(s) you want to use:
```
AI_PROVIDER = openai          ← default (OpenAI is first)
AI_MODEL    = gpt-4o          ← optional model override
OPENAI_API_KEY = sk-...
```

### 2. Replace your existing imports

**Before** (Anthropic SDK directly):
```js
const Anthropic = require('@anthropic-ai/sdk');
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const response = await client.messages.create({ ... });
const text = response.content[0].text;
```

**After** (universal adapter):
```js
const ai = require('./argiflow-ai-adapter');
const text = await ai.chat('Your prompt here');
```

---

## API

```js
const ai = require('./argiflow-ai-adapter');

// Simple string prompt (uses AI_PROVIDER + AI_MODEL from env)
const reply = await ai.chat('Write a cold email');

// With system prompt
const reply = await ai.chatWithSystem('You are Aria...', 'Write a cold email');

// Override provider for one call
const reply = await ai.chat('Write a cold email', { provider: 'openai', model: 'gpt-4o' });

// Returns parsed JSON
const plan = await ai.chatJSON('Return a JSON action plan...', { system: '...' });

// Multi-turn conversation
const reply = await ai.chat([
  { role: 'user', content: 'Hello' },
  { role: 'assistant', content: 'Hi! How can I help?' },
  { role: 'user', content: 'Write me a subject line' }
], { system: 'You are Aria...' });

// Check active config
ai.getActiveProvider() // → 'openai'
ai.getActiveModel()    // → 'gpt-4o'
ai.listProviders()     // → [{ name, defaultModel, configured }]
```

---

## Plug into server.js

```js
// Add provider API routes (list, test, switch)
const aiRoutes = require('./argiflow-ai-adapter/aiProviderRoutes');
app.use('/api/ai', aiRoutes);

// Replace marketing suite routes with multi-provider version
const marketingSuite = require('./argiflow-ai-adapter/marketingSuite-multiProvider');
app.use('/api/marketing-suite', marketingSuite);
```

---

## Replace Agent files

| Replace this file | With this file |
|---|---|
| `agent/AgentBrain.js` | `argiflow-ai-adapter/AgentBrain-multiProvider.js` |
| `agent/CompanyDiscovery.js` | `argiflow-ai-adapter/CompanyDiscovery-multiProvider.js` |
| `routes/marketingSuite.js` | `argiflow-ai-adapter/marketingSuite-multiProvider.js` |

---

## Switch provider at runtime

```bash
# Via API
PATCH /api/ai/provider
{ "provider": "groq", "model": "llama-3.3-70b-versatile" }

# Test it's working
POST /api/ai/test
→ { "reply": "ArgiFlow AI adapter is working!", "provider": "groq" }
```

---

## Cost comparison (per 1M tokens, approx)

| Provider | Input | Output | Notes |
|---|---|---|---|
| Groq (Llama 3 70B) | $0.59 | $0.79 | Fastest, cheapest |
| Together (Llama 3 70B) | $0.90 | $0.90 | Many model options |
| Mistral Large | $3.00 | $9.00 | Strong reasoning |
| Gemini 1.5 Flash | $0.075 | $0.30 | Very cheap |
| GPT-4o mini | $0.15 | $0.60 | Good balance |
| GPT-4o | $2.50 | $10.00 | Best OpenAI |
| Claude Sonnet | $3.00 | $15.00 | Best for complex tasks |
| Ollama (local) | FREE | FREE | Needs your own hardware |

**Recommendation for ArgiFlow:** Use **Groq** for fast/cheap operations (sequence review, quick copy) and **Claude/GPT-4o** for complex planning (action plans, discovery).
