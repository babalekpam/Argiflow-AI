/**
 * marketingSuite-multiProvider.js
 * Drop-in replacement for routes/marketingSuite.js
 * Uses the universal AI adapter instead of Anthropic SDK directly.
 *
 * Mount in server.js:
 *   const marketingSuite = require('./argiflow-ai-adapter/marketingSuite-multiProvider');
 *   app.use('/api/marketing-suite', marketingSuite);
 */

const express = require('express');
const router = express.Router();
const ai = require('./index');
const { getSkill, buildSkillPrompt, buildAutoPrompt, listSkills } = require('../argiflow-marketing-skills/lib/skillsLoader');
const fs = require('fs');
const path = require('path');

const ARGIFLOW_CONTEXT = (() => {
  try {
    return fs.readFileSync(
      path.join(__dirname, '../argiflow-marketing-skills/context/argiflow-product-context.md'), 'utf8'
    );
  } catch { return ''; }
})();

async function callWithSkill(skillName, userPrompt, extraContext = '') {
  const skillContent = getSkill(skillName);
  const system = `You are Aria, ArgiFlow's AI marketing assistant — sharp, direct, expert-level.

${ARGIFLOW_CONTEXT}
${extraContext ? `\n## Additional Context\n${extraContext}` : ''}

---

# ACTIVE SKILL: ${skillName}
${skillContent}

Always give complete, actionable, ready-to-use output. Write final copy — no [brackets].`;

  return ai.chatWithSystem(system, userPrompt, { maxTokens: 2000 });
}

// List skills
router.get('/skills', (req, res) => res.json({ skills: listSkills() }));

// Cold email
router.post('/cold-email', async (req, res) => {
  try {
    const { target_role, company_name, industry, pain_point, your_offer, tone = 'peer-level' } = req.body;
    const result = await callWithSkill('cold-email',
      `Write a complete 4-touch cold email sequence:
Target: ${target_role} at ${company_name || `a ${industry} company`}
Industry: ${industry} | Pain: ${pain_point} | Offer: ${your_offer} | Tone: ${tone}
Deliver subject lines, full body copy, timing, and purpose for all 4 emails.`
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Email sequence
router.post('/email-sequence', async (req, res) => {
  try {
    const { sequence_type, audience, goal, product_context = '', num_emails = 5 } = req.body;
    const result = await callWithSkill('email-sequence',
      `Design a complete ${sequence_type} email sequence:
Audience: ${audience} | Goal: ${goal} | Emails: ${num_emails}
${product_context ? `Context: ${product_context}` : ''}
For each email: number, purpose, timing, subject, preview, body, CTA.`
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Page audit
router.post('/page-audit', async (req, res) => {
  try {
    const { page_url, page_copy, page_type, goal, traffic_source = 'organic' } = req.body;
    const result = await callWithSkill('page-cro',
      `Audit this ${page_type} page:\n${page_url ? `URL: ${page_url}\n` : ''}Goal: ${goal} | Traffic: ${traffic_source}\n\nPage copy:\n"""\n${page_copy}\n"""\n\nProvide: score (1-10), quick wins, high-impact changes, 3 headline alternatives, CTA alternatives, top objection not addressed.`
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Copy writer (uses 2 skills combined)
router.post('/copy-writer', async (req, res) => {
  try {
    const { copy_type, audience, tone, key_points, existing_copy = '' } = req.body;
    const system = buildSkillPrompt(['copywriting', 'marketing-psychology'], ARGIFLOW_CONTEXT);
    const result = await ai.chat(
      `Write ${copy_type} for: ${audience} | Tone: ${tone} | Key points: ${key_points}${existing_copy ? `\n\nImprove this:\n"""\n${existing_copy}\n"""` : ''}\n\nDeliver final copy + 2 headline alternatives.`,
      { system, maxTokens: 2000 }
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Launch planner
router.post('/launch-planner', async (req, res) => {
  try {
    const { launch_type, product_name, target_audience, timeline, channels_available } = req.body;
    const result = await callWithSkill('launch-strategy',
      `Create a complete launch plan for "${product_name}" (${launch_type}):
Audience: ${target_audience} | Timeline: ${timeline} | Channels: ${channels_available}
Deliver: pre-launch checklist, launch day schedule, 30-day post-plan, top channel moves, announcement email copy.`
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Pricing advisor
router.post('/pricing-advisor', async (req, res) => {
  try {
    const { product_type, current_pricing = 'none', target_market, competitors, goal } = req.body;
    const result = await callWithSkill('pricing-strategy',
      `Advise on pricing: ${product_type} | Current: ${current_pricing} | Market: ${target_market}
Competitors: ${competitors} | Goal: ${goal}
Deliver: 3-tier structure, value metric, psychology tactics, annual vs monthly recommendation, what to test first.`
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Ad creative
router.post('/ad-creative', async (req, res) => {
  try {
    const { platform, audience, offer, goal, tone = 'direct' } = req.body;
    const result = await callWithSkill('ad-creative',
      `Create ad creative for ${platform}: Audience: ${audience} | Offer: ${offer} | Goal: ${goal} | Tone: ${tone}
Deliver: 3 headlines, 2 body copy variations, 3 CTAs, hook line.`
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Sequence reviewer
router.post('/sequence-review', async (req, res) => {
  try {
    const { sequence_name, target_segment, emails } = req.body;
    const formatted = emails.map((e, i) => `Email ${i+1}:\nSubject: ${e.subject}\n\n${e.body}`).join('\n\n---\n\n');
    const system = buildSkillPrompt(['cold-email', 'marketing-psychology'], ARGIFLOW_CONTEXT);
    const result = await ai.chat(
      `Review sequence "${sequence_name}" for ${target_segment}:\n\n${formatted}\n\nScore each email (1-10), what's working, what to fix, subject line alternatives. Then overall sequence assessment + #1 change before sending.`,
      { system, maxTokens: 2500 }
    );
    res.json({ success: true, result });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Aria enhanced (auto-skill detection)
router.post('/aria-enhanced', async (req, res) => {
  try {
    const { message, conversation_history = [], user_context = '' } = req.body;
    const { skills, prompt: systemPrompt } = buildAutoPrompt(message, ARGIFLOW_CONTEXT);
    const messages = [...conversation_history, { role: 'user', content: message }];
    const result = await ai.chat(messages, { system: `You are Aria, ArgiFlow's AI assistant.\n\n${systemPrompt}${user_context ? `\n\nUser context: ${user_context}` : ''}`, maxTokens: 1500 });
    res.json({ success: true, result, skills_used: skills });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

module.exports = router;
