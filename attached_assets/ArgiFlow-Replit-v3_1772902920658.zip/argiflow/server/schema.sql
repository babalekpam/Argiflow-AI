-- ═══════════════════════════════════════════════════════
--  ArgiFlow PostgreSQL Schema
--  Run: npm run db:init
-- ═══════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users
CREATE TABLE IF NOT EXISTS users (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email      TEXT UNIQUE NOT NULL,
  name       TEXT NOT NULL,
  org        TEXT,
  plan       TEXT DEFAULT 'starter',
  credits    INTEGER DEFAULT 3000,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Credits ledger
CREATE TABLE IF NOT EXISTS credits_ledger (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  action       TEXT NOT NULL,
  credits_used INTEGER NOT NULL,
  provider     TEXT,
  model        TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Leads
CREATE TABLE IF NOT EXISTS leads (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT,
  title      TEXT,
  company    TEXT,
  email      TEXT,
  industry   TEXT,
  size       TEXT,
  location   TEXT,
  country    TEXT,
  score      INTEGER DEFAULT 0,
  intent     TEXT DEFAULT 'cold',
  verified   BOOLEAN DEFAULT FALSE,
  enriched   BOOLEAN DEFAULT FALSE,
  enrichment JSONB,
  source     TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS leads_user_idx   ON leads(user_id);
CREATE INDEX IF NOT EXISTS leads_intent_idx ON leads(intent);
CREATE INDEX IF NOT EXISTS leads_score_idx  ON leads(score DESC);

-- Agent runs
CREATE TABLE IF NOT EXISTS agent_runs (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  agent_id   TEXT NOT NULL,
  agent_name TEXT,
  prompt     TEXT,
  output     TEXT,
  provider   TEXT,
  model      TEXT,
  status     TEXT DEFAULT 'completed',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Intent signals
CREATE TABLE IF NOT EXISTS intent_signals (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  company    TEXT NOT NULL,
  domain     TEXT NOT NULL,
  signal     TEXT NOT NULL,
  strength   TEXT DEFAULT 'MED',
  score      INTEGER DEFAULT 50,
  source     TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS intent_user_idx ON intent_signals(user_id);

-- Monitored domains
CREATE TABLE IF NOT EXISTS monitored_domains (
  id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id  UUID REFERENCES users(id) ON DELETE CASCADE,
  domain   TEXT NOT NULL,
  company  TEXT,
  active   BOOLEAN DEFAULT TRUE,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, domain)
);

-- Workflows
CREATE TABLE IF NOT EXISTS workflows (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  status     TEXT DEFAULT 'draft',
  runs       INTEGER DEFAULT 0,
  nodes      JSONB DEFAULT '[]',
  edges      JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Sites
CREATE TABLE IF NOT EXISTS sites (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  url        TEXT,
  status     TEXT DEFAULT 'draft',
  visitors   INTEGER DEFAULT 0,
  blocks     JSONB DEFAULT '[]',
  pages      JSONB DEFAULT '["Home"]',
  template   TEXT DEFAULT 'blank',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pipeline snapshots
CREATE TABLE IF NOT EXISTS pipeline_snapshots (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  found      INTEGER DEFAULT 0,
  enriched   INTEGER DEFAULT 0,
  contacted  INTEGER DEFAULT 0,
  replied    INTEGER DEFAULT 0,
  meeting    INTEGER DEFAULT 0,
  closed     INTEGER DEFAULT 0,
  snapped_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed demo user
INSERT INTO users (email, name, org, plan, credits)
VALUES ('abel@argilette.co', 'Abel Nkawula', 'ARGILETTE LLC', 'growth', 8000)
ON CONFLICT (email) DO NOTHING;


-- ═══════════════════════════════════════════════════════
--  TRACKING TABLES
-- ═══════════════════════════════════════════════════════

-- Visitors (anonymous + identified)
CREATE TABLE IF NOT EXISTS track_visitors (
  visitor_id    TEXT PRIMARY KEY,               -- persistent cookie ID
  user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
  email         TEXT,                           -- set after identify()
  name          TEXT,
  company       TEXT,
  first_ip      TEXT,
  first_browser TEXT,
  first_device  TEXT,
  first_seen    TIMESTAMPTZ DEFAULT NOW(),
  last_seen     TIMESTAMPTZ DEFAULT NOW(),
  visit_count   INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS tv_user_idx   ON track_visitors(user_id);
CREATE INDEX IF NOT EXISTS tv_last_idx   ON track_visitors(last_seen DESC);
CREATE INDEX IF NOT EXISTS tv_email_idx  ON track_visitors(email);

-- Sessions (one per browser tab open → close)
CREATE TABLE IF NOT EXISTS track_sessions (
  session_id       TEXT PRIMARY KEY,
  visitor_id       TEXT NOT NULL,
  user_id          UUID REFERENCES users(id) ON DELETE SET NULL,
  entry_page       TEXT,
  exit_page        TEXT,
  referrer         TEXT,
  utm_source       TEXT,
  utm_medium       TEXT,
  utm_campaign     TEXT,
  ip               TEXT,
  browser          TEXT,
  device           TEXT,
  is_mobile        BOOLEAN DEFAULT FALSE,
  page_count       INTEGER DEFAULT 1,
  duration_seconds INTEGER,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  last_activity    TIMESTAMPTZ DEFAULT NOW(),
  ended_at         TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ts_visitor_idx ON track_sessions(visitor_id);
CREATE INDEX IF NOT EXISTS ts_created_idx ON track_sessions(created_at DESC);
CREATE INDEX IF NOT EXISTS ts_utm_idx     ON track_sessions(utm_source, utm_campaign);

-- Page views
CREATE TABLE IF NOT EXISTS track_pageviews (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id      TEXT,
  visitor_id      TEXT,
  user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
  page            TEXT NOT NULL,
  title           TEXT,
  referrer        TEXT,
  utm_source      TEXT,
  utm_medium      TEXT,
  utm_campaign    TEXT,
  utm_term        TEXT,
  ip              TEXT,
  browser         TEXT,
  device          TEXT,
  is_mobile       BOOLEAN DEFAULT FALSE,
  screen_width    INTEGER,
  screen_height   INTEGER,
  timezone        TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tpv_session_idx  ON track_pageviews(session_id);
CREATE INDEX IF NOT EXISTS tpv_visitor_idx  ON track_pageviews(visitor_id);
CREATE INDEX IF NOT EXISTS tpv_page_idx     ON track_pageviews(page);
CREATE INDEX IF NOT EXISTS tpv_created_idx  ON track_pageviews(created_at DESC);

-- Click events (includes rage clicks)
CREATE TABLE IF NOT EXISTS track_clicks (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id     TEXT,
  visitor_id     TEXT,
  page           TEXT,
  element_type   TEXT,           -- button, link, image, div
  element_text   TEXT,           -- visible label
  element_id     TEXT,
  element_class  TEXT,
  href           TEXT,           -- destination if link
  x              INTEGER,        -- click X coordinate
  y              INTEGER,        -- click Y coordinate
  is_rage_click  BOOLEAN DEFAULT FALSE,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tc_visitor_idx   ON track_clicks(visitor_id);
CREATE INDEX IF NOT EXISTS tc_rage_idx      ON track_clicks(is_rage_click) WHERE is_rage_click=true;
CREATE INDEX IF NOT EXISTS tc_page_idx      ON track_clicks(page);

-- Search queries
CREATE TABLE IF NOT EXISTS track_searches (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id      TEXT,
  visitor_id      TEXT,
  user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
  query           TEXT NOT NULL,
  page            TEXT,
  results_count   INTEGER DEFAULT 0,
  clicked_result  TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tsr_visitor_idx ON track_searches(visitor_id);
CREATE INDEX IF NOT EXISTS tsr_query_idx   ON track_searches(query);
CREATE INDEX IF NOT EXISTS tsr_created_idx ON track_searches(created_at DESC);

-- Search term popularity (aggregated)
CREATE TABLE IF NOT EXISTS track_search_terms (
  query            TEXT PRIMARY KEY,
  count            INTEGER DEFAULT 1,
  last_searched_at TIMESTAMPTZ DEFAULT NOW()
);

-- Scroll depth
CREATE TABLE IF NOT EXISTS track_scroll (
  id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id             TEXT,
  visitor_id             TEXT,
  page                   TEXT,
  max_depth_percent      INTEGER DEFAULT 0,   -- 0–100
  time_to_bottom_seconds INTEGER,
  created_at             TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(session_id, page)
);
CREATE INDEX IF NOT EXISTS tsc_page_idx ON track_scroll(page);

-- Form interaction tracking
CREATE TABLE IF NOT EXISTS track_forms (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id            TEXT,
  visitor_id            TEXT,
  page                  TEXT,
  form_id               TEXT,
  form_name             TEXT,
  event_type            TEXT NOT NULL,    -- start|field_focus|field_blur|abandon|submit
  field_name            TEXT,             -- which field (NOT the value)
  time_on_form_seconds  INTEGER,
  created_at            TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tf_session_idx ON track_forms(session_id);
CREATE INDEX IF NOT EXISTS tf_form_idx    ON track_forms(form_name);

-- Custom events (feature usage, video play, modal open, etc.)
CREATE TABLE IF NOT EXISTS track_custom_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id      TEXT,
  visitor_id      TEXT,
  user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
  event_name      TEXT NOT NULL,
  event_category  TEXT,
  properties      JSONB DEFAULT '{}',
  page            TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tce_event_idx   ON track_custom_events(event_name);
CREATE INDEX IF NOT EXISTS tce_visitor_idx ON track_custom_events(visitor_id);

-- Email sends (registered emails for tracking)
CREATE TABLE IF NOT EXISTS track_email_sends (
  token              TEXT PRIMARY KEY,
  user_id            UUID REFERENCES users(id) ON DELETE SET NULL,
  recipient_email    TEXT NOT NULL,
  recipient_name     TEXT,
  subject            TEXT,
  campaign           TEXT,
  opens              INTEGER DEFAULT 0,
  clicks             INTEGER DEFAULT 0,
  open_device        TEXT,
  open_browser       TEXT,
  first_opened_at    TIMESTAMPTZ,
  last_opened_at     TIMESTAMPTZ,
  first_clicked_at   TIMESTAMPTZ,
  last_clicked_at    TIMESTAMPTZ,
  created_at         TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tes_user_idx       ON track_email_sends(user_id);
CREATE INDEX IF NOT EXISTS tes_recipient_idx  ON track_email_sends(recipient_email);
CREATE INDEX IF NOT EXISTS tes_campaign_idx   ON track_email_sends(campaign);

-- Email tracked links
CREATE TABLE IF NOT EXISTS track_email_links (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token        TEXT NOT NULL,
  link_id      TEXT NOT NULL,
  original_url TEXT NOT NULL,
  label        TEXT,
  UNIQUE(token, link_id)
);

-- Email events log (every open, every click logged separately)
CREATE TABLE IF NOT EXISTS track_email_events (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token       TEXT NOT NULL,
  event_type  TEXT NOT NULL,    -- open | click
  link_id     TEXT,             -- which link was clicked
  ip          TEXT,
  user_agent  TEXT,
  browser     TEXT,
  device      TEXT,
  is_mobile   BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tee_token_idx ON track_email_events(token);
CREATE INDEX IF NOT EXISTS tee_type_idx  ON track_email_events(event_type);
