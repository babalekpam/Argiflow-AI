# ArgiFlow — AI Sales Automation Platform
**By ARGILETTE LLC** | argilette.co | Built by Abel Nkawula

---

## 🚀 Deploy on Replit (4 Steps)

### Step 1 — Import
1. Go to replit.com → **Create Repl** → **Import from ZIP**
2. Upload `ArgiFlow-Replit.zip`
3. Replit auto-detects Node.js

### Step 2 — Add Secrets (Environment Variables)
In Replit sidebar → **Secrets** → add each:

| Secret Key | Value |
|---|---|
| `DATABASE_URL` | Your PostgreSQL URL (use Replit built-in DB or Neon.tech free tier) |
| `LLM_PROVIDER` | `anthropic` (or `openai`, `groq`, `gemini`, `mistral`) |
| `LLM_MODEL` | `claude-sonnet-4-6` (or your chosen model) |
| `ANTHROPIC_API_KEY` | `sk-ant-api03-...` |
| `NODE_ENV` | `development` |
| `PORT` | `3001` |

### Step 3 — Initialize Database
In Replit Shell tab:
```bash
npm install
npm run db:init
```

### Step 4 — Run
Click the **Run** button. Both frontend (port 5173) and backend (port 3001) start together.

---

## 📁 Project Structure

```
argiflow/
├── public/
│   └── argiflow-tracker.js     ← Visitor tracking snippet (embed on any site)
├── src/
│   ├── main.jsx
│   └── App.jsx                 ← Full platform UI
├── server/
│   ├── index.js                ← Express server
│   ├── db.js                   ← PostgreSQL connection
│   ├── db-init.js              ← Run once to create tables
│   ├── schema.sql              ← All database tables
│   ├── llm.js                  ← Universal LLM router
│   ├── middleware/
│   │   └── credits.js          ← Credit deduction system
│   └── routes/
│       ├── agents.js           ← 6 universal AI agents
│       ├── dashboard.js        ← Overview stats
│       ├── leads.js            ← Lead search + enrichment
│       ├── intent.js           ← Intent signal monitoring
│       ├── tracker.js          ← 🆕 Full visitor + behavior tracking
│       ├── account.js          ← User account + credits
│       ├── workflows.js        ← Workflow automation
│       └── sites.js            ← Website builder
├── .env.example
├── .replit
├── package.json
└── vite.config.js
```

---

## 🔀 Switch LLM Provider

Change 2 secrets in Replit, restart. No code changes.

| Provider | LLM_PROVIDER | LLM_MODEL | Free Tier? |
|---|---|---|---|
| Anthropic | `anthropic` | `claude-sonnet-4-6` | No |
| OpenAI | `openai` | `gpt-4o` | No |
| Google | `gemini` | `gemini-1.5-flash` | Yes |
| Groq | `groq` | `llama-3.3-70b-versatile` | **Yes** |
| Mistral | `mistral` | `mistral-large-latest` | No |
| Together AI | `together` | `meta-llama/Llama-3-70b-chat-hf` | No |

---

## 📊 Tracking System

### Embed on any website
```html
<!-- Paste in <head> of any site ArgiFlow builds -->
<script src="https://your-argiflow.replit.app/argiflow-tracker.js"
        data-host="https://your-argiflow.replit.app"></script>
```

### Identify logged-in users
```javascript
ArgiFlow.identify({
  user_id: 'u_123',
  email: 'john@company.com',
  name: 'John Smith',
  company: 'Acme Corp'
});
```

### Track custom events
```javascript
ArgiFlow.track('add_to_cart', 'ecommerce', { product: 'iPhone 15', price: 999 });
ArgiFlow.track('agent_run',   'platform',  { agent: 'lead-scout' });
ArgiFlow.track('video_play',  'engagement',{ video: 'product_demo' });
```

### What gets tracked automatically
| Signal | What It Captures |
|---|---|
| Page Views | Every page, SPA route changes, title, referrer |
| Sessions | Entry/exit page, duration, bounce, UTM attribution |
| Clicks | Every click — element, text, coordinates |
| Rage Clicks | 3+ clicks same spot < 1 sec = frustrated user |
| Scroll Depth | 0–100% per page, time to reach bottom |
| Search Queries | Auto-detects all search inputs, logs every query |
| Form Behavior | Start, field focus, abandon, submit — with time spent |
| Email Opens | Device, browser, how many times opened |
| Email Clicks | Per-link tracking, open-to-click time |

### Analytics API endpoints
```
GET /api/tracker/dashboard?days=7     — Summary stats
GET /api/tracker/visitors?days=7      — Visitor list + behavior
GET /api/tracker/visitor/:id          — Full visitor journey
GET /api/tracker/emails?days=30       — Email performance
GET /api/tracker/realtime             — Active visitors now
```

---

## 💳 Credit System

| Action | Credits |
|---|---|
| Agent run | 50 |
| Lead enrichment | 15 |
| Intent scan | 20 |
| AI email write | 8 |
| Reply analysis | 10 |
| Email sequence | 30 |

Demo user starts with **8,000 credits** (abel@argilette.co).

---

## 🏭 Production Deploy

```bash
npm run build
NODE_ENV=production npm start
```
Serves frontend + backend on a single port.

---

*ArgiFlow — Built by Abel Nkawula, ARGILETTE LLC*
