const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  agentType: { type: String, required: true },
  leadId: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },

  type: { type: String, enum: ['purchase', 'sale', 'commission', 'refund', 'fee'], required: true },
  status: { type: String, enum: ['pending', 'completed', 'failed', 'refunded'], default: 'pending' },

  amount: { type: Number, required: true },
  currency: { type: String, default: 'USD' },
  description: String,

  // Payment
  paymentMethod: String,
  paymentRef: String,
  stripePaymentId: String,

  // ROI tracking
  investedAmount: Number,
  returnAmount: Number,
  profit: Number,
  roi: Number,

  metadata: { type: mongoose.Schema.Types.Mixed },

  completedAt: Date,
}, { timestamps: true });

transactionSchema.index({ userId: 1, agentType: 1 });
transactionSchema.index({ userId: 1, status: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
