const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  agentType: { type: String, required: true },
  agentConfigId: { type: mongoose.Schema.Types.ObjectId, ref: 'AgentConfig' },

  // Task details
  taskType: {
    type: String,
    enum: ['crawl', 'analyze', 'outreach', 'bid', 'monitor', 'report', 'notify', 'custom'],
    required: true
  },
  description: String,

  // Status
  status: {
    type: String,
    enum: ['queued', 'running', 'completed', 'failed', 'cancelled'],
    default: 'queued'
  },
  priority: { type: Number, default: 5, min: 1, max: 10 },

  // Execution
  scheduledFor: { type: Date, default: Date.now },
  startedAt: Date,
  completedAt: Date,
  duration: Number, // ms

  // Results
  result: { type: mongoose.Schema.Types.Mixed },
  error: String,
  retries: { type: Number, default: 0 },
  maxRetries: { type: Number, default: 3 },

  // Related leads
  leadIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Lead' }],

}, { timestamps: true });

taskSchema.index({ status: 1, scheduledFor: 1 });
taskSchema.index({ userId: 1, agentType: 1, status: 1 });

module.exports = mongoose.model('Task', taskSchema);
