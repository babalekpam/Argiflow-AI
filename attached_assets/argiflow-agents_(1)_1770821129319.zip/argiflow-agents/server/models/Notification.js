const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  agentType: String,
  leadId: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },

  type: {
    type: String,
    enum: ['new_lead', 'high_priority', 'auction_reminder', 'bid_result', 'deal_completed',
           'agent_error', 'approval_needed', 'report', 'system'],
    required: true
  },

  title: { type: String, required: true },
  message: { type: String, required: true },
  priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },

  read: { type: Boolean, default: false },
  readAt: Date,

  // Action
  actionUrl: String,
  actionLabel: String,
  requiresAction: { type: Boolean, default: false },
  actionTaken: { type: Boolean, default: false },

  // Delivery
  channels: [{
    type: { type: String, enum: ['in_app', 'email', 'sms'] },
    sentAt: Date,
    delivered: Boolean,
  }],

}, { timestamps: true });

notificationSchema.index({ userId: 1, read: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);
