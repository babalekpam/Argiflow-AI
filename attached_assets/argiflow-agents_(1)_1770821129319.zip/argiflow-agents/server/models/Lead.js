const mongoose = require('mongoose');

const leadSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  agentType: { type: String, required: true, index: true },
  agentConfigId: { type: mongoose.Schema.Types.ObjectId, ref: 'AgentConfig' },

  // Universal lead fields
  title: { type: String, required: true },
  description: String,
  source: String,
  sourceUrl: String,
  externalId: String, // parcel number, contract ID, ASIN, etc.

  // Status pipeline
  status: {
    type: String,
    enum: ['discovered', 'analyzing', 'qualified', 'approved', 'bidding', 'won', 'lost', 'passed', 'completed', 'archived'],
    default: 'discovered',
    index: true
  },

  // Scoring
  score: { type: Number, default: 0, min: 0, max: 100 },
  priority: { type: String, enum: ['low', 'medium', 'high', 'critical'], default: 'medium' },
  aiRecommendation: { type: String, enum: ['buy', 'pass', 'watch', 'pending'], default: 'pending' },
  aiAnalysis: String,

  // Financial
  estimatedCost: Number,
  estimatedValue: Number,
  estimatedROI: Number,
  actualCost: Number,
  actualValue: Number,
  actualROI: Number,

  // Location (for property-based agents)
  location: {
    address: String,
    city: String,
    county: String,
    state: String,
    zip: String,
    lat: Number,
    lng: Number,
  },

  // Agent-specific data (flexible)
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },

  // Timeline
  discoveredAt: { type: Date, default: Date.now },
  analyzedAt: Date,
  approvedAt: Date,
  actionDeadline: Date, // auction date, bid deadline, etc.
  completedAt: Date,

  // Outreach tracking
  outreach: [{
    type: { type: String, enum: ['email', 'sms', 'call', 'mail', 'bid'] },
    sentAt: Date,
    status: String,
    response: String,
  }],

  // Notes
  notes: [{
    content: String,
    createdAt: { type: Date, default: Date.now },
    author: { type: String, enum: ['user', 'agent'], default: 'agent' }
  }],

  // Documents
  documents: [{
    name: String,
    type: String,
    url: String,
    generatedAt: Date,
  }],

  isArchived: { type: Boolean, default: false },
}, { timestamps: true });

// Text search index
leadSchema.index({ title: 'text', description: 'text', 'location.address': 'text' });

// Compound indexes for common queries
leadSchema.index({ userId: 1, agentType: 1, status: 1 });
leadSchema.index({ userId: 1, priority: 1, status: 1 });
leadSchema.index({ actionDeadline: 1 });

module.exports = mongoose.model('Lead', leadSchema);
