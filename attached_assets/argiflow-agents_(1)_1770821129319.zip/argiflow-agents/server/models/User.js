const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6 },
  phone: { type: String },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },

  // Subscription
  plan: {
    type: String,
    enum: ['free', 'starter', 'pro', 'enterprise'],
    default: 'free'
  },
  stripeCustomerId: String,
  subscriptionId: String,
  subscriptionStatus: { type: String, default: 'inactive' },

  // Active agents for this user
  activeAgents: [{
    agentType: String,
    enabled: { type: Boolean, default: false },
    configId: { type: mongoose.Schema.Types.ObjectId, ref: 'AgentConfig' }
  }],

  // Notification preferences
  notifications: {
    email: { type: Boolean, default: true },
    sms: { type: Boolean, default: false },
    push: { type: Boolean, default: true },
    frequency: { type: String, enum: ['instant', 'hourly', 'daily'], default: 'instant' }
  },

  // Stats
  totalDeals: { type: Number, default: 0 },
  totalInvested: { type: Number, default: 0 },
  totalProfit: { type: Number, default: 0 },

  lastLogin: Date,
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

// Hash password
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Generate JWT
userSchema.methods.generateToken = function() {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d'
  });
};

module.exports = mongoose.model('User', userSchema);
