const mongoose = require('mongoose');

const agentConfigSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  agentType: { type: String, required: true, index: true },
  enabled: { type: Boolean, default: false },

  // Universal settings (all agents use these)
  settings: {
    // Budget
    budgetMin: { type: Number, default: 0 },
    budgetMax: { type: Number, default: 10000 },
    monthlyBudgetCap: { type: Number, default: 50000 },

    // ROI / Performance
    minROI: { type: Number, default: 10 },
    riskTolerance: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },

    // Scheduling
    runFrequency: { type: String, enum: ['hourly', 'daily', 'weekly'], default: 'daily' },
    runTime: { type: String, default: '06:00' },

    // Notifications
    notifyOnNewLeads: { type: Boolean, default: true },
    notifyOnHighPriority: { type: Boolean, default: true },
    notifyOnAuction: { type: Boolean, default: true },
    requireApproval: { type: Boolean, default: true },
    autoApproveUnder: { type: Number, default: 0 },
  },

  // Agent-specific configuration (flexible schema per agent type)
  agentSettings: { type: mongoose.Schema.Types.Mixed, default: {} },

  // Agent state
  state: {
    lastRun: Date,
    nextRun: Date,
    totalLeadsFound: { type: Number, default: 0 },
    totalDealsCompleted: { type: Number, default: 0 },
    isRunning: { type: Boolean, default: false },
    lastError: String,
    healthScore: { type: Number, default: 100 },
  },

  // Crawl targets (URLs, counties, regions, etc.)
  targets: [{ type: mongoose.Schema.Types.Mixed }],

}, { timestamps: true });

// Compound index for fast lookups
agentConfigSchema.index({ userId: 1, agentType: 1 }, { unique: true });

module.exports = mongoose.model('AgentConfig', agentConfigSchema);
