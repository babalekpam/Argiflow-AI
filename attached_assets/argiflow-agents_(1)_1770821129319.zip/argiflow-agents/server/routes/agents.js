const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const AgentConfig = require('../models/AgentConfig');
const registry = require('../agents/AgentRegistry');

// Get agent catalog (all available agents)
router.get('/catalog', auth, (req, res) => {
  const catalog = registry.getCatalog();
  res.json({ agents: catalog });
});

// Get user's agent configurations
router.get('/my-agents', auth, async (req, res) => {
  try {
    const configs = await AgentConfig.find({ userId: req.user._id });
    const catalog = registry.getCatalog();

    // Merge catalog info with user configs
    const agents = catalog.map(agent => {
      const config = configs.find(c => c.agentType === agent.type);
      return {
        ...agent,
        configured: !!config,
        enabled: config?.enabled || false,
        config: config || null,
      };
    });

    res.json({ agents });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Setup / configure an agent
router.post('/configure/:agentType', auth, async (req, res) => {
  try {
    const { agentType } = req.params;

    if (!registry.has(agentType)) {
      return res.status(404).json({ error: 'Agent type not found' });
    }

    const agent = registry.get(agentType);
    const { settings, agentSettings, targets, enabled } = req.body;

    let config = await AgentConfig.findOne({ userId: req.user._id, agentType });

    if (config) {
      // Update existing
      if (settings) config.settings = { ...config.settings, ...settings };
      if (agentSettings) config.agentSettings = { ...config.agentSettings, ...agentSettings };
      if (targets) config.targets = targets;
      if (enabled !== undefined) config.enabled = enabled;
      await config.save();
    } else {
      // Create new
      config = await AgentConfig.create({
        userId: req.user._id,
        agentType,
        enabled: enabled || false,
        settings: settings || {},
        agentSettings: agentSettings || agent.defaultAgentSettings,
        targets: targets || [],
      });

      // Add to user's active agents
      await require('../models/User').findByIdAndUpdate(req.user._id, {
        $push: {
          activeAgents: {
            agentType,
            enabled: enabled || false,
            configId: config._id,
          }
        }
      });
    }

    res.json({ config });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Enable/disable an agent
router.patch('/toggle/:agentType', auth, async (req, res) => {
  try {
    const config = await AgentConfig.findOne({
      userId: req.user._id,
      agentType: req.params.agentType,
    });

    if (!config) {
      return res.status(404).json({ error: 'Agent not configured. Set it up first.' });
    }

    config.enabled = !config.enabled;
    if (config.enabled && !config.state.nextRun) {
      config.state.nextRun = new Date(); // Run immediately
    }
    await config.save();

    res.json({ enabled: config.enabled, config });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Manually trigger an agent run
router.post('/run/:agentType', auth, async (req, res) => {
  try {
    const config = await AgentConfig.findOne({
      userId: req.user._id,
      agentType: req.params.agentType,
    });

    if (!config) {
      return res.status(404).json({ error: 'Agent not configured' });
    }

    if (config.state.isRunning) {
      return res.status(409).json({ error: 'Agent is already running' });
    }

    const agent = registry.get(req.params.agentType);

    // Run async (don't await)
    agent.run(config).catch(err => {
      console.error(`Manual run error for ${req.params.agentType}:`, err);
    });

    res.json({ message: 'Agent run started', agentType: req.params.agentType });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get agent status
router.get('/status/:agentType', auth, async (req, res) => {
  try {
    const config = await AgentConfig.findOne({
      userId: req.user._id,
      agentType: req.params.agentType,
    });

    if (!config) {
      return res.status(404).json({ error: 'Agent not configured' });
    }

    const Task = require('../models/Task');
    const recentTasks = await Task.find({
      userId: req.user._id,
      agentType: req.params.agentType,
    }).sort({ createdAt: -1 }).limit(10);

    res.json({ state: config.state, recentTasks });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
