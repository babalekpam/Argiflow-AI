const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const Lead = require('../models/Lead');

// Get leads with filtering
router.get('/', auth, async (req, res) => {
  try {
    const {
      agentType, status, priority, recommendation,
      page = 1, limit = 20, sort = '-discoveredAt',
      search
    } = req.query;

    const filter = { userId: req.user._id, isArchived: false };
    if (agentType) filter.agentType = agentType;
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (recommendation) filter.aiRecommendation = recommendation;

    let query = Lead.find(filter);

    if (search) {
      query = Lead.find({
        ...filter,
        $text: { $search: search }
      });
    }

    const total = await Lead.countDocuments(filter);
    const leads = await query
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    res.json({
      leads,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single lead with full details
router.get('/:id', auth, async (req, res) => {
  try {
    const lead = await Lead.findOne({ _id: req.params.id, userId: req.user._id });
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    res.json({ lead });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update lead status (approve, pass, etc.)
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ['approved', 'passed', 'archived', 'watching'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: `Status must be one of: ${validStatuses.join(', ')}` });
    }

    const update = { status };
    if (status === 'approved') update.approvedAt = new Date();

    const lead = await Lead.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      update,
      { new: true }
    );

    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    res.json({ lead });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Bulk approve leads
router.post('/bulk-approve', auth, async (req, res) => {
  try {
    const { leadIds } = req.body;
    const result = await Lead.updateMany(
      { _id: { $in: leadIds }, userId: req.user._id },
      { status: 'approved', approvedAt: new Date() }
    );
    res.json({ updated: result.modifiedCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add note to lead
router.post('/:id/notes', auth, async (req, res) => {
  try {
    const lead = await Lead.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      { $push: { notes: { content: req.body.content, author: 'user' } } },
      { new: true }
    );
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    res.json({ lead });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get pipeline summary
router.get('/pipeline/summary', auth, async (req, res) => {
  try {
    const { agentType } = req.query;
    const filter = { userId: req.user._id, isArchived: false };
    if (agentType) filter.agentType = agentType;

    const pipeline = await Lead.aggregate([
      { $match: filter },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          totalValue: { $sum: '$estimatedValue' },
          totalCost: { $sum: '$estimatedCost' },
          avgScore: { $avg: '$score' },
          avgROI: { $avg: '$estimatedROI' },
        }
      }
    ]);

    res.json({ pipeline });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
