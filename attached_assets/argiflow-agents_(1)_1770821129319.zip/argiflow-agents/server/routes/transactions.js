const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const Transaction = require('../models/Transaction');

// Get transactions
router.get('/', auth, async (req, res) => {
  try {
    const { agentType, status, page = 1, limit = 20 } = req.query;
    const filter = { userId: req.user._id };
    if (agentType) filter.agentType = agentType;
    if (status) filter.status = status;

    const total = await Transaction.countDocuments(filter);
    const transactions = await Transaction.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .populate('leadId', 'title location');

    res.json({ transactions, total, page: parseInt(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get transaction summary
router.get('/summary', auth, async (req, res) => {
  try {
    const summary = await Transaction.aggregate([
      { $match: { userId: req.user._id } },
      {
        $group: {
          _id: '$agentType',
          totalInvested: { $sum: '$investedAmount' },
          totalReturns: { $sum: '$returnAmount' },
          totalProfit: { $sum: '$profit' },
          avgROI: { $avg: '$roi' },
          count: { $sum: 1 },
        }
      }
    ]);
    res.json({ summary });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
