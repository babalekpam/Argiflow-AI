const logger = require('../config/logger');

class AgentRegistry {
  constructor() {
    this.agents = new Map();
  }

  /**
   * Register an agent class
   */
  register(AgentClass) {
    const agent = new AgentClass();
    this.agents.set(agent.type, agent);
    logger.info(`Registered agent: ${agent.type} (${agent.name})`);
    return this;
  }

  /**
   * Get agent instance by type
   */
  get(type) {
    const agent = this.agents.get(type);
    if (!agent) {
      throw new Error(`Agent type "${type}" not found in registry`);
    }
    return agent;
  }

  /**
   * Get all registered agents
   */
  getAll() {
    return Array.from(this.agents.values());
  }

  /**
   * Get all agent info for dashboard
   */
  getCatalog() {
    return this.getAll().map(agent => agent.getInfo());
  }

  /**
   * Check if agent type exists
   */
  has(type) {
    return this.agents.has(type);
  }
}

// Singleton registry
const registry = new AgentRegistry();

// ===== REGISTER ALL AGENTS HERE =====
// To add a new agent, just add one line:

const TaxLienAgent = require('./tax-lien/TaxLienAgent');
registry.register(TaxLienAgent);

// Future agents (uncomment when ready):
// const TaxDeedAgent = require('./tax-deed/TaxDeedAgent');
// registry.register(TaxDeedAgent);
//
// const WholesaleREAgent = require('./wholesale-re/WholesaleREAgent');
// registry.register(WholesaleREAgent);
//
// const GovtContractsAgent = require('./govt-contracts/GovtContractsAgent');
// registry.register(GovtContractsAgent);
//
// const ArbitrageAgent = require('./arbitrage/ArbitrageAgent');
// registry.register(ArbitrageAgent);
//
// const LeadGenAgent = require('./lead-gen/LeadGenAgent');
// registry.register(LeadGenAgent);

module.exports = registry;
