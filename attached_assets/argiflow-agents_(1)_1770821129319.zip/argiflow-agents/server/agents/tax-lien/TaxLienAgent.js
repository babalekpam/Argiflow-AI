const BaseAgent = require('../BaseAgent');
const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../../config/logger');

class TaxLienAgent extends BaseAgent {
  get type() { return 'tax-lien'; }
  get name() { return 'Tax Lien Hunter'; }
  get description() { return 'Discovers tax lien properties, analyzes ROI, monitors auctions, and manages your lien portfolio automatically.'; }
  get icon() { return '🏛️'; }

  get defaultAgentSettings() {
    return {
      // Target locations
      targetStates: ['FL', 'AZ', 'IN', 'NJ', 'IL'],
      targetCounties: [],

      // Property filters
      propertyTypes: ['residential', 'commercial', 'vacant_land'],
      minPropertyValue: 25000,
      maxPropertyValue: 500000,

      // Lien filters
      minLienAmount: 500,
      maxLienAmount: 15000,
      minInterestRate: 8,

      // Strategy
      bidStrategy: 'conservative', // conservative, moderate, aggressive
      maxBidPremium: 5, // % above face value
      preferRedemption: true, // prefer liens likely to be redeemed

      // Auction
      autoRegisterAuctions: true,
      autoBid: false, // requires explicit approval by default
      maxConcurrentBids: 10,
    };
  }

  get settingsSchema() {
    return [
      {
        key: 'targetStates',
        label: 'Target States',
        type: 'multi-select',
        options: [
          { value: 'FL', label: 'Florida' },
          { value: 'AZ', label: 'Arizona' },
          { value: 'IN', label: 'Indiana' },
          { value: 'NJ', label: 'New Jersey' },
          { value: 'IL', label: 'Illinois' },
          { value: 'MD', label: 'Maryland' },
          { value: 'IA', label: 'Iowa' },
          { value: 'SC', label: 'South Carolina' },
          { value: 'CO', label: 'Colorado' },
          { value: 'WV', label: 'West Virginia' },
        ],
        description: 'States with tax lien certificates (not deeds)'
      },
      {
        key: 'propertyTypes',
        label: 'Property Types',
        type: 'multi-select',
        options: [
          { value: 'residential', label: 'Residential' },
          { value: 'commercial', label: 'Commercial' },
          { value: 'vacant_land', label: 'Vacant Land' },
          { value: 'multi_family', label: 'Multi-Family' },
        ]
      },
      {
        key: 'minLienAmount',
        label: 'Min Lien Amount ($)',
        type: 'number',
        min: 100,
        max: 100000,
      },
      {
        key: 'maxLienAmount',
        label: 'Max Lien Amount ($)',
        type: 'number',
        min: 100,
        max: 100000,
      },
      {
        key: 'minInterestRate',
        label: 'Min Interest Rate (%)',
        type: 'number',
        min: 1,
        max: 36,
      },
      {
        key: 'bidStrategy',
        label: 'Bid Strategy',
        type: 'select',
        options: [
          { value: 'conservative', label: 'Conservative - Low risk, steady returns' },
          { value: 'moderate', label: 'Moderate - Balanced approach' },
          { value: 'aggressive', label: 'Aggressive - Higher risk, higher returns' },
        ]
      },
      {
        key: 'autoBid',
        label: 'Auto-Bid at Auctions',
        type: 'toggle',
        description: 'Allow the agent to automatically place bids within your parameters'
      },
    ];
  }

  // ========== PHASE 1: DISCOVERY ==========

  async discover(config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const allLeads = [];

    // Crawl each target state/county
    for (const state of settings.targetStates) {
      try {
        const leads = await this._crawlState(state, settings, config);
        allLeads.push(...leads);
      } catch (err) {
        logger.error(`[tax-lien] Error crawling state ${state}:`, err.message);
      }
    }

    // Also check online auction platforms
    try {
      const auctionLeads = await this._crawlAuctionPlatforms(settings, config);
      allLeads.push(...auctionLeads);
    } catch (err) {
      logger.error('[tax-lien] Error crawling auction platforms:', err.message);
    }

    return allLeads;
  }

  async _crawlState(state, settings, config) {
    const leads = [];

    // Get county sources for this state
    const counties = this._getCountySources(state);

    for (const county of counties) {
      // Skip if user specified target counties and this isn't one
      if (settings.targetCounties.length > 0 &&
          !settings.targetCounties.includes(county.name)) {
        continue;
      }

      try {
        const response = await axios.get(county.url, {
          headers: { 'User-Agent': process.env.SCRAPER_USER_AGENT || 'ArgiFlow-Agent/1.0' },
          timeout: 30000,
        });

        // Use AI to parse the page — handles any format
        const parsedLeads = await this._parseCountyPage(response.data, county, state, settings);
        leads.push(...parsedLeads);

        // Rate limiting between requests
        await this._delay(parseInt(process.env.SCRAPER_DELAY_MS) || 2000);

      } catch (err) {
        logger.warn(`[tax-lien] Failed to crawl ${county.name}, ${state}: ${err.message}`);
      }
    }

    return leads;
  }

  async _parseCountyPage(html, county, state, settings) {
    // First try structured parsing with cheerio
    const $ = cheerio.load(html);
    const pageText = $('body').text().substring(0, 10000); // Limit for AI

    // Use Claude to extract structured data from any format
    const prompt = `Extract tax lien property listings from this county tax collector page.

County: ${county.name}, ${state}
Page content (truncated):
${pageText}

For each property/parcel found, extract:
- parcelNumber: the parcel/tax ID number
- ownerName: property owner name
- address: full property address
- propertyType: residential, commercial, vacant_land, or multi_family
- assessedValue: assessed/market value (number only)
- amountOwed: total tax amount owed (number only)
- interestRate: annual interest rate if shown (number only)
- auctionDate: next auction date if shown (ISO format)
- lienStatus: status of the lien

Return as JSON array. If no listings found, return empty array [].
Only include properties where amountOwed is between ${settings.minLienAmount} and ${settings.maxLienAmount}.`;

    try {
      const parsed = await this.askClaudeJSON(prompt,
        'You are a tax lien data extraction specialist. Extract structured data from county tax pages. Only return valid JSON arrays.'
      );

      if (!Array.isArray(parsed)) return [];

      return parsed.map(item => ({
        title: `Tax Lien - ${item.address || item.parcelNumber}`,
        description: `${county.name}, ${state} - Owner: ${item.ownerName || 'Unknown'}`,
        source: `${county.name} County, ${state}`,
        sourceUrl: county.url,
        externalId: `${state}-${county.name}-${item.parcelNumber}`.toLowerCase().replace(/\s/g, '-'),
        estimatedCost: item.amountOwed || 0,
        estimatedValue: item.assessedValue || 0,
        location: {
          address: item.address,
          county: county.name,
          state: state,
        },
        metadata: {
          parcelNumber: item.parcelNumber,
          ownerName: item.ownerName,
          propertyType: item.propertyType,
          assessedValue: item.assessedValue,
          amountOwed: item.amountOwed,
          interestRate: item.interestRate || this._getStateInterestRate(state),
          auctionDate: item.auctionDate,
          lienStatus: item.lienStatus,
          redemptionPeriod: this._getRedemptionPeriod(state),
        },
        actionDeadline: item.auctionDate ? new Date(item.auctionDate) : null,
      }));
    } catch (err) {
      logger.warn(`[tax-lien] AI parsing failed for ${county.name}: ${err.message}`);
      return [];
    }
  }

  async _crawlAuctionPlatforms(settings, config) {
    // Major online auction platforms
    const platforms = [
      {
        name: 'RealAuction',
        url: 'https://www.realauction.com',
        searchUrl: 'https://www.realauction.com/tax-lien-auctions',
      },
      {
        name: 'GovEase',
        url: 'https://www.govease.com',
        searchUrl: 'https://www.govease.com/auctions',
      },
      {
        name: 'Bid4Assets',
        url: 'https://www.bid4assets.com',
        searchUrl: 'https://www.bid4assets.com/auction/taxlien',
      },
    ];

    const leads = [];

    for (const platform of platforms) {
      try {
        const response = await axios.get(platform.searchUrl, {
          headers: { 'User-Agent': process.env.SCRAPER_USER_AGENT || 'ArgiFlow-Agent/1.0' },
          timeout: 30000,
        });

        const $ = cheerio.load(response.data);
        const pageText = $('body').text().substring(0, 10000);

        const parsed = await this.askClaudeJSON(`
Extract upcoming tax lien auction listings from this online auction platform page.

Platform: ${platform.name}
Content: ${pageText}

For each listing extract: title, location (state, county), auctionDate, numberOfParcels, registrationDeadline, url.
Return as JSON array. If no listings found, return [].
Only include auctions in these states: ${settings.targetStates.join(', ')}`,
          'You are an auction data extraction specialist. Return only valid JSON arrays.'
        );

        if (Array.isArray(parsed)) {
          for (const auction of parsed) {
            leads.push({
              title: auction.title || `${platform.name} - ${auction.location?.county}, ${auction.location?.state}`,
              description: `${auction.numberOfParcels || '?'} parcels - Registration by ${auction.registrationDeadline || 'TBD'}`,
              source: platform.name,
              sourceUrl: auction.url || platform.searchUrl,
              externalId: `auction-${platform.name}-${auction.location?.state}-${auction.location?.county}`.toLowerCase().replace(/\s/g, '-'),
              location: auction.location || {},
              actionDeadline: auction.auctionDate ? new Date(auction.auctionDate) : null,
              metadata: {
                platform: platform.name,
                numberOfParcels: auction.numberOfParcels,
                registrationDeadline: auction.registrationDeadline,
                auctionUrl: auction.url,
                type: 'auction_listing',
              },
            });
          }
        }

        await this._delay(2000);
      } catch (err) {
        logger.warn(`[tax-lien] Failed to crawl ${platform.name}: ${err.message}`);
      }
    }

    return leads;
  }

  // ========== PHASE 2: ANALYSIS ==========

  async analyze(lead, config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const meta = lead.metadata || {};

    // Build analysis prompt
    const prompt = `Analyze this tax lien investment opportunity:

PROPERTY DETAILS:
- Location: ${lead.location?.address || 'N/A'}, ${lead.location?.county}, ${lead.location?.state}
- Parcel: ${meta.parcelNumber || 'N/A'}
- Property Type: ${meta.propertyType || 'Unknown'}
- Assessed Value: $${meta.assessedValue || 'Unknown'}
- Amount Owed: $${meta.amountOwed || 'Unknown'}
- Interest Rate: ${meta.interestRate || 'Unknown'}%
- Redemption Period: ${meta.redemptionPeriod || 'Unknown'}

INVESTOR CRITERIA:
- Budget Range: $${settings.minLienAmount} - $${settings.maxLienAmount}
- Min ROI: ${config.settings.minROI}%
- Risk Tolerance: ${config.settings.riskTolerance}
- Strategy: ${settings.bidStrategy}
- Prefers Redemption: ${settings.preferRedemption}

ANALYZE AND RETURN JSON:
{
  "score": (0-100, overall deal quality),
  "priority": ("low", "medium", "high", or "critical"),
  "recommendation": ("buy", "pass", or "watch"),
  "estimatedROI": (percentage),
  "riskFactors": ["list of risk factors"],
  "positiveFactors": ["list of positive factors"],
  "redemptionProbability": (0-100, likelihood owner will redeem),
  "maxRecommendedBid": (dollar amount),
  "analysisNotes": "brief summary of analysis"
}`;

    const analysis = await this.askClaudeJSON(prompt,
      'You are a tax lien investment analyst. Provide conservative, data-driven analysis. Never exaggerate returns. Factor in all risks including property condition, location desirability, and economic conditions.'
    );

    return {
      score: analysis.score || 50,
      priority: analysis.priority || 'medium',
      aiRecommendation: analysis.recommendation || 'watch',
      estimatedROI: analysis.estimatedROI || 0,
      aiAnalysis: analysis.analysisNotes || '',
      metadata: {
        ...meta,
        riskFactors: analysis.riskFactors || [],
        positiveFactors: analysis.positiveFactors || [],
        redemptionProbability: analysis.redemptionProbability || 50,
        maxRecommendedBid: analysis.maxRecommendedBid || meta.amountOwed,
      }
    };
  }

  // ========== PHASE 3: ENRICHMENT ==========

  async enrich(lead, config) {
    const meta = lead.metadata || {};

    // Try to get additional property data
    let enrichedData = {};

    // 1. Property valuation estimate
    try {
      if (lead.location?.address && lead.location?.state) {
        enrichedData.valuationData = await this._getPropertyValuation(lead.location);
      }
    } catch (err) {
      logger.warn(`[tax-lien] Valuation lookup failed: ${err.message}`);
    }

    // 2. Neighborhood analysis via AI
    const neighborhoodAnalysis = await this.askClaudeJSON(`
Provide a brief neighborhood analysis for a property at:
${lead.location?.address || ''}, ${lead.location?.county || ''}, ${lead.location?.state || ''}

Return JSON:
{
  "neighborhoodScore": (1-10),
  "medianHomeValue": (estimated),
  "marketTrend": "rising", "stable", or "declining",
  "demandLevel": "high", "medium", or "low",
  "concerns": ["any environmental or market concerns"],
  "summary": "2-3 sentence neighborhood overview"
}`,
      'You are a real estate market analyst. Provide realistic assessments based on general knowledge of the area.'
    );

    return {
      metadata: {
        ...meta,
        ...enrichedData,
        neighborhoodAnalysis: neighborhoodAnalysis,
      }
    };
  }

  // ========== PHASE 4: ACTION ==========

  async act(lead, config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };

    // For now, prepare bid documentation
    // Full auto-bidding would integrate with specific auction platform APIs

    const bidPrep = await this.askClaudeJSON(`
Prepare a bid strategy for this tax lien:

Property: ${lead.title}
Location: ${lead.location?.county}, ${lead.location?.state}
Amount Owed: $${lead.metadata?.amountOwed}
Interest Rate: ${lead.metadata?.interestRate}%
Max Recommended Bid: $${lead.metadata?.maxRecommendedBid}
Auction Date: ${lead.actionDeadline || 'TBD'}
Strategy: ${settings.bidStrategy}

Return JSON:
{
  "openingBid": (dollar amount),
  "maxBid": (dollar amount),
  "bidIncrement": (dollar amount),
  "targetRate": (if bidding down interest rate),
  "registrationSteps": ["step-by-step registration instructions"],
  "documentsNeeded": ["list of documents needed"],
  "bidNotes": "strategy notes for the investor"
}`,
      'You are a tax lien auction bidding strategist.'
    );

    return {
      status: 'bidding',
      metadata: {
        ...lead.metadata,
        bidStrategy: bidPrep,
      },
      notes: [{
        content: `Bid prepared: Opening at $${bidPrep.openingBid}, max $${bidPrep.maxBid}. ${bidPrep.bidNotes}`,
        author: 'agent',
      }]
    };
  }

  // ========== PHASE 5: MONITORING ==========

  async monitor(config) {
    const Lead = require('../../models/Lead');
    const updates = [];

    // Find all active/won liens for this user
    const activeLeads = await Lead.find({
      userId: config.userId,
      agentType: this.type,
      status: { $in: ['won', 'completed'] },
    });

    for (const lead of activeLeads) {
      const meta = lead.metadata || {};

      // Check redemption period status
      if (meta.redemptionPeriod && lead.completedAt) {
        const expiryDate = new Date(lead.completedAt);
        const months = this._parseRedemptionMonths(meta.redemptionPeriod);
        expiryDate.setMonth(expiryDate.getMonth() + months);

        const daysRemaining = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));

        if (daysRemaining <= 30 && daysRemaining > 0) {
          updates.push({
            leadId: lead._id,
            data: {
              'metadata.redemptionDaysRemaining': daysRemaining,
              'metadata.redemptionAlert': true,
            }
          });

          // Notify user
          await this._notifyUser(config.userId, {
            type: 'auction_reminder',
            leadId: lead._id,
            title: '⏰ Redemption Period Expiring Soon',
            message: `${lead.title}: Only ${daysRemaining} days left in the redemption period. Prepare foreclosure if not redeemed.`,
            priority: 'high',
            requiresAction: true,
          });
        }
      }
    }

    return updates;
  }

  // ========== HELPER METHODS ==========

  _getCountySources(state) {
    // Major counties with online tax lien data
    const sources = {
      FL: [
        { name: 'Miami-Dade', url: 'https://www.miamidade.gov/taxcollector/tax-certificate-sale.asp' },
        { name: 'Broward', url: 'https://www.broward.org/RecordsTaxesTreasury/TaxCertificateSales/Pages/Default.aspx' },
        { name: 'Palm Beach', url: 'https://www.pbctax.com/tax-certificate-sales' },
        { name: 'Hillsborough', url: 'https://www.hillstax.org/taxcertificates/' },
        { name: 'Orange', url: 'https://www.octaxcol.com/taxes-fees/tax-certificate-sale/' },
        { name: 'Duval', url: 'https://www.coj.net/departments/finance/tax-collector/tax-certificates' },
      ],
      AZ: [
        { name: 'Maricopa', url: 'https://treasurer.maricopa.gov/tax-lien-sales/' },
        { name: 'Pima', url: 'https://www.pima.gov/treasurer/tax-lien-sale' },
        { name: 'Pinal', url: 'https://www.pinalcountyaz.gov/Treasurer/Pages/TaxLienSale.aspx' },
      ],
      IN: [
        { name: 'Marion', url: 'https://www.indy.gov/activity/tax-sale' },
        { name: 'Lake', url: 'https://www.lakecountyin.org/departments/treasurer/tax-sale/' },
        { name: 'Allen', url: 'https://www.allencounty.us/auditor/tax-sale' },
      ],
      NJ: [
        { name: 'Essex', url: 'https://www.essexcountynj.org/treasurer/tax-sale/' },
        { name: 'Hudson', url: 'https://www.hudsoncountynj.org/tax-sale' },
        { name: 'Bergen', url: 'https://www.co.bergen.nj.us/finance/tax-sale' },
      ],
      IL: [
        { name: 'Cook', url: 'https://www.cookcountyclerkil.gov/service/delinquent-property-tax-sales' },
        { name: 'DuPage', url: 'https://www.dupageco.org/Treasurer/Tax_Sale/' },
      ],
      MD: [
        { name: 'Baltimore City', url: 'https://finance.baltimorecity.gov/tax-sale' },
        { name: 'Baltimore County', url: 'https://www.baltimorecountymd.gov/departments/finance/tax-sale' },
      ],
      SC: [
        { name: 'Charleston', url: 'https://www.charlestoncounty.org/departments/delinquent-tax/tax-sale.php' },
        { name: 'Greenville', url: 'https://www.greenvillecounty.org/Delinquent_Tax/TaxSale.aspx' },
      ],
      CO: [
        { name: 'Denver', url: 'https://www.denvergov.org/Government/Agencies-Departments-Offices/Treasury/Tax-Lien-Sales' },
        { name: 'El Paso', url: 'https://treasurer.elpasoco.com/tax-lien-sales/' },
      ],
      IA: [
        { name: 'Polk', url: 'https://www.polkcountyiowa.gov/treasurer/tax-sale/' },
      ],
      WV: [
        { name: 'Kanawha', url: 'https://kanawha.us/sheriff/delinquent-land-sales/' },
      ],
    };

    return sources[state] || [];
  }

  _getStateInterestRate(state) {
    const rates = {
      FL: 18, AZ: 16, IN: 10, NJ: 18, IL: 18,
      MD: 12, SC: 12, CO: 9, IA: 24, WV: 12,
    };
    return rates[state] || 12;
  }

  _getRedemptionPeriod(state) {
    const periods = {
      FL: '2 years', AZ: '3 years', IN: '1 year', NJ: '2 years', IL: '2-3 years',
      MD: '6 months', SC: '1 year', CO: '3 years', IA: '2 years', WV: '18 months',
    };
    return periods[state] || '2 years';
  }

  _parseRedemptionMonths(period) {
    const match = period.match(/(\d+)/);
    if (!match) return 24;
    const num = parseInt(match[1]);
    if (period.includes('month')) return num;
    return num * 12; // years to months
  }

  async _getPropertyValuation(location) {
    // This would integrate with property data APIs (ATTOM, Zillow, etc.)
    // For now, return a placeholder structure
    return {
      source: 'estimated',
      estimatedMarketValue: null,
      lastSalePrice: null,
      lastSaleDate: null,
      comps: [],
    };
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = TaxLienAgent;
