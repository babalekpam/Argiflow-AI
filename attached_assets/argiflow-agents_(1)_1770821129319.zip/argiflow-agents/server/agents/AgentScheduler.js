const cron = require('node-cron');
const AgentConfig = require('../models/AgentConfig');
const registry = require('./AgentRegistry');
const logger = require('../config/logger');

class AgentScheduler {
  constructor() {
    this.jobs = [];
  }

  start() {
    // Run every 15 minutes — check for agents that need to run
    const mainJob = cron.schedule('*/15 * * * *', async () => {
      await this.processQueue();
    });
    this.jobs.push(mainJob);

    // Hourly health check
    const healthJob = cron.schedule('0 * * * *', async () => {
      await this.healthCheck();
    });
    this.jobs.push(healthJob);

    // Daily report at 8pm
    const reportJob = cron.schedule('0 20 * * *', async () => {
      await this.generateDailyReports();
    });
    this.jobs.push(reportJob);

    logger.info('Agent scheduler initialized with 3 cron jobs');
  }

  async processQueue() {
    try {
      const now = new Date();

      // Find all enabled agent configs that are due to run
      const configs = await AgentConfig.find({
        enabled: true,
        'state.isRunning': false,
        $or: [
          { 'state.nextRun': { $lte: now } },
          { 'state.nextRun': null },
        ]
      }).populate('userId');

      logger.info(`Scheduler: ${configs.length} agents due to run`);

      for (const config of configs) {
        // Skip if user is inactive
        if (!config.userId || !config.userId.isActive) continue;

        try {
          const agent = registry.get(config.agentType);

          // Run agent (non-blocking)
          this._runAgent(agent, config);

          // Calculate next run
          const nextRun = this._calculateNextRun(config.settings.runFrequency);
          await AgentConfig.findByIdAndUpdate(config._id, {
            'state.nextRun': nextRun,
          });

        } catch (err) {
          logger.error(`Scheduler: Error running ${config.agentType} for user ${config.userId}:`, err);
        }
      }
    } catch (err) {
      logger.error('Scheduler processQueue error:', err);
    }
  }

  async _runAgent(agent, config) {
    try {
      await agent.run(config);
    } catch (err) {
      logger.error(`Agent ${agent.type} runtime error:`, err);
    }
  }

  _calculateNextRun(frequency) {
    const now = new Date();
    switch (frequency) {
      case 'hourly':
        return new Date(now.getTime() + 60 * 60 * 1000);
      case 'daily':
        return new Date(now.getTime() + 24 * 60 * 60 * 1000);
      case 'weekly':
        return new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      default:
        return new Date(now.getTime() + 24 * 60 * 60 * 1000);
    }
  }

  async healthCheck() {
    const configs = await AgentConfig.find({ enabled: true });
    for (const config of configs) {
      // If agent has been "running" for over 30 minutes, it's stuck
      if (config.state.isRunning && config.state.lastRun) {
        const runningFor = Date.now() - config.state.lastRun.getTime();
        if (runningFor > 30 * 60 * 1000) {
          logger.warn(`Agent ${config.agentType} for user ${config.userId} appears stuck. Resetting.`);
          await AgentConfig.findByIdAndUpdate(config._id, {
            'state.isRunning': false,
            'state.lastError': 'Agent was stuck and auto-reset by health check',
            'state.healthScore': Math.max(0, (config.state.healthScore || 100) - 10),
          });
        }
      }
    }
  }

  async generateDailyReports() {
    // TODO: Generate daily summary for each user
    logger.info('Daily reports generated');
  }

  stop() {
    this.jobs.forEach(job => job.stop());
    logger.info('Agent scheduler stopped');
  }
}

module.exports = AgentScheduler;
