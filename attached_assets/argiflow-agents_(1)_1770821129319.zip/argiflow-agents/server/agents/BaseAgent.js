const Anthropic = require('@anthropic-ai/sdk');
const Lead = require('../models/Lead');
const Task = require('../models/Task');
const AgentConfig = require('../models/AgentConfig');
const Notification = require('../models/Notification');
const logger = require('../config/logger');

class BaseAgent {
  constructor() {
    if (new.target === BaseAgent) {
      throw new Error('BaseAgent is abstract and cannot be instantiated directly');
    }

    this.claude = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }

  // ========== MUST OVERRIDE ==========

  /** Unique identifier for this agent type */
  get type() { throw new Error('Agent must define type'); }

  /** Display name */
  get name() { throw new Error('Agent must define name'); }

  /** Short description */
  get description() { throw new Error('Agent must define description'); }

  /** Icon emoji */
  get icon() { return '🤖'; }

  /** Default agent-specific settings */
  get defaultAgentSettings() { return {}; }

  /** Agent-specific settings schema for the config UI */
  get settingsSchema() { return []; }

  // ========== LIFECYCLE HOOKS (Override as needed) ==========

  /**
   * PHASE 1: Discovery — Find new leads/opportunities
   * @param {Object} config - AgentConfig document
   * @returns {Array} Array of raw lead data objects
   */
  async discover(config) {
    throw new Error(`${this.type}: discover() not implemented`);
  }

  /**
   * PHASE 2: Analyze — Score and evaluate discovered leads
   * @param {Object} lead - Lead document
   * @param {Object} config - AgentConfig document
   * @returns {Object} Updated lead data with scores/analysis
   */
  async analyze(lead, config) {
    throw new Error(`${this.type}: analyze() not implemented`);
  }

  /**
   * PHASE 3: Enrich — Add additional data to qualified leads
   * @param {Object} lead - Lead document
   * @param {Object} config - AgentConfig document
   * @returns {Object} Enriched lead data
   */
  async enrich(lead, config) {
    return lead; // Optional, default is passthrough
  }

  /**
   * PHASE 4: Act — Execute action (bid, outreach, purchase, etc.)
   * @param {Object} lead - Lead document
   * @param {Object} config - AgentConfig document
   * @returns {Object} Action result
   */
  async act(lead, config) {
    return null; // Optional
  }

  /**
   * PHASE 5: Monitor — Track existing portfolio items
   * @param {Object} config - AgentConfig document
   * @returns {Array} Status updates for existing leads
   */
  async monitor(config) {
    return []; // Optional
  }

  // ========== CORE ENGINE (Do not override) ==========

  /**
   * Main execution loop — runs all phases for a user's agent config
   */
  async run(config) {
    const startTime = Date.now();
    logger.info(`[${this.type}] Starting run for user ${config.userId}`);

    try {
      // Mark as running
      await AgentConfig.findByIdAndUpdate(config._id, {
        'state.isRunning': true,
        'state.lastRun': new Date(),
        'state.lastError': null,
      });

      // Create task record
      const task = await Task.create({
        userId: config.userId,
        agentType: this.type,
        agentConfigId: config._id,
        taskType: 'crawl',
        description: `Scheduled run for ${this.name}`,
        status: 'running',
        startedAt: new Date(),
      });

      // PHASE 1: Discover
      logger.info(`[${this.type}] Phase 1: Discovery`);
      const rawLeads = await this.discover(config);
      logger.info(`[${this.type}] Found ${rawLeads.length} raw leads`);

      // Deduplicate
      const newLeads = await this._deduplicateLeads(rawLeads, config);
      logger.info(`[${this.type}] ${newLeads.length} new leads after dedup`);

      // Save new leads
      const savedLeads = [];
      for (const leadData of newLeads) {
        const lead = await Lead.create({
          userId: config.userId,
          agentType: this.type,
          agentConfigId: config._id,
          status: 'discovered',
          discoveredAt: new Date(),
          ...leadData,
        });
        savedLeads.push(lead);
      }

      // PHASE 2: Analyze
      logger.info(`[${this.type}] Phase 2: Analysis`);
      for (const lead of savedLeads) {
        try {
          const analysis = await this.analyze(lead, config);
          await Lead.findByIdAndUpdate(lead._id, {
            ...analysis,
            status: 'analyzing',
            analyzedAt: new Date(),
          });
        } catch (err) {
          logger.error(`[${this.type}] Analysis error for lead ${lead._id}:`, err);
        }
      }

      // PHASE 3: Qualify & Enrich leads that pass criteria
      logger.info(`[${this.type}] Phase 3: Qualification & Enrichment`);
      const qualifiedLeads = await Lead.find({
        userId: config.userId,
        agentType: this.type,
        status: 'analyzing',
        score: { $gte: config.settings.minROI || 0 },
      });

      for (const lead of qualifiedLeads) {
        try {
          const enriched = await this.enrich(lead, config);
          await Lead.findByIdAndUpdate(lead._id, {
            ...enriched,
            status: 'qualified',
          });
        } catch (err) {
          logger.error(`[${this.type}] Enrichment error for lead ${lead._id}:`, err);
        }
      }

      // Notify user of qualified leads
      if (qualifiedLeads.length > 0) {
        await this._notifyUser(config.userId, {
          type: 'new_lead',
          title: `${this.icon} ${qualifiedLeads.length} New Opportunities Found`,
          message: `Your ${this.name} found ${qualifiedLeads.length} qualified leads. Review and approve to take action.`,
          priority: qualifiedLeads.some(l => l.priority === 'critical') ? 'high' : 'medium',
        });
      }

      // PHASE 4: Auto-act on approved leads (if auto-approve is enabled)
      if (config.settings.autoApproveUnder > 0) {
        const autoApproveLeads = await Lead.find({
          userId: config.userId,
          agentType: this.type,
          status: 'qualified',
          estimatedCost: { $lte: config.settings.autoApproveUnder },
        });

        for (const lead of autoApproveLeads) {
          try {
            await Lead.findByIdAndUpdate(lead._id, { status: 'approved', approvedAt: new Date() });
            const result = await this.act(lead, config);
            if (result) {
              await Lead.findByIdAndUpdate(lead._id, {
                status: result.status || 'bidding',
                ...result,
              });
            }
          } catch (err) {
            logger.error(`[${this.type}] Action error for lead ${lead._id}:`, err);
          }
        }
      }

      // PHASE 5: Monitor existing portfolio
      logger.info(`[${this.type}] Phase 5: Monitoring`);
      const monitorUpdates = await this.monitor(config);
      for (const update of monitorUpdates) {
        if (update.leadId) {
          await Lead.findByIdAndUpdate(update.leadId, update.data);
        }
      }

      // Complete task
      const duration = Date.now() - startTime;
      await Task.findByIdAndUpdate(task._id, {
        status: 'completed',
        completedAt: new Date(),
        duration,
        result: {
          leadsFound: rawLeads.length,
          newLeads: newLeads.length,
          qualified: qualifiedLeads.length,
          monitored: monitorUpdates.length,
        },
      });

      // Update agent state
      await AgentConfig.findByIdAndUpdate(config._id, {
        'state.isRunning': false,
        'state.totalLeadsFound': (config.state.totalLeadsFound || 0) + newLeads.length,
        'state.healthScore': 100,
      });

      logger.info(`[${this.type}] Run completed in ${duration}ms`);

    } catch (err) {
      logger.error(`[${this.type}] Run failed:`, err);

      await AgentConfig.findByIdAndUpdate(config._id, {
        'state.isRunning': false,
        'state.lastError': err.message,
        'state.healthScore': Math.max(0, (config.state.healthScore || 100) - 20),
      });

      await this._notifyUser(config.userId, {
        type: 'agent_error',
        title: `⚠️ ${this.name} Error`,
        message: `Your ${this.name} encountered an error: ${err.message}`,
        priority: 'high',
      });
    }
  }

  // ========== AI HELPERS ==========

  /**
   * Ask Claude to analyze data
   */
  async askClaude(prompt, systemPrompt = null) {
    try {
      const messages = [{ role: 'user', content: prompt }];
      const params = {
        model: 'claude-sonnet-4-5-20250514',
        max_tokens: 4096,
        messages,
      };

      if (systemPrompt) {
        params.system = systemPrompt;
      }

      const response = await this.claude.messages.create(params);
      return response.content[0].text;
    } catch (err) {
      logger.error(`[${this.type}] Claude API error:`, err);
      throw err;
    }
  }

  /**
   * Ask Claude for structured JSON analysis
   */
  async askClaudeJSON(prompt, systemPrompt = null) {
    const fullPrompt = `${prompt}\n\nRespond ONLY with valid JSON. No markdown, no explanation, just JSON.`;
    const response = await this.askClaude(fullPrompt, systemPrompt);

    try {
      const cleaned = response.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      return JSON.parse(cleaned);
    } catch (err) {
      logger.error(`[${this.type}] Failed to parse Claude JSON:`, response);
      throw new Error('Failed to parse AI response as JSON');
    }
  }

  // ========== UTILITY METHODS ==========

  /**
   * Deduplicate leads against existing ones
   */
  async _deduplicateLeads(rawLeads, config) {
    const existingIds = await Lead.find({
      userId: config.userId,
      agentType: this.type,
      isArchived: false,
    }).distinct('externalId');

    const existingSet = new Set(existingIds.filter(Boolean));
    return rawLeads.filter(lead => !lead.externalId || !existingSet.has(lead.externalId));
  }

  /**
   * Send notification to user
   */
  async _notifyUser(userId, data) {
    return Notification.create({
      userId,
      agentType: this.type,
      channels: [{ type: 'in_app', sentAt: new Date(), delivered: true }],
      ...data,
    });
  }

  /**
   * Get agent info for registry/dashboard
   */
  getInfo() {
    return {
      type: this.type,
      name: this.name,
      description: this.description,
      icon: this.icon,
      defaultAgentSettings: this.defaultAgentSettings,
      settingsSchema: this.settingsSchema,
    };
  }
}

module.exports = BaseAgent;
