# ArgiFlow AI Agent Platform — Modular Framework

## Architecture
```
argiflow-agents/
├── server/
│   ├── index.js                 # Express server entry
│   ├── config/
│   │   └── database.js          # MongoDB connection
│   ├── middleware/
│   │   └── auth.js              # JWT authentication
│   ├── models/
│   │   ├── User.js              # User model
│   │   ├── AgentConfig.js       # Agent configuration per user
│   │   ├── Lead.js              # Universal lead/opportunity model
│   │   ├── Task.js              # Agent task queue
│   │   └── Transaction.js       # Completed deals/transactions
│   ├── agents/
│   │   ├── BaseAgent.js         # Abstract base agent (all agents extend this)
│   │   ├── AgentRegistry.js     # Plugin registry for all agents
│   │   ├── AgentScheduler.js    # Cron-based agent runner
│   │   ├── tax-lien/
│   │   │   ├── TaxLienAgent.js  # Tax lien agent implementation
│   │   │   ├── crawlers/        # County-specific crawlers
│   │   │   └── analyzers/       # Deal analysis logic
│   │   ├── tax-deed/            # (plug-in later)
│   │   ├── wholesale-re/        # (plug-in later)
│   │   ├── govt-contracts/      # (plug-in later)
│   │   ├── arbitrage/           # (plug-in later)
│   │   └── lead-gen/            # (plug-in later)
│   └── routes/
│       ├── auth.js
│       ├── agents.js
│       ├── leads.js
│       └── dashboard.js
├── client/
│   ├── index.html
│   ├── src/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   ├── components/
│   │   │   ├── Layout.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── AgentCard.jsx
│   │   │   ├── AgentConfig.jsx
│   │   │   ├── LeadTable.jsx
│   │   │   ├── DealAnalysis.jsx
│   │   │   ├── Pipeline.jsx
│   │   │   └── Notifications.jsx
│   │   └── styles/
│   │       └── globals.css
│   └── vite.config.js
├── package.json
└── .env.example
```

## Stack
- **Backend**: Node.js + Express
- **Database**: MongoDB + Mongoose
- **AI**: Anthropic Claude API
- **Frontend**: React + Vite + TailwindCSS
- **Scheduling**: node-cron
- **Auth**: JWT

## Adding a New Agent
1. Create folder in `server/agents/your-agent/`
2. Extend `BaseAgent.js`
3. Register in `AgentRegistry.js`
4. Agent auto-appears in dashboard

## Deployment
Upload to Replit → `npm install` → Set env vars → `npm start`
