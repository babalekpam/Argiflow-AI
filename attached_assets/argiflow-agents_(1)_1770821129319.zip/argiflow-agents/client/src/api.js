import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('argiflow_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 responses
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('argiflow_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

// Auth
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getProfile: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/me', data),
};

// Agents
export const agentsAPI = {
  getCatalog: () => api.get('/agents/catalog'),
  getMyAgents: () => api.get('/agents/my-agents'),
  configure: (agentType, data) => api.post(`/agents/configure/${agentType}`, data),
  toggle: (agentType) => api.patch(`/agents/toggle/${agentType}`),
  run: (agentType) => api.post(`/agents/run/${agentType}`),
  getStatus: (agentType) => api.get(`/agents/status/${agentType}`),
};

// Leads
export const leadsAPI = {
  getAll: (params) => api.get('/leads', { params }),
  getOne: (id) => api.get(`/leads/${id}`),
  updateStatus: (id, status) => api.patch(`/leads/${id}/status`, { status }),
  bulkApprove: (leadIds) => api.post('/leads/bulk-approve', { leadIds }),
  addNote: (id, content) => api.post(`/leads/${id}/notes`, { content }),
  getPipeline: (agentType) => api.get('/leads/pipeline/summary', { params: { agentType } }),
};

// Dashboard
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
  getPerformance: (period) => api.get('/dashboard/performance', { params: { period } }),
};

// Notifications
export const notificationsAPI = {
  getAll: (params) => api.get('/notifications', { params }),
  markRead: (id) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/read-all'),
};

// Transactions
export const transactionsAPI = {
  getAll: (params) => api.get('/transactions', { params }),
  getSummary: () => api.get('/transactions/summary'),
};
