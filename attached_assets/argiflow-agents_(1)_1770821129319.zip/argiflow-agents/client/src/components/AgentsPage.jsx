import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { agentsAPI } from '../api';
import { Bot, Play, Pause, Settings, Zap, ChevronRight, Shield, Lock } from 'lucide-react';

const agentMeta = {
  'tax-lien': { color: 'from-emerald-500 to-teal-600', emoji: '🏛️', category: 'Real Estate' },
  'tax-deed': { color: 'from-blue-500 to-indigo-600', emoji: '🏠', category: 'Real Estate' },
  'wholesale-re': { color: 'from-purple-500 to-violet-600', emoji: '🔑', category: 'Real Estate' },
  'govt-contracts': { color: 'from-amber-500 to-orange-600', emoji: '📋', category: 'Government' },
  'arbitrage': { color: 'from-pink-500 to-rose-600', emoji: '📦', category: 'E-Commerce' },
  'lead-gen': { color: 'from-cyan-500 to-blue-600', emoji: '🎯', category: 'Services' },
};

export default function AgentsPage() {
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchAgents = () => {
    agentsAPI.getMyAgents()
      .then(res => setAgents(res.data.agents))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(fetchAgents, []);

  const handleToggle = async (agentType, e) => {
    e.stopPropagation();
    try {
      await agentsAPI.toggle(agentType);
      fetchAgents();
    } catch (err) {
      if (err.response?.status === 404) {
        navigate(`/agents/${agentType}`);
      }
    }
  };

  const handleRun = async (agentType, e) => {
    e.stopPropagation();
    try {
      await agentsAPI.run(agentType);
      fetchAgents();
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">AI Agents</h1>
        <p className="text-surface-400 text-sm mt-1">Configure and manage your autonomous agents</p>
      </div>

      {/* Active Agents */}
      {agents.filter(a => a.enabled).length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-surface-400 uppercase tracking-wider mb-3">Active</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {agents.filter(a => a.enabled).map(agent => {
              const meta = agentMeta[agent.type] || { color: 'from-gray-500 to-gray-600', emoji: '🤖', category: 'Other' };
              const state = agent.config?.state || {};

              return (
                <div
                  key={agent.type}
                  onClick={() => navigate(`/agents/${agent.type}`)}
                  className="card-hover cursor-pointer"
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${meta.color} rounded-xl flex items-center justify-center text-2xl shadow-lg`}>
                      {meta.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-white">{agent.name}</h3>
                        <span className="badge-green">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1" />
                          Running
                        </span>
                      </div>
                      <p className="text-sm text-surface-400 mt-0.5">{agent.description}</p>

                      <div className="flex items-center gap-4 mt-3 text-xs text-surface-500">
                        <span>Leads: {state.totalLeadsFound || 0}</span>
                        <span>Health: {state.healthScore || 100}%</span>
                        {state.lastRun && (
                          <span>Last run: {new Date(state.lastRun).toLocaleString()}</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => handleRun(agent.type, e)}
                        className="p-2 rounded-lg text-brand-400 hover:bg-brand-500/10 transition-colors"
                        title="Run now"
                      >
                        <Play size={16} />
                      </button>
                      <button
                        onClick={(e) => handleToggle(agent.type, e)}
                        className="p-2 rounded-lg text-amber-400 hover:bg-amber-500/10 transition-colors"
                        title="Pause"
                      >
                        <Pause size={16} />
                      </button>
                      <ChevronRight size={16} className="text-surface-600 ml-1" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Available Agents */}
      <div>
        <h2 className="text-sm font-semibold text-surface-400 uppercase tracking-wider mb-3">
          {agents.filter(a => a.enabled).length > 0 ? 'Available Agents' : 'All Agents'}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agents.filter(a => !a.enabled).map(agent => {
            const meta = agentMeta[agent.type] || { color: 'from-gray-500 to-gray-600', emoji: '🤖', category: 'Other' };

            return (
              <div
                key={agent.type}
                onClick={() => navigate(`/agents/${agent.type}`)}
                className="card-hover cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 bg-gradient-to-br ${meta.color} rounded-xl flex items-center justify-center text-xl opacity-80`}>
                    {meta.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-surface-200">{agent.name}</h3>
                      <span className="text-[10px] font-medium text-surface-500 bg-surface-800 px-1.5 py-0.5 rounded">{meta.category}</span>
                    </div>
                    <p className="text-xs text-surface-500 mt-1 line-clamp-2">{agent.description}</p>
                  </div>
                  <ChevronRight size={16} className="text-surface-600 mt-1" />
                </div>
                {agent.configured && !agent.enabled && (
                  <div className="mt-3 pt-3 border-t border-surface-700 flex items-center justify-between">
                    <span className="text-xs text-surface-500">Configured but paused</span>
                    <button
                      onClick={(e) => handleToggle(agent.type, e)}
                      className="text-xs btn-primary py-1 px-3"
                    >
                      Enable
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          {/* Coming Soon Placeholders */}
          {['Tax Deed Agent', 'Wholesale RE Agent', 'Govt Contracts Agent', 'Arbitrage Agent', 'Lead Gen Agent'].map(name => {
            if (agents.some(a => a.name === name)) return null;
            return (
              <div key={name} className="card opacity-50 cursor-not-allowed">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-surface-700 rounded-xl flex items-center justify-center">
                    <Lock size={16} className="text-surface-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-surface-400">{name}</h3>
                    <p className="text-xs text-surface-600 mt-1">Coming soon</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
