import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { agentsAPI } from '../api';
import { ArrowLeft, Save, Play, Power, AlertCircle } from 'lucide-react';

export default function AgentConfig() {
  const { agentType } = useParams();
  const navigate = useNavigate();
  const [agent, setAgent] = useState(null);
  const [config, setConfig] = useState(null);
  const [settings, setSettings] = useState({});
  const [agentSettings, setAgentSettings] = useState({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    agentsAPI.getMyAgents().then(res => {
      const found = res.data.agents.find(a => a.type === agentType);
      if (found) {
        setAgent(found);
        setConfig(found.config);
        setSettings(found.config?.settings || {
          budgetMin: 0, budgetMax: 10000, monthlyBudgetCap: 50000,
          minROI: 10, riskTolerance: 'medium', runFrequency: 'daily',
          notifyOnNewLeads: true, notifyOnHighPriority: true, notifyOnAuction: true,
          requireApproval: true, autoApproveUnder: 0,
        });
        setAgentSettings(found.config?.agentSettings || found.defaultAgentSettings || {});
      }
    });
  }, [agentType]);

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);
    try {
      await agentsAPI.configure(agentType, { settings, agentSettings, enabled: config?.enabled || false });
      setMessage({ type: 'success', text: 'Configuration saved!' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Failed to save' });
    }
    setSaving(false);
  };

  const handleEnable = async () => {
    try {
      // Save first if not configured
      if (!config) {
        await agentsAPI.configure(agentType, { settings, agentSettings, enabled: true });
      } else {
        await agentsAPI.toggle(agentType);
      }
      // Refresh
      const res = await agentsAPI.getMyAgents();
      const found = res.data.agents.find(a => a.type === agentType);
      setAgent(found);
      setConfig(found.config);
      setMessage({ type: 'success', text: found.config?.enabled ? 'Agent enabled!' : 'Agent paused' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Failed to toggle agent' });
    }
  };

  const handleRun = async () => {
    try {
      await agentsAPI.run(agentType);
      setMessage({ type: 'success', text: 'Agent run started! Check back in a few minutes.' });
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Failed to start agent' });
    }
  };

  if (!agent) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const renderSettingField = (schema) => {
    const value = agentSettings[schema.key];

    switch (schema.type) {
      case 'multi-select':
        return (
          <div className="flex flex-wrap gap-2">
            {schema.options.map(opt => (
              <button
                key={opt.value}
                onClick={() => {
                  const current = agentSettings[schema.key] || [];
                  const updated = current.includes(opt.value)
                    ? current.filter(v => v !== opt.value)
                    : [...current, opt.value];
                  setAgentSettings({ ...agentSettings, [schema.key]: updated });
                }}
                className={`px-3 py-1.5 rounded-lg text-sm border transition-colors ${
                  (agentSettings[schema.key] || []).includes(opt.value)
                    ? 'bg-brand-600/20 border-brand-500/40 text-brand-300'
                    : 'bg-surface-900 border-surface-700 text-surface-400 hover:border-surface-500'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        );

      case 'select':
        return (
          <div className="space-y-2">
            {schema.options.map(opt => (
              <label
                key={opt.value}
                className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  agentSettings[schema.key] === opt.value
                    ? 'bg-brand-600/10 border-brand-500/40'
                    : 'bg-surface-900 border-surface-700 hover:border-surface-500'
                }`}
              >
                <input
                  type="radio"
                  name={schema.key}
                  value={opt.value}
                  checked={agentSettings[schema.key] === opt.value}
                  onChange={(e) => setAgentSettings({ ...agentSettings, [schema.key]: e.target.value })}
                  className="sr-only"
                />
                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                  agentSettings[schema.key] === opt.value ? 'border-brand-500' : 'border-surface-500'
                }`}>
                  {agentSettings[schema.key] === opt.value && (
                    <div className="w-2 h-2 rounded-full bg-brand-500" />
                  )}
                </div>
                <span className="text-sm text-surface-200">{opt.label}</span>
              </label>
            ))}
          </div>
        );

      case 'number':
        return (
          <input
            type="number"
            value={agentSettings[schema.key] || ''}
            onChange={(e) => setAgentSettings({ ...agentSettings, [schema.key]: parseFloat(e.target.value) || 0 })}
            min={schema.min}
            max={schema.max}
            className="input w-full"
          />
        );

      case 'toggle':
        return (
          <button
            onClick={() => setAgentSettings({ ...agentSettings, [schema.key]: !agentSettings[schema.key] })}
            className={`relative w-12 h-6 rounded-full transition-colors ${
              agentSettings[schema.key] ? 'bg-brand-500' : 'bg-surface-600'
            }`}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
              agentSettings[schema.key] ? 'translate-x-6' : ''
            }`} />
          </button>
        );

      default:
        return (
          <input
            type="text"
            value={agentSettings[schema.key] || ''}
            onChange={(e) => setAgentSettings({ ...agentSettings, [schema.key]: e.target.value })}
            className="input w-full"
          />
        );
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/agents')} className="p-2 rounded-lg hover:bg-surface-800 text-surface-400 transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-white">{agent.icon} {agent.name}</h1>
          <p className="text-surface-400 text-sm mt-1">{agent.description}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleEnable} className={config?.enabled ? 'btn-danger' : 'btn-primary'}>
            <Power size={16} className="inline mr-1" />
            {config?.enabled ? 'Disable' : 'Enable Agent'}
          </button>
          {config?.enabled && (
            <button onClick={handleRun} className="btn-secondary">
              <Play size={16} className="inline mr-1" /> Run Now
            </button>
          )}
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${
          message.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
          'bg-red-500/10 text-red-400 border border-red-500/20'
        }`}>
          <AlertCircle size={16} />
          {message.text}
        </div>
      )}

      {/* Universal Settings */}
      <div className="card space-y-4">
        <h2 className="text-lg font-semibold text-white">General Settings</h2>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-surface-400 mb-1 block">Min Budget ($)</label>
            <input type="number" value={settings.budgetMin || 0}
              onChange={e => setSettings({ ...settings, budgetMin: parseFloat(e.target.value) || 0 })}
              className="input w-full" />
          </div>
          <div>
            <label className="text-sm text-surface-400 mb-1 block">Max Budget ($)</label>
            <input type="number" value={settings.budgetMax || 10000}
              onChange={e => setSettings({ ...settings, budgetMax: parseFloat(e.target.value) || 0 })}
              className="input w-full" />
          </div>
          <div>
            <label className="text-sm text-surface-400 mb-1 block">Monthly Budget Cap ($)</label>
            <input type="number" value={settings.monthlyBudgetCap || 50000}
              onChange={e => setSettings({ ...settings, monthlyBudgetCap: parseFloat(e.target.value) || 0 })}
              className="input w-full" />
          </div>
          <div>
            <label className="text-sm text-surface-400 mb-1 block">Min ROI (%)</label>
            <input type="number" value={settings.minROI || 10}
              onChange={e => setSettings({ ...settings, minROI: parseFloat(e.target.value) || 0 })}
              className="input w-full" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-surface-400 mb-1 block">Risk Tolerance</label>
            <select value={settings.riskTolerance || 'medium'}
              onChange={e => setSettings({ ...settings, riskTolerance: e.target.value })}
              className="input w-full">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-surface-400 mb-1 block">Run Frequency</label>
            <select value={settings.runFrequency || 'daily'}
              onChange={e => setSettings({ ...settings, runFrequency: e.target.value })}
              className="input w-full">
              <option value="hourly">Hourly</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
            </select>
          </div>
        </div>

        <div>
          <label className="text-sm text-surface-400 mb-1 block">Auto-approve deals under ($)</label>
          <input type="number" value={settings.autoApproveUnder || 0}
            onChange={e => setSettings({ ...settings, autoApproveUnder: parseFloat(e.target.value) || 0 })}
            className="input w-48" />
          <p className="text-xs text-surface-500 mt-1">Set to 0 to require manual approval for all deals</p>
        </div>
      </div>

      {/* Agent-Specific Settings */}
      {agent.settingsSchema?.length > 0 && (
        <div className="card space-y-5">
          <h2 className="text-lg font-semibold text-white">{agent.name} Settings</h2>
          {agent.settingsSchema.map(schema => (
            <div key={schema.key}>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-surface-300">{schema.label}</label>
              </div>
              {schema.description && (
                <p className="text-xs text-surface-500 mb-2">{schema.description}</p>
              )}
              {renderSettingField(schema)}
            </div>
          ))}
        </div>
      )}

      {/* Save */}
      <div className="flex items-center gap-3">
        <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2">
          <Save size={16} />
          {saving ? 'Saving...' : 'Save Configuration'}
        </button>
        <button onClick={() => navigate('/agents')} className="btn-secondary">Cancel</button>
      </div>
    </div>
  );
}
