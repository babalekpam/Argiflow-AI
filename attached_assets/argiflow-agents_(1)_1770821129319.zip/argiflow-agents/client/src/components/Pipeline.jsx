import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { leadsAPI } from '../api';
import { GitBranch, DollarSign } from 'lucide-react';

const stages = [
  { key: 'discovered', label: 'Discovered', color: 'border-surface-500' },
  { key: 'qualified', label: 'Qualified', color: 'border-amber-500' },
  { key: 'approved', label: 'Approved', color: 'border-brand-500' },
  { key: 'bidding', label: 'Bidding', color: 'border-purple-500' },
  { key: 'won', label: 'Won', color: 'border-emerald-500' },
  { key: 'completed', label: 'Completed', color: 'border-green-500' },
];

export default function Pipeline() {
  const [pipeline, setPipeline] = useState([]);
  const [leads, setLeads] = useState({});
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      leadsAPI.getPipeline(),
      ...stages.map(s => leadsAPI.getAll({ status: s.key, limit: 10 }))
    ]).then(([pipeRes, ...leadResults]) => {
      setPipeline(pipeRes.data.pipeline);
      const leadsMap = {};
      stages.forEach((s, i) => {
        leadsMap[s.key] = leadResults[i].data.leads;
      });
      setLeads(leadsMap);
    }).catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const getStageStats = (stageKey) => {
    return pipeline.find(p => p._id === stageKey) || { count: 0, totalValue: 0, totalCost: 0, avgROI: 0 };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <GitBranch size={24} className="text-brand-400" /> Deal Pipeline
        </h1>
        <p className="text-surface-400 text-sm mt-1">Track deals as they move through each stage</p>
      </div>

      {/* Pipeline columns */}
      <div className="flex gap-4 overflow-x-auto pb-4">
        {stages.map(stage => {
          const stats = getStageStats(stage.key);
          const stageLeads = leads[stage.key] || [];

          return (
            <div key={stage.key} className="flex-shrink-0 w-72">
              {/* Column header */}
              <div className={`border-t-2 ${stage.color} bg-surface-800 rounded-t-lg px-4 py-3`}>
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-surface-200">{stage.label}</h3>
                  <span className="text-xs bg-surface-700 text-surface-400 px-2 py-0.5 rounded-full">
                    {stats.count || stageLeads.length}
                  </span>
                </div>
                {stats.totalCost > 0 && (
                  <p className="text-xs text-surface-500 mt-1 flex items-center gap-1">
                    <DollarSign size={10} />
                    ${(stats.totalCost || 0).toLocaleString()} total
                  </p>
                )}
              </div>

              {/* Cards */}
              <div className="bg-surface-900/50 rounded-b-lg p-2 space-y-2 min-h-[200px]">
                {stageLeads.length === 0 ? (
                  <p className="text-xs text-surface-600 text-center py-8">No deals</p>
                ) : (
                  stageLeads.map(lead => (
                    <div
                      key={lead._id}
                      onClick={() => navigate(`/leads/${lead._id}`)}
                      className="bg-surface-800 border border-surface-700 rounded-lg p-3 cursor-pointer hover:border-brand-500/30 transition-colors"
                    >
                      <p className="text-sm font-medium text-surface-200 truncate">{lead.title}</p>
                      <p className="text-xs text-surface-500 mt-1">
                        {lead.location?.county}, {lead.location?.state}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs font-mono text-surface-400">
                          ${(lead.estimatedCost || 0).toLocaleString()}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-mono ${
                            lead.estimatedROI >= 15 ? 'text-emerald-400' : 'text-surface-400'
                          }`}>
                            {lead.estimatedROI || 0}% ROI
                          </span>
                          <div className="w-6 h-1.5 bg-surface-700 rounded-full overflow-hidden">
                            <div className={`h-full rounded-full ${
                              lead.score >= 70 ? 'bg-emerald-400' : lead.score >= 40 ? 'bg-amber-400' : 'bg-red-400'
                            }`} style={{ width: `${lead.score}%` }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
