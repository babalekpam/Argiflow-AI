import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { notificationsAPI } from '../api';
import { Bell, CheckCheck, AlertTriangle, Target, Gavel, Bot, Info } from 'lucide-react';

const typeIcons = {
  new_lead: Target,
  high_priority: AlertTriangle,
  auction_reminder: Gavel,
  bid_result: Gavel,
  deal_completed: CheckCheck,
  agent_error: Bot,
  approval_needed: AlertTriangle,
  report: Info,
  system: Info,
};

const typeColors = {
  new_lead: 'text-brand-400',
  high_priority: 'text-amber-400',
  auction_reminder: 'text-purple-400',
  bid_result: 'text-brand-400',
  deal_completed: 'text-emerald-400',
  agent_error: 'text-red-400',
  approval_needed: 'text-amber-400',
  report: 'text-surface-400',
  system: 'text-surface-400',
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchNotifs = () => {
    notificationsAPI.getAll({ limit: 50 })
      .then(res => {
        setNotifications(res.data.notifications);
        setUnreadCount(res.data.unreadCount);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(fetchNotifs, []);

  const markRead = async (id) => {
    await notificationsAPI.markRead(id);
    fetchNotifs();
  };

  const markAllRead = async () => {
    await notificationsAPI.markAllRead();
    fetchNotifs();
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Bell size={24} className="text-brand-400" /> Notifications
          </h1>
          <p className="text-surface-400 text-sm mt-1">{unreadCount} unread</p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="btn-secondary text-sm">
            <CheckCheck size={14} className="inline mr-1" /> Mark all read
          </button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : notifications.length === 0 ? (
        <div className="card text-center py-12">
          <Bell size={32} className="text-surface-600 mx-auto mb-3" />
          <p className="text-surface-400">No notifications yet</p>
          <p className="text-surface-600 text-sm mt-1">Your agents will notify you when they find opportunities</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map(notif => {
            const Icon = typeIcons[notif.type] || Info;
            const color = typeColors[notif.type] || 'text-surface-400';

            return (
              <div
                key={notif._id}
                onClick={() => {
                  if (!notif.read) markRead(notif._id);
                  if (notif.leadId) navigate(`/leads/${notif.leadId}`);
                }}
                className={`card-hover cursor-pointer flex items-start gap-3 ${
                  !notif.read ? 'border-brand-500/20 bg-brand-500/5' : ''
                }`}
              >
                <div className={`p-2 rounded-lg bg-surface-800 ${color}`}>
                  <Icon size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className={`text-sm font-medium ${!notif.read ? 'text-white' : 'text-surface-300'}`}>
                      {notif.title}
                    </h3>
                    {!notif.read && <span className="w-2 h-2 rounded-full bg-brand-500" />}
                  </div>
                  <p className="text-sm text-surface-400 mt-0.5">{notif.message}</p>
                  <p className="text-xs text-surface-600 mt-1">
                    {new Date(notif.createdAt).toLocaleString()}
                  </p>
                </div>
                {notif.priority === 'urgent' || notif.priority === 'high' ? (
                  <span className="badge-red text-[10px]">{notif.priority}</span>
                ) : null}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
