import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { leadsAPI } from '../api';
import { Search, Filter, Check, X, Eye, ChevronLeft, ChevronRight, ArrowUpDown } from 'lucide-react';

const statusColors = {
  discovered: 'badge-gray', analyzing: 'badge-blue', qualified: 'badge-yellow',
  approved: 'badge-green', bidding: 'badge-blue', won: 'badge-green',
  lost: 'badge-red', passed: 'badge-gray', completed: 'badge-green', archived: 'badge-gray',
};

const priorityColors = {
  low: 'text-surface-400', medium: 'text-brand-400', high: 'text-amber-400', critical: 'text-red-400',
};

const recColors = {
  buy: 'badge-green', pass: 'badge-red', watch: 'badge-yellow', pending: 'badge-gray',
};

export default function LeadsPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [leads, setLeads] = useState([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState([]);

  const page = parseInt(searchParams.get('page')) || 1;
  const status = searchParams.get('status') || '';
  const priority = searchParams.get('priority') || '';
  const search = searchParams.get('search') || '';

  const fetchLeads = () => {
    setLoading(true);
    const params = { page, limit: 20 };
    if (status) params.status = status;
    if (priority) params.priority = priority;
    if (search) params.search = search;

    leadsAPI.getAll(params)
      .then(res => {
        setLeads(res.data.leads);
        setTotal(res.data.total);
        setPages(res.data.pages);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(fetchLeads, [page, status, priority, search]);

  const setFilter = (key, value) => {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    params.set('page', '1');
    setSearchParams(params);
  };

  const handleBulkApprove = async () => {
    if (selected.length === 0) return;
    await leadsAPI.bulkApprove(selected);
    setSelected([]);
    fetchLeads();
  };

  const toggleSelect = (id) => {
    setSelected(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const toggleSelectAll = () => {
    if (selected.length === leads.length) {
      setSelected([]);
    } else {
      setSelected(leads.map(l => l._id));
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Leads</h1>
          <p className="text-surface-400 text-sm">{total} total leads</p>
        </div>
        {selected.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-surface-400">{selected.length} selected</span>
            <button onClick={handleBulkApprove} className="btn-primary text-sm py-1.5">
              <Check size={14} className="inline mr-1" /> Approve Selected
            </button>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-500" />
          <input
            type="text"
            placeholder="Search leads..."
            value={search}
            onChange={e => setFilter('search', e.target.value)}
            className="input w-full pl-9"
          />
        </div>

        <select value={status} onChange={e => setFilter('status', e.target.value)} className="input text-sm">
          <option value="">All Statuses</option>
          <option value="discovered">Discovered</option>
          <option value="qualified">Qualified</option>
          <option value="approved">Approved</option>
          <option value="bidding">Bidding</option>
          <option value="won">Won</option>
          <option value="passed">Passed</option>
        </select>

        <select value={priority} onChange={e => setFilter('priority', e.target.value)} className="input text-sm">
          <option value="">All Priorities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : leads.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-surface-500">
            <p>No leads found</p>
            <p className="text-xs mt-1">Your agents will discover leads automatically</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-surface-700 text-left">
                <th className="px-4 py-3 w-10">
                  <input type="checkbox" checked={selected.length === leads.length && leads.length > 0}
                    onChange={toggleSelectAll}
                    className="rounded border-surface-600" />
                </th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">Property</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">Location</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">Cost</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">ROI</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">Score</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">AI Rec</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">Status</th>
                <th className="px-4 py-3 text-xs font-semibold text-surface-400 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {leads.map(lead => (
                <tr key={lead._id}
                  className="border-b border-surface-800 hover:bg-surface-800/50 transition-colors cursor-pointer"
                  onClick={() => navigate(`/leads/${lead._id}`)}
                >
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    <input type="checkbox" checked={selected.includes(lead._id)}
                      onChange={() => toggleSelect(lead._id)}
                      className="rounded border-surface-600" />
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-sm font-medium text-surface-200 truncate max-w-[200px]">{lead.title}</p>
                    <p className="text-xs text-surface-500">{lead.source}</p>
                  </td>
                  <td className="px-4 py-3 text-sm text-surface-400">
                    {lead.location?.county}, {lead.location?.state}
                  </td>
                  <td className="px-4 py-3 text-sm text-surface-300 font-mono">
                    ${(lead.estimatedCost || 0).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-sm font-mono">
                    <span className={lead.estimatedROI >= 15 ? 'text-emerald-400' : lead.estimatedROI >= 8 ? 'text-amber-400' : 'text-surface-400'}>
                      {lead.estimatedROI || 0}%
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-1.5 bg-surface-700 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${
                          lead.score >= 70 ? 'bg-emerald-400' : lead.score >= 40 ? 'bg-amber-400' : 'bg-red-400'
                        }`} style={{ width: `${lead.score}%` }} />
                      </div>
                      <span className="text-xs text-surface-400">{lead.score}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={recColors[lead.aiRecommendation] || 'badge-gray'}>
                      {lead.aiRecommendation}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={statusColors[lead.status] || 'badge-gray'}>
                      {lead.status}
                    </span>
                  </td>
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1">
                      {lead.status === 'qualified' && (
                        <>
                          <button
                            onClick={() => leadsAPI.updateStatus(lead._id, 'approved').then(fetchLeads)}
                            className="p-1.5 rounded text-emerald-400 hover:bg-emerald-500/10" title="Approve"
                          ><Check size={14} /></button>
                          <button
                            onClick={() => leadsAPI.updateStatus(lead._id, 'passed').then(fetchLeads)}
                            className="p-1.5 rounded text-red-400 hover:bg-red-500/10" title="Pass"
                          ><X size={14} /></button>
                        </>
                      )}
                      <button
                        onClick={() => navigate(`/leads/${lead._id}`)}
                        className="p-1.5 rounded text-surface-400 hover:bg-surface-700" title="View"
                      ><Eye size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-surface-500">Page {page} of {pages}</p>
          <div className="flex items-center gap-2">
            <button
              disabled={page <= 1}
              onClick={() => setFilter('page', String(page - 1))}
              className="btn-secondary text-sm py-1.5 disabled:opacity-50"
            ><ChevronLeft size={16} /></button>
            <button
              disabled={page >= pages}
              onClick={() => setFilter('page', String(page + 1))}
              className="btn-secondary text-sm py-1.5 disabled:opacity-50"
            ><ChevronRight size={16} /></button>
          </div>
        </div>
      )}
    </div>
  );
}
