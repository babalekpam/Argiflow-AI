import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { leadsAPI } from '../api';
import {
  ArrowLeft, MapPin, DollarSign, TrendingUp, Shield, Clock,
  Check, X, MessageSquare, FileText, AlertTriangle, Star
} from 'lucide-react';

export default function LeadDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [lead, setLead] = useState(null);
  const [loading, setLoading] = useState(true);
  const [note, setNote] = useState('');

  useEffect(() => {
    leadsAPI.getOne(id)
      .then(res => setLead(res.data.lead))
      .catch(() => navigate('/leads'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleStatus = async (status) => {
    const res = await leadsAPI.updateStatus(id, status);
    setLead(res.data.lead);
  };

  const handleAddNote = async () => {
    if (!note.trim()) return;
    const res = await leadsAPI.addNote(id, note);
    setLead(res.data.lead);
    setNote('');
  };

  if (loading || !lead) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const meta = lead.metadata || {};

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex items-start gap-4">
        <button onClick={() => navigate('/leads')} className="p-2 rounded-lg hover:bg-surface-800 text-surface-400 mt-1">
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-white">{lead.title}</h1>
          <div className="flex items-center gap-3 mt-1">
            <span className="flex items-center gap-1 text-sm text-surface-400">
              <MapPin size={14} /> {lead.location?.county}, {lead.location?.state}
            </span>
            <span className={`badge ${lead.status === 'qualified' ? 'badge-yellow' : lead.status === 'approved' ? 'badge-green' : 'badge-gray'}`}>
              {lead.status}
            </span>
            <span className={`badge ${lead.aiRecommendation === 'buy' ? 'badge-green' : lead.aiRecommendation === 'pass' ? 'badge-red' : 'badge-yellow'}`}>
              AI: {lead.aiRecommendation}
            </span>
          </div>
        </div>

        {lead.status === 'qualified' && (
          <div className="flex gap-2">
            <button onClick={() => handleStatus('approved')} className="btn-primary text-sm">
              <Check size={14} className="inline mr-1" /> Approve
            </button>
            <button onClick={() => handleStatus('passed')} className="btn-danger text-sm">
              <X size={14} className="inline mr-1" /> Pass
            </button>
          </div>
        )}
      </div>

      {/* Score Bar */}
      <div className="card">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-surface-300">Deal Score</span>
          <span className="text-2xl font-bold text-white">{lead.score}/100</span>
        </div>
        <div className="w-full h-3 bg-surface-700 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${
              lead.score >= 70 ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' :
              lead.score >= 40 ? 'bg-gradient-to-r from-amber-500 to-amber-400' :
              'bg-gradient-to-r from-red-500 to-red-400'
            }`}
            style={{ width: `${lead.score}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Financial */}
        <div className="card space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <DollarSign size={18} className="text-emerald-400" /> Financial Details
          </h2>
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Amount Owed</span>
              <span className="text-sm font-mono text-white">${(meta.amountOwed || 0).toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Assessed Value</span>
              <span className="text-sm font-mono text-white">${(meta.assessedValue || 0).toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Interest Rate</span>
              <span className="text-sm font-mono text-emerald-400">{meta.interestRate || 0}%</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Estimated ROI</span>
              <span className="text-sm font-mono text-emerald-400">{lead.estimatedROI || 0}%</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Redemption Period</span>
              <span className="text-sm text-white">{meta.redemptionPeriod || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-sm text-surface-400">Redemption Probability</span>
              <span className="text-sm text-white">{meta.redemptionProbability || 0}%</span>
            </div>
          </div>
        </div>

        {/* Property Details */}
        <div className="card space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <MapPin size={18} className="text-brand-400" /> Property Details
          </h2>
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Address</span>
              <span className="text-sm text-white">{lead.location?.address || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Parcel #</span>
              <span className="text-sm font-mono text-white">{meta.parcelNumber || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Property Type</span>
              <span className="text-sm text-white capitalize">{meta.propertyType || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-surface-700">
              <span className="text-sm text-surface-400">Owner</span>
              <span className="text-sm text-white">{meta.ownerName || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-sm text-surface-400">Source</span>
              <a href={lead.sourceUrl} target="_blank" rel="noreferrer" className="text-sm text-brand-400 hover:underline">
                {lead.source}
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* AI Analysis */}
      {lead.aiAnalysis && (
        <div className="card">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-3">
            <Star size={18} className="text-amber-400" /> AI Analysis
          </h2>
          <p className="text-sm text-surface-300 leading-relaxed">{lead.aiAnalysis}</p>

          {(meta.positiveFactors?.length > 0 || meta.riskFactors?.length > 0) && (
            <div className="grid grid-cols-2 gap-4 mt-4">
              {meta.positiveFactors?.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-emerald-400 mb-2">Positive Factors</h3>
                  {meta.positiveFactors.map((f, i) => (
                    <p key={i} className="text-xs text-surface-400 py-1 flex items-start gap-1.5">
                      <Check size={12} className="text-emerald-400 mt-0.5 flex-shrink-0" /> {f}
                    </p>
                  ))}
                </div>
              )}
              {meta.riskFactors?.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-red-400 mb-2">Risk Factors</h3>
                  {meta.riskFactors.map((f, i) => (
                    <p key={i} className="text-xs text-surface-400 py-1 flex items-start gap-1.5">
                      <AlertTriangle size={12} className="text-red-400 mt-0.5 flex-shrink-0" /> {f}
                    </p>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Notes */}
      <div className="card">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-3">
          <MessageSquare size={18} className="text-brand-400" /> Notes
        </h2>

        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={note}
            onChange={e => setNote(e.target.value)}
            placeholder="Add a note..."
            className="input flex-1"
            onKeyDown={e => e.key === 'Enter' && handleAddNote()}
          />
          <button onClick={handleAddNote} className="btn-primary text-sm">Add</button>
        </div>

        {lead.notes?.length > 0 ? (
          <div className="space-y-2">
            {lead.notes.slice().reverse().map((n, i) => (
              <div key={i} className="flex items-start gap-3 py-2 border-b border-surface-800 last:border-0">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  n.author === 'agent' ? 'bg-brand-600 text-white' : 'bg-surface-600 text-surface-300'
                }`}>
                  {n.author === 'agent' ? 'AI' : 'U'}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-surface-300">{n.content}</p>
                  <p className="text-xs text-surface-600 mt-0.5">
                    {new Date(n.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-surface-500 text-center py-2">No notes yet</p>
        )}
      </div>
    </div>
  );
}
