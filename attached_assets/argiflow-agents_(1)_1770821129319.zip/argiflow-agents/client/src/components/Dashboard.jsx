import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { dashboardAPI } from '../api';
import {
  Bot, Target, TrendingUp, DollarSign, Clock, AlertTriangle,
  ArrowUpRight, ArrowDownRight, Activity
} from 'lucide-react';

function StatCard({ icon: Icon, label, value, subValue, trend, color = 'brand' }) {
  const colors = {
    brand: 'from-brand-500/20 to-brand-600/5 border-brand-500/20 text-brand-400',
    green: 'from-emerald-500/20 to-emerald-600/5 border-emerald-500/20 text-emerald-400',
    amber: 'from-amber-500/20 to-amber-600/5 border-amber-500/20 text-amber-400',
    red: 'from-red-500/20 to-red-600/5 border-red-500/20 text-red-400',
  };

  return (
    <div className={`bg-gradient-to-br ${colors[color]} border rounded-xl p-5`}>
      <div className="flex items-start justify-between mb-3">
        <div className="p-2 rounded-lg bg-surface-800/50">
          <Icon size={20} />
        </div>
        {trend !== undefined && (
          <span className={`flex items-center gap-1 text-xs font-medium ${trend >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {trend >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-sm text-surface-400 mt-1">{label}</p>
      {subValue && <p className="text-xs text-surface-500 mt-0.5">{subValue}</p>}
    </div>
  );
}

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    dashboardAPI.getStats()
      .then(res => setStats(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const o = stats?.overview || {};
  const f = stats?.financial || {};

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Command Center</h1>
          <p className="text-surface-400 text-sm mt-1">Your AI agents are working around the clock</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${
            o.activeAgents > 0
              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
              : 'bg-surface-700 text-surface-400 border border-surface-600'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${o.activeAgents > 0 ? 'bg-emerald-400 animate-pulse' : 'bg-surface-500'}`} />
            {o.activeAgents || 0} Agent{o.activeAgents !== 1 ? 's' : ''} Active
          </span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Bot} label="Active Agents" value={o.activeAgents || 0} subValue={`${o.totalAgents || 0} configured`} color="brand" />
        <StatCard icon={Target} label="Total Leads" value={o.totalLeads || 0} subValue={`${o.qualifiedLeads || 0} qualified`} color="green" />
        <StatCard icon={TrendingUp} label="Avg ROI" value={`${o.avgROI || 0}%`} subValue={`Avg score: ${o.avgScore || 0}/100`} color="amber" />
        <StatCard icon={DollarSign} label="Total Profit" value={`$${(f.totalProfit || 0).toLocaleString()}`} subValue={`${f.dealCount || 0} deals completed`} color="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Needs Attention */}
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={18} className="text-amber-400" />
            <h2 className="text-lg font-semibold text-white">Needs Your Attention</h2>
          </div>
          {stats?.needsAttention?.length > 0 ? (
            <div className="space-y-2">
              {stats.needsAttention.map(lead => (
                <div
                  key={lead._id}
                  onClick={() => navigate(`/leads/${lead._id}`)}
                  className="flex items-center justify-between p-3 bg-surface-900 rounded-lg cursor-pointer hover:bg-surface-800 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-surface-200 truncate">{lead.title}</p>
                    <p className="text-xs text-surface-500">{lead.location?.county}, {lead.location?.state}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="badge-yellow">Score: {lead.score}</span>
                    <span className={lead.priority === 'critical' ? 'badge-red' : 'badge-yellow'}>{lead.priority}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-surface-500 text-sm py-4 text-center">No items need attention right now</p>
          )}
        </div>

        {/* Upcoming Deadlines */}
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Clock size={18} className="text-brand-400" />
            <h2 className="text-lg font-semibold text-white">Upcoming Deadlines</h2>
          </div>
          {stats?.upcomingDeadlines?.length > 0 ? (
            <div className="space-y-2">
              {stats.upcomingDeadlines.map(lead => {
                const daysLeft = Math.ceil((new Date(lead.actionDeadline) - new Date()) / (1000 * 60 * 60 * 24));
                return (
                  <div
                    key={lead._id}
                    onClick={() => navigate(`/leads/${lead._id}`)}
                    className="flex items-center justify-between p-3 bg-surface-900 rounded-lg cursor-pointer hover:bg-surface-800 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-surface-200 truncate">{lead.title}</p>
                      <p className="text-xs text-surface-500">{new Date(lead.actionDeadline).toLocaleDateString()}</p>
                    </div>
                    <span className={daysLeft <= 3 ? 'badge-red' : daysLeft <= 7 ? 'badge-yellow' : 'badge-blue'}>
                      {daysLeft}d left
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-surface-500 text-sm py-4 text-center">No upcoming deadlines</p>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Activity size={18} className="text-brand-400" />
          <h2 className="text-lg font-semibold text-white">Recent Agent Activity</h2>
        </div>
        {stats?.recentActivity?.length > 0 ? (
          <div className="space-y-2">
            {stats.recentActivity.slice(0, 8).map(task => (
              <div key={task._id} className="flex items-center gap-3 py-2 border-b border-surface-800 last:border-0">
                <div className={`w-2 h-2 rounded-full ${
                  task.status === 'completed' ? 'bg-emerald-400' :
                  task.status === 'running' ? 'bg-brand-400 animate-pulse' :
                  task.status === 'failed' ? 'bg-red-400' : 'bg-surface-500'
                }`} />
                <div className="flex-1">
                  <span className="text-sm text-surface-300">{task.description}</span>
                </div>
                <span className="text-xs text-surface-500">
                  {new Date(task.createdAt).toLocaleString()}
                </span>
                <span className={`text-xs font-medium ${
                  task.status === 'completed' ? 'text-emerald-400' :
                  task.status === 'failed' ? 'text-red-400' : 'text-surface-400'
                }`}>{task.status}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-surface-500 text-sm py-4 text-center">No activity yet. Enable an agent to get started!</p>
        )}
      </div>
    </div>
  );
}
