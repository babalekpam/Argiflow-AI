import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../App';
import { Zap, User, Mail, Lock, Phone, AlertCircle } from 'lucide-react';

export default function Register() {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const update = (key, val) => setForm({ ...form, [key]: val });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await register(form);
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-surface-950 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-brand-500 to-brand-700 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-brand-500/20">
            <Zap size={28} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Create your account</h1>
          <p className="text-surface-400 text-sm mt-1">Start automating with AI agents today</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="card space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm text-red-400">
              <AlertCircle size={16} /> {error}
            </div>
          )}

          <div>
            <label className="text-sm text-surface-400 mb-1 block">Full Name</label>
            <div className="relative">
              <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-500" />
              <input
                type="text" value={form.name} onChange={e => update('name', e.target.value)}
                className="input w-full pl-9" placeholder="John Doe" required
              />
            </div>
          </div>

          <div>
            <label className="text-sm text-surface-400 mb-1 block">Email</label>
            <div className="relative">
              <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-500" />
              <input
                type="email" value={form.email} onChange={e => update('email', e.target.value)}
                className="input w-full pl-9" placeholder="you@example.com" required
              />
            </div>
          </div>

          <div>
            <label className="text-sm text-surface-400 mb-1 block">Phone (optional)</label>
            <div className="relative">
              <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-500" />
              <input
                type="tel" value={form.phone} onChange={e => update('phone', e.target.value)}
                className="input w-full pl-9" placeholder="+1 (555) 000-0000"
              />
            </div>
          </div>

          <div>
            <label className="text-sm text-surface-400 mb-1 block">Password</label>
            <div className="relative">
              <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-500" />
              <input
                type="password" value={form.password} onChange={e => update('password', e.target.value)}
                className="input w-full pl-9" placeholder="Min 6 characters" required minLength={6}
              />
            </div>
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 text-sm">
            {loading ? 'Creating account...' : 'Create Account'}
          </button>

          <p className="text-xs text-surface-500 text-center">
            By signing up, you agree to our Terms of Service
          </p>
        </form>

        <p className="text-center text-sm text-surface-500 mt-4">
          Already have an account?{' '}
          <Link to="/login" className="text-brand-400 hover:text-brand-300 font-medium">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
