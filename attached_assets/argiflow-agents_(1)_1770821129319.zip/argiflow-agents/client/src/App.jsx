import React, { useState, useEffect, createContext, useContext } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { authAPI } from './api';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import AgentsPage from './components/AgentsPage';
import AgentConfig from './components/AgentConfig';
import LeadsPage from './components/LeadsPage';
import LeadDetail from './components/LeadDetail';
import Pipeline from './components/Pipeline';
import NotificationsPage from './components/NotificationsPage';
import Login from './components/Login';
import Register from './components/Register';

// Auth Context
const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('argiflow_token');
    if (token) {
      authAPI.getProfile()
        .then(res => setUser(res.data.user))
        .catch(() => localStorage.removeItem('argiflow_token'))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (email, password) => {
    const res = await authAPI.login({ email, password });
    localStorage.setItem('argiflow_token', res.data.token);
    setUser(res.data.user);
    return res.data;
  };

  const register = async (data) => {
    const res = await authAPI.register(data);
    localStorage.setItem('argiflow_token', res.data.token);
    setUser(res.data.user);
    return res.data;
  };

  const logout = () => {
    localStorage.removeItem('argiflow_token');
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-surface-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-surface-400 text-sm">Loading ArgiFlow...</span>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
        <Route path="/register" element={!user ? <Register /> : <Navigate to="/" />} />
        <Route path="/" element={user ? <Layout /> : <Navigate to="/login" />}>
          <Route index element={<Dashboard />} />
          <Route path="agents" element={<AgentsPage />} />
          <Route path="agents/:agentType" element={<AgentConfig />} />
          <Route path="leads" element={<LeadsPage />} />
          <Route path="leads/:id" element={<LeadDetail />} />
          <Route path="pipeline" element={<Pipeline />} />
          <Route path="notifications" element={<NotificationsPage />} />
        </Route>
      </Routes>
    </AuthContext.Provider>
  );
}

export default App;
