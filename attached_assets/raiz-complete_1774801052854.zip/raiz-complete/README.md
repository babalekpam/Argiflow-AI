# 🌿 RAIZ — Complete Package
# Africa's Traditional Medicine Intelligence Platform
# Built by Abel Nkawula · ARGILETTE LLC · St. Louis, MO

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## CONTENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

raiz-complete/
│
├── README.md                          ← You are here
│
├── platform/
│   └── raiz-platform-v2.zip           ← MAIN APP — deploy this on Replit
│
├── database/
│   ├── plantsDB.js                    ← 100-plant database (plug-in)
│   └── INTEGRATION.md                ← How to plug in the database
│
└── brand_assets/
    ├── svg/
    │   ├── raiz-icon-1024.svg         ← App icon (scalable, any size)
    │   ├── raiz-icon-512.svg          ← App icon 512px variant
    │   └── raiz-logo.svg              ← Full horizontal logo
    │
    └── jpeg/
        ├── raiz-icon-1024x1024.jpg               ← Google Play icon
        ├── raiz-icon-1024x1024-white-bg.jpg      ← Apple App Store icon
        ├── raiz-icon-512x512.jpg                 ← Google Play hi-res icon
        ├── raiz-logo-horizontal.jpg              ← Website / documents
        ├── raiz-logo-dark-bg.jpg                 ← Dark mode / social media
        └── raiz-feature-graphic-1024x500.jpg     ← Google Play feature banner

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## QUICK DEPLOY — Replit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Upload  platform/raiz-platform-v2.zip  to Replit (Import from ZIP)
2. Add Secrets:
     JWT_SECRET  = (generate: openssl rand -hex 48)
     NODE_ENV    = production
     APP_URL     = https://your-app.replit.app
3. Run in Shell:
     npm install && npm run build && npm start

Admin login: admin@raiz.africa / Admin@RAIZ2024
(Change password after first login)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## PLATFORM FEATURES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅  50 African medicinal plants (original database)
✅  100-plant database available (see database/plantsDB.js)
✅  AI Plant Scanner (Claude Vision — photo identification)
✅  AI Symptom Advisor (evidence-based recommendations)
✅  Combination Safety Checker (17 interaction pairs)
✅  Field Guide (emergency criteria, edibility, dosage rules)
✅  4 Languages: EN · FR · SW · PT
✅  Membership system (Trial / Practitioner / Institution / Admin)
✅  User signup → onboarding → dashboard
✅  Super admin dashboard (stats, users, audit log, community moderation)
✅  Community Knowledge System:
     → Practitioners can submit new plants (4-step wizard)
     → Practitioners can document proven treatment protocols
     → Admin review workflow (approve / feature / reject)
     → Upvote/downvote system
     → My Submissions tracker
✅  Password reset flow
✅  JWT auth, bcrypt passwords, NeDB database (no setup required)
✅  PWA-ready (installable on Android/iOS from browser)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## MEMBERSHIP PLANS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Plan            Price     Scans/mo   Queries/mo
─────────────── ───────── ────────── ──────────
Free Trial      Free      5          10          (7 days)
Practitioner    $9.99/mo  200        500
Institution     $49/mo    Unlimited  Unlimited
Admin           —         Unlimited  Unlimited

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## PLUG IN 100-PLANT DATABASE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The platform ships with 50 African plants.
To upgrade to 100 plants (Africa + Caribbean + Latin America + Global):

1. Copy  database/plantsDB.js  →  src/data/plantsDB.js  (inside the ZIP)
2. In RAIZApp.jsx, replace the line:
     const PLANTS = [
   with:
     import { PLANTS } from '../data/plantsDB.js';
3. Delete the old PLANTS array
4. Rebuild: npm run build

See  database/INTEGRATION.md  for full details.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## BRAND ASSETS — WHERE TO USE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

File                                    Use
──────────────────────────────────────  ─────────────────────────────────
raiz-icon-1024x1024.jpg                Google Play Store — App icon
raiz-icon-1024x1024-white-bg.jpg       Apple App Store — requires white bg
raiz-icon-512x512.jpg                  Google Play — hi-res icon (required)
raiz-feature-graphic-1024x500.jpg      Google Play — feature graphic banner
raiz-logo-horizontal.jpg               Website header, documents, pitch deck
raiz-logo-dark-bg.jpg                  Dark websites, social media, banners
raiz-icon-1024.svg / raiz-logo.svg     Print, any size — source files

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ARGILETTE LLC · argilette.com
Built for traditional practitioners across Africa and the world.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
