# RAIZ Plant Database v2 — Integration Guide
# 100 Plants: Africa · Caribbean/Jamaica · Latin America · Global

## What changed
- **50 → 100 plants** (doubled)
- New sections: Caribbean/Jamaica, Latin America, Global/Universal
- All plants follow the SAME data structure as the original 50
- Zero breaking changes — drop-in replacement

---

## Integration: 2 steps

### Step 1 — Add the database file
Copy `plantsDB.js` into your project:
```
src/
  data/
    plantsDB.js    ← add this file
  components/
    RAIZApp.jsx
```

### Step 2 — Update RAIZApp.jsx
Open `src/components/RAIZApp.jsx` (or wherever your main app component is).

Find the line that starts the PLANTS array:
```javascript
const PLANTS = [
  { id:1, name:"Artemisia annua", ...
```

Replace ONLY that line with:
```javascript
import { PLANTS } from '../data/plantsDB.js';
```

That's it. Move the import to the top of the file (before the component functions).

**Full import block at top of RAIZApp.jsx:**
```javascript
import { useState, useRef, useCallback } from "react";
import { PLANTS } from '../data/plantsDB.js';   // ← ADD THIS LINE

const C = {
  terra:"#B83A0A", ...
```

Then delete the entire `const PLANTS = [ ... ]` block (from `const PLANTS = [` to the closing `];`).

---

## What's new in the database

### Section 1 — Africa (plants 1–50)
Original 50 plants, updated data.
- All original plants preserved with same IDs
- Added: Griffonia simplicifolia (5-HTP), Prunus africana (Pygeum), Cryptolepis sanguinolenta (Ghana Quinine), Annona senegalensis (Wild Custard Apple), Acacia senegal (Gum Arabic), Ziziphus mauritiana (Jujube), Moringa stenopetala (African Moringa)

### Section 2 — Caribbean & Jamaica (plants 51–62)
- Annona muricata — Soursop/Corossol/Graviola
- Petiveria alliacea — Guinea Hen Weed
- Morinda citrifolia — Noni
- Pimenta dioica — Allspice/Pimento (Jamaica's famous spice)
- Smilax balbisiana — Chaney Root
- Boerhavia diffusa — Strongback
- Sambucus nigra — Elderberry
- Ruta graveolens — Rue (WARNING plant — abortifacient)
- Momordica charantia var. — Cerasee (Caribbean bitter melon)
- Verbena officinalis — Vervain

### Section 3 — Latin America (plants 63–74)
- Uncaria tomentosa — Cat's Claw / Uña de Gato
- Tabebuia impetiginosa — Pau d'Arco / Lapacho
- Passiflora incarnata — Passion Flower
- Ilex paraguariensis — Yerba Mate
- Lepidium meyenii — Maca
- Croton lechleri — Sangre de Drago
- Stevia rebaudiana — Stevia
- Paullinia cupana — Guaraná
- Smilax regelii — Sarsaparilla
- Dysphania ambrosioides — Epazote
- Peumus boldus — Boldo
- Cissus quadrangularis — Bone Setter

### Section 4 — Global (plants 75–100)
- Allium sativum — Garlic
- Nigella sativa — Black Seed / Habbatus Sauda
- Centella asiatica — Gotu Kola
- Andrographis paniculata — King of Bitters
- Withania somnifera — Ashwagandha
- Ocimum tenuiflorum — Holy Basil / Tulsi
- Echinacea purpurea — Echinacea
- Hypericum perforatum — St. John's Wort
- Panax ginseng — Korean Ginseng
- Valeriana officinalis — Valerian
- Mentha piperita — Peppermint
- Eucalyptus globulus — Eucalyptus
- Matricaria chamomilla — Chamomile
- Taraxacum officinale — Dandelion
- Calendula officinalis — Calendula
- Boswellia sacra — Frankincense
- Rosmarinus officinalis — Rosemary
- Zingiber zerumbet — Shampoo Ginger
- Urtica dioica — Stinging Nettle
- Plantago major — Plantain Herb
- Camellia sinensis — Green/Black Tea
- Mimosa pudica — Sensitive Plant
- Aloe ferox — Cape Aloe
- Tribulus terrestris — Puncture Vine
- Moringa stenopetala — African Moringa

---

## New utility exports

```javascript
import {
  PLANTS,               // full array of 100 plants
  PLANT_COUNT,          // 100
  EDIBLE_PLANTS,        // plants where edible === true
  DANGEROUS_PLANTS,     // plants where toxicityRisk === "high"
  PLANTS_BY_REGION,     // function(region) => filtered array
  PLANTS_BY_CATEGORY,   // function(category) => filtered array
  SEARCH_PLANTS,        // function(query) => filtered array
  REGIONS,              // full list of regions
  CATEGORIES,           // full list of categories
} from './data/plantsDB.js';
```

---

## No changes needed to:
- AI Advisor prompt (already global in context)
- Plant Scanner prompt (already global in context)
- Safety checker (uses PLANTS array — auto-updated)
- Field Guide (hardcoded — add new dangerous plants manually if desired)
- Combination checker (COMBOS array — add new pairs if needed)
- All filters, search, modals — work automatically

---

Built by Abel Nkawula · ARGILETTE LLC
