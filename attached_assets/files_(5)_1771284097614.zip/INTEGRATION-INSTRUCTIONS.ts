/**
 * ═══════════════════════════════════════════════════════════════
 * VOICE AI FIX — Integration Instructions
 * ═══════════════════════════════════════════════════════════════
 *
 * STEP 1: Add environment variable
 *   In your Replit Secrets, add:
 *     DEEPGRAM_API_KEY = your key from https://console.deepgram.com
 *     (Free tier: 45,000 minutes STT + TTS included)
 *
 * STEP 2: Install dependency
 *   npm install ws @types/ws
 *   (You already have @anthropic-ai/sdk)
 *
 * STEP 3: Copy voice-stream.ts to server/
 *   Copy voice-stream.ts → server/voice-stream.ts
 *
 * STEP 4: Attach WebSocket in server startup
 *   In your server/index.ts (or wherever createServer/app.listen is):
 *
 *   FIND something like:
 *     const server = app.listen(PORT, ...);
 *   OR:
 *     const server = createServer(app);
 *     server.listen(PORT, ...);
 *
 *   ADD after it:
 *     import { attachVoiceStreamWSS } from "./voice-stream";
 *     attachVoiceStreamWSS(server, storage);
 *
 * STEP 5: Replace the TwiML endpoint in server/routes.ts
 *   Find the TwiML handler (line ~4280):
 *     app.post("/api/twilio/voice/:callLogId/twiml", async (req, res) => {
 *   
 *   Replace the ENTIRE handler with this new version below.
 *   The old handler stays as a fallback for the initial greeting only,
 *   but the actual conversation now happens via WebSocket streaming.
 */

// ═══════════════════════════════════════════════════════════════
// REPLACEMENT TwiML HANDLER — paste this over the old one
// (from line ~4280 to the closing });)
// ═══════════════════════════════════════════════════════════════

/*

  // NEW: Real-time streaming Voice AI via Twilio Media Streams
  app.post("/api/twilio/voice/:callLogId/twiml", async (req, res) => {
    try {
      const { callLogId } = req.params;
      const callLog = await storage.getVoiceCallById(callLogId);

      if (!callLog) {
        res.type("text/xml");
        return res.send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>Sorry, an error occurred.</Say><Hangup/></Response>`);
      }

      const baseUrl = `https://${req.get("host")}`;
      // Convert https:// to wss:// for WebSocket
      const wsUrl = baseUrl.replace("https://", "wss://");

      // Check if Deepgram is configured for real-time streaming
      if (process.env.DEEPGRAM_API_KEY) {
        // USE REAL-TIME STREAMING PIPELINE
        // Twilio connects a WebSocket that streams audio bidirectionally
        res.type("text/xml");
        return res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="${wsUrl}/api/voice/stream/${callLogId}">
      <Parameter name="callLogId" value="${callLogId}" />
    </Stream>
  </Connect>
</Response>`);
      }

      // FALLBACK: Old <Gather>/<Say> method if Deepgram not configured
      // (This is the original code that has timeout issues)
      let greeting = "Hello, this is an AI assistant. How can I help you?";
      let systemPrompt = "You are a professional AI phone agent. Be helpful and concise.";

      try {
        const scriptData = callLog.script ? JSON.parse(callLog.script) : {};
        greeting = scriptData.greeting || greeting;
        systemPrompt = scriptData.systemPrompt || systemPrompt;
      } catch {
        greeting = callLog.script || greeting;
      }

      const speechResult = req.body?.SpeechResult;

      if (speechResult) {
        try {
          const existingTranscript = callLog.transcript ? JSON.parse(callLog.transcript) : [];
          existingTranscript.push({ role: "caller", text: speechResult });

          const conversationHistory = existingTranscript.map((t: any) =>
            ({ role: t.role === "agent" ? "assistant" as const : "user" as const, content: t.text })
          );

          let voiceAi: { client: Anthropic; model: string };
          try { voiceAi = await getAnthropicForUser(callLog.userId); } catch {
            res.type("text/xml");
            return res.send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>AI service not configured.</Say><Hangup/></Response>`);
          }

          const aiResponse = await voiceAi.client.messages.create({
            model: voiceAi.model,
            max_tokens: 300,
            system: systemPrompt,
            messages: conversationHistory,
          });

          const aiText = aiResponse.content[0]?.type === "text" ? aiResponse.content[0].text : "I understand. Is there anything else?";
          existingTranscript.push({ role: "agent", text: aiText });
          await storage.updateVoiceCall(callLogId, { transcript: JSON.stringify(existingTranscript) });

          const isGoodbye = aiText.toLowerCase().includes("goodbye") || existingTranscript.length > 20;

          res.type("text/xml");
          if (isGoodbye) {
            return res.send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="Polly.Joanna">${escapeXml(aiText)}</Say><Hangup/></Response>`);
          }
          return res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna">${escapeXml(aiText)}</Say>
  <Gather input="speech" timeout="8" speechTimeout="auto" action="${baseUrl}/api/twilio/voice/${callLogId}/twiml" method="POST">
    <Say voice="Polly.Joanna"></Say>
  </Gather>
  <Say voice="Polly.Joanna">Are you still there?</Say>
  <Hangup/>
</Response>`);
        } catch (aiErr) {
          console.error("AI response error:", aiErr);
          res.type("text/xml");
          return res.send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="Polly.Joanna">Technical issue. A team member will follow up. Goodbye!</Say><Hangup/></Response>`);
        }
      }

      const initialTranscript = [{ role: "agent", text: greeting }];
      await storage.updateVoiceCall(callLogId, { status: "in-progress", transcript: JSON.stringify(initialTranscript) });

      res.type("text/xml");
      res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna">${escapeXml(greeting)}</Say>
  <Gather input="speech" timeout="8" speechTimeout="auto" action="${baseUrl}/api/twilio/voice/${callLogId}/twiml" method="POST">
    <Say voice="Polly.Joanna"></Say>
  </Gather>
  <Say voice="Polly.Joanna">Hello? Are you still there?</Say>
  <Hangup/>
</Response>`);
    } catch (error) {
      console.error("TwiML error:", error);
      res.type("text/xml");
      res.send(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>An error occurred. Goodbye.</Say><Hangup/></Response>`);
    }
  });

*/
