/**
 * ArgiFlow Real-Time Voice AI Streaming Pipeline
 * ================================================
 * Twilio Media Streams (WebSocket) → Deepgram STT → Claude API (streaming) → Deepgram TTS → Twilio
 *
 * This replaces the broken <Gather>/<Say> TwiML loop that times out.
 * Now the AI responds in real-time with no silence gaps.
 *
 * Required env vars:
 *   DEEPGRAM_API_KEY  - For speech-to-text AND text-to-speech (https://console.deepgram.com)
 *   ANTHROPIC_API_KEY - Already configured for Claude
 *
 * Optional env vars:
 *   ELEVENLABS_API_KEY - Use ElevenLabs TTS instead of Deepgram (higher quality voice)
 *   ELEVENLABS_VOICE_ID - ElevenLabs voice (default: "21m00Tcm4TlvDq8ikWAM" = Rachel)
 */

import { WebSocket, WebSocketServer } from "ws";
import type { IncomingMessage } from "http";
import type { Server as HttpServer } from "http";
import Anthropic from "@anthropic-ai/sdk";

// ── Types ──

interface TwilioMediaMessage {
  event: "connected" | "start" | "media" | "stop" | "mark";
  sequenceNumber?: string;
  start?: { streamSid: string; callSid: string; accountSid: string; customParameters?: Record<string, string> };
  media?: { track: string; chunk: string; timestamp: string; payload: string };
  stop?: { accountSid: string; callSid: string };
  mark?: { name: string };
  streamSid?: string;
}

interface CallSession {
  callLogId: string;
  streamSid: string;
  callSid: string;
  systemPrompt: string;
  greeting: string;
  conversationHistory: { role: "user" | "assistant"; content: string }[];
  transcript: { role: string; text: string }[];
  deepgramWs: WebSocket | null;
  isProcessing: boolean;
  currentUtterance: string;
  silenceTimer: ReturnType<typeof setTimeout> | null;
  markCounter: number;
  isSpeaking: boolean;
  pendingAudio: Buffer[];
  userId: string;
}

// ── Helpers ──

function log(callId: string, msg: string) {
  console.log(`[VoiceStream:${callId.slice(0, 8)}] ${msg}`);
}

/**
 * Convert mulaw 8kHz (Twilio format) base64 to linear PCM 16-bit for Deepgram
 * Twilio sends audio as base64-encoded mulaw at 8000Hz mono
 */
const MULAW_DECODE_TABLE = new Int16Array(256);
(function buildMulawTable() {
  for (let i = 0; i < 256; i++) {
    let mu = ~i & 0xff;
    let sign = mu & 0x80;
    let exponent = (mu >> 4) & 0x07;
    let mantissa = mu & 0x0f;
    let sample = ((mantissa << 3) + 0x84) << exponent;
    sample -= 0x84;
    MULAW_DECODE_TABLE[i] = sign ? -sample : sample;
  }
})();

function mulawToLinear16(mulawBase64: string): Buffer {
  const mulawBytes = Buffer.from(mulawBase64, "base64");
  const pcm = Buffer.alloc(mulawBytes.length * 2);
  for (let i = 0; i < mulawBytes.length; i++) {
    const sample = MULAW_DECODE_TABLE[mulawBytes[i]];
    pcm.writeInt16LE(sample, i * 2);
  }
  return pcm;
}

/**
 * Convert linear PCM 16-bit to mulaw for sending back to Twilio
 */
function linear16ToMulaw(pcm16: Buffer): Buffer {
  const mulaw = Buffer.alloc(pcm16.length / 2);
  for (let i = 0; i < mulaw.length; i++) {
    let sample = pcm16.readInt16LE(i * 2);
    const sign = sample < 0 ? 0x80 : 0;
    if (sign) sample = -sample;
    if (sample > 32635) sample = 32635;
    sample += 0x84;
    let exponent = 7;
    for (let expMask = 0x4000; (sample & expMask) === 0 && exponent > 0; exponent--, expMask >>= 1) {}
    const mantissa = (sample >> (exponent + 3)) & 0x0f;
    mulaw[i] = ~(sign | (exponent << 4) | mantissa) & 0xff;
  }
  return mulaw;
}

// ── Deepgram STT (real-time WebSocket) ──

function createDeepgramSTT(
  session: CallSession,
  onTranscript: (text: string, isFinal: boolean) => void,
  onError: (err: Error) => void
): WebSocket {
  const apiKey = process.env.DEEPGRAM_API_KEY;
  if (!apiKey) throw new Error("DEEPGRAM_API_KEY not set");

  const dgUrl = "wss://api.deepgram.com/v1/listen?" + new URLSearchParams({
    model: "nova-2",
    language: "en-US",
    encoding: "linear16",
    sample_rate: "8000",
    channels: "1",
    punctuate: "true",
    interim_results: "true",
    utterance_end_ms: "1200",
    vad_events: "true",
    endpointing: "300",
    smart_format: "true",
  }).toString();

  const ws = new WebSocket(dgUrl, {
    headers: { Authorization: `Token ${apiKey}` },
  });

  ws.on("open", () => {
    log(session.callLogId, "Deepgram STT connected");
  });

  ws.on("message", (data: Buffer) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.type === "Results" && msg.channel?.alternatives?.[0]) {
        const alt = msg.channel.alternatives[0];
        const text = alt.transcript?.trim();
        if (text) {
          const isFinal = msg.is_final === true;
          onTranscript(text, isFinal);
        }
      }

      if (msg.type === "UtteranceEnd") {
        // Force-finalize whatever we have
        if (session.currentUtterance.trim()) {
          onTranscript(session.currentUtterance.trim(), true);
        }
      }
    } catch (e) {
      // Ignore parse errors for keepalive/metadata messages
    }
  });

  ws.on("error", (err) => {
    log(session.callLogId, `Deepgram STT error: ${err.message}`);
    onError(err);
  });

  ws.on("close", () => {
    log(session.callLogId, "Deepgram STT closed");
  });

  return ws;
}

// ── Text-to-Speech ──

async function textToMulawAudio(text: string): Promise<Buffer> {
  // Try ElevenLabs first if configured
  if (process.env.ELEVENLABS_API_KEY) {
    return elevenLabsTTS(text);
  }
  // Fallback to Deepgram TTS
  return deepgramTTS(text);
}

async function deepgramTTS(text: string): Promise<Buffer> {
  const apiKey = process.env.DEEPGRAM_API_KEY;
  if (!apiKey) throw new Error("DEEPGRAM_API_KEY not set");

  const response = await fetch("https://api.deepgram.com/v1/speak?" + new URLSearchParams({
    model: "aura-asteria-en",
    encoding: "mulaw",
    sample_rate: "8000",
    container: "none",
  }).toString(), {
    method: "POST",
    headers: {
      Authorization: `Token ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ text }),
  });

  if (!response.ok) {
    throw new Error(`Deepgram TTS error: ${response.status} ${response.statusText}`);
  }

  return Buffer.from(await response.arrayBuffer());
}

async function elevenLabsTTS(text: string): Promise<Buffer> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  const voiceId = process.env.ELEVENLABS_VOICE_ID || "21m00Tcm4TlvDq8ikWAM"; // Rachel

  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
    method: "POST",
    headers: {
      "xi-api-key": apiKey!,
      "Content-Type": "application/json",
      Accept: "audio/mpeg",
    },
    body: JSON.stringify({
      text,
      model_id: "eleven_turbo_v2",
      voice_settings: { stability: 0.5, similarity_boost: 0.75, style: 0.0 },
    }),
  });

  if (!response.ok) {
    throw new Error(`ElevenLabs TTS error: ${response.status}`);
  }

  // ElevenLabs returns MP3. We need to convert to mulaw 8kHz.
  // For simplicity, we'll use Deepgram as fallback if ElevenLabs returns MP3
  // In production, use ffmpeg or an audio conversion library
  // For now, Deepgram TTS with mulaw output is the cleanest path
  console.warn("[VoiceStream] ElevenLabs returns MP3, falling back to Deepgram for mulaw output");
  return deepgramTTS(text);
}

// ── Claude AI Streaming Response ──

async function getAIResponse(
  session: CallSession,
  userText: string,
  onSentence: (sentence: string) => void,
  onComplete: (fullText: string) => void,
): Promise<void> {
  session.conversationHistory.push({ role: "user", content: userText });
  session.transcript.push({ role: "caller", text: userText });

  let anthropicClient: Anthropic;
  let model: string;

  // Try to get user-specific Anthropic config
  try {
    const { getAnthropicForUser } = await import("./routes");
    const ai = await (getAnthropicForUser as any)(session.userId);
    anthropicClient = ai.client;
    model = ai.model;
  } catch {
    anthropicClient = new Anthropic();
    model = "claude-sonnet-4-20250514";
  }

  let fullResponse = "";
  let sentenceBuffer = "";

  const stream = await anthropicClient.messages.stream({
    model,
    max_tokens: 300,
    system: session.systemPrompt,
    messages: session.conversationHistory,
  });

  for await (const event of stream) {
    if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
      const chunk = event.delta.text;
      fullResponse += chunk;
      sentenceBuffer += chunk;

      // Split on sentence boundaries for natural speech pacing
      const sentenceEnders = /([.!?]+[\s]|[.!?]+$)/g;
      let match;
      let lastIndex = 0;

      while ((match = sentenceEnders.exec(sentenceBuffer)) !== null) {
        const sentence = sentenceBuffer.slice(lastIndex, match.index + match[0].length).trim();
        if (sentence.length > 3) {
          onSentence(sentence);
        }
        lastIndex = match.index + match[0].length;
      }

      if (lastIndex > 0) {
        sentenceBuffer = sentenceBuffer.slice(lastIndex);
      }
    }
  }

  // Flush remaining text
  if (sentenceBuffer.trim().length > 3) {
    onSentence(sentenceBuffer.trim());
  }

  session.conversationHistory.push({ role: "assistant", content: fullResponse });
  session.transcript.push({ role: "agent", text: fullResponse });

  onComplete(fullResponse);
}

// ── Send audio to Twilio via WebSocket ──

function sendAudioToTwilio(twilioWs: WebSocket, session: CallSession, audioPayload: Buffer) {
  if (twilioWs.readyState !== WebSocket.OPEN) return;

  // Send in 20ms chunks (160 bytes of mulaw at 8kHz)
  const chunkSize = 160;
  for (let offset = 0; offset < audioPayload.length; offset += chunkSize) {
    const chunk = audioPayload.subarray(offset, Math.min(offset + chunkSize, audioPayload.length));
    const base64Chunk = chunk.toString("base64");

    twilioWs.send(JSON.stringify({
      event: "media",
      streamSid: session.streamSid,
      media: { payload: base64Chunk },
    }));
  }

  // Send a mark so we know when audio finishes playing
  session.markCounter++;
  twilioWs.send(JSON.stringify({
    event: "mark",
    streamSid: session.streamSid,
    mark: { name: `speech_${session.markCounter}` },
  }));
}

// Clear Twilio's audio queue (interrupt when caller speaks)
function clearTwilioAudio(twilioWs: WebSocket, session: CallSession) {
  if (twilioWs.readyState !== WebSocket.OPEN) return;
  twilioWs.send(JSON.stringify({
    event: "clear",
    streamSid: session.streamSid,
  }));
  session.isSpeaking = false;
}

// ── Main WebSocket Handler ──

async function handleVoiceStream(
  twilioWs: WebSocket,
  callLogId: string,
  storage: any,
) {
  const session: CallSession = {
    callLogId,
    streamSid: "",
    callSid: "",
    systemPrompt: "",
    greeting: "",
    conversationHistory: [],
    transcript: [],
    deepgramWs: null,
    isProcessing: false,
    currentUtterance: "",
    silenceTimer: null,
    markCounter: 0,
    isSpeaking: false,
    pendingAudio: [],
    userId: "",
  };

  log(callLogId, "WebSocket connected");

  // Load call configuration from DB
  const callLog = await storage.getVoiceCallById(callLogId);
  if (!callLog) {
    log(callLogId, "Call log not found, closing");
    twilioWs.close();
    return;
  }

  session.userId = callLog.userId;

  try {
    const scriptData = callLog.script ? JSON.parse(callLog.script) : {};
    session.greeting = scriptData.greeting || "Hello, this is an AI assistant. How can I help you?";
    session.systemPrompt = scriptData.systemPrompt || "You are a professional AI phone agent. Be helpful and concise.";
  } catch {
    session.greeting = "Hello, this is an AI assistant. How can I help you?";
    session.systemPrompt = "You are a professional AI phone agent. Be helpful and concise.";
  }

  // ── Handle incoming Twilio messages ──

  twilioWs.on("message", async (data: Buffer) => {
    try {
      const msg: TwilioMediaMessage = JSON.parse(data.toString());

      switch (msg.event) {
        case "connected":
          log(callLogId, "Twilio stream connected");
          break;

        case "start":
          session.streamSid = msg.start!.streamSid;
          session.callSid = msg.start!.callSid;
          log(callLogId, `Stream started: ${session.streamSid}`);

          // Update call log status
          await storage.updateVoiceCall(callLogId, { status: "in-progress" });

          // Connect Deepgram STT
          try {
            session.deepgramWs = createDeepgramSTT(
              session,
              // onTranscript
              (text: string, isFinal: boolean) => {
                if (isFinal) {
                  log(callLogId, `[Caller] ${text}`);
                  session.currentUtterance = "";

                  // Clear any existing silence timer
                  if (session.silenceTimer) clearTimeout(session.silenceTimer);

                  // If AI is speaking, interrupt it
                  if (session.isSpeaking) {
                    clearTwilioAudio(twilioWs, session);
                  }

                  // Debounce: wait 500ms of silence before responding
                  // This handles cases where Deepgram splits a sentence into multiple finals
                  session.silenceTimer = setTimeout(async () => {
                    if (session.isProcessing) return;
                    session.isProcessing = true;

                    try {
                      session.isSpeaking = true;
                      await getAIResponse(
                        session,
                        text,
                        // onSentence — send each sentence as TTS immediately
                        async (sentence: string) => {
                          try {
                            log(callLogId, `[AI] ${sentence}`);
                            const audio = await textToMulawAudio(sentence);
                            sendAudioToTwilio(twilioWs, session, audio);
                          } catch (ttsErr) {
                            log(callLogId, `TTS error: ${(ttsErr as Error).message}`);
                          }
                        },
                        // onComplete
                        async (fullText: string) => {
                          // Save transcript to DB
                          try {
                            await storage.updateVoiceCall(callLogId, {
                              transcript: JSON.stringify(session.transcript),
                            });
                          } catch {}

                          // Check for goodbye
                          const lower = fullText.toLowerCase();
                          if (lower.includes("goodbye") || lower.includes("have a great day") || session.transcript.length > 40) {
                            // Send a final mark, then hang up after it plays
                            session.markCounter++;
                            twilioWs.send(JSON.stringify({
                              event: "mark",
                              streamSid: session.streamSid,
                              mark: { name: "goodbye" },
                            }));
                          }

                          session.isProcessing = false;
                        },
                      );
                    } catch (aiErr) {
                      log(callLogId, `AI error: ${(aiErr as Error).message}`);
                      session.isProcessing = false;
                      session.isSpeaking = false;

                      // Speak error message
                      try {
                        const errAudio = await textToMulawAudio("I apologize, I'm having a brief technical issue. Could you repeat that?");
                        sendAudioToTwilio(twilioWs, session, errAudio);
                      } catch {}
                    }
                  }, 500);
                } else {
                  // Interim result — accumulate
                  session.currentUtterance = text;
                }
              },
              // onError
              (err: Error) => {
                log(callLogId, `STT error: ${err.message}`);
              },
            );
          } catch (dgErr) {
            log(callLogId, `Failed to connect Deepgram: ${(dgErr as Error).message}`);
            // Speak error and hang up
            try {
              const errAudio = await textToMulawAudio("I apologize, the voice system is not available right now. A team member will follow up with you. Goodbye.");
              sendAudioToTwilio(twilioWs, session, errAudio);
            } catch {}
          }

          // Speak the greeting immediately
          try {
            session.transcript.push({ role: "agent", text: session.greeting });
            session.conversationHistory.push({ role: "assistant", content: session.greeting });
            const greetingAudio = await textToMulawAudio(session.greeting);
            sendAudioToTwilio(twilioWs, session, greetingAudio);
            session.isSpeaking = true;
            log(callLogId, `[AI Greeting] ${session.greeting}`);
          } catch (ttsErr) {
            log(callLogId, `Greeting TTS error: ${(ttsErr as Error).message}`);
          }
          break;

        case "media":
          // Forward audio to Deepgram STT
          if (session.deepgramWs && session.deepgramWs.readyState === WebSocket.OPEN && msg.media?.payload) {
            const pcmAudio = mulawToLinear16(msg.media.payload);
            session.deepgramWs.send(pcmAudio);
          }
          break;

        case "mark":
          // Audio finished playing
          if (msg.mark?.name === "goodbye") {
            log(callLogId, "Goodbye mark received, ending call");
            // Close connections
            session.deepgramWs?.close();
            twilioWs.close();
          } else {
            // Last speech mark played — AI finished speaking this chunk
            const markNum = parseInt(msg.mark?.name?.replace("speech_", "") || "0");
            if (markNum >= session.markCounter) {
              session.isSpeaking = false;
            }
          }
          break;

        case "stop":
          log(callLogId, "Stream stopped by Twilio");
          cleanup();
          break;
      }
    } catch (err) {
      log(callLogId, `Message handling error: ${(err as Error).message}`);
    }
  });

  // ── Cleanup ──

  function cleanup() {
    if (session.silenceTimer) clearTimeout(session.silenceTimer);

    if (session.deepgramWs && session.deepgramWs.readyState === WebSocket.OPEN) {
      // Send close frame to Deepgram
      session.deepgramWs.send(JSON.stringify({ type: "CloseStream" }));
      session.deepgramWs.close();
    }

    // Save final transcript
    if (session.transcript.length > 0) {
      storage.updateVoiceCall(callLogId, {
        transcript: JSON.stringify(session.transcript),
        status: "completed",
      }).catch(() => {});
    }

    log(callLogId, `Call ended. ${session.transcript.length} transcript entries.`);
  }

  twilioWs.on("close", () => {
    log(callLogId, "Twilio WebSocket closed");
    cleanup();
  });

  twilioWs.on("error", (err) => {
    log(callLogId, `Twilio WebSocket error: ${err.message}`);
    cleanup();
  });
}

// ── Attach WebSocket Server to Express/HTTP Server ──

export function attachVoiceStreamWSS(httpServer: HttpServer, storage: any) {
  const wss = new WebSocketServer({
    server: httpServer,
    path: undefined, // We'll handle path matching manually
  });

  // Actually, WebSocketServer with noServer is better for path matching
  wss.close(); // Close the auto-attached one

  const voiceWss = new WebSocketServer({ noServer: true });

  httpServer.on("upgrade", (request: IncomingMessage, socket, head) => {
    const url = request.url || "";

    // Match /api/voice/stream/:callLogId
    const match = url.match(/^\/api\/voice\/stream\/([a-zA-Z0-9_-]+)/);
    if (match) {
      const callLogId = match[1];
      voiceWss.handleUpgrade(request, socket, head, (ws) => {
        handleVoiceStream(ws, callLogId, storage);
      });
    }
    // Don't handle other upgrade requests — let Vite HMR etc. work
  });

  console.log("[VoiceStream] WebSocket server attached for /api/voice/stream/:callLogId");
  return voiceWss;
}

export { handleVoiceStream };
