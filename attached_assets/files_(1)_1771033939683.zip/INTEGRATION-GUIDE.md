# ARGILETTE Workflow Automation Engine — Integration Guide

## What You're Getting

4 production-ready TypeScript files that add a **complete n8n-style workflow automation engine** to your existing ArgiFlow platform:

| File | Size | Purpose |
|------|------|---------|
| `shared/workflow-schema.ts` | ~350 lines | 5 new DB tables + types + 6 pre-built templates |
| `server/workflow-engine.ts` | ~550 lines | Event bus, execution engine, delay processor |
| `server/workflow-routes.ts` | ~450 lines | 20+ API endpoints for CRUD, execution, analytics |
| `server/workflow-hooks.ts` | ~300 lines | 13 event hooks + exact integration instructions |

**Total: ~1,650 lines of production code**

---

## 5-Minute Integration

### Step 1: Copy Files

```
cp shared/workflow-schema.ts  → your-project/shared/workflow-schema.ts
cp server/workflow-engine.ts  → your-project/server/workflow-engine.ts
cp server/workflow-routes.ts  → your-project/server/workflow-routes.ts
cp server/workflow-hooks.ts   → your-project/server/workflow-hooks.ts
```

### Step 2: Export Schema

In `shared/schema.ts`, add at the bottom:

```typescript
export * from "./workflow-schema";
```

### Step 3: Create Tables

```bash
npm run db:push
```

This creates 5 new tables:
- `workflows` — Master workflow definitions
- `workflow_nodes` — Individual steps (trigger, condition, action, delay)
- `workflow_edges` — Connections between nodes
- `workflow_executions` — Execution history
- `workflow_execution_steps` — Step-by-step logs

### Step 4: Register Routes + Start Engine

In `server/routes.ts` (or wherever `registerRoutes` is), add these imports at the top:

```typescript
import { registerWorkflowRoutes } from "./workflow-routes";
import { startWorkflowEngine } from "./workflow-engine";
import { workflowHooks } from "./workflow-hooks";
```

Then at the **end** of `registerRoutes()`, before `return httpServer;`:

```typescript
// ---- WORKFLOW ENGINE ----
registerWorkflowRoutes(app);
startWorkflowEngine();
```

### Step 5: Wire Event Hooks

Add these one-liners to your existing route handlers (see `workflow-hooks.ts` for exact locations):

**Lead Created** — in `POST /api/leads`:
```typescript
const lead = await storage.createLead(parsed.data);
workflowHooks.onLeadCreated(userId, lead);  // ← ADD THIS
```

**Appointment Booked** — in `POST /api/appointments`:
```typescript
const appt = await storage.createAppointment({...});
workflowHooks.onAppointmentBooked(userId, appt);  // ← ADD THIS
```

**Email Opened** — in `GET /t/o/:leadId`:
```typescript
await storage.updateLead(lead.id, statusUpdate);
workflowHooks.onLeadEmailOpened(lead.userId, {...lead, emailOpens: newOpens});  // ← ADD THIS
```

**Email Clicked** — in `GET /t/c/:leadId`:
```typescript
await storage.updateLead(lead.id, statusUpdate);
workflowHooks.onLeadEmailClicked(lead.userId, {...lead, emailClicks: newClicks});  // ← ADD THIS
```

**User Registered** — in `POST /api/auth/register`:
```typescript
const user = await storage.createUser({...});
workflowHooks.onUserRegistered(user.id, user);  // ← ADD THIS
```

See `workflow-hooks.ts` for all 13 hook points with exact code.

---

## New API Endpoints

After integration, you get these new routes:

### Workflow CRUD
| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/workflows` | List user's workflows |
| `GET` | `/api/workflows/:id` | Get workflow with nodes + edges |
| `POST` | `/api/workflows` | Create new workflow |
| `PATCH` | `/api/workflows/:id` | Update workflow (name, status, etc.) |
| `DELETE` | `/api/workflows/:id` | Delete workflow + all data |

### Nodes & Edges
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/workflows/:id/nodes` | Add node to workflow |
| `PATCH` | `/api/workflow-nodes/:id` | Update node (config, position) |
| `DELETE` | `/api/workflow-nodes/:id` | Delete node + connected edges |
| `PUT` | `/api/workflows/:id/nodes/bulk` | Bulk update positions (drag-drop) |
| `POST` | `/api/workflows/:id/edges` | Add connection between nodes |
| `DELETE` | `/api/workflow-edges/:id` | Remove connection |

### Execution
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/workflows/:id/execute` | Manually trigger workflow |
| `GET` | `/api/workflows/:id/executions` | Get execution history |
| `GET` | `/api/workflow-executions` | All executions (all workflows) |
| `GET` | `/api/workflow-executions/:id` | Execution detail + step logs |
| `POST` | `/api/workflow-executions/:id/cancel` | Cancel running/waiting execution |

### Templates & Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/workflow-templates` | List pre-built templates |
| `POST` | `/api/workflow-templates/:key/create` | Create workflow from template |
| `GET` | `/api/workflow-analytics` | Dashboard stats |
| `GET` | `/api/workflow-config` | Available trigger/action types |
| `GET` | `/api/workflow-events` | Recent event log |
| `POST` | `/api/workflow-events/emit` | Manually emit event (testing) |

---

## Pre-Built Templates

6 templates ready to activate:

1. **Lead Capture → Nurture Sequence** — New lead → AI score → hot/warm/cold routing → outreach
2. **Email Engagement → Escalation** — Click detected → upgrade to hot → notify team → SMS follow-up
3. **Appointment Booked → Onboarding** — Booking → confirmation email + SMS → create task → qualify lead
4. **Deal Won → Invoice & Project** — Deal won → welcome email → project setup → notify team → log revenue
5. **AI Content Pipeline** — Scheduled → AI blog post → social posts → newsletter → ready notification
6. **Service Complete → Review Request** — Appointment done → wait 24h → request review → SMS nudge

---

## How It Works (Architecture)

```
┌─────────────────────────────────────────────────────┐
│                   YOUR EXISTING CODE                 │
│                                                      │
│  POST /api/leads ──► workflowHooks.onLeadCreated()  │
│  GET /t/o/:id    ──► workflowHooks.onEmailOpened()   │
│  POST /api/appts ──► workflowHooks.onApptBooked()    │
│  ... (13 hook points total)                          │
└──────────────────────┬──────────────────────────────┘
                       │ events
                       ▼
┌──────────────────────────────────────────────────────┐
│               WORKFLOW EVENT BUS                      │
│                                                       │
│  Receives events → matches against active workflows   │
│  Checks trigger configs (status, score, source, etc.) │
└──────────────────────┬───────────────────────────────┘
                       │ matched workflows
                       ▼
┌──────────────────────────────────────────────────────┐
│             WORKFLOW EXECUTION ENGINE                  │
│                                                       │
│  Loads nodes + edges → follows the flow graph         │
│  Executes each node in sequence                       │
│  Handles branching (conditions, A/B splits)           │
│  Handles delays (pauses + resumes via background job) │
│  Handles parallel paths (fan-out)                     │
│  Logs every step to workflow_execution_steps           │
└──────────────────────┬───────────────────────────────┘
                       │ executes actions using
                       ▼
┌──────────────────────────────────────────────────────┐
│             YOUR EXISTING INFRASTRUCTURE              │
│                                                       │
│  storage.createLead()      → PostgreSQL               │
│  storage.updateLead()      → PostgreSQL               │
│  storage.createAppointment → PostgreSQL               │
│  sendSMS()                 → Twilio                   │
│  nodemailer / sgMail       → Email                    │
│  Claude AI                 → Content gen / scoring    │
│  storage.createNotification → In-app notifications    │
└──────────────────────────────────────────────────────┘
```

---

## Supported Actions (30+)

### AI Actions
- `ai_classify` — Classify text into categories using Claude
- `ai_score_lead` — Score a lead 0-100 based on intent signals
- `ai_generate_content` — Generate emails, blog posts, social content
- `ai_summarize` — Summarize text
- `ai_extract` — Extract structured data from text

### CRM Actions
- `create_lead` — Add lead to CRM
- `update_lead` — Change lead status, score, notes
- `create_appointment` — Schedule appointment
- `move_deal` — Move deal to different funnel stage
- `create_funnel_deal` — Add deal to funnel

### Communication
- `send_email` — Send via SMTP or SendGrid (uses your existing config)
- `send_sms` — Send via Twilio
- `make_voice_call` — Queue a voice call
- `send_notification` — In-app notification

### Flow Control
- `condition_if` — If/then branching
- `condition_switch` — Multi-branch routing
- `delay_wait` — Wait X hours
- `delay_wait_until` — Wait until specific date
- `splitter_ab` — A/B test split

### Integrations
- `call_webhook` — POST to external URL
- `run_agent` — Trigger an agent from the catalog
- `trigger_workflow` — Chain workflows together
- `log_to_crm` — Log activity
- `create_task` — Create a project task

---

## No New Dependencies Required

The workflow engine uses ONLY what's already in your `package.json`:
- `drizzle-orm` + `pg` — Database
- `@anthropic-ai/sdk` — AI actions
- `@sendgrid/mail` + `nodemailer` — Email
- `twilio` — SMS
- `zod` — Validation
- `express` — Routes

**Zero new packages to install.**

---

## Testing After Integration

1. **Create from template:**
```bash
curl -X POST http://localhost:5000/api/workflow-templates/lead-capture-nurture/create \
  -H "Content-Type: application/json" \
  -H "Cookie: connect.sid=YOUR_SESSION" \
  -d '{"name": "My Lead Nurture Flow"}'
```

2. **Activate the workflow:**
```bash
curl -X PATCH http://localhost:5000/api/workflows/WORKFLOW_ID \
  -H "Content-Type: application/json" \
  -H "Cookie: connect.sid=YOUR_SESSION" \
  -d '{"status": "active"}'
```

3. **Create a lead (triggers the workflow):**
```bash
curl -X POST http://localhost:5000/api/leads \
  -H "Content-Type: application/json" \
  -H "Cookie: connect.sid=YOUR_SESSION" \
  -d '{"name": "Test Lead", "email": "test@example.com", "source": "API Test", "status": "new"}'
```

4. **Check execution:**
```bash
curl http://localhost:5000/api/workflow-executions \
  -H "Cookie: connect.sid=YOUR_SESSION"
```

---

## What's Next

After the engine is working, the next build is the **Visual Workflow Builder** — a React drag-and-drop UI that lets users:
- Pick from the node palette (triggers, actions, conditions)
- Drag nodes onto a canvas
- Connect them with edges
- Configure each node's settings
- Preview the flow
- Activate with one click

This uses your existing React + shadcn/ui + Framer Motion stack.
