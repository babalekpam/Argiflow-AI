// ArgiFlow - Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navItems = document.querySelectorAll('.nav-item[data-page]');
    const pages = document.querySelectorAll('.page');

    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetPage = this.getAttribute('data-page');
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Show target page
            pages.forEach(page => {
                page.classList.remove('active');
                if (page.id === `page-${targetPage}`) {
                    page.classList.add('active');
                }
            });
            
            // Update page title
            updatePageTitle(targetPage);
        });
    });

    function updatePageTitle(page) {
        const titles = {
            'overview': 'Dashboard Overview',
            'leads': 'Leads & CRM',
            'appointments': 'Appointments',
            'funnels': 'Funnels',
            'automation': 'Email & SMS Automation',
            'workflows': 'Workflows',
            'ads': 'Ad Templates',
            'training': 'Training & Resources',
            'analytics': 'Analytics',
            'settings': 'Settings'
        };
        document.title = `${titles[page] || 'Dashboard'} - ArgiFlow`;
    }

    // Chart.js-like simple charts
    createAppointmentsChart();
    createSourcesChart();

    function createAppointmentsChart() {
        const canvas = document.getElementById('appointmentsChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const data = [45, 52, 48, 65, 72, 85, 78];
        const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        
        // Set canvas size
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        
        const width = canvas.width;
        const height = canvas.height;
        const padding = 40;
        const chartWidth = width - padding * 2;
        const chartHeight = height - padding * 2;
        
        const maxValue = Math.max(...data);
        const barWidth = chartWidth / data.length * 0.6;
        const barSpacing = chartWidth / data.length;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw bars
        data.forEach((value, index) => {
            const barHeight = (value / maxValue) * chartHeight;
            const x = padding + index * barSpacing + (barSpacing - barWidth) / 2;
            const y = height - padding - barHeight;
            
            // Create gradient
            const gradient = ctx.createLinearGradient(0, y, 0, height - padding);
            gradient.addColorStop(0, '#6366f1');
            gradient.addColorStop(1, 'rgba(99, 102, 241, 0.2)');
            
            ctx.fillStyle = gradient;
            ctx.fillRect(x, y, barWidth, barHeight);
            
            // Draw label
            ctx.fillStyle = '#a1a1aa';
            ctx.font = '12px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(labels[index], x + barWidth / 2, height - padding + 20);
            
            // Draw value
            ctx.fillStyle = '#ffffff';
            ctx.fillText(value, x + barWidth / 2, y - 8);
        });
        
        // Draw grid lines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 5; i++) {
            const y = padding + (chartHeight / 5) * i;
            ctx.beginPath();
            ctx.moveTo(padding, y);
            ctx.lineTo(width - padding, y);
            ctx.stroke();
        }
    }

    function createSourcesChart() {
        const canvas = document.getElementById('sourcesChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const data = [
            { label: 'Facebook', value: 45, color: '#3b82f6' },
            { label: 'Google', value: 25, color: '#ef4444' },
            { label: 'Organic', value: 20, color: '#10b981' },
            { label: 'Referral', value: 10, color: '#8b5cf6' }
        ];
        
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        
        const width = canvas.width;
        const height = canvas.height;
        const centerX = width / 2;
        const centerY = height / 2 - 20;
        const radius = Math.min(width, height) / 3;
        
        let currentAngle = -Math.PI / 2;
        const total = data.reduce((sum, item) => sum + item.value, 0);
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw pie slices
        data.forEach(item => {
            const sliceAngle = (item.value / total) * 2 * Math.PI;
            
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
            ctx.closePath();
            ctx.fillStyle = item.color;
            ctx.fill();
            
            currentAngle += sliceAngle;
        });
        
        // Draw center hole (donut chart)
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius * 0.5, 0, 2 * Math.PI);
        ctx.fillStyle = '#1e1e3f';
        ctx.fill();
        
        // Draw legend
        let legendY = height - 60;
        data.forEach((item, index) => {
            const legendX = 20 + (index % 2) * (width / 2);
            if (index === 2) legendY += 25;
            
            ctx.fillStyle = item.color;
            ctx.fillRect(legendX, legendY, 12, 12);
            
            ctx.fillStyle = '#a1a1aa';
            ctx.font = '12px Inter';
            ctx.textAlign = 'left';
            ctx.fillText(`${item.label} (${item.value}%)`, legendX + 18, legendY + 10);
        });
    }

    // Filter buttons
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Re-render chart with different data (simulated)
            createAppointmentsChart();
        });
    });

    // Training categories
    const categoryBtns = document.querySelectorAll('.category-btn');
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            categoryBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Calendar day selection
    const calendarDays = document.querySelectorAll('.day:not(.other)');
    calendarDays.forEach(day => {
        day.addEventListener('click', function() {
            calendarDays.forEach(d => d.classList.remove('today'));
            this.classList.add('today');
        });
    });

    // View switcher
    const viewButtons = document.querySelectorAll('.view-switcher button');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            viewButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Pipeline stage selection
    const stageItems = document.querySelectorAll('.stage-item');
    stageItems.forEach(item => {
        item.addEventListener('click', function() {
            stageItems.forEach(s => s.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Checkbox selection
    const selectAllCheckbox = document.querySelector('.table-header .checkbox input');
    const rowCheckboxes = document.querySelectorAll('.lead-row .checkbox input');
    
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            rowCheckboxes.forEach(cb => {
                cb.checked = this.checked;
            });
        });
    }

    // Lead row actions
    const actionBtns = document.querySelectorAll('.action-btn');
    actionBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            // Show toast notification
            showToast('Action performed successfully', 'success');
        });
    });

    // Toast notification function
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        toast.style.cssText = `
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#6366f1'};
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Add toast animations
    const toastStyles = document.createElement('style');
    toastStyles.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(toastStyles);

    // Button click handlers
    document.querySelectorAll('.btn-primary, .btn-secondary, .btn-outline').forEach(btn => {
        if (!btn.getAttribute('href') || btn.getAttribute('href') === '#') {
            btn.addEventListener('click', function(e) {
                if (this.getAttribute('href') === '#') {
                    e.preventDefault();
                    const text = this.textContent.trim();
                    if (text && !text.includes('Get Started') && !text.includes('Contact')) {
                        showToast(`${text} - Coming soon!`, 'info');
                    }
                }
            });
        }
    });

    // Real-time updates simulation
    setInterval(() => {
        // Randomly update a stat value
        const statValues = document.querySelectorAll('.stat-value');
        if (statValues.length > 0) {
            const randomStat = statValues[Math.floor(Math.random() * statValues.length)];
            const currentValue = parseInt(randomStat.textContent);
            if (!isNaN(currentValue)) {
                const change = Math.random() > 0.5 ? 1 : -1;
                randomStat.textContent = currentValue + change;
            }
        }
    }, 30000); // Update every 30 seconds

    // Responsive sidebar toggle
    const mobileToggle = document.createElement('button');
    mobileToggle.className = 'mobile-sidebar-toggle';
    mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
    mobileToggle.style.cssText = `
        display: none;
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: var(--primary);
        color: white;
        border: none;
        box-shadow: 0 4px 20px rgba(99, 102, 241, 0.4);
        cursor: pointer;
        z-index: 1000;
        font-size: 20px;
    `;
    
    mobileToggle.addEventListener('click', () => {
        document.querySelector('.sidebar').classList.toggle('mobile-open');
    });
    
    document.body.appendChild(mobileToggle);

    // Add mobile sidebar styles
    const mobileStyles = document.createElement('style');
    mobileStyles.textContent = `
        @media (max-width: 768px) {
            .mobile-sidebar-toggle {
                display: flex !important;
                align-items: center;
                justify-content: center;
            }
            
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.mobile-open {
                transform: translateX(0);
            }
        }
    `;
    document.head.appendChild(mobileStyles);

    console.log('🚀 ArgiFlow Dashboard loaded successfully!');
});
