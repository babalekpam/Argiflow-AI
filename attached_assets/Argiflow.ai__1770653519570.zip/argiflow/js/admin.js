// ArgiFlow - Super Admin Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navItems = document.querySelectorAll('.nav-item[data-page]');
    const pages = document.querySelectorAll('.page');

    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetPage = this.getAttribute('data-page');
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Show target page
            pages.forEach(page => {
                page.classList.remove('active');
                if (page.id === `page-${targetPage}`) {
                    page.classList.add('active');
                }
            });
            
            // Update page title
            updatePageTitle(targetPage);
        });
    });

    function updatePageTitle(page) {
        const titles = {
            'overview': 'Platform Overview',
            'clients': 'All Clients',
            'subscriptions': 'Subscriptions & Billing',
            'funnels': 'Global Funnels',
            'templates': 'Templates',
            'training': 'Training Content',
            'support': 'Support Tickets',
            'analytics': 'Platform Analytics',
            'logs': 'Activity Logs',
            'settings': 'Platform Settings',
            'admins': 'Admin Users'
        };
        document.title = `${titles[page] || 'Dashboard'} - ArgiFlow Super Admin`;
    }

    // MRR Growth Chart
    createMRRChart();
    
    // Plan Distribution Chart
    createPlanChart();

    function createMRRChart() {
        const canvas = document.getElementById('mrrChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const data = [85, 92, 98, 105, 112, 128.4];
        const labels = ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb'];
        
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        
        const width = canvas.width;
        const height = canvas.height;
        const padding = 40;
        const chartWidth = width - padding * 2;
        const chartHeight = height - padding * 2;
        
        const maxValue = Math.max(...data);
        const stepX = chartWidth / (data.length - 1);
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw gradient area
        ctx.beginPath();
        ctx.moveTo(padding, height - padding);
        
        data.forEach((value, index) => {
            const x = padding + index * stepX;
            const y = height - padding - (value / maxValue) * chartHeight;
            
            if (index === 0) {
                ctx.lineTo(x, y);
            } else {
                // Smooth curve
                const prevX = padding + (index - 1) * stepX;
                const prevY = height - padding - (data[index - 1] / maxValue) * chartHeight;
                const cpX = (prevX + x) / 2;
                ctx.bezierCurveTo(cpX, prevY, cpX, y, x, y);
            }
        });
        
        ctx.lineTo(padding + (data.length - 1) * stepX, height - padding);
        ctx.closePath();
        
        const gradient = ctx.createLinearGradient(0, padding, 0, height - padding);
        gradient.addColorStop(0, 'rgba(99, 102, 241, 0.3)');
        gradient.addColorStop(1, 'rgba(99, 102, 241, 0)');
        ctx.fillStyle = gradient;
        ctx.fill();
        
        // Draw line
        ctx.beginPath();
        data.forEach((value, index) => {
            const x = padding + index * stepX;
            const y = height - padding - (value / maxValue) * chartHeight;
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                const prevX = padding + (index - 1) * stepX;
                const prevY = height - padding - (data[index - 1] / maxValue) * chartHeight;
                const cpX = (prevX + x) / 2;
                ctx.bezierCurveTo(cpX, prevY, cpX, y, x, y);
            }
        });
        
        ctx.strokeStyle = '#6366f1';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Draw points
        data.forEach((value, index) => {
            const x = padding + index * stepX;
            const y = height - padding - (value / maxValue) * chartHeight;
            
            ctx.beginPath();
            ctx.arc(x, y, 6, 0, Math.PI * 2);
            ctx.fillStyle = '#6366f1';
            ctx.fill();
            
            ctx.beginPath();
            ctx.arc(x, y, 10, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(99, 102, 241, 0.2)';
            ctx.fill();
            
            // Draw value label
            ctx.fillStyle = '#ffffff';
            ctx.font = '12px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(`$${value}K`, x, y - 15);
            
            // Draw month label
            ctx.fillStyle = '#a1a1aa';
            ctx.fillText(labels[index], x, height - padding + 20);
        });
    }

    function createPlanChart() {
        const canvas = document.getElementById('planChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const data = [
            { label: 'Starter', value: 130, color: '#06b6d4' },
            { label: 'Professional', value: 300, color: '#6366f1' },
            { label: 'Enterprise', value: 57, color: '#f59e0b' }
        ];
        
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        
        const width = canvas.width;
        const height = canvas.height;
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) / 3;
        
        let currentAngle = -Math.PI / 2;
        const total = data.reduce((sum, item) => sum + item.value, 0);
        
        ctx.clearRect(0, 0, width, height);
        
        // Draw donut slices
        data.forEach(item => {
            const sliceAngle = (item.value / total) * 2 * Math.PI;
            
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
            ctx.closePath();
            ctx.fillStyle = item.color;
            ctx.fill();
            
            currentAngle += sliceAngle;
        });
        
        // Draw center hole
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius * 0.6, 0, 2 * Math.PI);
        ctx.fillStyle = '#1e1e3f';
        ctx.fill();
        
        // Draw center text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 24px Inter';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(total.toString(), centerX, centerY - 10);
        
        ctx.fillStyle = '#a1a1aa';
        ctx.font = '12px Inter';
        ctx.fillText('Clients', centerX, centerY + 15);
    }

    // Filter buttons
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const parent = this.closest('.card-header');
            parent.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Checkbox selection
    const selectAllCheckbox = document.querySelector('.table-header .checkbox input');
    const rowCheckboxes = document.querySelectorAll('.client-row .checkbox input');
    
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            rowCheckboxes.forEach(cb => {
                cb.checked = this.checked;
            });
        });
    }

    // Quick action buttons
    document.querySelectorAll('.quick-action-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.querySelector('span').textContent;
            showToast(`${action} - Opening...`, 'info');
        });
    });

    // Row action buttons
    document.querySelectorAll('.action-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const title = this.getAttribute('title');
            if (title === 'View Dashboard' || title === 'Login As') {
                showToast('Opening client dashboard...', 'success');
                setTimeout(() => {
                    window.open('../dashboard.html', '_blank');
                }, 500);
            } else if (title === 'Edit') {
                showToast('Opening client editor...', 'info');
            } else {
                showToast('Action performed', 'success');
            }
        });
    });

    // Pagination
    document.querySelectorAll('.pagination button').forEach(btn => {
        btn.addEventListener('click', function() {
            if (!this.disabled) {
                document.querySelectorAll('.pagination button').forEach(b => b.classList.remove('active'));
                if (!this.querySelector('i')) {
                    this.classList.add('active');
                }
            }
        });
    });

    // Toast notification
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        toast.style.cssText = `
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#6366f1'};
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Add toast animations
    const toastStyles = document.createElement('style');
    toastStyles.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(toastStyles);

    // Real-time counter animation for stats
    function animateCounter(element, target, duration = 2000) {
        let start = 0;
        const increment = target / (duration / 16);
        const prefix = element.textContent.includes('$') ? '$' : '';
        const suffix = element.textContent.includes('K') ? 'K' : '';
        const suffix2 = element.textContent.includes('%') ? '%' : '';
        
        function updateCounter() {
            start += increment;
            if (start < target) {
                element.textContent = prefix + start.toFixed(1) + suffix + suffix2;
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = prefix + target + suffix + suffix2;
            }
        }
        
        updateCounter();
    }

    // Animate stats on page load
    const statValues = document.querySelectorAll('.stat-value');
    statValues.forEach(stat => {
        const text = stat.textContent;
        const numMatch = text.match(/[\d.]+/);
        if (numMatch) {
            const target = parseFloat(numMatch[0]);
            stat.textContent = text.replace(/[\d.]+/, '0');
            setTimeout(() => animateCounter(stat, target), 500);
        }
    });

    // Simulate real-time updates
    setInterval(() => {
        // Randomly update activity feed
        const activities = [
            { icon: 'signup', text: 'New client signed up', sub: 'Agency Pro', time: 'Just now' },
            { icon: 'payment', text: 'Payment received', sub: '$297 from Scale Co', time: 'Just now' },
            { icon: 'funnel', text: 'New funnel created', sub: 'Growth Digital', time: 'Just now' }
        ];
        
        const activityList = document.querySelector('.activity-list');
        if (activityList && Math.random() > 0.7) {
            const randomActivity = activities[Math.floor(Math.random() * activities.length)];
            const newItem = document.createElement('div');
            newItem.className = 'activity-item';
            newItem.style.animation = 'slideIn 0.3s ease';
            newItem.innerHTML = `
                <div class="activity-icon ${randomActivity.icon}">
                    <i class="fas fa-${randomActivity.icon === 'signup' ? 'user-plus' : randomActivity.icon === 'payment' ? 'credit-card' : 'filter'}"></i>
                </div>
                <div class="activity-content">
                    <p><strong>${randomActivity.text}</strong> - ${randomActivity.sub}</p>
                    <span class="activity-time">${randomActivity.time}</span>
                </div>
            `;
            activityList.insertBefore(newItem, activityList.firstChild);
            if (activityList.children.length > 5) {
                activityList.lastChild.remove();
            }
        }
    }, 10000);

    console.log('🚀 ArgiFlow Super Admin Dashboard loaded!');
});
