import React, { useState, useEffect } from 'react';
import { Globe, MapPin, ArrowRight } from 'lucide-react';

const AFRICAN_COUNTRIES = [
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬', currency: 'NGN' },
  { code: 'KE', name: 'Kenya', flag: '🇰🇪', currency: 'KES' },
  { code: 'GH', name: 'Ghana', flag: '🇬🇭', currency: 'GHS' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦', currency: 'ZAR' },
  { code: 'TZ', name: 'Tanzania', flag: '🇹🇿', currency: 'TZS' },
  { code: 'UG', name: 'Uganda', flag: '🇺🇬', currency: 'UGX' },
  { code: 'RW', name: 'Rwanda', flag: '🇷🇼', currency: 'USD' },
  { code: 'ET', name: 'Ethiopia', flag: '🇪🇹', currency: 'USD' },
  { code: 'SN', name: 'Senegal', flag: '🇸🇳', currency: 'XOF' },
  { code: 'CI', name: "Côte d'Ivoire", flag: '🇨🇮', currency: 'XOF' },
  { code: 'CM', name: 'Cameroon', flag: '🇨🇲', currency: 'XAF' },
  { code: 'CD', name: 'DR Congo', flag: '🇨🇩', currency: 'USD' },
  { code: 'EG', name: 'Egypt', flag: '🇪🇬', currency: 'EGP' },
  { code: 'MA', name: 'Morocco', flag: '🇲🇦', currency: 'MAD' },
  { code: 'ZM', name: 'Zambia', flag: '🇿🇲', currency: 'USD' },
  { code: 'ZW', name: 'Zimbabwe', flag: '🇿🇼', currency: 'USD' },
  { code: 'MW', name: 'Malawi', flag: '🇲🇼', currency: 'USD' },
];

const WESTERN_COUNTRIES = [
  { code: 'US', name: 'United States', flag: '🇺🇸', currency: 'USD' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', currency: 'GBP' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', currency: 'CAD' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', currency: 'EUR' },
  { code: 'FR', name: 'France', flag: '🇫🇷', currency: 'EUR' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺', currency: 'AUD' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱', currency: 'EUR' },
  { code: 'AE', name: 'UAE', flag: '🇦🇪', currency: 'USD' },
];

export default function RegionSelect({ onSelect }) {
  const [step, setStep] = useState('region'); // region → country
  const [region, setRegion] = useState(null);
  const [country, setCountry] = useState(null);

  const handleRegionSelect = (r) => {
    setRegion(r);
    setStep('country');
  };

  const handleCountrySelect = (c) => {
    setCountry(c);
    onSelect({
      region: region,
      country: c.code,
      currency: c.currency,
      brand: region === 'africa' ? 'tradeflow' : 'argiflow',
    });
  };

  if (step === 'region') {
    return (
      <div className="space-y-4">
        <div className="text-center mb-6">
          <Globe size={32} className="text-brand-400 mx-auto mb-2" />
          <h2 className="text-lg font-bold text-white">Where are you based?</h2>
          <p className="text-surface-400 text-sm">This helps us show you the right opportunities and pricing</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => handleRegionSelect('africa')}
            className="card-hover text-center py-8 cursor-pointer"
          >
            <span className="text-4xl mb-3 block">🌍</span>
            <h3 className="font-bold text-white text-lg">Africa</h3>
            <p className="text-surface-400 text-xs mt-1">
              Tenders, Trade, Agriculture, Diaspora
            </p>
            <span className="text-xs text-emerald-400 mt-2 block">From $5/month</span>
          </button>

          <button
            onClick={() => handleRegionSelect('western')}
            className="card-hover text-center py-8 cursor-pointer"
          >
            <span className="text-4xl mb-3 block">🌎</span>
            <h3 className="font-bold text-white text-lg">Americas / Europe</h3>
            <p className="text-surface-400 text-xs mt-1">
              Tax Liens, Real Estate, Lead Gen
            </p>
            <span className="text-xs text-brand-400 mt-2 block">From $97/month</span>
          </button>
        </div>

        <p className="text-xs text-surface-600 text-center mt-4">
          African diaspora? Choose Africa to access diaspora-specific investment tools
        </p>
      </div>
    );
  }

  const countries = region === 'africa' ? AFRICAN_COUNTRIES : WESTERN_COUNTRIES;

  return (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <MapPin size={24} className="text-brand-400 mx-auto mb-2" />
        <h2 className="text-lg font-bold text-white">Select your country</h2>
        <button onClick={() => setStep('region')} className="text-sm text-brand-400 hover:underline mt-1">
          ← Change region
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto">
        {countries.map(c => (
          <button
            key={c.code}
            onClick={() => handleCountrySelect(c)}
            className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-surface-900 border border-surface-700 hover:border-brand-500/40 hover:bg-surface-800 transition-colors text-left"
          >
            <span className="text-lg">{c.flag}</span>
            <div>
              <span className="text-sm text-surface-200 block">{c.name}</span>
              <span className="text-xs text-surface-500">{c.currency}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
