import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { getBrand } from '../config/brands';
import { Check, Star, Zap, Shield } from 'lucide-react';
import api from '../api';

export default function PricingPage() {
  const { user } = useAuth();
  const brand = getBrand();
  const [pricing, setPricing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState(false);

  useEffect(() => {
    const region = user?.region || (brand.key === 'tradeflow' ? 'africa' : 'western');
    api.get(`/regions/pricing/${region}`, {
      params: { currency: user?.currency || 'USD' }
    })
      .then(res => setPricing(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [user]);

  const handleSubscribe = async (planKey) => {
    setSubscribing(planKey);
    try {
      const res = await api.post('/payments/subscribe', { planKey });
      if (res.data.paymentResult?.paymentLink) {
        window.location.href = res.data.paymentResult.paymentLink;
      } else if (res.data.paymentResult?.authorizationUrl) {
        window.location.href = res.data.paymentResult.authorizationUrl;
      } else {
        // Stripe — would need client-side confirmation
        alert('Subscription created! Refresh to see your plan.');
        window.location.reload();
      }
    } catch (err) {
      alert(err.response?.data?.error || 'Payment failed');
    }
    setSubscribing(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const plans = pricing?.plans || {};
  const planKeys = Object.keys(plans);
  const isAfrica = pricing?.region === 'africa';

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-white">
          {isAfrica ? 'Choose Your Plan' : 'Scale Your Automation'}
        </h1>
        <p className="text-surface-400 mt-2">
          {isAfrica
            ? 'Start with Pay Per Result — zero risk, pay only when you earn'
            : 'Start with Starter and scale as your agents find more deals'}
        </p>
      </div>

      <div className={`grid grid-cols-1 ${planKeys.length <= 3 ? 'md:grid-cols-3' : 'md:grid-cols-2 lg:grid-cols-4'} gap-6`}>
        {planKeys.map((key, i) => {
          const plan = plans[key];
          const isPopular = i === 1; // second plan is usually "recommended"
          const isCurrent = user?.planKey === key;

          return (
            <div
              key={key}
              className={`rounded-2xl border p-6 relative transition-all ${
                isPopular
                  ? 'border-brand-500/50 bg-brand-500/5 shadow-lg shadow-brand-500/10'
                  : 'border-surface-700 bg-surface-800'
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-brand-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                    <Star size={12} /> Most Popular
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                <div className="mt-3">
                  <span className="text-3xl font-bold text-white">{plan.formattedPrice}</span>
                  {plan.interval !== 'none' && (
                    <span className="text-surface-400 text-sm">/{plan.interval}</span>
                  )}
                </div>
                {plan.successFee > 0 && (
                  <p className="text-xs text-amber-400 mt-1">
                    + {plan.successFee}% success fee on deals won
                  </p>
                )}
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features?.map((feature, fi) => (
                  <li key={fi} className="flex items-start gap-2 text-sm">
                    <Check size={16} className={`flex-shrink-0 mt-0.5 ${isPopular ? 'text-brand-400' : 'text-emerald-400'}`} />
                    <span className="text-surface-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleSubscribe(key)}
                disabled={subscribing === key || isCurrent}
                className={`w-full py-2.5 rounded-lg font-medium text-sm transition-colors ${
                  isCurrent
                    ? 'bg-surface-700 text-surface-400 cursor-default'
                    : isPopular
                      ? 'bg-brand-500 hover:bg-brand-400 text-white'
                      : 'bg-surface-700 hover:bg-surface-600 text-surface-200'
                }`}
              >
                {isCurrent ? 'Current Plan' :
                 subscribing === key ? 'Processing...' :
                 plan.localPrice === 0 ? 'Start Free' :
                 'Get Started'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Payment methods */}
      <div className="text-center">
        <p className="text-xs text-surface-500 mb-2">Accepted payment methods</p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          {isAfrica ? (
            <>
              <span className="badge-gray text-xs">M-Pesa</span>
              <span className="badge-gray text-xs">MTN MoMo</span>
              <span className="badge-gray text-xs">Airtel Money</span>
              <span className="badge-gray text-xs">Card</span>
              <span className="badge-gray text-xs">Bank Transfer</span>
              <span className="badge-gray text-xs">USSD</span>
            </>
          ) : (
            <>
              <span className="badge-gray text-xs">Venmo</span>
              <span className="badge-gray text-xs">PayPal</span>
            </>
          )}
        </div>
      </div>

      {/* Trust signals */}
      <div className="grid grid-cols-3 gap-4 text-center">
        <div className="card py-4">
          <Shield size={20} className="text-emerald-400 mx-auto mb-2" />
          <p className="text-xs text-surface-400">Secure Payments</p>
        </div>
        <div className="card py-4">
          <Zap size={20} className="text-brand-400 mx-auto mb-2" />
          <p className="text-xs text-surface-400">Cancel Anytime</p>
        </div>
        <div className="card py-4">
          <Star size={20} className="text-amber-400 mx-auto mb-2" />
          <p className="text-xs text-surface-400">7-Day Free Trial</p>
        </div>
      </div>
    </div>
  );
}
