/**
 * ArgiFlow / TradeFlow — Dual Brand Configuration
 * Frontend uses this to switch themes, copy, and features based on region
 */

export const BRANDS = {
  argiflow: {
    name: 'ArgiFlow',
    tagline: 'AI Agents That Make You Money While You Sleep',
    logo: '⚡',
    domain: 'argiflow.co',

    // Colors (Tailwind classes)
    theme: {
      primary: 'brand',
      accent: 'blue',
      gradient: 'from-brand-500 to-brand-700',
      bgGradient: 'from-surface-950 via-surface-900 to-surface-950',
    },

    // Navigation labels
    nav: {
      dashboard: 'Command Center',
      agents: 'AI Agents',
      leads: 'Leads',
      pipeline: 'Pipeline',
      notifications: 'Notifications',
    },

    // Plan labels
    planLabels: {
      starter: 'Starter',
      pro: 'Pro',
      enterprise: 'Enterprise',
    },

    // Feature labels
    features: {
      showWhatsApp: false,
      showMobileMoney: false,
      showSuccessFees: false,
      showDiaspora: false,
      showAfCFTA: false,
      paymentMethods: ['Venmo', 'PayPal'],
    },

    // Copy
    copy: {
      heroTitle: 'AI Agents Working 24/7 So You Don\'t Have To',
      heroSubtitle: 'Autonomous AI agents that find deals, analyze opportunities, and execute — while you sleep.',
      ctaButton: 'Start Free Trial',
      agentsTitle: 'Your AI Agent Army',
      leadsEmpty: 'Your agents will discover opportunities automatically',
    },
  },

  tradeflow: {
    name: 'TradeFlow',
    tagline: 'AI-Powered Business Automation for African Entrepreneurs',
    logo: '🌍',
    domain: 'tradeflow.africa',

    theme: {
      primary: 'emerald',
      accent: 'amber',
      gradient: 'from-emerald-500 to-teal-600',
      bgGradient: 'from-surface-950 via-emerald-950/10 to-surface-950',
    },

    nav: {
      dashboard: 'Dashboard',
      agents: 'AI Agents',
      leads: 'Opportunities',
      pipeline: 'Deal Flow',
      notifications: 'Alerts',
    },

    planLabels: {
      hustle: 'Hustle',
      business: 'Business',
      mogul: 'Mogul',
      payPerResult: 'Pay Per Result',
    },

    features: {
      showWhatsApp: true,
      showMobileMoney: true,
      showSuccessFees: true,
      showDiaspora: true,
      showAfCFTA: true,
      paymentMethods: ['Mobile Money', 'Card', 'Bank Transfer', 'USSD'],
    },

    copy: {
      heroTitle: 'Your AI Business Partner — From Tenders to Trade',
      heroSubtitle: 'Find government tenders, cross-border trade deals, and investment opportunities — all automated by AI.',
      ctaButton: 'Start for Free',
      agentsTitle: 'Your AI Agents',
      leadsEmpty: 'Your agents will find opportunities across Africa',
    },
  },
};

// Agent display metadata per brand
export const AGENT_META = {
  // Western agents
  'tax-lien': { color: 'from-emerald-500 to-teal-600', emoji: '🏛️', category: 'Real Estate', brand: 'argiflow' },
  'tax-deed': { color: 'from-blue-500 to-indigo-600', emoji: '🏠', category: 'Real Estate', brand: 'argiflow' },
  'wholesale-re': { color: 'from-purple-500 to-violet-600', emoji: '🔑', category: 'Real Estate', brand: 'argiflow' },
  'govt-contracts-us': { color: 'from-amber-500 to-orange-600', emoji: '📋', category: 'Government', brand: 'argiflow' },
  'arbitrage': { color: 'from-pink-500 to-rose-600', emoji: '📦', category: 'E-Commerce', brand: 'argiflow' },
  'lead-gen': { color: 'from-cyan-500 to-blue-600', emoji: '🎯', category: 'Services', brand: 'argiflow' },

  // African agents
  'govt-tender-africa': { color: 'from-amber-500 to-orange-600', emoji: '📋', category: 'Government', brand: 'tradeflow' },
  'cross-border-trade': { color: 'from-blue-500 to-indigo-600', emoji: '🚢', category: 'Trade', brand: 'tradeflow' },
  'agri-market': { color: 'from-green-500 to-emerald-600', emoji: '🌾', category: 'Agriculture', brand: 'tradeflow' },
  'diaspora-services': { color: 'from-purple-500 to-violet-600', emoji: '🌍', category: 'Diaspora', brand: 'tradeflow' },
  'forex-monitor': { color: 'from-yellow-500 to-amber-600', emoji: '💱', category: 'Finance', brand: 'tradeflow' },
  'solar-energy': { color: 'from-orange-500 to-red-600', emoji: '⚡', category: 'Energy', brand: 'tradeflow' },
  'commodity-trading': { color: 'from-teal-500 to-cyan-600', emoji: '📊', category: 'Trading', brand: 'tradeflow' },
  'skills-freelance': { color: 'from-pink-500 to-rose-600', emoji: '💻', category: 'Skills', brand: 'tradeflow' },
};

/**
 * Detect which brand to use based on hostname or user region
 */
export function detectBrand() {
  const host = window.location.hostname;
  if (host.includes('tradeflow') || host.includes('africa')) return 'tradeflow';

  // Check URL param override (for development)
  const params = new URLSearchParams(window.location.search);
  if (params.get('brand') === 'tradeflow') return 'tradeflow';

  // Check stored user preference
  const stored = localStorage.getItem('argiflow_brand');
  if (stored) return stored;

  return 'argiflow';
}

/**
 * Get the active brand configuration
 */
export function getBrand() {
  const brandKey = detectBrand();
  return { key: brandKey, ...BRANDS[brandKey] };
}
