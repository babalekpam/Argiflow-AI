# ArgiFlow Multi-Region Module
# Integration Guide — Add to Existing Replit Project

## What This Module Adds
- Multi-region support (Western markets + Africa)
- Two-brand system from one codebase
- African-specific AI agents (Government Tenders, Cross-Border Trade, Agri Market, Diaspora)
- Flutterwave/Paystack payment integration for Africa
- M-Pesa, MTN MoMo, Airtel Money support
- Region-based pricing engine
- Dual-brand frontend theming
- Success-fee billing model for African market

## Integration Steps

### 1. Copy Files
Copy these folders/files into your existing Replit project:
```
server/config/regions.js         → NEW (region + pricing config)
server/config/payments.js        → NEW (multi-payment processor)
server/models/User.js            → REPLACE (adds region fields)
server/models/Subscription.js    → NEW (flexible billing)
server/agents/AgentRegistry.js   → REPLACE (adds region filtering)
server/agents/BaseAgent.js       → REPLACE (adds region awareness)
server/agents/govt-tender/       → NEW (Government Tender Agent)
server/agents/cross-border/      → NEW (Cross-Border Trade Agent)
server/agents/agri-market/       → NEW (Agricultural Market Agent)
server/agents/diaspora/          → NEW (Diaspora Services Agent)
server/routes/payments.js        → NEW (payment webhooks)
server/routes/regions.js         → NEW (region API)
client/src/config/brands.js      → NEW (brand theming)
client/src/components/RegionSelect.jsx → NEW
client/src/components/PricingPage.jsx  → NEW
```

### 2. Install New Dependencies
```bash
npm install flutterwave-node-v3 paystack-node @paypal/checkout-server-sdk
```

### 3. Add Environment Variables
```
FLUTTERWAVE_SECRET_KEY=your-key
FLUTTERWAVE_PUBLIC_KEY=your-key
PAYSTACK_SECRET_KEY=your-key
REGION_DETECTION=auto
```

### 4. Add Routes to server/index.js
```javascript
app.use('/api/payments', require('./routes/payments'));
app.use('/api/regions', require('./routes/regions'));
```

### 5. Done
The system auto-detects user region and shows the right brand, agents, and pricing.
