const BaseAgent = require('../BaseAgent');
const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../../config/logger');

class AgriMarketAgent extends BaseAgent {
  get type() { return 'agri-market'; }
  get name() { return 'Farm Scout'; }
  get description() { return 'Monitors agricultural commodity prices, connects farmers with buyers, tracks weather patterns, and optimizes crop timing and market sales.'; }
  get icon() { return '🌾'; }
  get regions() { return ['africa']; }

  get defaultAgentSettings() {
    return {
      country: 'KE',
      region: '', // specific region within country
      userRole: 'farmer', // farmer, buyer, cooperative, trader
      crops: ['maize', 'beans', 'coffee', 'tea', 'rice'],
      livestock: [],
      farmSize: 'small', // small (<5ha), medium (5-50ha), large (>50ha)
      trackWeather: true,
      trackInputPrices: true, // fertilizer, seeds, chemicals
      connectWithBuyers: true,
      connectWithSuppliers: true,
      priceAlertThreshold: 10, // alert when price moves > X%
    };
  }

  get settingsSchema() {
    return [
      {
        key: 'country',
        label: 'Country',
        type: 'select',
        options: [
          { value: 'KE', label: '🇰🇪 Kenya' }, { value: 'NG', label: '🇳🇬 Nigeria' },
          { value: 'TZ', label: '🇹🇿 Tanzania' }, { value: 'UG', label: '🇺🇬 Uganda' },
          { value: 'GH', label: '🇬🇭 Ghana' }, { value: 'ET', label: '🇪🇹 Ethiopia' },
          { value: 'RW', label: '🇷🇼 Rwanda' }, { value: 'ZA', label: '🇿🇦 South Africa' },
          { value: 'CM', label: '🇨🇲 Cameroon' }, { value: 'SN', label: '🇸🇳 Senegal' },
          { value: 'CI', label: '🇨🇮 Côte d\'Ivoire' }, { value: 'MW', label: '🇲🇼 Malawi' },
          { value: 'ZM', label: '🇿🇲 Zambia' },
        ],
      },
      {
        key: 'userRole',
        label: 'Your Role',
        type: 'select',
        options: [
          { value: 'farmer', label: 'Farmer — I grow crops/raise livestock' },
          { value: 'buyer', label: 'Buyer — I buy agricultural products' },
          { value: 'cooperative', label: 'Cooperative — I manage a farming cooperative' },
          { value: 'trader', label: 'Trader — I trade commodities' },
        ],
      },
      {
        key: 'crops',
        label: 'Crops You Grow/Trade',
        type: 'multi-select',
        options: [
          { value: 'maize', label: 'Maize/Corn' }, { value: 'beans', label: 'Beans' },
          { value: 'rice', label: 'Rice' }, { value: 'wheat', label: 'Wheat' },
          { value: 'coffee', label: 'Coffee' }, { value: 'tea', label: 'Tea' },
          { value: 'cocoa', label: 'Cocoa' }, { value: 'cashew', label: 'Cashew' },
          { value: 'sesame', label: 'Sesame' }, { value: 'sorghum', label: 'Sorghum' },
          { value: 'cassava', label: 'Cassava' }, { value: 'yam', label: 'Yam' },
          { value: 'plantain', label: 'Plantain' }, { value: 'palm_oil', label: 'Palm Oil' },
          { value: 'groundnuts', label: 'Groundnuts' }, { value: 'cotton', label: 'Cotton' },
          { value: 'tobacco', label: 'Tobacco' }, { value: 'vanilla', label: 'Vanilla' },
          { value: 'avocado', label: 'Avocado' }, { value: 'macadamia', label: 'Macadamia' },
          { value: 'flowers', label: 'Cut Flowers' },
        ],
      },
      {
        key: 'priceAlertThreshold',
        label: 'Price Alert Threshold (%)',
        type: 'number',
        min: 5,
        max: 50,
        description: 'Alert when market price changes by this percentage',
      },
      {
        key: 'trackWeather',
        label: 'Weather Tracking',
        type: 'toggle',
        description: 'Get weather alerts and planting advisories',
      },
      {
        key: 'connectWithBuyers',
        label: 'Auto-Connect with Buyers',
        type: 'toggle',
        description: 'Agent will find and match you with buyers for your produce',
      },
    ];
  }

  // ===== PHASE 1: DISCOVERY =====
  async discover(config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const leads = [];

    // 1. Crawl agricultural market information systems
    const marketSources = this._getMarketSources(settings.country);
    for (const source of marketSources) {
      try {
        const response = await axios.get(source.url, {
          headers: { 'User-Agent': 'TradeFlow-Agent/1.0' },
          timeout: 30000,
        });
        const $ = cheerio.load(response.data);
        const pageText = $('body').text().substring(0, 10000);

        const prices = await this.askClaudeJSON(`
Extract agricultural commodity prices from this market information page.
Source: ${source.name} (${settings.country})
Content: ${pageText}

For each commodity, extract:
- commodity: name
- variety: specific variety if shown
- market: which market/location
- price: price per unit
- unit: kg, bag, tonne, etc.
- currency: currency code
- priceUSD: approximate USD equivalent
- trend: up, down, or stable (if shown)
- date: price date

Only include commodities in: ${settings.crops.join(', ')}
Return as JSON array.`,
          'Extract agricultural market data accurately. Return only valid JSON arrays.'
        );

        if (Array.isArray(prices)) {
          for (const price of prices) {
            leads.push({
              title: `${price.commodity} Price: ${price.currency} ${price.price}/${price.unit} at ${price.market}`,
              description: `Trend: ${price.trend || 'N/A'} | ~$${price.priceUSD || 'N/A'} USD`,
              source: source.name,
              sourceUrl: source.url,
              externalId: `agri-${settings.country}-${price.commodity}-${price.market}-${new Date().toISOString().split('T')[0]}`.toLowerCase().replace(/\s/g, '-'),
              estimatedValue: price.priceUSD || 0,
              location: { city: price.market, county: settings.country },
              metadata: {
                ...price,
                type: 'market_price',
                country: settings.country,
              },
            });
          }
        }
        await this._delay(2000);
      } catch (err) {
        logger.warn(`[agri-market] Failed crawling ${source.name}:`, err.message);
      }
    }

    // 2. Find buyer/seller opportunities
    if (settings.connectWithBuyers) {
      try {
        const buyerLeads = await this._findBuyerOpportunities(settings);
        leads.push(...buyerLeads);
      } catch (err) {
        logger.warn('[agri-market] Buyer matching error:', err.message);
      }
    }

    // 3. Weather and planting advisories
    if (settings.trackWeather) {
      try {
        const weatherLeads = await this._getWeatherAdvisories(settings);
        leads.push(...weatherLeads);
      } catch (err) {
        logger.warn('[agri-market] Weather check error:', err.message);
      }
    }

    // 4. Input price tracking
    if (settings.trackInputPrices) {
      try {
        const inputLeads = await this._trackInputPrices(settings);
        leads.push(...inputLeads);
      } catch (err) {
        logger.warn('[agri-market] Input price tracking error:', err.message);
      }
    }

    return leads;
  }

  async _findBuyerOpportunities(settings) {
    const buyerPlatforms = [
      { name: 'Twiga Foods', url: 'https://twigafoods.com', country: 'KE' },
      { name: 'Farmcrowdy', url: 'https://www.farmcrowdy.com', country: 'NG' },
      { name: 'AgroMall', url: 'https://www.agromall.com', country: 'NG' },
      { name: 'eProd', url: 'https://eprod.com', country: 'KE' },
    ];

    const leads = [];
    const relevantPlatforms = buyerPlatforms.filter(p => p.country === settings.country || true);

    for (const platform of relevantPlatforms.slice(0, 3)) {
      try {
        const response = await axios.get(platform.url, {
          headers: { 'User-Agent': 'TradeFlow-Agent/1.0' },
          timeout: 15000,
        });
        const $ = cheerio.load(response.data);
        const text = $('body').text().substring(0, 5000);

        const parsed = await this.askClaudeJSON(`
From ${platform.name}, identify any buying opportunities or demand signals for: ${settings.crops.join(', ')}
Content: ${text}
Return JSON array: [{crop, buyerName, quantity, priceOffered, currency, location, deadline}]`, 'Return only valid JSON arrays.');

        if (Array.isArray(parsed)) {
          leads.push(...parsed.map(item => ({
            title: `Buyer: ${item.buyerName} wants ${item.crop}`,
            description: `Qty: ${item.quantity} | Price: ${item.currency} ${item.priceOffered}`,
            source: platform.name,
            externalId: `buyer-${platform.name}-${item.crop}-${Date.now()}`.toLowerCase().replace(/\s/g, '-'),
            metadata: { ...item, type: 'buyer_opportunity', platform: platform.name },
          })));
        }
        await this._delay(1500);
      } catch (err) { /* silent */ }
    }
    return leads;
  }

  async _getWeatherAdvisories(settings) {
    // Use Claude's knowledge for agricultural weather advice
    const advisory = await this.askClaudeJSON(`
For a farmer in ${settings.country}, growing ${settings.crops.join(', ')}:
Current month: ${new Date().toLocaleString('en', { month: 'long' })}

Provide agricultural weather advisory:
{
  "season": "current agricultural season",
  "weatherOutlook": "general weather forecast for this region and time",
  "plantingAdvice": "what should be planted or harvested now",
  "risks": ["weather risks to watch for"],
  "actionItems": ["specific actions to take this week"],
  "marketTiming": "when is the best time to sell current harvest"
}`,
      'You are an agricultural extension officer for African farming. Give practical, actionable advice.'
    );

    return [{
      title: `🌤️ Weekly Farm Advisory — ${settings.country}`,
      description: advisory.weatherOutlook || 'Check advisory details',
      source: 'TradeFlow Weather',
      externalId: `weather-${settings.country}-${new Date().toISOString().split('T')[0]}`,
      metadata: { ...advisory, type: 'weather_advisory' },
    }];
  }

  async _trackInputPrices(settings) {
    const inputAnalysis = await this.askClaudeJSON(`
For farming in ${settings.country}, growing ${settings.crops.join(', ')}:

Provide current agricultural input price intelligence:
[
  { "input": "DAP Fertilizer", "typicalPrice": "USD per 50kg bag", "trend": "up/down/stable", "bestSource": "where to buy cheapest", "tip": "buying advice" },
  { "input": "Urea", "typicalPrice": "...", "trend": "...", "bestSource": "...", "tip": "..." },
  { "input": "Seeds (${settings.crops[0]})", "typicalPrice": "...", "trend": "...", "bestSource": "...", "tip": "..." },
  { "input": "Pesticides", "typicalPrice": "...", "trend": "...", "bestSource": "...", "tip": "..." }
]`,
      'You are an agricultural input price analyst for African markets. Return valid JSON arrays.'
    );

    if (!Array.isArray(inputAnalysis)) return [];

    return inputAnalysis.map(input => ({
      title: `📦 Input Price: ${input.input} — ${input.trend}`,
      description: `~${input.typicalPrice} | Best: ${input.bestSource} | ${input.tip}`,
      source: 'TradeFlow Input Tracker',
      externalId: `input-${settings.country}-${input.input}-${new Date().toISOString().split('T')[0]}`.toLowerCase().replace(/\s/g, '-'),
      metadata: { ...input, type: 'input_price', country: settings.country },
    }));
  }

  // ===== PHASE 2: ANALYSIS =====
  async analyze(lead, config) {
    const meta = lead.metadata || {};

    if (meta.type === 'weather_advisory' || meta.type === 'input_price') {
      return {
        score: 70,
        priority: 'medium',
        aiRecommendation: 'watch',
        estimatedROI: 0,
        aiAnalysis: lead.description,
      };
    }

    const analysis = await this.askClaudeJSON(`
Analyze this agricultural market opportunity:
${JSON.stringify(meta, null, 2)}

Consider local market dynamics, seasonality, storage requirements, and transport costs.

Return JSON: {
  "score": (0-100),
  "priority": ("low","medium","high","critical"),
  "recommendation": ("buy","pass","watch"),
  "estimatedROI": percentage,
  "bestTimeToSell": "when to sell for maximum price",
  "storageAdvice": "should farmer store or sell now",
  "transportCost": "estimated transport to market",
  "riskFactors": ["risks"],
  "analysisNotes": "summary"
}`,
      'You are an African agricultural market analyst.'
    );

    return {
      score: analysis.score || 50,
      priority: analysis.priority || 'medium',
      aiRecommendation: analysis.recommendation || 'watch',
      estimatedROI: analysis.estimatedROI || 0,
      aiAnalysis: analysis.analysisNotes || '',
      metadata: { ...meta, analysis },
    };
  }

  // ===== HELPERS =====
  _getMarketSources(country) {
    const sources = {
      KE: [
        { name: 'KMDP Kenya', url: 'https://amis.co.ke' },
        { name: 'NAFIS', url: 'https://www.nafis.go.ke/market-info/' },
      ],
      NG: [
        { name: 'FMARD Nigeria', url: 'https://fmard.gov.ng' },
        { name: 'AFEX Nigeria', url: 'https://www.afex.africa/market-data' },
      ],
      GH: [
        { name: 'ESOKO Ghana', url: 'https://esoko.com/market-prices/' },
        { name: 'MOFA Ghana', url: 'https://mofa.gov.gh' },
      ],
      TZ: [
        { name: 'EAGC', url: 'https://www.eagc.org/market-information' },
      ],
      UG: [
        { name: 'Farmgain Africa', url: 'https://farmgainafrica.org' },
      ],
      ET: [
        { name: 'ECX Ethiopia', url: 'https://www.ecx.com.et' },
      ],
      ZA: [
        { name: 'SAFEX', url: 'https://www.jse.co.za/trade/commodity-derivatives-market' },
      ],
    };
    return sources[country] || sources.KE; // default to Kenya
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = AgriMarketAgent;
