const BaseAgent = require('../BaseAgent');
const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../../config/logger');

class CrossBorderTradeAgent extends BaseAgent {
  get type() { return 'cross-border-trade'; }
  get name() { return 'Trade Scout'; }
  get description() { return 'Finds cross-border trade opportunities, price arbitrage, and supplier-buyer matches across African markets under AfCFTA.'; }
  get icon() { return '🚢'; }
  get regions() { return ['africa']; }

  get defaultAgentSettings() {
    return {
      sourceCountries: ['NG', 'KE', 'GH', 'ZA'],
      destinationCountries: ['NG', 'KE', 'GH', 'ZA', 'TZ', 'UG', 'RW'],
      productCategories: ['electronics', 'textiles', 'food_beverages', 'cosmetics', 'building_materials', 'auto_parts', 'agriculture'],
      minProfitMargin: 20, // %
      minDealValue: 500,
      maxDealValue: 50000,
      includeImportFromAsia: true,
      afcftaFocus: true, // prefer intra-African trade
      trackShippingRates: true,
    };
  }

  get settingsSchema() {
    return [
      {
        key: 'sourceCountries',
        label: 'Source Countries (Buy From)',
        type: 'multi-select',
        options: [
          { value: 'NG', label: '🇳🇬 Nigeria' }, { value: 'KE', label: '🇰🇪 Kenya' },
          { value: 'GH', label: '🇬🇭 Ghana' }, { value: 'ZA', label: '🇿🇦 South Africa' },
          { value: 'CN', label: '🇨🇳 China (Alibaba)' }, { value: 'IN', label: '🇮🇳 India' },
          { value: 'TR', label: '🇹🇷 Turkey' }, { value: 'AE', label: '🇦🇪 UAE (Dubai)' },
        ],
      },
      {
        key: 'destinationCountries',
        label: 'Destination Countries (Sell To)',
        type: 'multi-select',
        options: [
          { value: 'NG', label: '🇳🇬 Nigeria' }, { value: 'KE', label: '🇰🇪 Kenya' },
          { value: 'GH', label: '🇬🇭 Ghana' }, { value: 'TZ', label: '🇹🇿 Tanzania' },
          { value: 'UG', label: '🇺🇬 Uganda' }, { value: 'RW', label: '🇷🇼 Rwanda' },
          { value: 'CD', label: '🇨🇩 DR Congo' }, { value: 'ET', label: '🇪🇹 Ethiopia' },
          { value: 'SN', label: '🇸🇳 Senegal' }, { value: 'CI', label: '🇨🇮 Côte d\'Ivoire' },
          { value: 'CM', label: '🇨🇲 Cameroon' }, { value: 'ZA', label: '🇿🇦 South Africa' },
        ],
      },
      {
        key: 'productCategories',
        label: 'Product Categories',
        type: 'multi-select',
        options: [
          { value: 'electronics', label: 'Electronics & Phones' },
          { value: 'textiles', label: 'Textiles & Fashion' },
          { value: 'food_beverages', label: 'Food & Beverages' },
          { value: 'cosmetics', label: 'Cosmetics & Beauty' },
          { value: 'building_materials', label: 'Building Materials' },
          { value: 'auto_parts', label: 'Auto Parts' },
          { value: 'agriculture', label: 'Agriculture & Raw Materials' },
          { value: 'pharmaceuticals', label: 'Pharmaceuticals' },
          { value: 'machinery', label: 'Machinery & Equipment' },
        ],
      },
      {
        key: 'minProfitMargin',
        label: 'Minimum Profit Margin (%)',
        type: 'number',
        min: 5,
        max: 200,
      },
    ];
  }

  // ===== PHASE 1: DISCOVERY =====
  async discover(config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const allLeads = [];

    // 1. Crawl African e-commerce platforms for price data
    const platforms = this._getEcommercePlatforms(settings);
    for (const platform of platforms) {
      try {
        const response = await axios.get(platform.url, {
          headers: { 'User-Agent': 'TradeFlow-Agent/1.0' },
          timeout: 30000,
        });

        const $ = cheerio.load(response.data);
        const pageText = $('body').text().substring(0, 10000);

        const products = await this.askClaudeJSON(`
Extract product listings and prices from this ${platform.country} e-commerce page:
Platform: ${platform.name}
Content: ${pageText}

For each product extract:
- productName: name
- category: closest from [${settings.productCategories.join(', ')}]
- price: price in local currency
- currency: currency code
- priceUSD: approximate USD equivalent
- seller: seller name if shown
- url: product URL
- availability: in_stock or out_of_stock

Return JSON array. Focus on products in categories: ${settings.productCategories.join(', ')}`,
          'Extract product and pricing data. Return only valid JSON arrays.'
        );

        if (Array.isArray(products)) {
          for (const product of products) {
            allLeads.push({
              title: `${product.productName} — ${platform.country} → Other Markets`,
              description: `${platform.name}: ${product.currency} ${product.price} (~$${product.priceUSD})`,
              source: platform.name,
              sourceUrl: product.url || platform.url,
              externalId: `trade-${platform.country}-${product.productName}`.toLowerCase().replace(/\s/g, '-').substring(0, 100),
              estimatedCost: product.priceUSD || 0,
              location: { county: platform.country },
              metadata: {
                productName: product.productName,
                category: product.category,
                sourceCountry: platform.country,
                sourcePrice: product.price,
                sourceCurrency: product.currency,
                sourcePriceUSD: product.priceUSD,
                platform: platform.name,
                seller: product.seller,
                type: 'price_data',
              },
            });
          }
        }

        await this._delay(2000);
      } catch (err) {
        logger.warn(`[cross-border] Failed to crawl ${platform.name}:`, err.message);
      }
    }

    // 2. Find arbitrage opportunities by comparing prices
    const arbitrageLeads = await this._findArbitrageOpportunities(allLeads, settings);

    // 3. Crawl B2B platforms for bulk supplier deals
    try {
      const supplierLeads = await this._crawlSupplierPlatforms(settings);
      arbitrageLeads.push(...supplierLeads);
    } catch (err) {
      logger.warn('[cross-border] Supplier crawl error:', err.message);
    }

    return arbitrageLeads;
  }

  async _findArbitrageOpportunities(priceData, settings) {
    if (priceData.length < 2) return priceData;

    const prompt = `Analyze these product prices across African markets and identify arbitrage opportunities:

${JSON.stringify(priceData.slice(0, 30).map(l => ({
  product: l.metadata?.productName,
  country: l.metadata?.sourceCountry,
  priceUSD: l.metadata?.sourcePriceUSD,
  category: l.metadata?.category,
})), null, 2)}

Target markets to sell in: ${settings.destinationCountries.join(', ')}
Minimum profit margin: ${settings.minProfitMargin}%

For each arbitrage opportunity found, return:
{
  "product": "product name",
  "buyCountry": "country code",
  "buyPrice": USD amount,
  "sellCountry": "best country to sell",
  "estimatedSellPrice": USD amount,
  "profitMargin": percentage,
  "shippingEstimate": USD amount,
  "customsDuty": estimated percentage,
  "netProfit": USD per unit after all costs,
  "demand": "high/medium/low",
  "risk": "description of main risks",
  "recommendation": "buy/pass/watch"
}

Return as JSON array. Only include opportunities with margin >= ${settings.minProfitMargin}%.`;

    try {
      const opportunities = await this.askClaudeJSON(prompt,
        'You are an African cross-border trade analyst. Factor in real shipping costs, customs duties, forex risks, and AfCFTA tariff reductions.'
      );

      if (!Array.isArray(opportunities)) return priceData;

      return opportunities.map(opp => ({
        title: `${opp.product}: ${opp.buyCountry} → ${opp.sellCountry} (${opp.profitMargin}% margin)`,
        description: `Buy at $${opp.buyPrice}, sell at ~$${opp.estimatedSellPrice}. Net profit: $${opp.netProfit}/unit`,
        source: 'Cross-Border Analysis',
        externalId: `arb-${opp.buyCountry}-${opp.sellCountry}-${opp.product}`.toLowerCase().replace(/\s/g, '-').substring(0, 100),
        estimatedCost: opp.buyPrice,
        estimatedValue: opp.estimatedSellPrice,
        estimatedROI: opp.profitMargin,
        metadata: {
          ...opp,
          type: 'arbitrage_opportunity',
          shippingEstimate: opp.shippingEstimate,
          customsDuty: opp.customsDuty,
        },
      }));
    } catch (err) {
      logger.warn('[cross-border] Arbitrage analysis failed:', err.message);
      return priceData;
    }
  }

  async _crawlSupplierPlatforms(settings) {
    const platforms = [
      { name: 'TradeKey Africa', url: 'https://www.tradekey.com/selling-leads/africa/' },
      { name: 'Go4WorldBusiness', url: 'https://www.go4worldbusiness.com/supplierlist/africa/' },
    ];

    if (settings.includeImportFromAsia) {
      platforms.push(
        { name: 'Alibaba Africa', url: 'https://www.alibaba.com/trade/search?fsb=y&SearchText=africa' },
      );
    }

    const leads = [];
    for (const platform of platforms) {
      try {
        const response = await axios.get(platform.url, {
          headers: { 'User-Agent': 'TradeFlow-Agent/1.0' },
          timeout: 30000,
        });
        const $ = cheerio.load(response.data);
        const pageText = $('body').text().substring(0, 8000);

        const parsed = await this.askClaudeJSON(`
Extract supplier/product listings from ${platform.name}:
${pageText}

Return JSON array: [{product, supplier, country, moq, priceRange, category}]
Focus on: ${settings.productCategories.join(', ')}`,
          'Return only valid JSON arrays of trade opportunities.'
        );

        if (Array.isArray(parsed)) {
          leads.push(...parsed.map(item => ({
            title: `Supplier: ${item.product} from ${item.supplier}`,
            description: `${item.country} — MOQ: ${item.moq || 'N/A'} — ${item.priceRange || 'Contact for price'}`,
            source: platform.name,
            sourceUrl: platform.url,
            externalId: `supplier-${item.supplier}-${item.product}`.toLowerCase().replace(/\s/g, '-').substring(0, 100),
            metadata: { ...item, type: 'supplier_listing', platform: platform.name },
          })));
        }
        await this._delay(2000);
      } catch (err) {
        logger.warn(`[cross-border] Failed crawling ${platform.name}:`, err.message);
      }
    }
    return leads;
  }

  // ===== PHASE 2: ANALYSIS =====
  async analyze(lead, config) {
    const meta = lead.metadata || {};

    const prompt = `Analyze this cross-border trade opportunity:

${JSON.stringify(meta, null, 2)}

Consider: shipping logistics, customs clearance, AfCFTA tariff benefits, forex risk, payment terms, product shelf life, import regulations, and competition.

Return JSON:
{
  "score": (0-100),
  "priority": ("low","medium","high","critical"),
  "recommendation": ("buy","pass","watch"),
  "estimatedROI": percentage,
  "totalLandedCost": USD,
  "netProfitPerUnit": USD,
  "shippingOptions": ["best shipping methods"],
  "regulatoryNotes": "import/export requirements",
  "paymentAdvice": "recommended payment terms",
  "riskFactors": ["risks"],
  "afcftaBenefits": "relevant AfCFTA advantages",
  "analysisNotes": "summary"
}`;

    const analysis = await this.askClaudeJSON(prompt,
      'You are an African trade analyst specializing in cross-border commerce, AfCFTA regulations, and intra-African logistics.'
    );

    return {
      score: analysis.score || 50,
      priority: analysis.priority || 'medium',
      aiRecommendation: analysis.recommendation || 'watch',
      estimatedROI: analysis.estimatedROI || 0,
      aiAnalysis: analysis.analysisNotes || '',
      metadata: { ...meta, analysis },
    };
  }

  // ===== HELPERS =====
  _getEcommercePlatforms(settings) {
    const all = {
      NG: [
        { name: 'Jumia Nigeria', url: 'https://www.jumia.com.ng/catalog/', country: 'NG' },
        { name: 'Konga', url: 'https://www.konga.com/category/', country: 'NG' },
      ],
      KE: [
        { name: 'Jumia Kenya', url: 'https://www.jumia.co.ke/catalog/', country: 'KE' },
        { name: 'Kilimall', url: 'https://www.kilimall.co.ke/', country: 'KE' },
      ],
      GH: [
        { name: 'Jumia Ghana', url: 'https://www.jumia.com.gh/catalog/', country: 'GH' },
        { name: 'Tonaton', url: 'https://tonaton.com/', country: 'GH' },
      ],
      ZA: [
        { name: 'Takealot', url: 'https://www.takealot.com/', country: 'ZA' },
        { name: 'Bidorbuy', url: 'https://www.bidorbuy.co.za/', country: 'ZA' },
      ],
      TZ: [
        { name: 'Jumia Tanzania', url: 'https://www.jumia.co.tz/', country: 'TZ' },
      ],
    };

    const platforms = [];
    for (const country of [...settings.sourceCountries, ...settings.destinationCountries]) {
      if (all[country]) platforms.push(...all[country]);
    }
    return [...new Map(platforms.map(p => [p.name, p])).values()]; // dedupe
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CrossBorderTradeAgent;
