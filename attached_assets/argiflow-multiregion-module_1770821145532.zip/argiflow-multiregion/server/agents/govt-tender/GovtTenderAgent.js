const BaseAgent = require('../BaseAgent');
const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../../config/logger');

class GovtTenderAgent extends BaseAgent {
  get type() { return 'govt-tender-africa'; }
  get name() { return 'Tender Hunter'; }
  get description() { return 'Finds government procurement tenders across African countries, matches them to your business, and helps prepare winning bids.'; }
  get icon() { return '📋'; }
  get regions() { return ['africa']; }

  get defaultAgentSettings() {
    return {
      targetCountries: ['NG', 'KE', 'GH', 'ZA', 'TZ'],
      businessCategories: ['IT', 'construction', 'consulting', 'supplies', 'healthcare', 'agriculture'],
      minTenderValue: 1000,
      maxTenderValue: 500000,
      tenderTypes: ['open', 'restricted', 'rfq', 'rfp'],
      autoApplyForRFQ: false,
      preferLocalTenders: true,
      languages: ['en', 'fr'],
    };
  }

  get settingsSchema() {
    return [
      {
        key: 'targetCountries',
        label: 'Target Countries',
        type: 'multi-select',
        options: [
          { value: 'NG', label: '🇳🇬 Nigeria' },
          { value: 'KE', label: '🇰🇪 Kenya' },
          { value: 'GH', label: '🇬🇭 Ghana' },
          { value: 'ZA', label: '🇿🇦 South Africa' },
          { value: 'TZ', label: '🇹🇿 Tanzania' },
          { value: 'UG', label: '🇺🇬 Uganda' },
          { value: 'RW', label: '🇷🇼 Rwanda' },
          { value: 'ET', label: '🇪🇹 Ethiopia' },
          { value: 'SN', label: '🇸🇳 Senegal' },
          { value: 'CI', label: '🇨🇮 Côte d\'Ivoire' },
          { value: 'CM', label: '🇨🇲 Cameroon' },
          { value: 'EG', label: '🇪🇬 Egypt' },
          { value: 'MA', label: '🇲🇦 Morocco' },
        ],
      },
      {
        key: 'businessCategories',
        label: 'Business Categories',
        type: 'multi-select',
        options: [
          { value: 'IT', label: 'IT & Technology' },
          { value: 'construction', label: 'Construction & Engineering' },
          { value: 'consulting', label: 'Consulting & Professional Services' },
          { value: 'supplies', label: 'Supplies & Equipment' },
          { value: 'healthcare', label: 'Healthcare & Medical' },
          { value: 'agriculture', label: 'Agriculture & Food' },
          { value: 'transport', label: 'Transport & Logistics' },
          { value: 'education', label: 'Education & Training' },
          { value: 'energy', label: 'Energy & Utilities' },
          { value: 'security', label: 'Security & Safety' },
        ],
      },
      {
        key: 'minTenderValue',
        label: 'Min Tender Value ($)',
        type: 'number',
        min: 100,
        max: 10000000,
      },
      {
        key: 'maxTenderValue',
        label: 'Max Tender Value ($)',
        type: 'number',
        min: 100,
        max: 10000000,
      },
      {
        key: 'autoApplyForRFQ',
        label: 'Auto-submit for small RFQs',
        type: 'toggle',
        description: 'Automatically prepare and flag small quote requests for your review',
      },
    ];
  }

  // ===== PHASE 1: DISCOVERY =====
  async discover(config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const allLeads = [];

    for (const country of settings.targetCountries) {
      try {
        const portals = this._getTenderPortals(country);
        for (const portal of portals) {
          try {
            const response = await axios.get(portal.url, {
              headers: { 'User-Agent': process.env.SCRAPER_USER_AGENT || 'TradeFlow-Agent/1.0' },
              timeout: 30000,
            });

            const leads = await this._parseTenderPage(response.data, portal, country, settings);
            allLeads.push(...leads);
            await this._delay(2000);
          } catch (err) {
            logger.warn(`[govt-tender] Failed to crawl ${portal.name}: ${err.message}`);
          }
        }
      } catch (err) {
        logger.error(`[govt-tender] Error with country ${country}:`, err.message);
      }
    }

    // Also crawl multi-country platforms
    try {
      const multiLeads = await this._crawlMultiCountryPlatforms(settings);
      allLeads.push(...multiLeads);
    } catch (err) {
      logger.warn(`[govt-tender] Multi-country crawl error:`, err.message);
    }

    return allLeads;
  }

  async _parseTenderPage(html, portal, country, settings) {
    const $ = cheerio.load(html);
    const pageText = $('body').text().substring(0, 12000);

    const prompt = `Extract government tender/procurement listings from this page.

Source: ${portal.name} (${country})
Content: ${pageText}

For each tender extract:
- tenderNumber: reference/tender number
- title: tender title/description
- organization: issuing government body
- category: closest match from [${settings.businessCategories.join(', ')}]
- estimatedValue: value in USD if shown
- currency: original currency
- closingDate: deadline in ISO format
- tenderType: open, restricted, rfq, or rfp
- location: city/region within the country
- contactInfo: any contact details shown
- documentUrl: link to tender documents if available

Return as JSON array. Only include tenders in these categories: ${settings.businessCategories.join(', ')}.
Only include tenders with estimated value between $${settings.minTenderValue} and $${settings.maxTenderValue} (if value is shown).`;

    try {
      const parsed = await this.askClaudeJSON(prompt,
        'You are a government procurement data specialist for African markets. Extract structured data accurately. Return only valid JSON arrays.'
      );

      if (!Array.isArray(parsed)) return [];

      return parsed.map(item => ({
        title: item.title || `Tender ${item.tenderNumber}`,
        description: `${item.organization} — ${item.category} — ${portal.name}`,
        source: portal.name,
        sourceUrl: portal.url,
        externalId: `tender-${country}-${item.tenderNumber || Date.now()}`.toLowerCase().replace(/\s/g, '-'),
        estimatedCost: 0, // Tenders don't cost money to bid (usually)
        estimatedValue: item.estimatedValue || 0,
        location: {
          city: item.location,
          state: item.location,
          county: country,
        },
        actionDeadline: item.closingDate ? new Date(item.closingDate) : null,
        metadata: {
          tenderNumber: item.tenderNumber,
          organization: item.organization,
          category: item.category,
          tenderType: item.tenderType,
          originalCurrency: item.currency,
          contactInfo: item.contactInfo,
          documentUrl: item.documentUrl,
          country,
          portal: portal.name,
        },
      }));
    } catch (err) {
      logger.warn(`[govt-tender] AI parsing failed for ${portal.name}:`, err.message);
      return [];
    }
  }

  async _crawlMultiCountryPlatforms(settings) {
    const platforms = [
      { name: 'UNGM', url: 'https://www.ungm.org/Public/Notice', description: 'United Nations Global Marketplace' },
      { name: 'AfDB Procurement', url: 'https://www.afdb.org/en/projects-and-operations/procurement', description: 'African Development Bank' },
      { name: 'Tenders.go.ke', url: 'https://tenders.go.ke/website/tenders/new', description: 'Kenya Public Procurement' },
      { name: 'DgMarket', url: 'https://www.dgmarket.com/tenders/africa', description: 'Development Gateway' },
    ];

    const leads = [];
    for (const platform of platforms) {
      try {
        const response = await axios.get(platform.url, {
          headers: { 'User-Agent': 'TradeFlow-Agent/1.0' },
          timeout: 30000,
        });

        const $ = cheerio.load(response.data);
        const pageText = $('body').text().substring(0, 10000);

        const parsed = await this.askClaudeJSON(`
Extract procurement opportunities from: ${platform.name} (${platform.description})
Content: ${pageText}

Extract tenders relevant to Africa in categories: ${settings.businessCategories.join(', ')}
Return JSON array with: title, organization, country, category, closingDate, estimatedValue, tenderNumber, url`,
          'Return only valid JSON arrays of African procurement opportunities.'
        );

        if (Array.isArray(parsed)) {
          for (const item of parsed) {
            if (settings.targetCountries.includes(item.country) || !item.country) {
              leads.push({
                title: item.title,
                description: `${item.organization} — ${platform.name}`,
                source: platform.name,
                sourceUrl: item.url || platform.url,
                externalId: `tender-multi-${item.tenderNumber || Date.now()}-${Math.random().toString(36).substr(2,5)}`,
                estimatedValue: item.estimatedValue || 0,
                actionDeadline: item.closingDate ? new Date(item.closingDate) : null,
                metadata: {
                  ...item,
                  portal: platform.name,
                  multiCountry: true,
                },
              });
            }
          }
        }
        await this._delay(2000);
      } catch (err) {
        logger.warn(`[govt-tender] Failed to crawl ${platform.name}:`, err.message);
      }
    }
    return leads;
  }

  // ===== PHASE 2: ANALYSIS =====
  async analyze(lead, config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const meta = lead.metadata || {};

    const prompt = `Analyze this government tender opportunity for an African entrepreneur:

TENDER DETAILS:
- Title: ${lead.title}
- Organization: ${meta.organization || 'Unknown'}
- Country: ${meta.country || 'Unknown'}
- Category: ${meta.category || 'Unknown'}
- Estimated Value: $${lead.estimatedValue || 'Unknown'}
- Deadline: ${lead.actionDeadline || 'Unknown'}
- Type: ${meta.tenderType || 'Unknown'}

USER BUSINESS CATEGORIES: ${settings.businessCategories.join(', ')}
USER BUDGET RANGE: $${settings.minTenderValue} - $${settings.maxTenderValue}

Analyze considering:
- Match quality between tender and user's business
- Competition level (how many bidders typically)
- Documentation requirements complexity
- Payment reliability of the issuing organization
- Local vs international preference
- Required certifications or registrations

Return JSON:
{
  "score": (0-100),
  "priority": ("low", "medium", "high", "critical"),
  "recommendation": ("buy", "pass", "watch"),
  "matchScore": (0-100, how well it matches user's business),
  "competitionLevel": ("low", "medium", "high"),
  "winProbability": (0-100),
  "requiredDocuments": ["list of docs needed"],
  "estimatedPrepTime": "e.g. 3-5 days",
  "keyRequirements": ["critical requirements to note"],
  "tips": "strategic advice for winning this tender",
  "analysisNotes": "brief summary"
}`;

    const analysis = await this.askClaudeJSON(prompt,
      'You are an African government procurement specialist. Provide realistic analysis considering local business realities, registration requirements, and competition dynamics.'
    );

    return {
      score: analysis.score || 50,
      priority: analysis.priority || 'medium',
      aiRecommendation: analysis.recommendation || 'watch',
      estimatedROI: analysis.winProbability || 0,
      aiAnalysis: analysis.analysisNotes || '',
      metadata: {
        ...meta,
        matchScore: analysis.matchScore,
        competitionLevel: analysis.competitionLevel,
        winProbability: analysis.winProbability,
        requiredDocuments: analysis.requiredDocuments || [],
        estimatedPrepTime: analysis.estimatedPrepTime,
        keyRequirements: analysis.keyRequirements || [],
        tips: analysis.tips,
      },
    };
  }

  // ===== PHASE 3: ENRICHMENT =====
  async enrich(lead, config) {
    const meta = lead.metadata || {};

    const enrichment = await this.askClaudeJSON(`
For this government tender in ${meta.country || 'Africa'}:
Organization: ${meta.organization}
Category: ${meta.category}

Provide:
{
  "organizationProfile": "brief overview of this government body",
  "paymentHistory": "general reputation for paying contractors on time",
  "previousTenders": "typical types of tenders they issue",
  "registrationRequired": "what business registration is needed to bid",
  "localPartnerNeeded": "whether a local partner/JV is typically required",
  "fundingSource": "whether this is likely government-funded, donor-funded, or loan-funded"
}`,
      'You are an expert on African government procurement. Provide practical intelligence.'
    );

    return {
      metadata: { ...meta, enrichment },
    };
  }

  // ===== PHASE 4: ACTION =====
  async act(lead, config) {
    const meta = lead.metadata || {};

    const bidPrep = await this.askClaudeJSON(`
Prepare a bid strategy for this tender:

Tender: ${lead.title}
Organization: ${meta.organization}
Country: ${meta.country}
Category: ${meta.category}
Value: $${lead.estimatedValue}
Deadline: ${lead.actionDeadline}

Return JSON:
{
  "bidChecklist": ["step-by-step preparation checklist"],
  "documentTemplate": "outline of the bid document structure",
  "pricingStrategy": "how to price competitively",
  "differentiators": ["key points to emphasize in the bid"],
  "timeline": "day-by-day preparation timeline",
  "commonMistakes": ["mistakes to avoid"],
  "submissionInstructions": "how to submit the bid"
}`,
      'You are a bid preparation specialist for African government tenders.'
    );

    return {
      status: 'bidding',
      metadata: { ...meta, bidStrategy: bidPrep },
      notes: [{
        content: `Bid strategy prepared. ${bidPrep.bidChecklist?.length || 0} checklist items. ${bidPrep.timeline || 'Review timeline in details.'}`,
        author: 'agent',
      }],
    };
  }

  // ===== PHASE 5: MONITORING =====
  async monitor(config) {
    const Lead = require('../../models/Lead');
    const updates = [];

    const activeLeads = await Lead.find({
      userId: config.userId,
      agentType: this.type,
      status: { $in: ['qualified', 'approved', 'bidding'] },
      actionDeadline: { $exists: true },
    });

    for (const lead of activeLeads) {
      const daysLeft = Math.ceil((new Date(lead.actionDeadline) - new Date()) / (1000 * 60 * 60 * 24));

      if (daysLeft <= 3 && daysLeft > 0) {
        await this._notifyUser(config.userId, {
          type: 'auction_reminder',
          leadId: lead._id,
          title: `⏰ Tender Closing in ${daysLeft} Day${daysLeft > 1 ? 's' : ''}!`,
          message: `${lead.title}: Deadline is ${new Date(lead.actionDeadline).toLocaleDateString()}. Submit your bid now!`,
          priority: 'urgent',
          requiresAction: true,
        });
      } else if (daysLeft <= 0) {
        updates.push({
          leadId: lead._id,
          data: { status: 'archived', 'metadata.expired': true },
        });
      }
    }

    return updates;
  }

  // ===== HELPERS =====
  _getTenderPortals(country) {
    const portals = {
      NG: [
        { name: 'BPP Nigeria', url: 'https://www.bpp.gov.ng/opportunities/' },
        { name: 'NOCOPO', url: 'https://nocopo.bpp.gov.ng' },
        { name: 'Nigeria Tenders', url: 'https://nigeriaprocurement.org' },
      ],
      KE: [
        { name: 'PPIP Kenya', url: 'https://tenders.go.ke/website/tenders/new' },
        { name: 'MyGov Kenya', url: 'https://www.mygov.go.ke/all-tenders' },
      ],
      GH: [
        { name: 'PPA Ghana', url: 'https://www.ppaghana.org/opportunities' },
        { name: 'Ghana Tenders', url: 'https://ghanatenders.gov.gh' },
      ],
      ZA: [
        { name: 'eTenders SA', url: 'https://www.etenders.gov.za/content/advertised-tenders' },
        { name: 'National Treasury', url: 'http://www.treasury.gov.za/tenderinfo/' },
      ],
      TZ: [
        { name: 'PPRA Tanzania', url: 'https://www.ppra.go.tz/tenders' },
        { name: 'TANePS', url: 'https://taneps.go.tz' },
      ],
      UG: [
        { name: 'PPDA Uganda', url: 'https://www.ppda.go.ug/bids-awards/bid-notices/' },
      ],
      RW: [
        { name: 'Rwanda e-Procurement', url: 'https://www.umucyo.gov.rw' },
      ],
      ET: [
        { name: 'Ethiopia PPA', url: 'https://ppa.gov.et/tenders' },
      ],
      SN: [
        { name: 'ARMP Senegal', url: 'https://www.armp.sn/appels-offres' },
      ],
      CI: [
        { name: 'ANRMP Côte d\'Ivoire', url: 'https://www.anrmp.ci/appels-d-offres' },
      ],
      CM: [
        { name: 'ARMP Cameroon', url: 'https://www.armp.cm/appels-d-offres' },
      ],
      EG: [
        { name: 'Egypt Tenders', url: 'https://etenders.gov.eg' },
      ],
      MA: [
        { name: 'Morocco Procurement', url: 'https://www.marchespublics.gov.ma' },
      ],
    };

    return portals[country] || [];
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = GovtTenderAgent;
