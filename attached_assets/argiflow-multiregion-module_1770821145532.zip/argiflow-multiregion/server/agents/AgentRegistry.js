const logger = require('../config/logger');

class AgentRegistry {
  constructor() {
    this.agents = new Map();
  }

  register(AgentClass) {
    const agent = new AgentClass();
    this.agents.set(agent.type, agent);
    logger.info(`Registered agent: ${agent.type} (${agent.name}) [${agent.regions.join(', ')}]`);
    return this;
  }

  get(type) {
    const agent = this.agents.get(type);
    if (!agent) throw new Error(`Agent type "${type}" not found in registry`);
    return agent;
  }

  getAll() {
    return Array.from(this.agents.values());
  }

  /** Get agents available for a specific region */
  getByRegion(region) {
    return this.getAll().filter(agent =>
      agent.regions.includes(region) || agent.regions.includes('all')
    );
  }

  /** Get catalog filtered by region */
  getCatalog(region = null) {
    const agents = region ? this.getByRegion(region) : this.getAll();
    return agents.map(agent => agent.getInfo());
  }

  has(type) {
    return this.agents.has(type);
  }
}

// Singleton registry
const registry = new AgentRegistry();

// ===== REGISTER ALL AGENTS =====

// Western market agents
const TaxLienAgent = require('./tax-lien/TaxLienAgent');
registry.register(TaxLienAgent);

// African market agents
const GovtTenderAgent = require('./govt-tender/GovtTenderAgent');
registry.register(GovtTenderAgent);

const CrossBorderTradeAgent = require('./cross-border/CrossBorderTradeAgent');
registry.register(CrossBorderTradeAgent);

const AgriMarketAgent = require('./agri-market/AgriMarketAgent');
registry.register(AgriMarketAgent);

const DiasporaAgent = require('./diaspora/DiasporaAgent');
registry.register(DiasporaAgent);

// Future agents (uncomment when ready):
// const TaxDeedAgent = require('./tax-deed/TaxDeedAgent');
// registry.register(TaxDeedAgent);
// const GovtContractsUSAgent = require('./govt-contracts-us/GovtContractsUSAgent');
// registry.register(GovtContractsUSAgent);
// const ForexMonitorAgent = require('./forex-monitor/ForexMonitorAgent');
// registry.register(ForexMonitorAgent);

module.exports = registry;
