const BaseAgent = require('../BaseAgent');
const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../../config/logger');

class DiasporaAgent extends BaseAgent {
  get type() { return 'diaspora-services'; }
  get name() { return 'Diaspora Connect'; }
  get description() { return 'Helps Africans abroad invest back home — finds property opportunities, monitors construction projects, optimizes remittances, and manages investments remotely.'; }
  get icon() { return '🌍'; }
  get regions() { return ['africa']; }

  get defaultAgentSettings() {
    return {
      currentCountry: 'US', // where the diaspora member lives
      homeCountry: 'NG', // where they want to invest
      investmentTypes: ['property', 'land', 'business', 'agriculture'],
      budgetMin: 5000,
      budgetMax: 100000,
      budgetCurrency: 'USD',
      trackRemittanceRates: true,
      trackPropertyMarket: true,
      monitorConstruction: false,
      preferredCities: [],
      verifiedAgentsOnly: true, // only show opportunities from verified local agents
    };
  }

  get settingsSchema() {
    return [
      {
        key: 'currentCountry',
        label: 'Where You Live Now',
        type: 'select',
        options: [
          { value: 'US', label: '🇺🇸 United States' }, { value: 'GB', label: '🇬🇧 United Kingdom' },
          { value: 'CA', label: '🇨🇦 Canada' }, { value: 'DE', label: '🇩🇪 Germany' },
          { value: 'FR', label: '🇫🇷 France' }, { value: 'AE', label: '🇦🇪 UAE' },
          { value: 'SA', label: '🇸🇦 Saudi Arabia' }, { value: 'AU', label: '🇦🇺 Australia' },
          { value: 'IT', label: '🇮🇹 Italy' }, { value: 'NL', label: '🇳🇱 Netherlands' },
        ],
      },
      {
        key: 'homeCountry',
        label: 'Home Country (Invest Here)',
        type: 'select',
        options: [
          { value: 'NG', label: '🇳🇬 Nigeria' }, { value: 'KE', label: '🇰🇪 Kenya' },
          { value: 'GH', label: '🇬🇭 Ghana' }, { value: 'ZA', label: '🇿🇦 South Africa' },
          { value: 'ET', label: '🇪🇹 Ethiopia' }, { value: 'TZ', label: '🇹🇿 Tanzania' },
          { value: 'UG', label: '🇺🇬 Uganda' }, { value: 'RW', label: '🇷🇼 Rwanda' },
          { value: 'SN', label: '🇸🇳 Senegal' }, { value: 'CM', label: '🇨🇲 Cameroon' },
          { value: 'CI', label: '🇨🇮 Côte d\'Ivoire' }, { value: 'CD', label: '🇨🇩 DR Congo' },
          { value: 'EG', label: '🇪🇬 Egypt' }, { value: 'MA', label: '🇲🇦 Morocco' },
          { value: 'ZM', label: '🇿🇲 Zambia' }, { value: 'ZW', label: '🇿🇼 Zimbabwe' },
        ],
      },
      {
        key: 'investmentTypes',
        label: 'Investment Interests',
        type: 'multi-select',
        options: [
          { value: 'property', label: 'Houses & Apartments' },
          { value: 'land', label: 'Land (Residential/Commercial)' },
          { value: 'business', label: 'Business Investment/Partnership' },
          { value: 'agriculture', label: 'Farmland & Agriculture' },
          { value: 'stocks', label: 'Local Stock Market' },
          { value: 'real_estate_fund', label: 'Real Estate Investment Trusts' },
        ],
      },
      {
        key: 'budgetMax',
        label: 'Maximum Investment Budget (USD)',
        type: 'number',
        min: 1000,
        max: 1000000,
      },
      {
        key: 'trackRemittanceRates',
        label: 'Track Remittance Rates',
        type: 'toggle',
        description: 'Monitor exchange rates across remittance providers to find the best rate',
      },
      {
        key: 'verifiedAgentsOnly',
        label: 'Verified Agents Only',
        type: 'toggle',
        description: 'Only show opportunities from registered/verified agents and developers',
      },
    ];
  }

  // ===== PHASE 1: DISCOVERY =====
  async discover(config) {
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };
    const leads = [];

    // 1. Property opportunities
    if (settings.investmentTypes.includes('property') || settings.investmentTypes.includes('land')) {
      try {
        const propertyLeads = await this._findPropertyOpportunities(settings);
        leads.push(...propertyLeads);
      } catch (err) {
        logger.warn('[diaspora] Property search error:', err.message);
      }
    }

    // 2. Remittance rate comparison
    if (settings.trackRemittanceRates) {
      try {
        const rateLeads = await this._compareRemittanceRates(settings);
        leads.push(...rateLeads);
      } catch (err) {
        logger.warn('[diaspora] Remittance rate error:', err.message);
      }
    }

    // 3. Business & investment opportunities
    if (settings.investmentTypes.includes('business')) {
      try {
        const bizLeads = await this._findBusinessOpportunities(settings);
        leads.push(...bizLeads);
      } catch (err) {
        logger.warn('[diaspora] Business opportunity error:', err.message);
      }
    }

    // 4. Stock market / REIT opportunities
    if (settings.investmentTypes.includes('stocks') || settings.investmentTypes.includes('real_estate_fund')) {
      try {
        const stockLeads = await this._findStockOpportunities(settings);
        leads.push(...stockLeads);
      } catch (err) {
        logger.warn('[diaspora] Stock search error:', err.message);
      }
    }

    return leads;
  }

  async _findPropertyOpportunities(settings) {
    const portals = this._getPropertyPortals(settings.homeCountry);
    const leads = [];

    for (const portal of portals) {
      try {
        const response = await axios.get(portal.url, {
          headers: { 'User-Agent': 'TradeFlow-Agent/1.0' },
          timeout: 30000,
        });
        const $ = cheerio.load(response.data);
        const text = $('body').text().substring(0, 10000);

        const properties = await this.askClaudeJSON(`
Extract property listings from ${portal.name} (${settings.homeCountry}):
${text}

For each property extract:
- title: property description
- type: house, apartment, land, commercial
- location: city/area
- price: asking price
- currency: currency code
- priceUSD: approximate USD
- size: square meters or plot size
- bedrooms: number (if applicable)
- features: key features
- agent: listing agent/developer name
- verified: true/false if agent appears to be a registered company
- url: listing URL

Budget range: $${settings.budgetMin} - $${settings.budgetMax} USD
Return as JSON array.`,
          'Extract property listing data. Return only valid JSON arrays.'
        );

        if (Array.isArray(properties)) {
          for (const prop of properties) {
            if (settings.verifiedAgentsOnly && !prop.verified) continue;
            leads.push({
              title: `🏠 ${prop.title} — ${prop.location}`,
              description: `${prop.currency} ${prop.price} (~$${prop.priceUSD}) | ${prop.bedrooms ? prop.bedrooms + 'BR' : prop.size} | ${prop.agent}`,
              source: portal.name,
              sourceUrl: prop.url || portal.url,
              externalId: `prop-${settings.homeCountry}-${prop.title}-${prop.price}`.toLowerCase().replace(/\s/g, '-').substring(0, 100),
              estimatedCost: prop.priceUSD || 0,
              estimatedValue: prop.priceUSD || 0,
              location: { city: prop.location, county: settings.homeCountry },
              metadata: { ...prop, type: 'property', country: settings.homeCountry, portal: portal.name },
            });
          }
        }
        await this._delay(2000);
      } catch (err) {
        logger.warn(`[diaspora] Failed crawling ${portal.name}:`, err.message);
      }
    }
    return leads;
  }

  async _compareRemittanceRates(settings) {
    const corridor = `${settings.currentCountry} → ${settings.homeCountry}`;

    const analysis = await this.askClaudeJSON(`
Compare remittance rates for sending money from ${settings.currentCountry} to ${settings.homeCountry}:

Provide rates for these providers:
- WorldRemit
- Wise (TransferWise)
- Sendwave
- Remitly
- Western Union
- MoneyGram
- Chipper Cash

For each return:
{
  "provider": "name",
  "exchangeRate": approximate rate,
  "fee": typical fee for $500 transfer,
  "speed": "instant/1-2 days/3-5 days",
  "payoutMethod": "bank/mobile money/cash",
  "rating": 1-5 stars
}

Return as JSON array sorted by best overall value (rate + fees).`,
      'You are a remittance rate comparison expert. Provide realistic current estimates.'
    );

    if (!Array.isArray(analysis)) return [];

    const bestRate = analysis[0];
    const worstRate = analysis[analysis.length - 1];
    const savings = bestRate && worstRate ?
      `Save up to ${((worstRate.fee - bestRate.fee) + ((worstRate.exchangeRate - bestRate.exchangeRate) * 500)).toFixed(0)} on a $500 transfer` : '';

    return [{
      title: `💱 Best Remittance Rates: ${corridor}`,
      description: `Best: ${bestRate?.provider} | ${savings}`,
      source: 'TradeFlow Remittance Monitor',
      externalId: `remit-${settings.currentCountry}-${settings.homeCountry}-${new Date().toISOString().split('T')[0]}`,
      estimatedValue: 0,
      metadata: {
        type: 'remittance_comparison',
        corridor,
        providers: analysis,
        bestProvider: bestRate?.provider,
        date: new Date().toISOString(),
      },
    }];
  }

  async _findBusinessOpportunities(settings) {
    const opps = await this.askClaudeJSON(`
Find 3-5 realistic business investment opportunities for someone in ${settings.currentCountry} wanting to invest in ${settings.homeCountry}.
Budget: $${settings.budgetMin} - $${settings.budgetMax}

Return JSON array:
[{
  "title": "opportunity title",
  "type": "franchise/partnership/startup/acquisition",
  "industry": "sector",
  "investmentRequired": USD amount,
  "expectedROI": "annual return percentage",
  "description": "2-3 sentence description",
  "riskLevel": "low/medium/high",
  "managementRequired": "passive/semi-active/active",
  "verified": false
}]

Focus on opportunities that can be managed remotely by diaspora investors.`,
      'You are a diaspora investment advisor for African markets.'
    );

    if (!Array.isArray(opps)) return [];

    return opps.map(opp => ({
      title: `💼 ${opp.title}`,
      description: `${opp.type} | $${opp.investmentRequired} | ${opp.expectedROI} ROI | ${opp.managementRequired} management`,
      source: 'TradeFlow Business Scout',
      externalId: `biz-${settings.homeCountry}-${opp.title}`.toLowerCase().replace(/\s/g, '-').substring(0, 100),
      estimatedCost: opp.investmentRequired,
      metadata: { ...opp, type: 'business_opportunity', country: settings.homeCountry },
    }));
  }

  async _findStockOpportunities(settings) {
    const stockExchanges = {
      NG: 'Nigerian Stock Exchange (NGX)',
      KE: 'Nairobi Securities Exchange (NSE)',
      GH: 'Ghana Stock Exchange (GSE)',
      ZA: 'Johannesburg Stock Exchange (JSE)',
      EG: 'Egyptian Exchange (EGX)',
      MA: 'Casablanca Stock Exchange',
    };

    const exchange = stockExchanges[settings.homeCountry];
    if (!exchange) return [];

    const stocks = await this.askClaudeJSON(`
Provide 3-5 notable investment opportunities on the ${exchange} for a diaspora investor:

Return JSON array:
[{
  "name": "company/REIT name",
  "ticker": "ticker symbol",
  "type": "stock/reit/etf",
  "sector": "industry",
  "currentPrice": "approximate in local currency",
  "dividendYield": "percentage if applicable",
  "marketCap": "large/mid/small",
  "thesis": "2-3 sentence investment case",
  "riskLevel": "low/medium/high"
}]

Focus on blue-chip, dividend-paying stocks accessible to overseas investors.`,
      'You are an African capital markets analyst.'
    );

    if (!Array.isArray(stocks)) return [];

    return stocks.map(stock => ({
      title: `📈 ${stock.name} (${stock.ticker}) — ${exchange}`,
      description: `${stock.sector} | ${stock.type} | Dividend: ${stock.dividendYield || 'N/A'} | ${stock.thesis}`,
      source: exchange,
      externalId: `stock-${settings.homeCountry}-${stock.ticker}`.toLowerCase(),
      metadata: { ...stock, type: 'stock_opportunity', exchange, country: settings.homeCountry },
    }));
  }

  // ===== PHASE 2: ANALYSIS =====
  async analyze(lead, config) {
    const meta = lead.metadata || {};
    const settings = { ...this.defaultAgentSettings, ...config.agentSettings };

    if (meta.type === 'remittance_comparison') {
      return { score: 80, priority: 'medium', aiRecommendation: 'watch', estimatedROI: 0, aiAnalysis: 'Rate comparison updated' };
    }

    const analysis = await this.askClaudeJSON(`
Analyze this diaspora investment opportunity:
${JSON.stringify(meta, null, 2)}

Investor lives in: ${settings.currentCountry}
Investing in: ${settings.homeCountry}
Budget: $${settings.budgetMin}-$${settings.budgetMax}

Consider: fraud risk (critical for diaspora), title verification, remote management feasibility, currency risk, legal protections, and exit strategy.

Return JSON: {
  "score": (0-100),
  "priority": ("low","medium","high","critical"),
  "recommendation": ("buy","pass","watch"),
  "estimatedROI": percentage,
  "fraudRisk": ("low","medium","high"),
  "verificationSteps": ["steps to verify this is legitimate"],
  "legalRequirements": ["legal steps needed"],
  "remoteManagementPlan": "how to manage from abroad",
  "exitStrategy": "how to exit this investment",
  "riskFactors": ["risks"],
  "analysisNotes": "summary"
}`,
      'You are a diaspora investment risk analyst. Fraud prevention is your top priority.'
    );

    return {
      score: analysis.score || 50,
      priority: analysis.priority || 'medium',
      aiRecommendation: analysis.recommendation || 'watch',
      estimatedROI: analysis.estimatedROI || 0,
      aiAnalysis: analysis.analysisNotes || '',
      metadata: { ...meta, analysis },
    };
  }

  // ===== HELPERS =====
  _getPropertyPortals(country) {
    const portals = {
      NG: [
        { name: 'Property Pro Nigeria', url: 'https://www.propertypro.ng/property-for-sale' },
        { name: 'Nigeria Property Centre', url: 'https://nigeriapropertycentre.com/for-sale' },
        { name: 'Private Property NG', url: 'https://www.privateproperty.com.ng' },
      ],
      KE: [
        { name: 'BuyRentKenya', url: 'https://www.buyrentkenya.com/houses-for-sale' },
        { name: 'Property24 Kenya', url: 'https://www.property24.co.ke/houses-for-sale' },
      ],
      GH: [
        { name: 'MeQasa', url: 'https://meqasa.com/properties-for-sale' },
        { name: 'Tonaton Property', url: 'https://tonaton.com/s_84-houses-apartments-for-sale' },
      ],
      ZA: [
        { name: 'Property24 SA', url: 'https://www.property24.com/for-sale' },
        { name: 'Private Property SA', url: 'https://www.privateproperty.co.za' },
      ],
      ET: [
        { name: 'EthioProperty', url: 'https://www.ethioproperty.com' },
      ],
      TZ: [
        { name: 'Property Bongo', url: 'https://www.propertybongo.co.tz' },
      ],
    };
    return portals[country] || [];
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = DiasporaAgent;
