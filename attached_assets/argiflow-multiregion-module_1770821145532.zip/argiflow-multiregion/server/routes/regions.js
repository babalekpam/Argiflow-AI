const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');
const { REGIONS, detectRegion, getDefaultCurrency, formatPrice, getPlanPrice } = require('../config/regions');

// Auto-detect region from request
router.get('/detect', (req, res) => {
  // Try headers first, then query param
  const countryCode = req.headers['cf-ipcountry'] || // Cloudflare
    req.headers['x-country-code'] ||
    req.query.country ||
    'US';

  const region = detectRegion(countryCode);
  const currency = getDefaultCurrency(countryCode);
  const regionConfig = REGIONS[region];

  res.json({
    region,
    country: countryCode,
    currency,
    brand: regionConfig.brand,
    tagline: regionConfig.tagline,
  });
});

// Get pricing for a region
router.get('/pricing/:region', (req, res) => {
  const { region } = req.params;
  const { currency } = req.query;
  const regionConfig = REGIONS[region];

  if (!regionConfig) {
    return res.status(404).json({ error: 'Region not found' });
  }

  const pricing = {};
  for (const [key, plan] of Object.entries(regionConfig.plans)) {
    const cur = currency || regionConfig.defaultCurrency;
    const localPrice = getPlanPrice(region, key, cur);
    pricing[key] = {
      ...plan,
      localPrice,
      formattedPrice: formatPrice(localPrice, cur),
      currency: cur,
    };
  }

  res.json({
    region,
    brand: regionConfig.brand,
    tagline: regionConfig.tagline,
    billingModel: regionConfig.billingModel,
    plans: pricing,
    paymentProcessors: regionConfig.paymentProcessors,
    agents: regionConfig.agents,
  });
});

// Get brand config for frontend
router.get('/brand', (req, res) => {
  const host = req.hostname || req.headers.host || '';

  let region = 'western';
  if (host.includes('tradeflow') || host.includes('africa')) {
    region = 'africa';
  }

  // Override with query param
  if (req.query.region === 'africa') region = 'africa';
  if (req.query.region === 'western') region = 'western';

  const config = REGIONS[region];

  res.json({
    region,
    brand: config.brand,
    tagline: config.tagline,
    billingModel: config.billingModel,
    supportedCurrencies: config.supportedCurrencies,
    paymentProcessors: config.paymentProcessors,
    mobileMoneyProviders: config.mobileMoneyProviders || {},
  });
});

// Set user region (during registration or settings)
router.patch('/set', auth, async (req, res) => {
  try {
    const { region, country, currency } = req.body;

    if (region && !REGIONS[region]) {
      return res.status(400).json({ error: 'Invalid region' });
    }

    const updates = {};
    if (region) {
      updates.region = region;
      updates.brand = region === 'africa' ? 'tradeflow' : 'argiflow';
    }
    if (country) updates.country = country;
    if (currency) updates.currency = currency;

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true }).select('-password');
    res.json({ user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
