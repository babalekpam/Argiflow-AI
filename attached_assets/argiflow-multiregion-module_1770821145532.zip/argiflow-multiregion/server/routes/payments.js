const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');
const Subscription = require('../models/Subscription');
const paymentProcessor = require('../config/payments');
const { REGIONS, getPlanPrice } = require('../config/regions');
const logger = require('../config/logger');

// ===== SUBSCRIBE — Routes to correct processor =====
router.post('/subscribe', auth, async (req, res) => {
  try {
    const { planKey, paymentData } = req.body;
    const user = req.user;
    const region = user.region || 'western';
    const regionConfig = REGIONS[region];

    if (!regionConfig?.plans[planKey]) {
      return res.status(400).json({ error: 'Invalid plan for your region' });
    }

    const plan = regionConfig.plans[planKey];
    const paymentResult = await paymentProcessor.processPayment(user, planKey, paymentData || {});

    // Create subscription record (pending until payment confirmed)
    const localPrice = getPlanPrice(region, planKey, user.currency || 'USD');
    await Subscription.create({
      userId: user._id,
      region,
      planKey,
      status: 'pending',
      billingModel: plan.successFee ? 'hybrid' : 'subscription',
      amount: localPrice,
      currency: user.currency || 'USD',
      interval: plan.interval || 'month',
      processor: paymentResult.processor,
      processorSubscriptionId: paymentResult.orderId || paymentResult.txRef || paymentResult.reference,
      successFeePercentage: plan.successFee || 0,
      agentLimit: plan.agentLimit,
      leadsPerMonth: plan.leadsPerMonth,
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    });

    res.json({
      success: true,
      paymentResult,
      plan: { ...plan, localPrice, currency: user.currency },
    });
  } catch (err) {
    logger.error('Payment error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ===== VENMO: Direct link generator (lightweight option) =====
router.get('/venmo-link', auth, async (req, res) => {
  try {
    const { planKey } = req.query;
    const plan = REGIONS.western.plans[planKey];
    if (!plan) return res.status(400).json({ error: 'Invalid plan' });

    const amount = getPlanPrice('western', planKey, 'USD');
    const note = `ArgiFlow ${plan.name} Plan — ${req.user.email}`;
    const links = paymentProcessor.generateVenmoDirectLink(amount, note);

    res.json({ ...links, amount, plan: plan.name });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== VENMO: Capture after user approves =====
router.post('/venmo/capture', auth, async (req, res) => {
  try {
    const { orderId } = req.body;
    if (!orderId) return res.status(400).json({ error: 'orderId required' });

    const result = await paymentProcessor.captureVenmoPayment(orderId);

    if (result.status === 'COMPLETED') {
      // Activate subscription
      const sub = await Subscription.findOne({ userId: req.user._id, status: 'pending' }).sort({ createdAt: -1 });
      if (sub) {
        sub.status = 'active';
        sub.payments.push({
          amount: sub.amount,
          currency: 'USD',
          processor: 'venmo',
          reference: result.orderId,
          status: 'completed',
          paidAt: new Date(),
          method: 'venmo',
        });
        await sub.save();

        await User.findByIdAndUpdate(req.user._id, {
          paymentProcessor: 'venmo',
          subscriptionStatus: 'active',
          plan: sub.planKey,
          planKey: sub.planKey,
        });
      }
    }

    res.json({ success: true, result });
  } catch (err) {
    logger.error('Venmo capture error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ===== PAYPAL/VENMO WEBHOOK =====
router.post('/webhook/paypal', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const event = req.body;

    // Verify webhook signature (production)
    // const isValid = await verifyPayPalWebhook(req);
    // if (!isValid) return res.status(401).json({ error: 'Invalid webhook' });

    if (event.event_type === 'CHECKOUT.ORDER.APPROVED' || event.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
      const resource = event.resource;
      const customId = resource.purchase_units?.[0]?.custom_id;

      if (customId) {
        try {
          const { userId, planKey } = JSON.parse(customId);
          const sub = await Subscription.findOne({ userId, status: 'pending' }).sort({ createdAt: -1 });
          if (sub) {
            sub.status = 'active';
            sub.payments.push({
              amount: parseFloat(resource.purchase_units?.[0]?.amount?.value || sub.amount),
              currency: 'USD',
              processor: 'venmo',
              reference: resource.id,
              status: 'completed',
              paidAt: new Date(),
              method: resource.payment_source?.venmo ? 'venmo' : 'paypal',
            });
            await sub.save();

            await User.findByIdAndUpdate(userId, {
              paymentProcessor: 'venmo',
              subscriptionStatus: 'active',
              plan: sub.planKey,
              planKey: sub.planKey,
            });
          }
        } catch (parseErr) {
          logger.warn('Could not parse custom_id:', customId);
        }
      }
    }

    res.status(200).json({ status: 'ok' });
  } catch (err) {
    logger.error('PayPal/Venmo webhook error:', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// ===== FLUTTERWAVE WEBHOOK (Africa) =====
router.post('/webhook/flutterwave', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const event = req.body;
    const secretHash = process.env.FLUTTERWAVE_WEBHOOK_SECRET;

    if (secretHash && req.headers['verif-hash'] !== secretHash) {
      return res.status(401).json({ error: 'Invalid webhook' });
    }

    if (event.event === 'charge.completed' && event.data.status === 'successful') {
      const meta = event.data.meta || event.data.customer?.meta;
      const userId = meta?.userId;

      if (userId) {
        const sub = await Subscription.findOne({ userId, status: 'pending' }).sort({ createdAt: -1 });
        if (sub) {
          sub.status = 'active';
          sub.payments.push({
            amount: event.data.amount,
            currency: event.data.currency,
            processor: 'flutterwave',
            reference: event.data.tx_ref,
            status: 'completed',
            paidAt: new Date(),
            method: event.data.payment_type, // card, mpesa, mtn_momo, etc.
          });
          await sub.save();

          await User.findByIdAndUpdate(userId, {
            paymentProcessor: 'flutterwave',
            subscriptionStatus: 'active',
            plan: sub.planKey,
            planKey: sub.planKey,
            flutterwaveToken: event.data.card?.token || null,
          });
        }
      }
    }

    res.status(200).json({ status: 'ok' });
  } catch (err) {
    logger.error('Flutterwave webhook error:', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// ===== PAYSTACK WEBHOOK (Africa — NG, GH, ZA, KE) =====
router.post('/webhook/paystack', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const crypto = require('crypto');
    const hash = crypto.createHmac('sha512', process.env.PAYSTACK_SECRET_KEY)
      .update(JSON.stringify(req.body)).digest('hex');

    if (hash !== req.headers['x-paystack-signature']) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    const event = req.body;

    if (event.event === 'charge.success') {
      const meta = event.data.metadata;
      const userId = meta?.userId;

      if (userId) {
        const sub = await Subscription.findOne({ userId, status: 'pending' }).sort({ createdAt: -1 });
        if (sub) {
          sub.status = 'active';
          sub.payments.push({
            amount: event.data.amount / 100,
            currency: event.data.currency,
            processor: 'paystack',
            reference: event.data.reference,
            status: 'completed',
            paidAt: new Date(),
            method: event.data.channel, // card, bank, ussd, mobile_money
          });
          await sub.save();

          await User.findByIdAndUpdate(userId, {
            paymentProcessor: 'paystack',
            subscriptionStatus: 'active',
            plan: sub.planKey,
            planKey: sub.planKey,
            paystackAuthCode: event.data.authorization?.authorization_code,
          });
        }
      }
    }

    res.status(200).json({ status: 'ok' });
  } catch (err) {
    logger.error('Paystack webhook error:', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// ===== GET SUBSCRIPTION STATUS =====
router.get('/status', auth, async (req, res) => {
  try {
    const sub = await Subscription.findOne({ userId: req.user._id }).sort({ createdAt: -1 });
    const pricing = req.user.getPricing();
    res.json({ subscription: sub, pricing, region: req.user.region });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
