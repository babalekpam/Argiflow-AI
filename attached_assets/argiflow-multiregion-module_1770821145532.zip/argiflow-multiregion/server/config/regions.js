/**
 * ArgiFlow Multi-Region Configuration
 * Defines regions, pricing, currencies, and available agents per region
 */

const REGIONS = {
  western: {
    id: 'western',
    brand: 'ArgiFlow',
    tagline: 'AI Agents That Make You Money While You Sleep',
    domains: ['argiflow.co', 'app.argiflow.co'],
    countries: [
      'US', 'CA', 'GB', 'DE', 'FR', 'AU', 'NZ', 'IE', 'NL', 'BE',
      'CH', 'AT', 'SE', 'NO', 'DK', 'FI', 'IT', 'ES', 'PT', 'JP',
      'KR', 'SG', 'AE', 'IL', 'SA', 'QA',
    ],
    defaultCurrency: 'USD',
    supportedCurrencies: ['USD', 'EUR', 'GBP', 'CAD', 'AUD'],
    paymentProcessors: ['venmo'],
    billingModel: 'subscription', // monthly subscription
    agents: [
      'tax-lien', 'tax-deed', 'wholesale-re', 'govt-contracts-us',
      'arbitrage', 'lead-gen', 'domain-flip', 'recruiting',
    ],
    plans: {
      starter: {
        name: 'Starter',
        price: { USD: 97, EUR: 89, GBP: 79 },
        interval: 'month',
        agentLimit: 1,
        leadsPerMonth: 100,
        features: ['1 AI Agent', '100 leads/month', 'Email notifications', 'Basic dashboard'],
      },
      pro: {
        name: 'Pro',
        price: { USD: 297, EUR: 269, GBP: 239 },
        interval: 'month',
        agentLimit: 3,
        leadsPerMonth: 500,
        features: ['3 AI Agents', '500 leads/month', 'SMS + Email alerts', 'Pipeline view', 'Auto-bidding', 'Priority support'],
      },
      enterprise: {
        name: 'Enterprise',
        price: { USD: 497, EUR: 449, GBP: 399 },
        interval: 'month',
        agentLimit: -1, // unlimited
        leadsPerMonth: -1,
        features: ['Unlimited Agents', 'Unlimited leads', 'All channels', 'API access', 'Custom agents', 'Dedicated support', 'White-label option'],
      },
    },
  },

  africa: {
    id: 'africa',
    brand: 'TradeFlow',
    tagline: 'AI-Powered Business Automation for African Entrepreneurs',
    domains: ['tradeflow.africa', 'app.tradeflow.africa'],
    countries: [
      'NG', 'KE', 'GH', 'ZA', 'TZ', 'UG', 'RW', 'ET', 'SN', 'CI',
      'CM', 'CD', 'AO', 'MZ', 'ZM', 'ZW', 'MW', 'BW', 'NA', 'MU',
      'MA', 'TN', 'EG', 'DZ', 'ML', 'BF', 'NE', 'TG', 'BJ', 'GA',
      'CG', 'MG', 'SC', 'LS', 'SZ', 'GM', 'SL', 'LR', 'GN', 'SS',
    ],
    defaultCurrency: 'USD',
    supportedCurrencies: ['USD', 'NGN', 'KES', 'GHS', 'ZAR', 'TZS', 'UGX', 'XOF', 'XAF', 'EGP', 'MAD'],
    paymentProcessors: ['flutterwave', 'paystack'],
    billingModel: 'hybrid', // subscription + success fees
    agents: [
      'govt-tender-africa', 'cross-border-trade', 'agri-market',
      'diaspora-services', 'forex-monitor', 'solar-energy',
      'commodity-trading', 'skills-freelance',
    ],
    plans: {
      hustle: {
        name: 'Hustle',
        price: { USD: 5, NGN: 5000, KES: 700, GHS: 60, ZAR: 90 },
        interval: 'month',
        agentLimit: 1,
        leadsPerMonth: 50,
        successFee: 5, // 5% of deals/tenders won
        features: ['1 AI Agent', '50 leads/month', 'WhatsApp alerts', 'Mobile dashboard'],
      },
      business: {
        name: 'Business',
        price: { USD: 15, NGN: 15000, KES: 2100, GHS: 180, ZAR: 270 },
        interval: 'month',
        agentLimit: 3,
        leadsPerMonth: 200,
        successFee: 3,
        features: ['3 AI Agents', '200 leads/month', 'WhatsApp + SMS alerts', 'Full dashboard', 'Tender auto-apply', 'Trade matching'],
      },
      mogul: {
        name: 'Mogul',
        price: { USD: 25, NGN: 25000, KES: 3500, GHS: 300, ZAR: 450 },
        interval: 'month',
        agentLimit: -1,
        leadsPerMonth: -1,
        successFee: 2,
        features: ['Unlimited Agents', 'Unlimited leads', 'All channels', 'Priority matching', 'Diaspora connect', 'API access', 'Dedicated support'],
      },
      payPerResult: {
        name: 'Pay Per Result',
        price: { USD: 0 },
        interval: 'none',
        agentLimit: 1,
        leadsPerMonth: 20,
        successFee: 8, // higher fee but no monthly cost
        features: ['1 AI Agent', '20 leads/month', 'WhatsApp alerts', 'No monthly fee', 'Pay only when you earn'],
      },
    },

    // Mobile money configs per country
    mobileMoneyProviders: {
      KE: ['mpesa', 'airtel_money'],
      TZ: ['mpesa', 'tigo_pesa', 'airtel_money'],
      UG: ['mtn_momo', 'airtel_money'],
      GH: ['mtn_momo', 'vodafone_cash', 'airteltigo'],
      NG: ['opay', 'palmpay', 'bank_transfer'],
      RW: ['mtn_momo', 'airtel_money'],
      SN: ['orange_money', 'wave'],
      CI: ['orange_money', 'mtn_momo', 'wave'],
      CM: ['mtn_momo', 'orange_money'],
      ZA: ['bank_transfer', 'snapscan'],
    },
  },
};

// Currency formatting
const CURRENCY_CONFIG = {
  USD: { symbol: '$', locale: 'en-US', decimals: 2 },
  EUR: { symbol: '€', locale: 'de-DE', decimals: 2 },
  GBP: { symbol: '£', locale: 'en-GB', decimals: 2 },
  NGN: { symbol: '₦', locale: 'en-NG', decimals: 0 },
  KES: { symbol: 'KSh', locale: 'en-KE', decimals: 0 },
  GHS: { symbol: 'GH₵', locale: 'en-GH', decimals: 0 },
  ZAR: { symbol: 'R', locale: 'en-ZA', decimals: 0 },
  TZS: { symbol: 'TSh', locale: 'en-TZ', decimals: 0 },
  UGX: { symbol: 'USh', locale: 'en-UG', decimals: 0 },
  XOF: { symbol: 'CFA', locale: 'fr-SN', decimals: 0 },
  XAF: { symbol: 'FCFA', locale: 'fr-CM', decimals: 0 },
  EGP: { symbol: 'E£', locale: 'ar-EG', decimals: 0 },
  MAD: { symbol: 'MAD', locale: 'ar-MA', decimals: 0 },
  CAD: { symbol: 'C$', locale: 'en-CA', decimals: 2 },
  AUD: { symbol: 'A$', locale: 'en-AU', decimals: 2 },
};

// Detect region from country code
function detectRegion(countryCode) {
  if (REGIONS.africa.countries.includes(countryCode)) return 'africa';
  if (REGIONS.western.countries.includes(countryCode)) return 'western';
  return 'western'; // default
}

// Get currency for country
function getDefaultCurrency(countryCode) {
  const currencyMap = {
    US: 'USD', CA: 'CAD', GB: 'GBP', AU: 'AUD', NZ: 'AUD',
    DE: 'EUR', FR: 'EUR', IT: 'EUR', ES: 'EUR', NL: 'EUR', BE: 'EUR',
    AT: 'EUR', IE: 'EUR', PT: 'EUR', FI: 'EUR',
    NG: 'NGN', KE: 'KES', GH: 'GHS', ZA: 'ZAR', TZ: 'TZS',
    UG: 'UGX', SN: 'XOF', CI: 'XOF', CM: 'XAF', EG: 'EGP', MA: 'MAD',
  };
  return currencyMap[countryCode] || 'USD';
}

// Format price in local currency
function formatPrice(amount, currencyCode) {
  const config = CURRENCY_CONFIG[currencyCode] || CURRENCY_CONFIG.USD;
  return `${config.symbol}${amount.toLocaleString(config.locale, {
    minimumFractionDigits: config.decimals,
    maximumFractionDigits: config.decimals,
  })}`;
}

// Get plan price in user's currency
function getPlanPrice(region, planKey, currencyCode) {
  const plan = REGIONS[region]?.plans[planKey];
  if (!plan) return null;
  return plan.price[currencyCode] || plan.price.USD;
}

module.exports = {
  REGIONS,
  CURRENCY_CONFIG,
  detectRegion,
  getDefaultCurrency,
  formatPrice,
  getPlanPrice,
};
