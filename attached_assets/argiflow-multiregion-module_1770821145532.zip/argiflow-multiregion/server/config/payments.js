/**
 * ArgiFlow Multi-Payment Processor
 * Venmo/PayPal (US/Western) | Flutterwave & Paystack (Africa)
 */

const logger = require('./logger');

class PaymentProcessor {

  // ============ VENMO (US / Western Markets) ============

  /**
   * Venmo payments via PayPal API (Venmo runs on PayPal infrastructure)
   * Requires PayPal Business account with Venmo enabled
   */
  async createVenmoPayment(user, planKey, returnUrl) {
    const { REGIONS, getPlanPrice } = require('./regions');
    const plan = REGIONS.western.plans[planKey];
    if (!plan) throw new Error('Invalid plan');

    const amount = getPlanPrice('western', planKey, 'USD');

    const paypal = require('@paypal/checkout-server-sdk');
    const environment = process.env.PAYPAL_MODE === 'live'
      ? new paypal.core.LiveEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_SECRET)
      : new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_SECRET);
    const client = new paypal.core.PayPalHttpClient(environment);

    const request = new paypal.orders.OrdersCreateRequest();
    request.prefer('return=representation');
    request.requestBody({
      intent: 'CAPTURE',
      purchase_units: [{
        amount: {
          currency_code: 'USD',
          value: amount.toFixed(2),
        },
        description: `ArgiFlow ${plan.name} Plan — Monthly`,
        custom_id: JSON.stringify({ userId: user._id.toString(), planKey }),
      }],
      payment_source: {
        venmo: {
          experience_context: {
            brand_name: 'ArgiFlow',
            shipping_preference: 'NO_SHIPPING',
            user_action: 'PAY_NOW',
            return_url: returnUrl || `${process.env.APP_URL}/payment/success`,
            cancel_url: `${process.env.APP_URL}/payment/cancel`,
          },
        },
      },
      application_context: {
        brand_name: 'ArgiFlow',
        landing_page: 'NO_PREFERENCE',
        user_action: 'PAY_NOW',
        return_url: returnUrl || `${process.env.APP_URL}/payment/success`,
        cancel_url: `${process.env.APP_URL}/payment/cancel`,
      },
    });

    const response = await client.execute(request);
    const approvalLink = response.result.links.find(l => l.rel === 'approve')?.href;

    return {
      processor: 'venmo',
      orderId: response.result.id,
      status: response.result.status,
      approvalUrl: approvalLink,
    };
  }

  async captureVenmoPayment(orderId) {
    const paypal = require('@paypal/checkout-server-sdk');
    const environment = process.env.PAYPAL_MODE === 'live'
      ? new paypal.core.LiveEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_SECRET)
      : new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_SECRET);
    const client = new paypal.core.PayPalHttpClient(environment);

    const request = new paypal.orders.OrdersCaptureRequest(orderId);
    request.requestBody({});
    const response = await client.execute(request);

    return {
      processor: 'venmo',
      orderId: response.result.id,
      status: response.result.status,
      captureId: response.result.purchase_units?.[0]?.payments?.captures?.[0]?.id,
      payerEmail: response.result.payer?.email_address,
      payerVenmo: response.result.payment_source?.venmo?.email,
    };
  }

  /**
   * Venmo direct link — lightweight option for manual payments
   * User clicks link → opens Venmo app → sends payment
   * Good for initial MVP before full PayPal API integration
   */
  generateVenmoDirectLink(amount, note) {
    const handle = process.env.VENMO_HANDLE;
    return {
      mobileLink: `venmo://paycharge?txn=pay&recipients=${handle}&amount=${amount}&note=${encodeURIComponent(note)}`,
      webLink: `https://venmo.com/${handle}?txn=pay&amount=${amount}&note=${encodeURIComponent(note)}`,
    };
  }

  // ============ FLUTTERWAVE (Africa — Primary) ============

  async createFlutterwavePayment(user, planKey, paymentData) {
    const Flutterwave = require('flutterwave-node-v3');
    const flw = new Flutterwave(
      process.env.FLUTTERWAVE_PUBLIC_KEY,
      process.env.FLUTTERWAVE_SECRET_KEY
    );
    const { REGIONS, getPlanPrice } = require('./regions');
    const plan = REGIONS.africa.plans[planKey];
    if (!plan) throw new Error('Invalid plan');

    const amount = getPlanPrice('africa', planKey, user.currency || 'USD');
    const txRef = `tf-${user._id}-${Date.now()}`;
    const paymentMethod = this._getAfricanPaymentMethod(user.country, paymentData);

    const payload = {
      tx_ref: txRef,
      amount,
      currency: user.currency || 'USD',
      email: user.email,
      fullname: user.name,
      phone_number: user.phone,
      meta: {
        userId: user._id.toString(),
        plan: planKey,
        region: 'africa',
      },
      customizations: {
        title: 'TradeFlow Subscription',
        description: `${plan.name} Plan — Monthly`,
        logo: 'https://tradeflow.africa/logo.png',
      },
    };

    let response;

    switch (paymentMethod) {
      case 'mobile_money_kenya':
        response = await flw.MobileMoney.mpesa({ ...payload, phone_number: paymentData.phone });
        break;
      case 'mobile_money_ghana':
        response = await flw.MobileMoney.ghana({ ...payload, phone_number: paymentData.phone, network: paymentData.network || 'MTN' });
        break;
      case 'mobile_money_uganda':
        response = await flw.MobileMoney.uganda({ ...payload, phone_number: paymentData.phone, network: paymentData.network || 'MTN' });
        break;
      case 'mobile_money_francophone':
        response = await flw.MobileMoney.franco_mobile({ ...payload, phone_number: paymentData.phone, country: user.country });
        break;
      case 'bank_transfer_ng':
        response = await flw.Charge.bank_transfer({ ...payload, is_permanent: true });
        break;
      case 'card':
      default:
        response = await flw.Payment.create({
          ...payload,
          redirect_url: `${process.env.APP_URL}/payment/callback`,
          payment_options: 'card,mobilemoney,ussd,banktransfer',
        });
        break;
    }

    return {
      processor: 'flutterwave',
      txRef,
      status: response.status,
      data: response.data,
      paymentLink: response.data?.link || null,
    };
  }

  async verifyFlutterwavePayment(transactionId) {
    const Flutterwave = require('flutterwave-node-v3');
    const flw = new Flutterwave(process.env.FLUTTERWAVE_PUBLIC_KEY, process.env.FLUTTERWAVE_SECRET_KEY);
    return flw.Transaction.verify({ id: transactionId });
  }

  // ============ PAYSTACK (Nigeria, Ghana, SA, Kenya) ============

  async createPaystackPayment(user, planKey) {
    const paystack = require('paystack-node');
    const client = new paystack(process.env.PAYSTACK_SECRET_KEY);
    const { REGIONS, getPlanPrice } = require('./regions');
    const plan = REGIONS.africa.plans[planKey];
    if (!plan) throw new Error('Invalid plan');

    const amount = getPlanPrice('africa', planKey, user.currency || 'NGN');
    const multiplier = ['NGN', 'GHS', 'ZAR', 'KES'].includes(user.currency) ? 100 : 1;

    const response = await client.initializeTransaction({
      email: user.email,
      amount: Math.round(amount * multiplier),
      currency: user.currency || 'NGN',
      reference: `tf-${user._id}-${Date.now()}`,
      callback_url: `${process.env.APP_URL}/payment/callback`,
      metadata: {
        userId: user._id.toString(),
        plan: planKey,
        custom_fields: [
          { display_name: 'Plan', variable_name: 'plan', value: plan.name },
        ],
      },
    });

    return {
      processor: 'paystack',
      reference: response.body.data.reference,
      authorizationUrl: response.body.data.authorization_url,
      accessCode: response.body.data.access_code,
    };
  }

  async verifyPaystackPayment(reference) {
    const paystack = require('paystack-node');
    const client = new paystack(process.env.PAYSTACK_SECRET_KEY);
    return client.verifyTransaction({ reference });
  }

  // ============ SUCCESS FEE (Africa — Pay Per Result) ============

  async chargeSuccessFee(user, dealAmount, agentType) {
    const { REGIONS } = require('./regions');
    const Subscription = require('../models/Subscription');

    const sub = await Subscription.findOne({ userId: user._id, status: 'active' });
    if (!sub) return null;

    const plan = REGIONS.africa.plans[sub.planKey];
    if (!plan || !plan.successFee) return null;

    const feeAmount = dealAmount * (plan.successFee / 100);
    logger.info(`[payments] Success fee: ${plan.successFee}% of $${dealAmount} = $${feeAmount} for user ${user._id}`);

    if (user.paymentProcessor === 'flutterwave' && user.flutterwaveToken) {
      const Flutterwave = require('flutterwave-node-v3');
      const flw = new Flutterwave(process.env.FLUTTERWAVE_PUBLIC_KEY, process.env.FLUTTERWAVE_SECRET_KEY);

      const response = await flw.Tokenized.charge({
        token: user.flutterwaveToken,
        currency: user.currency || 'USD',
        amount: feeAmount,
        email: user.email,
        tx_ref: `fee-${user._id}-${Date.now()}`,
        narration: `TradeFlow success fee — ${agentType}`,
      });

      return { processor: 'flutterwave', amount: feeAmount, percentage: plan.successFee, dealAmount, status: response.status };
    }

    return { processor: 'manual', amount: feeAmount, percentage: plan.successFee, dealAmount, status: 'pending_collection' };
  }

  // ============ SMART ROUTING ============

  async processPayment(user, planKey, paymentData = {}) {
    const { detectRegion } = require('./regions');
    const region = user.region || detectRegion(user.country);

    // US/Western → Venmo
    if (region === 'western') {
      return this.createVenmoPayment(user, planKey, paymentData.returnUrl);
    }

    // Africa → Paystack first (for NG, GH, ZA, KE), fallback to Flutterwave
    const paystackCountries = ['NG', 'GH', 'ZA', 'KE'];
    if (paystackCountries.includes(user.country)) {
      try {
        return await this.createPaystackPayment(user, planKey);
      } catch (err) {
        logger.warn(`Paystack failed for ${user.country}, falling back to Flutterwave:`, err.message);
      }
    }

    return await this.createFlutterwavePayment(user, planKey, paymentData);
  }

  // ============ HELPERS ============

  _getAfricanPaymentMethod(country, paymentData) {
    if (paymentData?.method) return paymentData.method;
    const methodMap = {
      KE: 'mobile_money_kenya', TZ: 'mobile_money_kenya',
      GH: 'mobile_money_ghana',
      UG: 'mobile_money_uganda', RW: 'mobile_money_uganda',
      SN: 'mobile_money_francophone', CI: 'mobile_money_francophone', CM: 'mobile_money_francophone',
      NG: 'bank_transfer_ng',
      ZA: 'card',
    };
    return methodMap[country] || 'card';
  }
}

module.exports = new PaymentProcessor();
