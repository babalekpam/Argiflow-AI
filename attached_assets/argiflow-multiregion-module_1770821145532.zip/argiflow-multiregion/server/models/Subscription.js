const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  region: { type: String, enum: ['western', 'africa'], required: true },
  planKey: { type: String, required: true },

  // Status
  status: {
    type: String,
    enum: ['active', 'past_due', 'cancelled', 'expired', 'trialing', 'paused'],
    default: 'active',
  },

  // Billing
  billingModel: { type: String, enum: ['subscription', 'payPerResult', 'hybrid'], default: 'subscription' },
  amount: Number,
  currency: { type: String, default: 'USD' },
  interval: { type: String, enum: ['month', 'year', 'none'], default: 'month' },

  // Payment processor refs
  processor: { type: String, enum: ['venmo', 'flutterwave', 'paystack', 'manual'] },
  processorSubscriptionId: String,
  processorCustomerId: String,

  // Success fee tracking (Africa)
  successFeePercentage: { type: Number, default: 0 },
  totalSuccessFees: { type: Number, default: 0 },
  pendingSuccessFees: { type: Number, default: 0 },
  successFeeHistory: [{
    amount: Number,
    dealAmount: Number,
    agentType: String,
    chargedAt: Date,
    status: { type: String, enum: ['charged', 'pending', 'failed', 'waived'] },
    reference: String,
  }],

  // Limits
  agentLimit: Number,
  leadsPerMonth: Number,
  leadsUsedThisMonth: { type: Number, default: 0 },

  // Dates
  currentPeriodStart: Date,
  currentPeriodEnd: Date,
  trialEnd: Date,
  cancelledAt: Date,

  // Payment history
  payments: [{
    amount: Number,
    currency: String,
    processor: String,
    reference: String,
    status: String,
    paidAt: Date,
    method: String, // card, mpesa, mtn_momo, bank_transfer, etc.
  }],

}, { timestamps: true });

subscriptionSchema.index({ userId: 1, status: 1 });

// Check if user is within limits
subscriptionSchema.methods.canAddAgent = function(currentCount) {
  if (this.agentLimit === -1) return true;
  return currentCount < this.agentLimit;
};

subscriptionSchema.methods.canGetMoreLeads = function() {
  if (this.leadsPerMonth === -1) return true;
  return this.leadsUsedThisMonth < this.leadsPerMonth;
};

// Record a success fee
subscriptionSchema.methods.recordSuccessFee = async function(dealAmount, agentType) {
  if (this.successFeePercentage <= 0) return null;

  const feeAmount = dealAmount * (this.successFeePercentage / 100);
  this.successFeeHistory.push({
    amount: feeAmount,
    dealAmount,
    agentType,
    chargedAt: new Date(),
    status: 'pending',
  });
  this.pendingSuccessFees += feeAmount;
  this.totalSuccessFees += feeAmount;
  await this.save();
  return feeAmount;
};

// Reset monthly counters
subscriptionSchema.methods.resetMonthly = async function() {
  this.leadsUsedThisMonth = 0;
  this.currentPeriodStart = new Date();
  const end = new Date();
  end.setMonth(end.getMonth() + 1);
  this.currentPeriodEnd = end;
  await this.save();
};

module.exports = mongoose.model('Subscription', subscriptionSchema);
