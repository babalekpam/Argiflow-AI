const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6 },
  phone: { type: String },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },

  // ===== MULTI-REGION FIELDS =====
  region: {
    type: String,
    enum: ['western', 'africa'],
    default: 'western',
  },
  country: { type: String, maxlength: 2 }, // ISO 3166-1 alpha-2
  currency: { type: String, default: 'USD' },
  language: { type: String, default: 'en' },
  timezone: { type: String, default: 'UTC' },

  // Brand the user signed up through
  brand: { type: String, enum: ['argiflow', 'tradeflow'], default: 'argiflow' },

  // Subscription (replaces old plan field)
  plan: {
    type: String,
    enum: ['free', 'starter', 'pro', 'enterprise', 'hustle', 'business', 'mogul', 'payPerResult'],
    default: 'free'
  },
  planKey: String,

  // Payment processors
  paymentProcessor: { type: String, enum: ['venmo', 'flutterwave', 'paystack', 'none'], default: 'none' },
  venmoHandle: String,
  venmoOrderId: String, // Last PayPal/Venmo order
  subscriptionId: String,
  subscriptionStatus: { type: String, default: 'inactive' },
  flutterwaveToken: String, // Saved payment token for recurring charges
  paystackAuthCode: String,

  // Active agents for this user
  activeAgents: [{
    agentType: String,
    enabled: { type: Boolean, default: false },
    configId: { type: mongoose.Schema.Types.ObjectId, ref: 'AgentConfig' }
  }],

  // Notification preferences
  notifications: {
    email: { type: Boolean, default: true },
    sms: { type: Boolean, default: false },
    whatsapp: { type: Boolean, default: false }, // Big in Africa
    push: { type: Boolean, default: true },
    frequency: { type: String, enum: ['instant', 'hourly', 'daily'], default: 'instant' }
  },

  // Business profile (for matching agents)
  businessProfile: {
    businessName: String,
    businessType: String, // sole_proprietor, llc, corporation, cooperative, ngo
    industry: String,
    registrationNumber: String, // CAC (Nigeria), KRA (Kenya), etc.
    annualRevenue: String,
    employeeCount: String,
    exportCapable: Boolean,
    // Africa-specific
    cooperativeMember: Boolean,
    mobileMoneyAgent: Boolean,
    diasporaMember: Boolean,
    homeCountry: String, // For diaspora — which country they want to invest in
  },

  // Stats
  totalDeals: { type: Number, default: 0 },
  totalInvested: { type: Number, default: 0 },
  totalProfit: { type: Number, default: 0 },
  successFeesOwed: { type: Number, default: 0 },
  successFeesPaid: { type: Number, default: 0 },

  // Referral system
  referralCode: { type: String, unique: true, sparse: true },
  referredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  referralCount: { type: Number, default: 0 },

  lastLogin: Date,
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

// Hash password
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);

  // Auto-generate referral code
  if (!this.referralCode) {
    this.referralCode = this.name.split(' ')[0].toLowerCase() + '-' +
      Math.random().toString(36).substring(2, 8);
  }

  next();
});

// Compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Generate JWT
userSchema.methods.generateToken = function() {
  return jwt.sign(
    { id: this._id, region: this.region, brand: this.brand },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '30d' }
  );
};

// Get available agents for this user's region
userSchema.methods.getAvailableAgents = function() {
  const { REGIONS } = require('../config/regions');
  return REGIONS[this.region]?.agents || [];
};

// Get pricing for this user's region and currency
userSchema.methods.getPricing = function() {
  const { REGIONS, getPlanPrice } = require('../config/regions');
  const region = REGIONS[this.region];
  if (!region) return {};

  const pricing = {};
  for (const [key, plan] of Object.entries(region.plans)) {
    pricing[key] = {
      ...plan,
      localPrice: getPlanPrice(this.region, key, this.currency),
      currency: this.currency,
    };
  }
  return pricing;
};

module.exports = mongoose.model('User', userSchema);
