/**
 * ============================================================
 *  ArgiFlow — Lead Generation Routes
 *  Plug-in module for your existing Express server
 *
 *  HOW TO ADD TO ARGIFLOW:
 *    const leadsRouter = require('./argiflow-leads/routes/leads');
 *    app.use('/api/leads', leadsRouter);
 *
 *  All endpoints require req.user (your existing JWT auth).
 * ============================================================
 */

const express = require('express');
const router  = express.Router();
const NodeCache = require('node-cache');

const {
  searchLeads,
  enrichCompany,
  findContact,
  searchLocal,
  scrapeYellowPages,
  searchLinkedIn,
  verifyEmail,
  generateEmailPatterns,
  findVerifiedEmails,
  cleanDomain,
} = require('../engine/free-scraper');

// Cache: reduces repeat scraping, protects from rate limits
const cache = new NodeCache({ stdTTL: 3600, checkperiod: 300 });

// Optional Hunter.io free key (25 searches/mo — set in your .env)
const HUNTER_KEY = process.env.HUNTER_API_KEY || null;

// ─── Simple auth guard (wire to your own middleware) ──────────────────────
// Replace this with your existing JWT/session middleware
function auth(req, res, next) {
  // If ArgiFlow already attaches req.user, just call next()
  // Otherwise do your own auth check here
  if (!req.user && process.env.NODE_ENV === 'production') {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// ════════════════════════════════════════════════════════════
//  GET /api/leads/search
//  Find B2B companies — no paid APIs
// ════════════════════════════════════════════════════════════
router.get('/search', auth, async (req, res) => {
  const { q = '', industry = '', location = '', size = '', limit = 20 } = req.query;

  if (!q && !industry && !location) {
    return res.status(400).json({ error: 'Provide q, industry, or location' });
  }

  const key = `search:${q}:${industry}:${location}:${limit}`;
  const hit = cache.get(key);
  if (hit) return res.json({ ...hit, cached: true });

  try {
    const leads = await searchLeads({
      q, industry, location, size,
      limit: Math.min(parseInt(limit) || 20, 50),
    });

    const result = {
      query: { q, industry, location, size },
      total: leads.length,
      leads,
      timestamp: new Date().toISOString(),
    };

    cache.set(key, result, 1800); // cache 30 min
    res.json(result);
  } catch (err) {
    console.error('[leads/search]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/local
//  Local business search — Yellow Pages + Manta + web
// ════════════════════════════════════════════════════════════
router.get('/local', auth, async (req, res) => {
  const { type, city, state = '', limit = 25 } = req.query;
  if (!type || !city) return res.status(400).json({ error: 'type and city are required' });

  const key = `local:${type}:${city}:${state}:${limit}`;
  const hit = cache.get(key);
  if (hit) return res.json({ ...hit, cached: true });

  try {
    const result = await searchLocal(type, city, state, parseInt(limit) || 25);
    cache.set(key, result, 3600);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/enrich?domain=acme.com
//  Full company enrichment — website + RDAP + DNS
// ════════════════════════════════════════════════════════════
router.get('/enrich', auth, async (req, res) => {
  const { domain } = req.query;
  if (!domain) return res.status(400).json({ error: 'domain is required' });

  const clean = cleanDomain(domain);
  const key   = `enrich:${clean}`;
  const hit   = cache.get(key);
  if (hit) return res.json({ ...hit, cached: true });

  try {
    const data = await enrichCompany(clean, { hunterKey: HUNTER_KEY });
    cache.set(key, data, 7200);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/contact?firstName=John&lastName=Smith&domain=acme.com
//  Find a contact's email + LinkedIn profile — no cost
// ════════════════════════════════════════════════════════════
router.get('/contact', auth, async (req, res) => {
  const { firstName, lastName, domain, company = '', title = '' } = req.query;

  if (!firstName || !lastName || !domain) {
    return res.status(400).json({ error: 'firstName, lastName, and domain are required' });
  }

  const key = `contact:${firstName}:${lastName}:${cleanDomain(domain)}`;
  const hit = cache.get(key);
  if (hit) return res.json({ ...hit, cached: true });

  try {
    const data = await findContact(firstName, lastName, domain, {
      company, title, hunterKey: HUNTER_KEY,
    });
    cache.set(key, data, 7200);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/emails?domain=acme.com
//  Get all emails for a domain (MX-verified patterns + Hunter)
// ════════════════════════════════════════════════════════════
router.get('/emails', auth, async (req, res) => {
  const { domain, firstName, lastName } = req.query;
  if (!domain) return res.status(400).json({ error: 'domain is required' });

  const clean = cleanDomain(domain);

  try {
    let emails = [];
    if (firstName && lastName) {
      emails = await findVerifiedEmails(firstName, lastName, clean);
    } else {
      // Generate common pattern variants and verify MX
      const commonFirst = ['info', 'contact', 'hello', 'admin', 'sales'];
      const checks = commonFirst.map(f => `${f}@${clean}`);
      const verified = await Promise.all(checks.map(async e => ({
        email: e, mxVerified: await verifyEmail(e), src: 'pattern'
      })));
      emails = verified.filter(e => e.mxVerified);
    }

    res.json({ domain: clean, emails, total: emails.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════
//  POST /api/leads/verify
//  Verify a list of emails via MX (free, unlimited)
// ════════════════════════════════════════════════════════════
router.post('/verify', auth, async (req, res) => {
  const { emails = [] } = req.body;
  if (!Array.isArray(emails) || emails.length === 0)
    return res.status(400).json({ error: 'emails array required' });
  if (emails.length > 200)
    return res.status(400).json({ error: 'Max 200 emails per request' });

  const results = await Promise.all(
    emails.map(async (email) => ({
      email,
      mxVerified: await verifyEmail(email),
      domain: email.split('@')[1] || null,
    }))
  );

  res.json({
    total: results.length,
    valid: results.filter(r => r.mxVerified).length,
    invalid: results.filter(r => !r.mxVerified).length,
    results,
  });
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/patterns?firstName=John&lastName=Smith&domain=acme.com
//  Just returns the email patterns (no verification) — instant
// ════════════════════════════════════════════════════════════
router.get('/patterns', auth, (req, res) => {
  const { firstName, lastName, domain } = req.query;
  if (!firstName || !lastName || !domain)
    return res.status(400).json({ error: 'firstName, lastName, domain required' });

  const patterns = generateEmailPatterns(firstName, lastName, cleanDomain(domain));
  res.json({ patterns, note: 'Use /verify to MX-check these' });
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/linkedin?company=Acme&industry=tech&location=Tampa
//  Search LinkedIn companies via Google dork (free)
// ════════════════════════════════════════════════════════════
router.get('/linkedin', auth, async (req, res) => {
  const { company = '', industry = '', location = '' } = req.query;
  if (!company && !industry) return res.status(400).json({ error: 'company or industry required' });

  const key = `li:${company}:${industry}:${location}`;
  const hit = cache.get(key);
  if (hit) return res.json({ ...hit, cached: true });

  try {
    const results = await searchLinkedIn(company, industry, location);
    const result  = { query: { company, industry, location }, results };
    cache.set(key, result, 3600);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════════
//  POST /api/leads/export
//  Export array of leads as CSV (no credits, no cost)
// ════════════════════════════════════════════════════════════
router.post('/export', auth, (req, res) => {
  const { leads = [], format = 'csv', crm } = req.body;
  if (!leads.length) return res.status(400).json({ error: 'No leads to export' });

  const fields = crm === 'hubspot'
    ? ['Company Name', 'Website URL', 'Email Address', 'Phone Number', 'Industry', 'City', 'Lead Source', 'Description']
    : ['name', 'domain', 'email', 'phone', 'industry', 'location', 'address', 'linkedin', 'score', 'src'];

  const fieldMap = {
    'Company Name': 'name', 'Website URL': 'website', 'Email Address': 'email',
    'Phone Number': 'phone', 'Industry': 'industry', 'City': 'location',
    'Lead Source': 'src', 'Description': 'snippet',
  };

  const header = fields.join(',');
  const rows   = leads.map(lead =>
    fields.map(f => {
      const key = fieldMap[f] || f;
      const val = key === 'src' ? 'ArgiFlow' : (lead[key] || '');
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',')
  );

  if (format === 'json') {
    return res.json({ exported: leads.length, leads });
  }

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="argiflow-leads.csv"');
  res.send([header, ...rows].join('\n'));
});

// ════════════════════════════════════════════════════════════
//  GET /api/leads/stats
//  Cache stats + source health check
// ════════════════════════════════════════════════════════════
router.get('/stats', auth, (req, res) => {
  const keys = cache.keys();
  res.json({
    cacheSize: keys.length,
    sources: {
      duckduckgo: { free: true, keyRequired: false },
      bing: { free: true, keyRequired: false },
      yellowpages: { free: true, keyRequired: false },
      manta: { free: true, keyRequired: false },
      linkedin_dork: { free: true, keyRequired: false },
      website_scrape: { free: true, keyRequired: false },
      rdap_whois: { free: true, keyRequired: false },
      dns_mx_verify: { free: true, keyRequired: false },
      email_patterns: { free: true, keyRequired: false },
      hunter_io: { free: '25/mo', keyRequired: true, hasKey: !!HUNTER_KEY },
      clearbit_logo: { free: true, keyRequired: false },
      sec_edgar: { free: true, keyRequired: false },
    },
    monthlyCost: HUNTER_KEY ? '$0 (free tier only)' : '$0',
  });
});

module.exports = router;
