/**
 * ArgiFlow Lead Intelligence — React Component
 * Drop this into your existing ArgiFlow dashboard.
 *
 * Usage:
 *   import LeadIntelligence from './LeadIntelligence';
 *   <LeadIntelligence apiBase="/api/leads" token={userToken} />
 */

import { useState, useCallback, useRef } from "react";

const API = (base, path) => `${base}${path}`;

// ── Tiny fetch helper
async function apiFetch(url, opts = {}, token) {
  const res = await fetch(url, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(opts.headers || {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return opts.raw ? res : res.json();
}

// ── Score color
function scoreColor(s) {
  if (s >= 75) return "#3dd68c";
  if (s >= 50) return "#f5c842";
  return "#7888aa";
}

// ── Avatar color from name
function avatarBg(name = "") {
  const colors = ["#4f8ef7", "#f5c842", "#00d4b4", "#ff5c6a", "#a78bfa", "#fb923c"];
  const i = (name.charCodeAt(0) || 65) % colors.length;
  return colors[i];
}

export default function LeadIntelligence({ apiBase = "/api/leads", token }) {
  const [tab, setTab] = useState("search"); // search | local | enrich | contact | saved
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);
  const [saved, setSaved] = useState(() => {
    try { return JSON.parse(localStorage.getItem("argiflow_leads") || "[]"); }
    catch { return []; }
  });
  const [enrichData, setEnrichData] = useState(null);
  const [contactData, setContactData] = useState(null);
  const [selectedLeads, setSelectedLeads] = useState(new Set());
  const [localResults, setLocalResults] = useState(null);

  const toastRef = useRef(null);

  // Search filters
  const [sq, setSq] = useState({ q: "", industry: "", location: "", size: "", limit: "20" });
  const [lq, setLq] = useState({ type: "medical practice", city: "", state: "", limit: "25" });
  const [eq, setEq] = useState({ domain: "" });
  const [cq, setCq] = useState({ firstName: "", lastName: "", domain: "", company: "", title: "" });

  function showToast(msg, type = "success") {
    setToast({ msg, type });
    clearTimeout(toastRef.current);
    toastRef.current = setTimeout(() => setToast(null), 3500);
  }

  // ── LEAD SEARCH ──────────────────────────────────────────
  const doSearch = useCallback(async () => {
    if (!sq.q && !sq.industry && !sq.location) {
      return showToast("Enter at least one search field", "error");
    }
    setLoading(true); setError(null); setResults([]);
    try {
      const params = new URLSearchParams(Object.fromEntries(Object.entries(sq).filter(([, v]) => v)));
      const data = await apiFetch(`${API(apiBase, "/search")}?${params}`, {}, token);
      setResults(data.leads || []);
      showToast(`Found ${data.total} leads`);
    } catch (e) { setError(e.message); showToast(e.message, "error"); }
    finally { setLoading(false); }
  }, [sq, apiBase, token]);

  // ── LOCAL SEARCH ─────────────────────────────────────────
  const doLocal = useCallback(async () => {
    if (!lq.city) return showToast("Enter a city", "error");
    setLoading(true); setError(null); setLocalResults(null);
    try {
      const params = new URLSearchParams(Object.fromEntries(Object.entries(lq).filter(([, v]) => v)));
      const data = await apiFetch(`${API(apiBase, "/local")}?${params}`, {}, token);
      setLocalResults(data);
      showToast(`Found ${data.total} businesses`);
    } catch (e) { setError(e.message); showToast(e.message, "error"); }
    finally { setLoading(false); }
  }, [lq, apiBase, token]);

  // ── ENRICH ───────────────────────────────────────────────
  const doEnrich = useCallback(async () => {
    if (!eq.domain) return showToast("Enter a domain", "error");
    setLoading(true); setError(null); setEnrichData(null);
    try {
      const data = await apiFetch(`${API(apiBase, "/enrich")}?domain=${encodeURIComponent(eq.domain)}`, {}, token);
      setEnrichData(data);
    } catch (e) { setError(e.message); showToast(e.message, "error"); }
    finally { setLoading(false); }
  }, [eq, apiBase, token]);

  // ── FIND CONTACT ─────────────────────────────────────────
  const doContact = useCallback(async () => {
    const { firstName, lastName, domain } = cq;
    if (!firstName || !lastName || !domain) return showToast("firstName, lastName & domain required", "error");
    setLoading(true); setError(null); setContactData(null);
    try {
      const params = new URLSearchParams(Object.fromEntries(Object.entries(cq).filter(([, v]) => v)));
      const data = await apiFetch(`${API(apiBase, "/contact")}?${params}`, {}, token);
      setContactData(data);
    } catch (e) { setError(e.message); showToast(e.message, "error"); }
    finally { setLoading(false); }
  }, [cq, apiBase, token]);

  // ── SAVE LEADS ───────────────────────────────────────────
  function saveLead(lead) {
    setSaved(prev => {
      if (prev.find(l => l.domain === lead.domain)) {
        showToast("Already saved", "info"); return prev;
      }
      const next = [{ ...lead, savedAt: new Date().toISOString() }, ...prev];
      localStorage.setItem("argiflow_leads", JSON.stringify(next));
      showToast(`Saved: ${lead.name || lead.domain}`);
      return next;
    });
  }

  function saveSelected() {
    results.filter(r => selectedLeads.has(r.domain)).forEach(saveLead);
    setSelectedLeads(new Set());
  }

  function removeSaved(domain) {
    setSaved(prev => {
      const next = prev.filter(l => l.domain !== domain);
      localStorage.setItem("argiflow_leads", JSON.stringify(next));
      return next;
    });
  }

  // ── EXPORT CSV ───────────────────────────────────────────
  async function exportCSV(leads, filename = "leads") {
    const res = await apiFetch(API(apiBase, "/export"), {
      method: "POST", body: JSON.stringify({ leads, format: "csv" }),
    }, token);
    const blob = new Blob([await (await fetch(API(apiBase, "/export"), {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ leads, format: "csv" }),
    })).text()], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `argiflow-${filename}.csv`;
    a.click();
    showToast("CSV downloaded");
  }

  function exportLocalCSV() {
    const rows = localResults?.businesses || [];
    const csv = ["Name,Phone,Address,Website,Source",
      ...rows.map(r => `"${r.name||""}","${r.phone||""}","${r.address||""}","${r.website||""}","${r.src||""}"`)
    ].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `argiflow-local.csv`;
    a.click();
    showToast("CSV downloaded");
  }

  // ══════════════════════════════════════════════════════════
  //  RENDER
  // ══════════════════════════════════════════════════════════
  const INDUSTRIES = ["Healthcare","Technology / SaaS","Real Estate","Legal Services","Financial Services","Manufacturing","Retail","Construction","Education","Hospitality","Logistics","Media & Marketing"];
  const BIZ_TYPES  = ["medical practice","dental office","law firm","accounting firm","physical therapy","chiropractic","mental health counseling","optometry","veterinary clinic","real estate agency","insurance agency","auto repair"];

  return (
    <div style={styles.wrap}>

      {/* ── HEADER ── */}
      <div style={styles.header}>
        <div>
          <h2 style={styles.h2}>Lead Intelligence</h2>
          <p style={styles.sub}>Find and enrich B2B leads — 100% free sources</p>
        </div>
        <div style={styles.headerRight}>
          <span style={styles.freeBadge}>★ $0 / month</span>
          {saved.length > 0 && (
            <button style={styles.btnGhost} onClick={() => setTab("saved")}>
              📋 {saved.length} Saved
            </button>
          )}
        </div>
      </div>

      {/* ── TABS ── */}
      <div style={styles.tabs}>
        {[
          { id: "search",  label: "🔍 Find Leads"   },
          { id: "local",   label: "📍 Local Search"  },
          { id: "enrich",  label: "🔬 Enrich Domain" },
          { id: "contact", label: "📧 Find Contact"  },
          { id: "saved",   label: `💾 Saved (${saved.length})` },
        ].map(t => (
          <button key={t.id}
            style={{ ...styles.tab, ...(tab === t.id ? styles.tabActive : {}) }}
            onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ════════ SEARCH TAB ════════ */}
      {tab === "search" && (
        <div>
          <div style={styles.card}>
            <div style={styles.filterGrid}>
              <Field label="Search Query">
                <input style={styles.input} value={sq.q}
                  placeholder="medical billing, SaaS startup…"
                  onChange={e => setSq(s => ({ ...s, q: e.target.value }))}
                  onKeyDown={e => e.key === "Enter" && doSearch()} />
              </Field>
              <Field label="Industry">
                <select style={styles.input} value={sq.industry}
                  onChange={e => setSq(s => ({ ...s, industry: e.target.value }))}>
                  <option value="">All Industries</option>
                  {INDUSTRIES.map(i => <option key={i}>{i}</option>)}
                </select>
              </Field>
              <Field label="Location">
                <input style={styles.input} value={sq.location}
                  placeholder="Tampa FL, Chicago…"
                  onChange={e => setSq(s => ({ ...s, location: e.target.value }))} />
              </Field>
              <Field label="Company Size">
                <select style={styles.input} value={sq.size}
                  onChange={e => setSq(s => ({ ...s, size: e.target.value }))}>
                  <option value="">Any Size</option>
                  <option value="micro">Micro (1-10)</option>
                  <option value="small">Small (11-50)</option>
                  <option value="medium">Medium (51-200)</option>
                  <option value="large">Large (200+)</option>
                </select>
              </Field>
              <Field label="Results">
                <select style={styles.input} value={sq.limit}
                  onChange={e => setSq(s => ({ ...s, limit: e.target.value }))}>
                  <option value="10">10</option>
                  <option value="20">20</option>
                  <option value="50">50</option>
                </select>
              </Field>
            </div>
            <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
              <button style={styles.btnPrimary} onClick={doSearch} disabled={loading}>
                {loading ? "Searching…" : "🔍 Search Leads"}
              </button>
              {results.length > 0 && selectedLeads.size > 0 && (
                <button style={styles.btnSecondary} onClick={saveSelected}>
                  💾 Save Selected ({selectedLeads.size})
                </button>
              )}
              {results.length > 0 && (
                <button style={styles.btnGhost} onClick={() => exportCSV(results, "search")}>
                  ⬇ Export CSV
                </button>
              )}
              <span style={styles.freeBadge}>Free · No API key needed</span>
            </div>
          </div>

          {error && <div style={styles.error}>{error}</div>}

          {results.length > 0 && (
            <div style={styles.card}>
              <div style={styles.resultHeader}>
                <span style={styles.resultCount}>{results.length} results</span>
                <label style={{ fontSize:12, color:"#7888aa", display:"flex", alignItems:"center", gap:6 }}>
                  <input type="checkbox"
                    checked={selectedLeads.size === results.length && results.length > 0}
                    onChange={e => setSelectedLeads(e.target.checked ? new Set(results.map(r => r.domain)) : new Set())}
                  /> Select all
                </label>
              </div>
              {results.map((lead, i) => (
                <LeadRow key={i} lead={lead}
                  selected={selectedLeads.has(lead.domain)}
                  onSelect={() => setSelectedLeads(prev => {
                    const next = new Set(prev);
                    next.has(lead.domain) ? next.delete(lead.domain) : next.add(lead.domain);
                    return next;
                  })}
                  onSave={() => saveLead(lead)}
                  onEnrich={() => { setEq({ domain: lead.domain }); setTab("enrich"); }}
                  saved={!!saved.find(s => s.domain === lead.domain)}
                />
              ))}
            </div>
          )}

          {!loading && results.length === 0 && !error && (
            <EmptyState icon="🌐" title="Find your next leads" sub="Enter a search query, industry, or location above" />
          )}
        </div>
      )}

      {/* ════════ LOCAL TAB ════════ */}
      {tab === "local" && (
        <div>
          <div style={styles.card}>
            <p style={{ fontSize:13, color:"#7888aa", marginBottom:16 }}>
              Searches Yellow Pages + Manta + web — zero cost, no API key.
            </p>
            <div style={styles.filterGrid}>
              <Field label="Business Type">
                <select style={styles.input} value={lq.type}
                  onChange={e => setLq(s => ({ ...s, type: e.target.value }))}>
                  {BIZ_TYPES.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}
                </select>
              </Field>
              <Field label="City">
                <input style={styles.input} value={lq.city} placeholder="Tampa"
                  onChange={e => setLq(s => ({ ...s, city: e.target.value }))} />
              </Field>
              <Field label="State">
                <input style={styles.input} value={lq.state} placeholder="FL"
                  onChange={e => setLq(s => ({ ...s, state: e.target.value }))} />
              </Field>
              <Field label="Limit">
                <select style={styles.input} value={lq.limit}
                  onChange={e => setLq(s => ({ ...s, limit: e.target.value }))}>
                  <option value="15">15</option>
                  <option value="25">25</option>
                  <option value="50">50</option>
                </select>
              </Field>
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <button style={styles.btnPrimary} onClick={doLocal} disabled={loading}>
                {loading ? "Searching…" : "📍 Find Businesses"}
              </button>
              {localResults && (
                <button style={styles.btnGhost} onClick={exportLocalCSV}>⬇ Export CSV</button>
              )}
            </div>
          </div>

          {localResults && (
            <div style={styles.card}>
              <div style={styles.resultHeader}>
                <span style={styles.resultCount}>{localResults.total} businesses in {localResults.location}</span>
              </div>
              <div style={{ overflowX:"auto" }}>
                <table style={styles.table}>
                  <thead>
                    <tr>
                      {["Business","Phone","Address","Source","Actions"].map(h => (
                        <th key={h} style={styles.th}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {localResults.businesses.map((biz, i) => (
                      <tr key={i} style={i % 2 === 0 ? {} : { background:"rgba(255,255,255,0.02)" }}>
                        <td style={styles.td}>
                          <div style={{ fontWeight:600, fontSize:13 }}>{biz.name}</div>
                          {biz.website && <div style={{ fontSize:11, color:"#7888aa" }}>{biz.website?.replace(/https?:\/\/(www\.)?/,"").split("/")[0]}</div>}
                        </td>
                        <td style={styles.td}><span style={{ color:"#f5c842", fontSize:12 }}>{biz.phone || "—"}</span></td>
                        <td style={styles.td}><span style={{ fontSize:12, color:"#9aa8c0" }}>{biz.address || "—"}</span></td>
                        <td style={styles.td}><SrcBadge src={biz.src} /></td>
                        <td style={styles.td}>
                          <button style={styles.btnMini} onClick={() => saveLead({ ...biz, domain: biz.domain || biz.website?.split("/")[2], src:"local" })}>
                            💾 Save
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {!loading && !localResults && (
            <EmptyState icon="📍" title="Local Business Finder" sub="Great for targeting medical practices, law firms, dentists — any local vertical" />
          )}
        </div>
      )}

      {/* ════════ ENRICH TAB ════════ */}
      {tab === "enrich" && (
        <div>
          <div style={styles.card}>
            <div style={{ display:"flex", gap:10, alignItems:"flex-end" }}>
              <Field label="Company Domain" style={{ flex:1 }}>
                <input style={styles.input} value={eq.domain}
                  placeholder="acme.com"
                  onChange={e => setEq({ domain: e.target.value })}
                  onKeyDown={e => e.key === "Enter" && doEnrich()} />
              </Field>
              <button style={{ ...styles.btnPrimary, marginBottom:0 }} onClick={doEnrich} disabled={loading}>
                {loading ? "Enriching…" : "🔬 Enrich"}
              </button>
            </div>
            <p style={{ fontSize:12, color:"#7888aa", marginTop:10 }}>
              Pulls from: company website · Schema.org · RDAP/WHOIS · DNS · Clearbit Logo (all free)
            </p>
          </div>

          {enrichData && (
            <div style={styles.card}>
              <div style={{ display:"flex", gap:16, alignItems:"flex-start", marginBottom:20 }}>
                <img src={enrichData.logo} alt="" width={52} height={52}
                  style={{ borderRadius:10, background:"#1e2840", objectFit:"contain", padding:4 }}
                  onError={e => { e.target.style.display="none"; }} />
                <div>
                  <h3 style={{ fontFamily:"'Syne',sans-serif", fontSize:20, fontWeight:800, marginBottom:2 }}>
                    {enrichData.name || enrichData.domain}
                  </h3>
                  <a href={`https://${enrichData.domain}`} target="_blank" rel="noreferrer"
                    style={{ color:"#4f8ef7", fontSize:12 }}>{enrichData.domain}</a>
                </div>
                <div style={{ marginLeft:"auto", display:"flex", gap:8 }}>
                  {enrichData.linkedin && <a href={enrichData.linkedin} target="_blank" rel="noreferrer" style={styles.btnMini}>LinkedIn</a>}
                  {enrichData.twitter  && <a href={enrichData.twitter}  target="_blank" rel="noreferrer" style={styles.btnMini}>Twitter</a>}
                  <button style={styles.btnPrimary} onClick={() => saveLead({ domain:enrichData.domain, name:enrichData.name, ...enrichData })}>
                    💾 Save
                  </button>
                </div>
              </div>
              {enrichData.description && (
                <p style={{ fontSize:13, color:"#9aa8c0", lineHeight:1.6, marginBottom:16 }}>{enrichData.description}</p>
              )}
              <div style={styles.infoGrid}>
                {[
                  ["Email",    enrichData.email],
                  ["Phone",    enrichData.phone],
                  ["Address",  enrichData.address],
                  ["Employees",enrichData.employees],
                  ["Founded",  enrichData.founded],
                  ["LinkedIn", enrichData.linkedin],
                  ["Domain Created", enrichData.domainCreated],
                  ["Registrar", enrichData.registrar],
                  ["DNS Active", enrichData.dnsActive ? "✅ Yes" : "❌ No"],
                  ["Has Email Server (MX)", enrichData.hasMX ? "✅ Yes" : "❌ No"],
                ].filter(([, v]) => v).map(([label, value]) => (
                  <div key={label} style={styles.infoRow}>
                    <span style={{ color:"#7888aa", fontSize:12 }}>{label}</span>
                    <span style={{ fontSize:13, wordBreak:"break-all" }}>{value}</span>
                  </div>
                ))}
              </div>
              {enrichData.mxRecords?.length > 0 && (
                <div style={{ marginTop:12 }}>
                  <span style={{ fontSize:11, color:"#7888aa", textTransform:"uppercase", letterSpacing:1 }}>MX Records</span>
                  <div style={{ marginTop:6, display:"flex", gap:6, flexWrap:"wrap" }}>
                    {enrichData.mxRecords.map(r => <span key={r} style={styles.chip}>{r}</span>)}
                  </div>
                </div>
              )}
            </div>
          )}

          {!loading && !enrichData && (
            <EmptyState icon="🔬" title="Enrich any domain" sub="Get email, phone, address, social links, DNS, and WHOIS — all free" />
          )}
        </div>
      )}

      {/* ════════ CONTACT TAB ════════ */}
      {tab === "contact" && (
        <div>
          <div style={styles.card}>
            <div style={styles.filterGrid}>
              <Field label="First Name"><input style={styles.input} value={cq.firstName} placeholder="John" onChange={e => setCq(s=>({...s,firstName:e.target.value}))} /></Field>
              <Field label="Last Name"><input style={styles.input} value={cq.lastName} placeholder="Smith" onChange={e => setCq(s=>({...s,lastName:e.target.value}))} /></Field>
              <Field label="Domain"><input style={styles.input} value={cq.domain} placeholder="acme.com" onChange={e => setCq(s=>({...s,domain:e.target.value}))} /></Field>
              <Field label="Company"><input style={styles.input} value={cq.company} placeholder="Acme Corp" onChange={e => setCq(s=>({...s,company:e.target.value}))} /></Field>
              <Field label="Job Title"><input style={styles.input} value={cq.title} placeholder="CEO, Practice Manager" onChange={e => setCq(s=>({...s,title:e.target.value}))} /></Field>
            </div>
            <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
              <button style={styles.btnPrimary} onClick={doContact} disabled={loading}>
                {loading ? "Searching…" : "📧 Find Contact"}
              </button>
              <span style={styles.freeBadge}>Email patterns · MX verify · LinkedIn dork — all free</span>
            </div>
          </div>

          {contactData && (
            <div style={styles.card}>
              <h4 style={{ fontFamily:"'Syne',sans-serif", fontWeight:700, marginBottom:16 }}>
                {contactData.firstName} {contactData.lastName} @ {contactData.domain}
                <span style={{ marginLeft:10, ...styles.freeBadge, fontSize:11 }}>
                  Confidence: {contactData.confidence}
                </span>
              </h4>

              {contactData.emails?.length > 0 ? (
                <div style={{ marginBottom:16 }}>
                  <div style={{ fontSize:11, color:"#7888aa", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>
                    Verified Emails ({contactData.emails.length})
                  </div>
                  {contactData.emails.map((e, i) => (
                    <div key={i} style={{ ...styles.emailRow }}>
                      <span style={{ fontWeight:600 }}>{e.email}</span>
                      <span style={styles.chip}>{e.confidence || "MX verified"}</span>
                      <SrcBadge src={e.src} />
                      <button style={styles.btnMini} onClick={() => navigator.clipboard.writeText(e.email).then(()=>showToast("Copied!"))}>Copy</button>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ color:"#7888aa", fontSize:13, marginBottom:12 }}>
                  No emails found via MX verification. Try adding Hunter.io free key (25/mo).
                </div>
              )}

              {contactData.linkedInProfiles?.length > 0 && (
                <div>
                  <div style={{ fontSize:11, color:"#7888aa", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>
                    LinkedIn Profiles
                  </div>
                  {contactData.linkedInProfiles.map((p, i) => (
                    <div key={i} style={styles.emailRow}>
                      <div>
                        <div style={{ fontWeight:600, fontSize:13 }}>{p.name}</div>
                        <div style={{ fontSize:11, color:"#9aa8c0" }}>{p.headline?.slice(0,120)}</div>
                      </div>
                      <a href={p.profileUrl} target="_blank" rel="noreferrer" style={{ ...styles.btnMini, textDecoration:"none" }}>View →</a>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {!loading && !contactData && (
            <EmptyState icon="📧" title="Find anyone's contact" sub="Enter a name + domain. We generate email patterns and verify via MX records — no cost." />
          )}
        </div>
      )}

      {/* ════════ SAVED TAB ════════ */}
      {tab === "saved" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <span style={styles.resultCount}>{saved.length} saved leads</span>
            {saved.length > 0 && (
              <div style={{ display:"flex", gap:8 }}>
                <button style={styles.btnGhost} onClick={() => exportCSV(saved, "saved")}>⬇ Export CSV</button>
                <button style={{ ...styles.btnGhost, color:"#ff5c6a" }} onClick={() => {
                  if (confirm("Clear all saved leads?")) { setSaved([]); localStorage.removeItem("argiflow_leads"); }
                }}>🗑 Clear All</button>
              </div>
            )}
          </div>

          {saved.length === 0
            ? <EmptyState icon="💾" title="No saved leads yet" sub="Search for leads and click Save to collect them here" />
            : saved.map((lead, i) => (
                <LeadRow key={i} lead={lead} saved onRemove={() => removeSaved(lead.domain)}
                  onEnrich={() => { setEq({ domain: lead.domain }); setTab("enrich"); }} />
              ))
          }
        </div>
      )}

      {/* ── TOAST ── */}
      {toast && (
        <div style={{
          position:"fixed", bottom:24, right:24,
          background:"#1e2840", border:`1px solid ${toast.type === "error" ? "#ff5c6a" : toast.type === "info" ? "#f5c842" : "#3dd68c"}`,
          borderRadius:10, padding:"12px 20px", fontSize:13, zIndex:9999,
          animation:"slideUp 0.3s ease",
          maxWidth:300,
        }}>
          {toast.msg}
        </div>
      )}

      <style>{`
        @keyframes slideUp { from { transform:translateY(16px); opacity:0; } to { transform:translateY(0); opacity:1; } }
        input[type=checkbox] { accent-color: #f5c842; }
        * { box-sizing: border-box; }
        select option { background: #131929; }
      `}</style>
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────

function Field({ label, children, style = {} }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:5, ...style }}>
      <label style={{ fontSize:11, color:"#7888aa", textTransform:"uppercase", letterSpacing:0.6, fontWeight:600 }}>{label}</label>
      {children}
    </div>
  );
}

function LeadRow({ lead, selected, onSelect, onSave, onRemove, onEnrich, saved }) {
  const bg = avatarBg(lead.name || lead.domain || "");
  return (
    <div style={{
      display:"flex", alignItems:"center", gap:12,
      padding:"12px 0", borderBottom:"1px solid rgba(42,53,85,0.5)",
    }}>
      {onSelect && (
        <input type="checkbox" checked={selected} onChange={onSelect} style={{ flexShrink:0 }} />
      )}
      <div style={{ width:36, height:36, borderRadius:8, background:bg, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:800, fontSize:14, color:"#0b0f19", flexShrink:0 }}>
        {(lead.name || lead.domain || "?")[0].toUpperCase()}
      </div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontWeight:600, fontSize:13, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>
          {lead.name || lead.domain}
        </div>
        <div style={{ fontSize:11, color:"#7888aa" }}>{lead.domain}</div>
      </div>
      {lead.score != null && (
        <div style={{ display:"flex", alignItems:"center", gap:6, flexShrink:0 }}>
          <div style={{ width:36, height:3, background:"#2a3555", borderRadius:2, overflow:"hidden" }}>
            <div style={{ width:`${lead.score}%`, height:"100%", background:scoreColor(lead.score), borderRadius:2 }} />
          </div>
          <span style={{ fontSize:11, fontWeight:700, color:scoreColor(lead.score) }}>{lead.score}</span>
        </div>
      )}
      <div style={{ flexShrink:0 }}>
        {lead.industry && <span style={styles.chip}>{lead.industry}</span>}
      </div>
      <SrcBadge src={lead.src} />
      <div style={{ display:"flex", gap:6, flexShrink:0 }}>
        <button style={styles.btnMini} onClick={onEnrich}>🔬</button>
        {!saved && onSave && <button style={styles.btnMini} onClick={onSave}>💾</button>}
        {onRemove && <button style={{ ...styles.btnMini, color:"#ff5c6a" }} onClick={onRemove}>✕</button>}
      </div>
    </div>
  );
}

function SrcBadge({ src }) {
  const map = {
    ddg:        { label:"DDG",   color:"#e85d04" },
    bing:       { label:"Bing",  color:"#00b4d8" },
    yellowpages:{ label:"YP",    color:"#ffd60a" },
    manta:      { label:"Manta", color:"#7b2d8b" },
    linkedin_dork: { label:"LI", color:"#0077b5" },
    web:        { label:"Web",   color:"#7888aa" },
    hunter:     { label:"Hunter",color:"#f4845f" },
    local:      { label:"Local", color:"#3dd68c" },
    pattern:    { label:"Pattern",color:"#9ca3af" },
  };
  const s = map[src] || { label: src || "?", color:"#7888aa" };
  return (
    <span style={{ background:`${s.color}22`, color:s.color, border:`1px solid ${s.color}55`, borderRadius:4, padding:"2px 7px", fontSize:10, fontWeight:700, flexShrink:0 }}>
      {s.label}
    </span>
  );
}

function EmptyState({ icon, title, sub }) {
  return (
    <div style={{ textAlign:"center", padding:"60px 20px", color:"#7888aa" }}>
      <div style={{ fontSize:44, marginBottom:12 }}>{icon}</div>
      <h4 style={{ fontFamily:"'Syne',sans-serif", color:"#e8eef8", fontSize:17, marginBottom:8 }}>{title}</h4>
      <p style={{ fontSize:13 }}>{sub}</p>
    </div>
  );
}

// ── Styles ──────────────────────────────────────────────────
const styles = {
  wrap: { fontFamily:"'DM Sans', system-ui, sans-serif", color:"#e8eef8", maxWidth:1100, margin:"0 auto", padding:24 },
  header: { display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:24, flexWrap:"wrap", gap:12 },
  headerRight: { display:"flex", gap:10, alignItems:"center" },
  h2: { fontFamily:"'Syne', sans-serif", fontSize:26, fontWeight:800, margin:0, letterSpacing:"-0.5px" },
  sub: { fontSize:13, color:"#7888aa", margin:"4px 0 0" },
  freeBadge: { background:"rgba(61,214,140,0.12)", color:"#3dd68c", border:"1px solid rgba(61,214,140,0.3)", borderRadius:999, padding:"4px 12px", fontSize:12, fontWeight:600, whiteSpace:"nowrap" },
  tabs: { display:"flex", gap:4, marginBottom:20, flexWrap:"wrap" },
  tab: { padding:"8px 18px", borderRadius:8, border:"none", background:"transparent", color:"#7888aa", fontSize:13, fontWeight:500, cursor:"pointer", fontFamily:"inherit", transition:"all 0.12s" },
  tabActive: { background:"#1e2840", color:"#e8eef8" },
  card: { background:"#131929", border:"1px solid #2a3555", borderRadius:12, padding:24, marginBottom:16 },
  filterGrid: { display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(180px,1fr))", gap:12, marginBottom:16 },
  input: { padding:"10px 12px", background:"#1e2840", border:"1px solid #2a3555", borderRadius:8, color:"#e8eef8", fontSize:13, fontFamily:"inherit", outline:"none", width:"100%" },
  btnPrimary: { background:"#f5c842", color:"#0b0f19", border:"none", borderRadius:8, padding:"10px 22px", fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"inherit", display:"inline-flex", alignItems:"center", gap:6 },
  btnSecondary: { background:"#00d4b4", color:"#0b0f19", border:"none", borderRadius:8, padding:"10px 18px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"inherit" },
  btnGhost: { background:"transparent", color:"#7888aa", border:"1px solid #2a3555", borderRadius:8, padding:"9px 16px", fontSize:13, fontWeight:500, cursor:"pointer", fontFamily:"inherit" },
  btnMini: { background:"#1e2840", color:"#e8eef8", border:"1px solid #2a3555", borderRadius:6, padding:"5px 10px", fontSize:11, cursor:"pointer", fontFamily:"inherit" },
  resultHeader: { display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12 },
  resultCount: { fontFamily:"'Syne',sans-serif", fontWeight:700, fontSize:15 },
  table: { width:"100%", borderCollapse:"collapse" },
  th: { padding:"10px 14px", textAlign:"left", fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:0.8, color:"#7888aa", background:"#1e2840", borderBottom:"1px solid #2a3555" },
  td: { padding:"11px 14px", fontSize:13, borderBottom:"1px solid rgba(42,53,85,0.4)", verticalAlign:"middle" },
  infoGrid: { display:"flex", flexDirection:"column", gap:2 },
  infoRow: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", padding:"8px 0", borderBottom:"1px solid rgba(42,53,85,0.4)" },
  chip: { background:"rgba(79,142,247,0.12)", color:"#7eb3ff", border:"1px solid rgba(79,142,247,0.2)", borderRadius:4, padding:"2px 8px", fontSize:11, fontWeight:500 },
  emailRow: { display:"flex", alignItems:"center", gap:10, padding:"10px", background:"#1e2840", borderRadius:8, marginBottom:8, flexWrap:"wrap" },
  error: { background:"rgba(255,92,106,0.1)", border:"1px solid rgba(255,92,106,0.3)", borderRadius:8, padding:"12px 16px", fontSize:13, color:"#ff5c6a", marginBottom:16 },
};
