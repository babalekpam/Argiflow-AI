/**
 * ============================================================
 *  ArgiFlow Lead Intelligence Engine — FREE SOURCES ONLY
 *  No paid APIs. No ZoomInfo. No Apollo subscription.
 *
 *  Sources Used (all free):
 *  1. DuckDuckGo HTML search
 *  2. Bing HTML search
 *  3. YellowPages.com scraping
 *  4. Manta.com (B2B directory)
 *  5. LinkedIn via Google dorks
 *  6. Company website direct scraping
 *  7. RDAP/WHOIS (domain info)
 *  8. DNS MX record verification
 *  9. Email pattern generation
 *  10. Hunter.io FREE tier (25/mo - optional)
 *  11. Clearbit Logo API (free, no key)
 *  12. SEC EDGAR (free public company API)
 * ============================================================
 */

const axios   = require('axios');
const cheerio = require('cheerio');
const dns     = require('dns').promises;

// ── HTTP CLIENT ──────────────────────────────────────────────────────────
const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
];

function randAgent() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function makeHeaders(extra = {}) {
  return {
    'User-Agent': randAgent(),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
    'DNT': '1',
    'Upgrade-Insecure-Requests': '1',
    ...extra,
  };
}

const http = axios.create({ timeout: 12000 });

// Polite delay between requests — avoids bans
const delay = (ms) => new Promise(r => setTimeout(r, ms));
const randDelay = () => delay(800 + Math.random() * 1200);

// ════════════════════════════════════════════════════════════
//  SOURCE 1 — DUCKDUCKGO (completely free, no key ever)
// ════════════════════════════════════════════════════════════
async function searchDDG(query, limit = 10) {
  try {
    await randDelay();
    const res = await http.get('https://html.duckduckgo.com/html/', {
      params: { q: query, kl: 'us-en', s: 0 },
      headers: makeHeaders({ 'Referer': 'https://duckduckgo.com/' }),
    });

    const $ = cheerio.load(res.data);
    const results = [];

    $('.result').each((i, el) => {
      if (i >= limit) return false;
      const title   = $(el).find('.result__title a').text().trim();
      const href    = $(el).find('.result__title a').attr('href') || '';
      const snippet = $(el).find('.result__snippet').text().trim();
      const domain  = cleanDomain(href);
      if (title && domain) results.push({ title, url: href, snippet, domain, src: 'ddg' });
    });

    return results;
  } catch (e) {
    console.warn('[DDG]', e.message);
    return [];
  }
}

// ════════════════════════════════════════════════════════════
//  SOURCE 2 — BING HTML (free, no key needed)
// ════════════════════════════════════════════════════════════
async function searchBing(query, limit = 10) {
  try {
    await randDelay();
    const res = await http.get('https://www.bing.com/search', {
      params: { q: query, count: limit, first: 1 },
      headers: makeHeaders({
        'Referer': 'https://www.bing.com/',
        'sec-fetch-site': 'same-origin',
      }),
    });

    const $ = cheerio.load(res.data);
    const results = [];

    $('#b_results .b_algo').each((i, el) => {
      if (i >= limit) return false;
      const title   = $(el).find('h2').text().trim();
      const url     = $(el).find('h2 a').attr('href') || '';
      const snippet = $(el).find('.b_caption p').text().trim();
      const domain  = cleanDomain(url);
      if (title && domain) results.push({ title, url, snippet, domain, src: 'bing' });
    });

    return results;
  } catch (e) {
    console.warn('[Bing]', e.message);
    return [];
  }
}

// ════════════════════════════════════════════════════════════
//  SOURCE 3 — YELLOW PAGES (the goldmine for local B2B)
// ════════════════════════════════════════════════════════════
async function scrapeYellowPages(type, location, limit = 20) {
  const results = [];
  try {
    const searchTerm = encodeURIComponent(type.replace(/\s/g, '-'));
    const locationTerm = encodeURIComponent(location.replace(/\s/g, '-').replace(',', ''));
    const url = `https://www.yellowpages.com/search?search_terms=${searchTerm}&geo_location_terms=${locationTerm}`;

    await randDelay();
    const res = await http.get(url, { headers: makeHeaders({ 'Referer': 'https://www.yellowpages.com/' }) });
    const $ = cheerio.load(res.data);

    $('.result').each((i, el) => {
      if (i >= limit) return false;

      const name    = $(el).find('.business-name span').text().trim()
                   || $(el).find('a.business-name').text().trim();
      const phone   = $(el).find('.phone').text().trim();
      const addr    = $(el).find('.adr').text().trim().replace(/\s+/g, ' ');
      const cats    = $(el).find('.categories a').map((_, a) => $(a).text()).get().join(', ');
      const website = $(el).find('a.track-visit-website').attr('href') || null;
      const rating  = $(el).find('.ratings .count').text().replace(/[()]/g, '').trim();
      const ypUrl   = 'https://www.yellowpages.com' + ($(el).find('a.business-name').attr('href') || '');

      if (name) {
        results.push({
          name, phone: cleanPhone(phone), address: addr,
          categories: cats, website, rating: rating || null,
          ypUrl, domain: website ? cleanDomain(website) : null,
          src: 'yellowpages'
        });
      }
    });
  } catch (e) {
    console.warn('[YellowPages]', e.message);
  }
  return results;
}

// ════════════════════════════════════════════════════════════
//  SOURCE 4 — MANTA.COM (B2B small business directory)
// ════════════════════════════════════════════════════════════
async function scrapeManta(query, location = '', limit = 15) {
  const results = [];
  try {
    const q = `${query} ${location}`.trim();
    const url = `https://www.manta.com/search?search_source=nav&q=${encodeURIComponent(q)}`;

    await randDelay();
    const res = await http.get(url, { headers: makeHeaders() });
    const $ = cheerio.load(res.data);

    $('[data-test="company-card"], .search-result-company, article.company').each((i, el) => {
      if (i >= limit) return false;

      const name    = $(el).find('h2 a, .company-name a, [data-test="company-name"]').first().text().trim();
      const phone   = $(el).find('[data-test="phone"], .phone').text().trim();
      const addr    = $(el).find('[data-test="address"], .address').text().trim().replace(/\s+/g, ' ');
      const website = $(el).find('a[href*="http"]:not([href*="manta.com"])').first().attr('href');
      const desc    = $(el).find('p, .description').first().text().trim();

      if (name) {
        results.push({
          name, phone: cleanPhone(phone), address: addr,
          website: website || null, description: desc || null,
          domain: website ? cleanDomain(website) : null,
          src: 'manta'
        });
      }
    });
  } catch (e) {
    console.warn('[Manta]', e.message);
  }
  return results;
}

// ════════════════════════════════════════════════════════════
//  SOURCE 5 — LINKEDIN via Google dorks (0 cost)
//  Uses DDG to search site:linkedin.com/company
// ════════════════════════════════════════════════════════════
async function searchLinkedIn(company, industry = '', location = '') {
  const parts = [company, industry, location].filter(Boolean).join(' ');
  const query = `${parts} site:linkedin.com/company`;

  const raw = await searchDDG(query, 5);
  return raw
    .filter(r => r.url?.includes('linkedin.com/company'))
    .map(r => ({
      name: r.title.replace('| LinkedIn', '').replace('LinkedIn', '').trim(),
      linkedinUrl: r.url,
      snippet: r.snippet,
      src: 'linkedin_dork'
    }));
}

// Find decision makers via LinkedIn people search dork
async function searchLinkedInPeople(name, company, title = '') {
  const query = `"${name}" "${company}" ${title} site:linkedin.com/in`;
  const raw = await searchDDG(query, 5);
  return raw
    .filter(r => r.url?.includes('linkedin.com/in'))
    .map(r => ({
      name: r.title.replace('| LinkedIn', '').trim(),
      profileUrl: r.url,
      headline: r.snippet,
      src: 'linkedin_dork'
    }));
}

// ════════════════════════════════════════════════════════════
//  SOURCE 6 — DIRECT WEBSITE SCRAPE
// ════════════════════════════════════════════════════════════
async function scrapeWebsite(domain) {
  const result = {
    name: null, description: null, email: null, phone: null,
    address: null, linkedin: null, twitter: null, facebook: null,
    instagram: null, employees: null, founded: null, logo: null,
  };

  const urls = [`https://${domain}`, `https://www.${domain}`];

  for (const url of urls) {
    try {
      await randDelay();
      const res = await http.get(url, {
        headers: makeHeaders(),
        maxRedirects: 4,
        timeout: 9000,
      });

      const $ = cheerio.load(res.data);
      const bodyText = $('body').text();
      const lowerHtml = res.data.toLowerCase();

      // ── Name
      result.name =
        $('meta[property="og:site_name"]').attr('content') ||
        $('meta[name="application-name"]').attr('content') ||
        $('title').text().split(/[|\-–—]/)[0].trim() || null;

      // ── Description
      result.description =
        $('meta[name="description"]').attr('content') ||
        $('meta[property="og:description"]').attr('content') || null;
      if (result.description) result.description = result.description.slice(0, 300);

      // ── Email — pick the most likely business email
      const emails = (bodyText.match(/[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}/g) || [])
        .filter(e => !e.match(/\.(png|jpg|gif|svg|webp)/i) && !e.includes('example.') && !e.includes('placeholder'));
      result.email = emails[0] || null;

      // ── Phone
      const phoneMatch = bodyText.match(
        /(\+1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/
      );
      result.phone = phoneMatch ? cleanPhone(phoneMatch[0]) : null;

      // ── Social links
      $('a[href]').each((_, el) => {
        const href = $(el).attr('href') || '';
        if (href.includes('linkedin.com/company') && !result.linkedin) result.linkedin = href;
        else if ((href.includes('twitter.com/') || href.includes('x.com/')) && !href.includes('intent') && !result.twitter) result.twitter = href;
        else if (href.includes('facebook.com/') && !href.includes('sharer') && !result.facebook) result.facebook = href;
        else if (href.includes('instagram.com/') && !result.instagram) result.instagram = href;
      });

      // ── Schema.org structured data (the best source)
      $('script[type="application/ld+json"]').each((_, el) => {
        try {
          const raw = $(el).html().trim();
          const schema = JSON.parse(raw);
          const orgs = [].concat(schema).filter(s =>
            s['@type'] === 'Organization' || s['@type'] === 'LocalBusiness' ||
            s['@type'] === 'MedicalBusiness' || s['@type'] === 'LegalService'
          );
          for (const org of orgs) {
            if (org.name && !result.name) result.name = org.name;
            if (org.telephone && !result.phone) result.phone = cleanPhone(org.telephone);
            if (org.email && !result.email) result.email = org.email;
            if (org.numberOfEmployees) result.employees = org.numberOfEmployees?.value || org.numberOfEmployees;
            if (org.foundingDate) result.founded = org.foundingDate;
            if (org.address) {
              const a = org.address;
              result.address = [a.streetAddress, a.addressLocality, a.addressRegion, a.postalCode, a.addressCountry]
                .filter(Boolean).join(', ');
            }
            if (org.logo) result.logo = typeof org.logo === 'string' ? org.logo : org.logo?.url;
            if (org.description && !result.description) result.description = org.description?.slice(0, 300);
          }
        } catch {}
      });

      // ── Clearbit Logo (free, no auth)
      if (!result.logo) {
        result.logo = `https://logo.clearbit.com/${domain}`;
      }

      break; // success on first URL
    } catch {}
  }

  return result;
}

// ════════════════════════════════════════════════════════════
//  SOURCE 7 — WHOIS / RDAP (free domain info)
// ════════════════════════════════════════════════════════════
async function getDomainInfo(domain) {
  try {
    // RDAP is the modern, free, structured replacement for WHOIS
    const tld = domain.split('.').pop();
    const rdapServers = {
      com: 'https://rdap.verisign.com/com/v1/domain/',
      net: 'https://rdap.verisign.com/net/v1/domain/',
      org: 'https://rdap.org/domain/',
      io:  'https://rdap.org/domain/',
      co:  'https://rdap.org/domain/',
    };

    const base = rdapServers[tld] || 'https://rdap.org/domain/';
    const res  = await http.get(`${base}${domain}`, { timeout: 6000 });
    const d    = res.data;

    const events    = d.events || [];
    const created   = events.find(e => e.eventAction === 'registration')?.eventDate?.split('T')[0];
    const updated   = events.find(e => e.eventAction === 'last changed')?.eventDate?.split('T')[0];
    const registrar = d.entities?.find(e => e.roles?.includes('registrar'))?.vcardArray?.[1]?.find(v => v[0] === 'fn')?.[3];

    return { registrar, created, updated, status: d.status, src: 'rdap' };
  } catch {
    return null;
  }
}

// ════════════════════════════════════════════════════════════
//  SOURCE 8 — DNS / MX VERIFICATION (completely free)
// ════════════════════════════════════════════════════════════
async function verifyDomain(domain) {
  try {
    const [a, mx] = await Promise.allSettled([
      dns.resolve(domain, 'A'),
      dns.resolve(domain, 'MX'),
    ]);
    return {
      hasA:  a.status === 'fulfilled' && a.value.length > 0,
      hasMX: mx.status === 'fulfilled' && mx.value.length > 0,
      mxRecords: mx.status === 'fulfilled' ? mx.value.map(r => r.exchange) : [],
    };
  } catch {
    return { hasA: false, hasMX: false, mxRecords: [] };
  }
}

async function verifyEmail(email) {
  const domain = email.split('@')[1];
  if (!domain) return false;
  try {
    const records = await dns.resolve(domain, 'MX');
    return records.length > 0;
  } catch {
    return false;
  }
}

// ════════════════════════════════════════════════════════════
//  SOURCE 9 — EMAIL PATTERN GENERATION
//  (free forever — just needs a domain and name)
// ════════════════════════════════════════════════════════════
function generateEmailPatterns(firstName, lastName, domain) {
  const f  = firstName.toLowerCase().replace(/[^a-z]/g, '');
  const l  = lastName.toLowerCase().replace(/[^a-z]/g, '');
  const fi = f[0];
  const li = l[0];

  return [
    `${f}.${l}@${domain}`,      // john.smith       (most common ~42%)
    `${fi}${l}@${domain}`,      // jsmith           (second ~24%)
    `${f}@${domain}`,           // john             (~8%)
    `${fi}.${l}@${domain}`,     // j.smith          (~7%)
    `${f}${l}@${domain}`,       // johnsmith        (~7%)
    `${f}-${l}@${domain}`,      // john-smith       (~3%)
    `${l}.${f}@${domain}`,      // smith.john       (~3%)
    `${l}${fi}@${domain}`,      // smithj           (~2%)
    `${f}${li}@${domain}`,      // johns            (~2%)
    `${fi}${li}@${domain}`,     // js               (<1%)
    `${f}_${l}@${domain}`,      // john_smith
    `${l}@${domain}`,           // smith
  ];
}

async function findVerifiedEmails(firstName, lastName, domain) {
  const patterns = generateEmailPatterns(firstName, lastName, domain);
  const { hasMX } = await verifyDomain(domain);

  if (!hasMX) return [];

  // Verify MX in parallel — fast
  const results = await Promise.all(
    patterns.map(async (email) => {
      const valid = await verifyEmail(email);
      return { email, mxVerified: valid, confidence: valid ? 'medium' : 'low' };
    })
  );

  return results.filter(r => r.mxVerified);
}

// ════════════════════════════════════════════════════════════
//  SOURCE 10 — HUNTER.IO FREE TIER (25 free/month, optional)
// ════════════════════════════════════════════════════════════
async function hunterDomainSearch(domain, apiKey) {
  if (!apiKey) return [];
  try {
    const res = await http.get('https://api.hunter.io/v2/domain-search', {
      params: { domain, limit: 10, api_key: apiKey },
    });
    return (res.data.data?.emails || []).map(e => ({
      email: e.value,
      firstName: e.first_name,
      lastName: e.last_name,
      position: e.position,
      confidence: e.confidence,
      linkedin: e.linkedin,
      src: 'hunter'
    }));
  } catch {
    return [];
  }
}

// ════════════════════════════════════════════════════════════
//  SOURCE 11 — SEC EDGAR (public companies, 100% free API)
// ════════════════════════════════════════════════════════════
async function searchSECEdgar(companyName) {
  try {
    const res = await http.get('https://efts.sec.gov/LATEST/search-index?q=' + encodeURIComponent(companyName) + '&dateRange=custom&startdt=2020-01-01&forms=10-K', {
      headers: { 'User-Agent': 'ArgiFlow contact@argiflow.com' }, // EDGAR requires this
    });
    // Search for company info
    const search = await http.get(`https://efts.sec.gov/LATEST/search-index?q=%22${encodeURIComponent(companyName)}%22&forms=10-K`, {
      headers: { 'User-Agent': 'ArgiFlow contact@argiflow.com' },
    });
    return search.data?.hits?.hits?.slice(0, 3).map(h => ({
      name: h._source?.display_names?.[0],
      cik: h._source?.entity_id,
      src: 'sec_edgar'
    })) || [];
  } catch {
    return [];
  }
}

// ════════════════════════════════════════════════════════════
//  MASTER FUNCTIONS — what ArgiFlow calls
// ════════════════════════════════════════════════════════════

/**
 * Search for B2B leads across all free sources
 * @param {object} opts - { q, industry, location, size, limit }
 * @returns {array} Deduplicated, scored lead array
 */
async function searchLeads({ q = '', industry = '', location = '', size = '', limit = 20 } = {}) {
  const BLACKLIST = new Set([
    'wikipedia.org', 'reddit.com', 'youtube.com', 'facebook.com', 'twitter.com',
    'instagram.com', 'indeed.com', 'glassdoor.com', 'amazon.com', 'yelp.com',
    'bbb.org', 'manta.com', 'yellowpages.com', 'mapquest.com', 'whitepages.com',
  ]);

  const part = [q, industry, location, size].filter(Boolean).join(' ');
  const queries = [
    `${part} company contact`,
    industry && location ? `${industry} businesses ${location}` : null,
    q && location ? `"${q}" ${location}` : null,
  ].filter(Boolean);

  // Run DDG + Bing in parallel across queries
  const webPromises = queries.slice(0, 2).flatMap(query => [
    searchDDG(query, Math.ceil(limit / 2)),
    searchBing(query, Math.ceil(limit / 2)),
  ]);

  const webResults = (await Promise.allSettled(webPromises))
    .filter(r => r.status === 'fulfilled')
    .flatMap(r => r.value);

  // Deduplicate by domain
  const seen = new Set();
  const leads = [];

  for (const r of webResults) {
    if (!r.domain || seen.has(r.domain) || BLACKLIST.has(r.domain)) continue;
    if (!r.domain.includes('.') || r.domain.length < 4) continue;
    seen.add(r.domain);

    leads.push({
      domain: r.domain,
      name: r.title?.split(/[|\-–—]/)[0].trim(),
      website: r.url,
      snippet: r.snippet,
      industry: industry || null,
      location: location || null,
      score: scoreResult(r, { industry, location, q }),
      src: r.src,
    });
  }

  return leads
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/**
 * Enrich a single company domain — hits every free source
 * @param {string} domain
 * @param {object} opts - { hunterKey }
 */
async function enrichCompany(domain, { hunterKey } = {}) {
  const clean = cleanDomain(domain);

  const [siteData, domainInfo, dnsInfo] = await Promise.allSettled([
    scrapeWebsite(clean),
    getDomainInfo(clean),
    verifyDomain(clean),
  ]);

  const site   = siteData.status   === 'fulfilled' ? siteData.value   : {};
  const rdap   = domainInfo.status === 'fulfilled' ? domainInfo.value  : null;
  const dns_   = dnsInfo.status    === 'fulfilled' ? dnsInfo.value     : {};

  // Optional: Hunter free tier if key provided
  const emails = hunterKey ? await hunterDomainSearch(clean, hunterKey) : [];

  return {
    domain: clean,
    ...site,
    logo: site.logo || `https://logo.clearbit.com/${clean}`,
    domainCreated: rdap?.created || null,
    registrar: rdap?.registrar || null,
    dnsActive: dns_.hasA,
    hasMX: dns_.hasMX,
    mxRecords: dns_.mxRecords,
    contacts: emails,
    enrichedAt: new Date().toISOString(),
    sources: ['website', rdap ? 'rdap' : null, dns_.hasA ? 'dns' : null, emails.length ? 'hunter' : null].filter(Boolean),
  };
}

/**
 * Find a contact's email + LinkedIn with ZERO paid APIs
 * @param {string} firstName
 * @param {string} lastName
 * @param {string} domain
 * @param {object} opts - { company, title, hunterKey }
 */
async function findContact(firstName, lastName, domain, { company = '', title = '', hunterKey } = {}) {
  const clean = cleanDomain(domain);

  const [emailResults, linkedInResults] = await Promise.allSettled([
    findVerifiedEmails(firstName, lastName, clean),
    searchLinkedInPeople(`${firstName} ${lastName}`, company || clean, title),
  ]);

  let emails = emailResults.status === 'fulfilled' ? emailResults.value : [];
  const profiles = linkedInResults.status === 'fulfilled' ? linkedInResults.value : [];

  // Fall back to Hunter if key provided and no emails found
  if (emails.length === 0 && hunterKey) {
    try {
      const res = await http.get('https://api.hunter.io/v2/email-finder', {
        params: { domain: clean, first_name: firstName, last_name: lastName, api_key: hunterKey },
      });
      if (res.data.data?.email) {
        emails.push({
          email: res.data.data.email,
          confidence: res.data.data.score ? `${res.data.data.score}%` : 'medium',
          mxVerified: true,
          src: 'hunter',
        });
      }
    } catch {}
  }

  return {
    firstName, lastName, domain: clean,
    emails,
    linkedInProfiles: profiles,
    confidence: emails.length > 0 ? (emails[0].src === 'hunter' ? 'high' : 'medium') : (profiles.length > 0 ? 'low' : 'none'),
  };
}

/**
 * Search local businesses (Yellow Pages + Manta + web)
 * @param {string} type  - "medical practice", "law firm", etc.
 * @param {string} city
 * @param {string} state - optional
 * @param {number} limit
 */
async function searchLocal(type, city, state = '', limit = 25) {
  const location = [city, state].filter(Boolean).join(', ');

  const [ypResults, mantaResults, webResults, linkedInResults] = await Promise.allSettled([
    scrapeYellowPages(type, location, limit),
    scrapeManta(type, location, Math.ceil(limit / 2)),
    searchDDG(`${type} ${location} contact phone email`, Math.ceil(limit / 2)),
    searchLinkedIn('', type, location),
  ]);

  const yp      = ypResults.status      === 'fulfilled' ? ypResults.value      : [];
  const manta   = mantaResults.status   === 'fulfilled' ? mantaResults.value   : [];
  const web     = webResults.status     === 'fulfilled' ? webResults.value     : [];
  const linkedin = linkedInResults.status === 'fulfilled' ? linkedInResults.value : [];

  // Merge and deduplicate by name
  const seen = new Set();
  const all  = [];

  for (const biz of [...yp, ...manta]) {
    const key = biz.name?.toLowerCase().replace(/\s+/g, '');
    if (!key || seen.has(key)) continue;
    seen.add(key);
    all.push(biz);
  }

  // Add web results that aren't blacklisted dirs
  const DIRS = new Set(['yellowpages.com', 'manta.com', 'whitepages.com', 'yelp.com']);
  for (const r of web) {
    if (!r.domain || DIRS.has(r.domain) || seen.has(r.domain)) continue;
    seen.add(r.domain);
    all.push({
      name: r.title?.split(/[|\-]/)[0].trim(),
      website: r.url, domain: r.domain,
      snippet: r.snippet, src: 'web'
    });
  }

  return {
    type, location,
    total: all.length,
    businesses: all.slice(0, limit),
    linkedin: linkedin.slice(0, 5),
  };
}

// ════════════════════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════════════════════
function cleanDomain(input = '') {
  try {
    if (!input.includes('http')) input = 'https://' + input;
    return new URL(input).hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return input.replace(/^www\./, '').split('/')[0].toLowerCase();
  }
}

function cleanPhone(raw = '') {
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 10) return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6)}`;
  if (digits.length === 11 && digits[0] === '1') return `+1 (${digits.slice(1,4)}) ${digits.slice(4,7)}-${digits.slice(7)}`;
  return raw.trim() || null;
}

function scoreResult(result, filters = {}) {
  let score = 50;
  const snip = (result.snippet || '').toLowerCase();
  const ttl  = (result.title   || '').toLowerCase();

  if (filters.industry && snip.includes(filters.industry.toLowerCase())) score += 18;
  if (filters.location  && snip.includes(filters.location.toLowerCase()))  score += 15;
  if (filters.q         && (snip.includes(filters.q.toLowerCase()) || ttl.includes(filters.q.toLowerCase()))) score += 12;
  if (snip.includes('contact') || snip.includes('about us')) score += 8;
  if (result.domain?.match(/\.(com|io|co|net)$/)) score += 5;
  if (result.domain?.length < 20) score += 5; // clean domain = legit company

  return Math.min(100, score);
}

module.exports = {
  searchLeads,
  enrichCompany,
  findContact,
  searchLocal,
  // raw sources (for custom use)
  searchDDG,
  searchBing,
  scrapeYellowPages,
  scrapeManta,
  searchLinkedIn,
  searchLinkedInPeople,
  scrapeWebsite,
  getDomainInfo,
  verifyDomain,
  verifyEmail,
  generateEmailPatterns,
  findVerifiedEmails,
  hunterDomainSearch,
  searchSECEdgar,
  // utils
  cleanDomain,
  cleanPhone,
};
