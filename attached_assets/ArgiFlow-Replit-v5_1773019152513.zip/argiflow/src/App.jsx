import { useState, useEffect, useRef, useCallback } from "react";

/*
  ARGIFLOW PLATFORM
  ──────────────────────────────────────────────────────────
  MULTI-LLM ROUTER — switch providers from UI, zero code changes
  Supported: Anthropic · OpenAI · Google Gemini · Mistral
             Groq · Together AI · Any OpenAI-compatible endpoint
  ──────────────────────────────────────────────────────────
*/

// ═══════════════════════════════════════════════════════
//  THEME
// ═══════════════════════════════════════════════════════
const T = {
  bg:"#F4F6FB", card:"#FFFFFF", card2:"#F0F3FA", card3:"#E6EAF6",
  line:"rgba(90,110,180,0.12)", lineHi:"rgba(90,110,180,0.24)",
  ink:"#161E36", mid:"#4E5E82", low:"#8E9BB8",
  blue:"#4B6CF7", blueL:"#EEF1FF",
  green:"#0DAD74", greenL:"#E5FAF1",
  amber:"#E79109", amberL:"#FEF3E0",
  red:"#E44444", redL:"#FEE9E9",
  violet:"#7B5BFB", violetL:"#EDEAFE",
  teal:"#0691A1", tealL:"#E0F6F8",
  gray:"#F0F3FA",
};

const CREDIT_COSTS = {
  ai_email:8, lead_enrich:15, agent_run:50,
  reply_analyze:10, intent_scan:20, email_sequence:30,
};

// ═══════════════════════════════════════════════════════
//  LLM PROVIDER REGISTRY
//  Each entry describes HOW to call that provider.
//  Users fill in api_key + model via Settings UI.
// ═══════════════════════════════════════════════════════
const LLM_REGISTRY = {
  anthropic: {
    name: "Anthropic",
    logo: "🟠",
    baseUrl: "https://api.anthropic.com",
    defaultModel: "claude-sonnet-4-6",
    modelOptions: ["claude-sonnet-4-6","claude-opus-4-6","claude-haiku-4-5-20251001"],
    format: "anthropic",
    docsUrl: "https://docs.anthropic.com",
    placeholder: "sk-ant-api03-…",
  },
  openai: {
    name: "OpenAI",
    logo: "🟢",
    baseUrl: "https://api.openai.com",
    defaultModel: "gpt-4o",
    modelOptions: ["gpt-4o","gpt-4o-mini","gpt-4-turbo","gpt-3.5-turbo"],
    format: "openai",
    docsUrl: "https://platform.openai.com/docs",
    placeholder: "sk-…",
  },
  gemini: {
    name: "Google Gemini",
    logo: "🔵",
    baseUrl: "https://generativelanguage.googleapis.com",
    defaultModel: "gemini-1.5-pro",
    modelOptions: ["gemini-1.5-pro","gemini-1.5-flash","gemini-2.0-flash"],
    format: "gemini",
    docsUrl: "https://ai.google.dev/docs",
    placeholder: "AIza…",
  },
  mistral: {
    name: "Mistral AI",
    logo: "🟡",
    baseUrl: "https://api.mistral.ai",
    defaultModel: "mistral-large-latest",
    modelOptions: ["mistral-large-latest","mistral-medium-latest","mistral-small-latest","open-mixtral-8x22b"],
    format: "openai",
    docsUrl: "https://docs.mistral.ai",
    placeholder: "…",
  },
  groq: {
    name: "Groq",
    logo: "⚡",
    baseUrl: "https://api.groq.com/openai",
    defaultModel: "llama-3.3-70b-versatile",
    modelOptions: ["llama-3.3-70b-versatile","llama-3.1-8b-instant","mixtral-8x7b-32768","gemma2-9b-it"],
    format: "openai",
    docsUrl: "https://console.groq.com/docs",
    placeholder: "gsk_…",
  },
  together: {
    name: "Together AI",
    logo: "🟣",
    baseUrl: "https://api.together.xyz",
    defaultModel: "meta-llama/Llama-3-70b-chat-hf",
    modelOptions: ["meta-llama/Llama-3-70b-chat-hf","mistralai/Mixtral-8x22B-Instruct-v0.1","Qwen/Qwen2-72B-Instruct"],
    format: "openai",
    docsUrl: "https://docs.together.ai",
    placeholder: "…",
  },
  custom: {
    name: "Custom / Self-hosted",
    logo: "🔧",
    baseUrl: "",
    defaultModel: "",
    modelOptions: [],
    format: "openai",
    docsUrl: "",
    placeholder: "Your API key",
  },
};

// ═══════════════════════════════════════════════════════
//  UNIVERSAL LLM CALLER
//  Reads active provider config from localStorage.
//  Zero code changes needed to switch providers.
// ═══════════════════════════════════════════════════════
async function callLLM({ system, userMessage, maxTokens = 800, providerConfig = null }) {
  // Load config from localStorage if not passed directly
  const cfg = providerConfig ?? JSON.parse(localStorage.getItem("argiflow_llm_config") ?? "null");

  if (!cfg || !cfg.providerId) throw new Error("No LLM provider configured. Go to Settings → AI Providers.");
  if (!cfg.apiKey) throw new Error(`No API key set for ${cfg.providerId}. Go to Settings → AI Providers.`);

  const reg = LLM_REGISTRY[cfg.providerId];
  if (!reg) throw new Error(`Unknown provider: ${cfg.providerId}`);

  const model   = cfg.model || reg.defaultModel;
  const baseUrl = cfg.customBaseUrl || reg.baseUrl;
  const format  = cfg.format || reg.format;

  // ── Anthropic format ──────────────────────────────
  if (format === "anthropic") {
    const res = await fetch(`${baseUrl}/v1/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": cfg.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model, max_tokens: maxTokens,
        system,
        messages: [{ role: "user", content: userMessage }],
      }),
    });
    if (!res.ok) { const e = await res.json().catch(()=>({error:{message:res.statusText}})); throw new Error(e?.error?.message || res.statusText); }
    const data = await res.json();
    return data.content?.[0]?.text ?? "";
  }

  // ── OpenAI-compatible format (OpenAI, Mistral, Groq, Together, Custom) ──
  if (format === "openai") {
    const endpoint = `${baseUrl}/v1/chat/completions`;
    const messages = [];
    if (system) messages.push({ role: "system", content: system });
    messages.push({ role: "user", content: userMessage });
    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({ model, max_tokens: maxTokens, messages }),
    });
    if (!res.ok) { const e = await res.json().catch(()=>({error:{message:res.statusText}})); throw new Error(e?.error?.message || res.statusText); }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? "";
  }

  // ── Google Gemini format ──────────────────────────
  if (format === "gemini") {
    const endpoint = `${baseUrl}/v1beta/models/${model}:generateContent?key=${cfg.apiKey}`;
    const body = {
      contents: [{ parts: [{ text: userMessage }] }],
      generationConfig: { maxOutputTokens: maxTokens },
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) { const e = await res.json().catch(()=>({error:{message:res.statusText}})); throw new Error(e?.error?.message || res.statusText); }
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  }

  throw new Error(`Unsupported format: ${format}`);
}

// ═══════════════════════════════════════════════════════
//  DEMO DATA  (overview + intent — shows your data)
// ═══════════════════════════════════════════════════════
const DEMO_PIPELINE = [
  { label:"Found",     count:12847, pct:100, color:T.blue   },
  { label:"Enriched",  count:9420,  pct:73,  color:"#6366F1" },
  { label:"Contacted", count:3204,  pct:25,  color:T.violet  },
  { label:"Replied",   count:387,   pct:3,   color:T.teal    },
  { label:"Meeting",   count:87,    pct:1,   color:T.green   },
  { label:"Closed",    count:34,    pct:0.3, color:"#059669"  },
];

const DEMO_ACTIVITY = [
  { icon:"✦", type:"agent",    text:"Lead Scout enriched 47 dental prospects in Texas",    time:"2m ago"  },
  { icon:"→", type:"outreach", text:"Outreach Agent sent 124 personalized cold emails",    time:"8m ago"  },
  { icon:"◎", type:"intent",   text:"Intent signal: Acme Solutions researching CRM tools", time:"15m ago" },
  { icon:"⊙", type:"meeting",  text:"Meeting booked: Sarah K. — Thu 2pm via AI reply",    time:"22m ago" },
  { icon:"⚡", type:"alert",   text:"'Hot Lead Alert' fired for 3 new 90+ score leads",   time:"40m ago" },
  { icon:"⬡", type:"agent",    text:"Forum Prospector found 28 new prospects on Reddit",   time:"58m ago" },
];

const DEMO_AGENT_HEALTH = [
  { name:"Lead Scout",        status:"active", runs:4821, rate:98.2 },
  { name:"Cold Email Writer", status:"active", runs:2204, rate:94.7 },
  { name:"Reply Analyzer",    status:"active", runs:891,  rate:99.1 },
  { name:"Intent Monitor",    status:"paused", runs:1240, rate:91.3 },
];

const DEMO_INTENT_SIGNALS = [
  { id:1, company:"Acme Solutions",  domain:"acmesol.com",     signal:"Visited 7 competitor pricing pages in 48h",      strength:"HIGH", score:94, time:"3m ago"  },
  { id:2, company:"TechBridge Corp", domain:"techbridge.io",   signal:"Posted 3 VP Sales roles — scaling team",          strength:"HIGH", score:88, time:"21m ago" },
  { id:3, company:"Global Dynamics", domain:"globaldyn.com",   signal:"Downloaded CRM comparison whitepaper",            strength:"MED",  score:71, time:"38m ago" },
  { id:4, company:"Nexus Partners",  domain:"nexusp.co",       signal:"CEO asking about outbound tools on LinkedIn",      strength:"MED",  score:76, time:"1h ago"  },
  { id:5, company:"BrightScale Inc", domain:"brightscale.com", signal:"$4.2M Series A announced",                       strength:"HIGH", score:91, time:"3h ago"  },
  { id:6, company:"Velocity Health", domain:"velocityh.io",    signal:"Hired RevOps Director last week",                 strength:"MED",  score:68, time:"5h ago"  },
  { id:7, company:"Lagos Ventures",  domain:"lagosv.ng",       signal:"Searching 'sales automation Africa' repeatedly",  strength:"HIGH", score:84, time:"6h ago"  },
];

const DEMO_INTENT_SOURCES = [
  { label:"Job postings",      count:1204 },
  { label:"Pricing page visits",count:384 },
  { label:"Content downloads", count:892  },
  { label:"LinkedIn signals",  count:2104 },
  { label:"News & funding",    count:247  },
  { label:"Forum mentions",    count:563  },
];

// ═══════════════════════════════════════════════════════
//  NAV
// ═══════════════════════════════════════════════════════
const NAV = [
  { section:"Main", items:[
    { id:"overview",          label:"Overview",            icon:"⬡" },
  ]},
  { section:"AI Automation", items:[
    { id:"ai-agents",         label:"AI Agents",           icon:"◉", badge:"LIVE" },
    { id:"sequences",         label:"Sequences",           icon:"⟳" },
  ]},
  { section:"Sales Intelligence", items:[
    { id:"lead-intelligence", label:"Lead Intelligence",   icon:"◎" },
    { id:"intent-data",       label:"Intent Data",         icon:"◈", badge:"NEW" },
    { id:"forum-prospector",  label:"Forum Prospector",    icon:"⬡" },
  ]},
  { section:"Platform", items:[
    { id:"website-builder",   label:"Website Builder",     icon:"⬟", badge:"NEW" },
    { id:"landing-pages",     label:"Landing Pages",       icon:"⟁" },
    { id:"forms",             label:"Forms & Surveys",     icon:"◫" },
    { id:"chat-widget",       label:"Chat Widget",         icon:"◉" },
    { id:"invoicing",         label:"Invoicing",           icon:"▤" },
    { id:"social-media",      label:"Social Media",        icon:"⬡" },
    { id:"calendar",          label:"Calendar",            icon:"⊙" },
  ]},
  { section:"Growth", items:[
    { id:"workflow-builder",  label:"Workflow Builder",    icon:"⬟" },
    { id:"automations",       label:"Automations",         icon:"⚡" },
    { id:"crm-integrations",  label:"CRM Integrations",    icon:"⬡" },
  ]},
  { section:"Analytics & Tracking", items:[
    { id:"analytics",         label:"Analytics Dashboard", icon:"◈", badge:"NEW" },
    { id:"visitor-list",      label:"Visitor Intelligence",icon:"◎" },
    { id:"realtime",          label:"Real-Time Feed",      icon:"◉", badge:"LIVE" },
    { id:"search-analytics",  label:"Search Analytics",   icon:"⬡" },
    { id:"email-tracking",    label:"Email Tracking",      icon:"→" },
    { id:"form-analytics",    label:"Form Analytics",      icon:"◫" },
    { id:"heatmaps",          label:"Click Heatmap",       icon:"⬟" },
  ]},
  { section:"Account", items:[
    { id:"ai-providers",      label:"AI Providers",        icon:"◈", badge:"NEW" },
    { id:"credits",           label:"Credits & Billing",   icon:"◎" },
    { id:"settings",          label:"Settings",            icon:"⊙" },
  ]},
];

// ═══════════════════════════════════════════════════════
//  PRIMITIVES
// ═══════════════════════════════════════════════════════
const Badge = ({ v }) => {
  const s = {
    NEW:{ bg:T.greenL,  border:"rgba(13,173,116,0.22)", c:T.green },
    LIVE:{ bg:T.blueL, border:"rgba(75,108,247,0.25)", c:T.blue  },
  };
  const st = s[v]||{};
  return <span style={{ fontSize:8.5, fontWeight:700, letterSpacing:"0.07em", padding:"2px 6px", borderRadius:4, fontFamily:"'JetBrains Mono',monospace", background:st.bg, border:`1px solid ${st.border}`, color:st.c }}>{v}</span>;
};

const Card = ({ children, sx={} }) => (
  <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, boxShadow:"0 1px 4px rgba(40,55,120,0.05)", ...sx }}>{children}</div>
);

const Btn = ({ children, variant="ghost", onClick, disabled, loading, sx={} }) => {
  const base = { padding:"7px 15px", borderRadius:9, fontSize:12.5, fontWeight:600, cursor:disabled||loading?"not-allowed":"pointer", border:"none", opacity:disabled||loading?0.6:1, transition:"all 0.14s", display:"inline-flex", alignItems:"center", justifyContent:"center", gap:6, ...sx };
  const v = {
    primary:{ background:`linear-gradient(135deg,${T.blue},${T.violet})`, color:"#fff", boxShadow:`0 3px 12px ${T.blue}28` },
    green:  { background:T.green,  color:"#fff" },
    ghost:  { background:T.card,   border:`1px solid ${T.line}`, color:T.mid },
    blue:   { background:T.blueL,  border:`1px solid rgba(75,108,247,0.22)`, color:T.blue },
    danger: { background:T.redL,   border:`1px solid rgba(228,68,68,0.22)`, color:T.red },
    amber:  { background:T.amberL, border:`1px solid rgba(231,145,9,0.22)`, color:T.amber },
    subtle: { background:T.card2,  border:`1px solid ${T.line}`, color:T.mid },
  };
  return <button onClick={onClick} disabled={disabled||loading} style={{...base,...(v[variant]||v.ghost)}}>{loading?"…":children}</button>;
};

const Dot = ({ active=true, color=T.green, size=6 }) => (
  <span style={{ display:"inline-block", width:size, height:size, borderRadius:"50%", background:active?color:T.low, flexShrink:0, boxShadow:active?`0 0 0 2.5px ${color}28`:undefined }} />
);

const Spinner = ({ size=16 }) => (
  <span style={{ display:"inline-block", width:size, height:size, borderRadius:"50%", border:`2px solid ${T.line}`, borderTopColor:T.blue, animation:"spin 0.7s linear infinite", flexShrink:0 }} />
);

const EmptyState = ({ icon="◈", title, desc, action }) => (
  <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"60px 20px", textAlign:"center", gap:16 }}>
    <div style={{ fontSize:44, opacity:0.12 }}>{icon}</div>
    <div>
      <div style={{ fontWeight:700, fontSize:17, color:T.ink, marginBottom:8 }}>{title}</div>
      {desc && <div style={{ fontSize:13, color:T.mid, maxWidth:360, lineHeight:1.7 }}>{desc}</div>}
    </div>
    {action}
  </div>
);

const FLabel = ({ children }) => <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:5 }}>{children}</div>;
const Field  = ({ label, children }) => <div><FLabel>{label}</FLabel>{children}</div>;

const Input = (props) => (
  <input {...props} style={{ width:"100%", background:T.card2, border:`1px solid ${T.line}`, borderRadius:8, padding:"8px 11px", fontSize:12.5, color:T.ink, outline:"none", transition:"border-color 0.14s", ...(props.style||{}) }}
    onFocus={e=>{e.target.style.borderColor="rgba(75,108,247,0.45)";e.target.style.background=T.card;}}
    onBlur={e =>{e.target.style.borderColor=T.line;e.target.style.background=T.card2;}}
  />
);

const SelectEl = ({ opts=[], def, value, onChange, style:sx={} }) => (
  <select value={value} onChange={onChange} defaultValue={def}
    style={{ width:"100%", background:T.card2, border:`1px solid ${T.line}`, borderRadius:8, padding:"8px 11px", fontSize:12.5, color:T.ink, outline:"none", ...sx }}>
    {opts.map(o => typeof o==="string"
      ? <option key={o} value={o}>{o}</option>
      : <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>
);

const CreditCost = ({ action }) => (
  <span style={{ fontSize:10, padding:"2px 7px", borderRadius:5, background:T.amberL, border:`1px solid rgba(231,145,9,0.2)`, color:T.amber, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>
    {CREDIT_COSTS[action]}cr
  </span>
);

// ═══════════════════════════════════════════════════════
//  ROOT APP
// ═══════════════════════════════════════════════════════
export default function App() {
  const [page, setPage]       = useState("overview");
  const [collapsed, setCollapsed] = useState(false);
  const [credits, setCredits] = useState(3000);
  const [user]                = useState({ name:"Abel Nkawula", org:"ARGILETTE LLC", plan:"growth" });

  // Active LLM config — loaded from localStorage, updated in AI Providers settings
  const [llmConfig, setLlmConfig] = useState(() => {
    try { return JSON.parse(localStorage.getItem("argiflow_llm_config") ?? "null"); }
    catch { return null; }
  });

  const saveLlmConfig = (cfg) => {
    setLlmConfig(cfg);
    localStorage.setItem("argiflow_llm_config", JSON.stringify(cfg));
  };

  const deductCredits = useCallback((action) => {
    setCredits(p => Math.max(0, p - (CREDIT_COSTS[action]||0)));
  }, []);

  const allItems = NAV.flatMap(s=>s.items);
  const current  = allItems.find(i=>i.id===page);
  const reg = llmConfig ? LLM_REGISTRY[llmConfig.providerId] : null;

  const PAGES = {
    "overview":          <OverviewPage credits={credits} setPage={setPage} />,
    "lead-intelligence": <LeadIntelPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "workflow-builder":  <WorkflowPage />,
    "ai-agents":         <AgentsPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "intent-data":       <IntentPage credits={credits} deductCredits={deductCredits} />,
    "website-builder":   <WebBuilderPage />,
    "ai-providers":      <AIProvidersPage llmConfig={llmConfig} saveLlmConfig={saveLlmConfig} />,
    "credits":           <CreditsPage credits={credits} user={user} />,
    // ── Tracking pages ───────────────────────────────
    "analytics":         <AnalyticsDashPage />,
    "visitor-list":      <VisitorListPage />,
    "realtime":          <RealtimePage />,
    "search-analytics":  <SearchAnalyticsPage />,
    "email-tracking":    <EmailTrackingPage />,
    "form-analytics":    <FormAnalyticsPage />,
    "heatmaps":          <HeatmapPage />,
    // ── Stub pages for all other nav items ───────────
    "sequences":         <SequencesPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "forum-prospector":  <ForumProspectorPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "landing-pages":     <LandingPagesPage />,
    "forms":             <FormsPage />,
    "chat-widget":       <ChatWidgetPage />,
    "invoicing":         <InvoicingPage />,
    "social-media":      <SocialMediaPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "calendar":          <CalendarPage />,
    "automations":       <AutomationsPage />,
    "crm-integrations":  <CRMIntegrationsPage />,
    "settings":          <SettingsPage user={user} />,
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:${T.bg};color:${T.ink};font-family:'Plus Jakarta Sans',sans-serif;}
        ::-webkit-scrollbar{width:4px;height:4px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:${T.line};border-radius:2px;}
        @keyframes fadein{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
        @keyframes slidein{from{opacity:0;transform:translateX(8px)}to{opacity:1;transform:none}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes flowdash{to{stroke-dashoffset:-14}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.35}}
        .fadein{animation:fadein 0.28s ease both;}
        .slidein{animation:slidein 0.22s ease both;}
        input,select,textarea,button{font-family:'Plus Jakarta Sans',sans-serif;}
      `}</style>

      <div style={{ display:"flex", height:"100vh", overflow:"hidden" }}>

        {/* SIDEBAR */}
        <aside style={{ width:collapsed?52:214, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column", transition:"width 0.2s ease", overflow:"hidden", zIndex:20, boxShadow:"2px 0 14px rgba(75,108,247,0.05)" }}>

          <div style={{ height:54, display:"flex", alignItems:"center", padding:`0 ${collapsed?"13px":"14px"}`, borderBottom:`1px solid ${T.line}`, gap:10, flexShrink:0 }}>
            <div style={{ width:30, height:30, borderRadius:9, background:`linear-gradient(135deg,${T.blue},${T.violet})`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, boxShadow:`0 3px 10px ${T.blue}35` }}>
              <span style={{ color:"#fff", fontWeight:800, fontSize:14 }}>A</span>
            </div>
            {!collapsed && <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontWeight:800, fontSize:14, color:T.ink }}>ArgiFlow</div>
              <div style={{ fontSize:9.5, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>ARGILETTE</div>
            </div>}
            <button onClick={()=>setCollapsed(p=>!p)} style={{ background:"none", border:"none", color:T.low, cursor:"pointer", fontSize:16, lineHeight:1, padding:4, flexShrink:0, marginLeft:"auto" }}>{collapsed?"›":"‹"}</button>
          </div>

          <div style={{ flex:1, overflowY:"auto", padding:"6px 0" }}>
            {NAV.map(section => (
              <div key={section.section}>
                {!collapsed && <div style={{ padding:"10px 14px 3px", fontSize:9, fontWeight:700, color:T.low, letterSpacing:"0.12em", textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>{section.section}</div>}
                {collapsed && <div style={{ height:5 }} />}
                {section.items.map(item => {
                  const active = page===item.id;
                  return (
                    <div key={item.id} onClick={()=>setPage(item.id)} title={collapsed?item.label:""}
                      style={{ display:"flex", alignItems:"center", gap:8, padding:collapsed?"7px 12px":"5px 9px 5px 12px", margin:"1px 6px", borderRadius:8, cursor:"pointer", background:active?T.blueL:"transparent", borderLeft:`2px solid ${active?T.blue:"transparent"}`, transition:"all 0.12s" }}
                      onMouseEnter={e=>{if(!active)e.currentTarget.style.background=T.card2;}}
                      onMouseLeave={e=>{if(!active)e.currentTarget.style.background="transparent";}}>
                      <span style={{ fontSize:12, color:active?T.blue:T.low, flexShrink:0, opacity:active?1:0.7 }}>{item.icon}</span>
                      {!collapsed && <>
                        <span style={{ flex:1, fontSize:12.5, fontWeight:active?600:400, color:active?T.blue:T.mid, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{item.label}</span>
                        {item.badge && <Badge v={item.badge} />}
                      </>}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* LLM indicator */}
          {!collapsed && (
            <div onClick={()=>setPage("ai-providers")} style={{ margin:"4px 10px", padding:"9px 12px", borderRadius:10, background:llmConfig?T.greenL:T.amberL, border:`1px solid ${llmConfig?"rgba(13,173,116,0.22)":"rgba(231,145,9,0.22)"}`, cursor:"pointer" }}>
              <div style={{ fontSize:9, fontWeight:700, color:T.low, fontFamily:"'JetBrains Mono',monospace", marginBottom:3 }}>AI PROVIDER</div>
              {llmConfig ? (
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  <span style={{ fontSize:13 }}>{reg?.logo}</span>
                  <div>
                    <div style={{ fontSize:12, fontWeight:700, color:T.ink }}>{reg?.name}</div>
                    <div style={{ fontSize:9.5, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{llmConfig.model}</div>
                  </div>
                  <Dot color={T.green} size={5} style={{ marginLeft:"auto" }} />
                </div>
              ) : (
                <div style={{ fontSize:11.5, fontWeight:600, color:T.amber }}>⚠ Not configured →</div>
              )}
            </div>
          )}

          {/* Credits */}
          {!collapsed && (
            <div onClick={()=>setPage("credits")} style={{ margin:"4px 10px 8px", padding:"9px 12px", borderRadius:10, background:credits<200?T.amberL:T.blueL, border:`1px solid ${credits<200?"rgba(231,145,9,0.22)":"rgba(75,108,247,0.2)"}`, cursor:"pointer" }}>
              <div style={{ fontSize:9, fontWeight:700, color:T.low, fontFamily:"'JetBrains Mono',monospace", marginBottom:2 }}>CREDITS</div>
              <div style={{ fontSize:20, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{credits.toLocaleString()}</div>
              {credits<200 && <div style={{ fontSize:10, color:T.amber, fontWeight:600 }}>Low — top up →</div>}
            </div>
          )}

          {/* User */}
          {!collapsed && (
            <div style={{ padding:"12px 14px", borderTop:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:9 }}>
              <div style={{ width:30, height:30, borderRadius:"50%", background:`linear-gradient(135deg,${T.green},${T.teal})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:"#fff", flexShrink:0 }}>{user.name[0]}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12.5, fontWeight:600, color:T.ink, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user.name}</div>
                <div style={{ fontSize:10, color:T.low }}>{user.org}</div>
              </div>
              <span style={{ fontSize:9, padding:"2px 7px", borderRadius:5, background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, textTransform:"uppercase" }}>{user.plan}</span>
            </div>
          )}
        </aside>

        {/* MAIN */}
        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          <header style={{ height:54, background:T.card, borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", padding:"0 20px", gap:12, flexShrink:0, zIndex:10 }}>
            <span style={{ fontWeight:700, fontSize:15, color:T.ink, flex:1 }}>{current?.label||"ArgiFlow"}</span>
            <div style={{ display:"flex", gap:4 }}>
              {[["overview","Overview"],["lead-intelligence","Leads"],["intent-data","Intent"],["ai-agents","AI Agents"],["workflow-builder","Flows"],["website-builder","Sites"],["ai-providers","⚡ AI"]].map(([id,lbl])=>(
                <button key={id} onClick={()=>setPage(id)} style={{ padding:"5px 12px", borderRadius:7, fontSize:12, fontWeight:page===id?600:400, cursor:"pointer", background:page===id?T.blueL:"transparent", border:`1px solid ${page===id?"rgba(75,108,247,0.3)":T.line}`, color:page===id?T.blue:T.mid, transition:"all 0.12s" }}>{lbl}</button>
              ))}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:6, padding:"5px 11px", background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, borderRadius:8 }}>
              <Dot size={5} /><span style={{ fontSize:11.5, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>System live</span>
            </div>
          </header>

          <main key={page} className="fadein" style={{ flex:1, overflow:"auto" }}>
            {PAGES[page]||<BlankPage label={current?.label} />}
          </main>
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════
//  AI PROVIDERS PAGE  ← THE KEY NEW PAGE
//  Change your LLM from the UI — zero code changes
// ═══════════════════════════════════════════════════════
function AIProvidersPage({ llmConfig, saveLlmConfig }) {
  const [draft, setDraft]     = useState(llmConfig ?? { providerId:"anthropic", apiKey:"", model:"", customBaseUrl:"" });
  const [testing, setTesting] = useState(false);
  const [testResult, setTest] = useState(null); // null | {ok, msg}
  const [saved, setSaved]     = useState(false);

  const reg = LLM_REGISTRY[draft.providerId];

  const ud = (k,v) => { setDraft(p=>({...p,[k]:v})); setTest(null); setSaved(false); };

  const testConnection = async () => {
    if (!draft.apiKey) { setTest({ok:false,msg:"Enter your API key first."}); return; }
    setTesting(true); setTest(null);
    try {
      const reply = await callLLM({
        system: "You are a test assistant.",
        userMessage: "Reply with exactly: CONNECTION OK",
        maxTokens: 20,
        providerConfig: { ...draft, model: draft.model || reg.defaultModel },
      });
      setTest({ ok:true, msg:`✓ Connected — model replied: "${reply.trim().slice(0,80)}"` });
    } catch (e) {
      setTest({ ok:false, msg:`✗ ${e.message}` });
    }
    setTesting(false);
  };

  const handleSave = () => {
    saveLlmConfig({ ...draft, model: draft.model || reg.defaultModel });
    setSaved(true);
  };

  return (
    <div style={{ padding:24, display:"flex", flexDirection:"column", gap:20, maxWidth:900 }}>

      {/* Header */}
      <div>
        <div style={{ fontWeight:800, fontSize:20, color:T.ink }}>AI Provider Settings</div>
        <div style={{ fontSize:13, color:T.mid, marginTop:4, lineHeight:1.65 }}>
          Switch between any LLM provider without touching code. Your API key is stored in your browser's local storage only — never sent to our servers.
        </div>
      </div>

      {/* Provider picker */}
      <Card sx={{ padding:24 }}>
        <div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:16 }}>
          Choose Provider
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10, marginBottom:24 }}>
          {Object.entries(LLM_REGISTRY).map(([id, r]) => {
            const active = draft.providerId===id;
            return (
              <div key={id} onClick={()=>ud("providerId",id)}
                style={{ padding:"14px 12px", borderRadius:12, cursor:"pointer", border:`2px solid ${active?"rgba(75,108,247,0.5)":T.line}`, background:active?T.blueL:T.card, transition:"all 0.15s", textAlign:"center" }}
                onMouseEnter={e=>{if(!active){e.currentTarget.style.borderColor=T.lineHi;e.currentTarget.style.background=T.card2;}}}
                onMouseLeave={e=>{if(!active){e.currentTarget.style.borderColor=T.line;e.currentTarget.style.background=T.card;}}}>
                <div style={{ fontSize:28, marginBottom:6 }}>{r.logo}</div>
                <div style={{ fontSize:12.5, fontWeight:active?700:500, color:active?T.blue:T.ink }}>{r.name}</div>
                {active && <div style={{ fontSize:9, color:T.blue, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, marginTop:3 }}>ACTIVE</div>}
              </div>
            );
          })}
        </div>

        {/* Config form */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
          <Field label={`API Key (${reg?.name})`}>
            <div style={{ position:"relative" }}>
              <Input type="password" value={draft.apiKey} onChange={e=>ud("apiKey",e.target.value)}
                placeholder={reg?.placeholder ?? "Your API key"} />
              {draft.apiKey && (
                <span style={{ position:"absolute", right:10, top:"50%", transform:"translateY(-50%)", fontSize:10, color:T.green, fontWeight:600 }}>●●●●●</span>
              )}
            </div>
            {reg?.docsUrl && (
              <div style={{ fontSize:10.5, color:T.low, marginTop:5 }}>
                Get yours at <a href={reg.docsUrl} target="_blank" rel="noreferrer"
                  style={{ color:T.blue, textDecoration:"none" }}>{reg.docsUrl.replace("https://","")}</a>
              </div>
            )}
          </Field>

          <Field label="Model">
            <SelectEl
              value={draft.model || (reg?.defaultModel??"")}
              onChange={e=>ud("model",e.target.value)}
              opts={reg?.modelOptions?.length
                ? reg.modelOptions.map(m=>({value:m,label:m}))
                : [{value:draft.model,label:draft.model||"Enter model below"}]}
            />
            {draft.providerId==="custom" && (
              <Input value={draft.model} onChange={e=>ud("model",e.target.value)}
                placeholder="e.g. llama-3-70b" style={{ marginTop:6 }} />
            )}
          </Field>

          {(draft.providerId==="custom" || draft.customBaseUrl) && (
            <Field label="Custom Base URL (optional)">
              <Input value={draft.customBaseUrl??""} onChange={e=>ud("customBaseUrl",e.target.value)}
                placeholder="https://your-endpoint.com" />
              <div style={{ fontSize:10.5, color:T.low, marginTop:5 }}>
                Override the default API endpoint. Use for self-hosted or proxy setups.
              </div>
            </Field>
          )}

          {draft.providerId==="custom" && (
            <Field label="Request Format">
              <SelectEl value={draft.format||"openai"} onChange={e=>ud("format",e.target.value)}
                opts={[{value:"openai",label:"OpenAI-compatible"},{value:"anthropic",label:"Anthropic"},{value:"gemini",label:"Google Gemini"}]} />
            </Field>
          )}
        </div>

        {/* Test + Save */}
        <div style={{ marginTop:20, display:"flex", alignItems:"center", gap:12 }}>
          <Btn variant="subtle" onClick={testConnection} loading={testing} sx={{ fontSize:12.5 }}>
            {testing ? "Testing…" : "⟳ Test Connection"}
          </Btn>
          <Btn variant="primary" onClick={handleSave} sx={{ fontSize:12.5 }}>
            Save & Activate
          </Btn>
          {saved && (
            <span className="fadein" style={{ fontSize:12, color:T.green, fontWeight:600 }}>
              ✓ Saved — ArgiFlow will now use {reg?.name}
            </span>
          )}
        </div>

        {testResult && (
          <div className="fadein" style={{ marginTop:12, padding:"11px 14px", borderRadius:9, background:testResult.ok?T.greenL:T.redL, border:`1px solid ${testResult.ok?"rgba(13,173,116,0.22)":"rgba(228,68,68,0.22)"}`, fontSize:12.5, color:testResult.ok?T.green:T.red }}>
            {testResult.msg}
          </div>
        )}
      </Card>

      {/* How it works */}
      <Card sx={{ padding:22 }}>
        <div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:14 }}>How provider switching works</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14 }}>
          {[
            { step:"1", title:"Pick provider", desc:"Select from Anthropic, OpenAI, Gemini, Mistral, Groq, Together AI, or any custom OpenAI-compatible endpoint." },
            { step:"2", title:"Enter API key", desc:"Your key is saved to browser localStorage only. It's never sent to ArgiFlow servers — only directly to the provider." },
            { step:"3", title:"All AI features update", desc:"Every AI agent, email writer, and enrichment in the platform instantly uses your chosen provider. No code changes." },
          ].map(s=>(
            <div key={s.step} style={{ padding:"16px 14px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:11 }}>
              <div style={{ width:28, height:28, borderRadius:8, background:T.blueL, border:`1px solid rgba(75,108,247,0.22)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:800, color:T.blue, marginBottom:10 }}>{s.step}</div>
              <div style={{ fontWeight:700, fontSize:13, color:T.ink, marginBottom:5 }}>{s.title}</div>
              <div style={{ fontSize:12, color:T.mid, lineHeight:1.65 }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Provider comparison */}
      <Card sx={{ padding:22 }}>
        <div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:14 }}>Provider Comparison</div>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12.5 }}>
            <thead>
              <tr style={{ background:T.card2 }}>
                {["Provider","Best for","Speed","Cost (approx)","Max tokens"].map(h=>(
                  <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", borderBottom:`1px solid ${T.line}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                ["🟠 Anthropic / Claude","Reasoning, writing","Medium","$3–15 / M tokens","200K"],
                ["🟢 OpenAI / GPT-4o","General tasks","Fast","$5–15 / M tokens","128K"],
                ["🔵 Google Gemini","Long context, speed","Fast","$1.25–5 / M tokens","1M"],
                ["🟡 Mistral","European data, cost","Fast","$2–8 / M tokens","128K"],
                ["⚡ Groq","Ultra-fast inference","Very fast","$0.05–0.27 / M tokens","128K"],
                ["🟣 Together AI","Open-source models","Fast","$0.10–0.90 / M tokens","128K"],
              ].map((row,i)=>(
                <tr key={i} style={{ borderBottom:`1px solid ${T.line}` }}>
                  {row.map((cell,j)=>(
                    <td key={j} style={{ padding:"11px 14px", color:j===0?T.ink:T.mid }}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  OVERVIEW PAGE  — with real data populated
// ═══════════════════════════════════════════════════════
function OverviewPage({ credits, setPage }) {
  const [tick, setTick] = useState(0);
  useEffect(() => { const t = setInterval(()=>setTick(p=>(p+1)%6),2800); return ()=>clearInterval(t); }, []);

  const liveCount = [12847,12891,12948,12982,13010,12998][tick];

  const topStats = [
    { label:"Leads in Database", value:liveCount.toLocaleString(), sub:`+${[203,247,312,189,271,228][tick]} added today`,     top:T.blue,   live:true  },
    { label:"Emails Sent (30d)",  value:"4,829",  sub:"94% delivered · 28% open rate",  top:T.teal  },
    { label:"Meetings Booked",   value:"87",     sub:"AI auto-booked 63 of them",       top:T.amber },
    { label:"Pipeline Value",    value:"$247K",  sub:"3 deals closing this week",        top:T.violet},
  ];

  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16 }}>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
        {topStats.map(m=>(
          <Card key={m.label} sx={{ padding:"18px 20px", position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${m.top}00,${m.top}70,${m.top}00)` }} />
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
              <span style={{ fontSize:10.5, color:T.low, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.05em" }}>{m.label}</span>
              {m.live && <Dot size={5} />}
            </div>
            <div style={{ fontSize:28, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace", letterSpacing:"-0.025em", lineHeight:1 }}>{m.value}</div>
            <div style={{ fontSize:11, color:T.low, marginTop:6 }}>{m.sub}</div>
          </Card>
        ))}
      </div>

      {/* Pipeline + Activity */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 320px", gap:12 }}>
        <Card sx={{ padding:22 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:20 }}>
            <div>
              <div style={{ fontWeight:700, fontSize:15, color:T.ink }}>End-to-End Pipeline</div>
              <div style={{ fontSize:11.5, color:T.low, marginTop:3 }}>Lead found → enriched → contacted → meeting</div>
            </div>
            <Btn variant="blue" sx={{ fontSize:11, padding:"5px 12px" }} onClick={()=>setPage("workflow-builder")}>Edit Flow →</Btn>
          </div>
          {DEMO_PIPELINE.map((s,i)=>(
            <div key={s.label} style={{ marginBottom:10 }}>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:5 }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <div style={{ width:6, height:6, borderRadius:"50%", background:s.color, flexShrink:0 }} />
                  <span style={{ fontSize:11.5, color:T.mid, width:72 }}>{s.label}</span>
                  <span style={{ fontSize:15, fontWeight:700, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{s.count.toLocaleString()}</span>
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  {i>0 && <span style={{ fontSize:10, color:T.low }}>↓{((s.count/DEMO_PIPELINE[i-1].count)*100).toFixed(0)}%</span>}
                  <span style={{ fontSize:10.5, color:T.low, fontFamily:"'JetBrains Mono',monospace", width:36, textAlign:"right" }}>{s.pct}%</span>
                </div>
              </div>
              <div style={{ height:6, background:T.card2, borderRadius:3, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${s.pct}%`, background:s.color, borderRadius:3, opacity:0.7, transition:"width 1.4s ease" }} />
              </div>
            </div>
          ))}
          <div style={{ marginTop:18, paddingTop:16, borderTop:`1px solid ${T.line}`, display:"flex", gap:8 }}>
            <Btn variant="primary" sx={{ fontSize:12 }} onClick={()=>setPage("lead-intelligence")}>Find Leads</Btn>
            <Btn sx={{ fontSize:12 }}>Run Sequence</Btn>
            <Btn sx={{ fontSize:12 }}>View Pipeline</Btn>
          </div>
        </Card>

        {/* Activity */}
        <Card sx={{ padding:20, display:"flex", flexDirection:"column" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:14, color:T.ink }}>AI Activity</div>
            <div style={{ display:"flex", alignItems:"center", gap:5 }}><Dot size={5} /><span style={{ fontSize:10, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>LIVE</span></div>
          </div>
          {DEMO_ACTIVITY.map((a,i)=>(
            <div key={i} style={{ display:"flex", gap:10, padding:"9px 0", borderBottom:i<DEMO_ACTIVITY.length-1?`1px solid ${T.line}`:"none" }}>
              <div style={{ width:28, height:28, borderRadius:8, background:`${T.blue}10`, border:`1px solid ${T.blue}18`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, color:T.blue, flexShrink:0 }}>{a.icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:11.5, color:T.mid, lineHeight:1.5 }}>{a.text}</div>
                <div style={{ fontSize:10, color:T.low, marginTop:2, fontFamily:"'JetBrains Mono',monospace" }}>{a.time}</div>
              </div>
            </div>
          ))}
        </Card>
      </div>

      {/* Agents + Next Action */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <Card sx={{ padding:20 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:14, color:T.ink }}>Agent Health</div>
            <Btn variant="blue" sx={{ fontSize:11, padding:"5px 12px" }} onClick={()=>setPage("ai-agents")}>Manage →</Btn>
          </div>
          {DEMO_AGENT_HEALTH.map(ag=>(
            <div key={ag.name} style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 12px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:9, marginBottom:6 }}>
              <Dot color={ag.status==="active"?T.green:T.amber} />
              <span style={{ flex:1, fontSize:12.5, fontWeight:500, color:T.ink }}>{ag.name}</span>
              <span style={{ fontSize:11.5, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{ag.runs.toLocaleString()}</span>
              <span style={{ fontSize:12, fontWeight:700, color:ag.status==="active"?T.green:T.amber, fontFamily:"'JetBrains Mono',monospace" }}>{ag.rate}%</span>
            </div>
          ))}
        </Card>

        <Card sx={{ padding:20, borderColor:"rgba(13,173,116,0.25)", background:`linear-gradient(135deg,${T.card},${T.greenL}50)` }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
            <div style={{ width:34, height:34, borderRadius:10, background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>✦</div>
            <div>
              <div style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>Next Best Action</div>
              <div style={{ fontSize:10.5, color:T.low }}>AI-recommended</div>
            </div>
          </div>
          <div style={{ background:T.greenL, border:`1px solid rgba(13,173,116,0.18)`, borderRadius:10, padding:16 }}>
            <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:6 }}>4 hot leads haven't been contacted</div>
            <div style={{ fontSize:12, color:T.mid, lineHeight:1.65, marginBottom:14 }}>Acme Solutions, AfriGrow, BrightScale, and Velocity Health scored 88+ in the last 4 hours. A sequence can go out in 90 seconds.</div>
            <div style={{ display:"flex", gap:8 }}>
              <Btn variant="green" sx={{ flex:1, fontSize:12 }}>Launch AI Sequence →</Btn>
              <Btn sx={{ fontSize:12 }} onClick={()=>setPage("lead-intelligence")}>View</Btn>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  INTENT DATA PAGE  — with real data
// ═══════════════════════════════════════════════════════
function IntentPage({ credits, deductCredits }) {
  const [signals, setSignals]   = useState(DEMO_INTENT_SIGNALS);
  const [domain,  setDomain]    = useState("");
  const [adding,  setAdding]    = useState(false);
  const [filterStr, setFilterStr] = useState("ALL");

  const stats = {
    monitored: 3847,
    active:    signals.length,
    hot_today: signals.filter(s=>s.strength==="HIGH").length,
    avg_score: Math.round(signals.reduce((a,s)=>a+s.score,0)/signals.length),
  };

  const addDomain = async () => {
    if (!domain.trim()) return;
    if ((credits??0) < CREDIT_COSTS.intent_scan) { alert("Not enough credits."); return; }
    setAdding(true); deductCredits("intent_scan");
    // Simulate adding — in production: POST /api/intent/monitor
    await new Promise(r=>setTimeout(r,900));
    const newSig = { id:Date.now(), company:domain.split(".")[0].replace(/^\w/,c=>c.toUpperCase()), domain:domain.trim(), signal:"Recently added to watchlist — monitoring started", strength:"MED", score:50, time:"just now" };
    setSignals(p=>[newSig,...p]); setDomain(""); setAdding(false);
  };

  const filtered = filterStr==="ALL" ? signals : signals.filter(s=>s.strength===filterStr);

  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16 }}>
      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
        {[
          { l:"Companies Monitored", v:stats.monitored.toLocaleString(), c:T.blue  },
          { l:"Active Signals",      v:stats.active,                     c:T.amber },
          { l:"Hot Prospects Today", v:stats.hot_today,                  c:T.red   },
          { l:"Avg Signal Score",    v:`${stats.avg_score}/100`,          c:T.green },
        ].map(m=>(
          <Card key={m.l} sx={{ padding:"16px 18px", position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${m.c}00,${m.c}60,${m.c}00)` }} />
            <div style={{ fontSize:10, color:T.low, textTransform:"uppercase", letterSpacing:"0.05em", fontWeight:600, marginBottom:8 }}>{m.l}</div>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:26, fontWeight:800, color:T.ink }}>{m.v}</div>
          </Card>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 228px", gap:12 }}>
        {/* Feed */}
        <Card sx={{ padding:20 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div>
              <div style={{ fontWeight:700, fontSize:14.5, color:T.ink }}>Live Intent Feed</div>
              <div style={{ fontSize:11.5, color:T.low, marginTop:2 }}>Buying signals from {stats.monitored.toLocaleString()} monitored companies</div>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              {/* Filter pills */}
              {["ALL","HIGH","MED"].map(f=>(
                <button key={f} onClick={()=>setFilterStr(f)} style={{ padding:"4px 10px", borderRadius:6, fontSize:11, fontWeight:filterStr===f?700:400, cursor:"pointer", background:filterStr===f?(f==="HIGH"?T.redL:f==="MED"?T.amberL:T.blueL):T.card2, border:`1px solid ${filterStr===f?(f==="HIGH"?"rgba(228,68,68,0.28)":f==="MED"?"rgba(231,145,9,0.28)":"rgba(75,108,247,0.28)"):T.line}`, color:filterStr===f?(f==="HIGH"?T.red:f==="MED"?T.amber:T.blue):T.mid }}>{f}</button>
              ))}
              <div style={{ display:"flex", alignItems:"center", gap:5 }}><Dot size={5} /><span style={{ fontSize:10, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>LIVE</span></div>
            </div>
          </div>

          {filtered.map((s,i)=>{
            const hi=s.strength==="HIGH";
            return (
              <div key={s.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"11px 0", borderBottom:i<filtered.length-1?`1px solid ${T.line}`:"none" }}>
                <div style={{ width:38, height:38, borderRadius:10, background:T.card2, border:`1px solid ${T.line}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:15, fontWeight:700, color:T.mid, flexShrink:0 }}>{s.company[0]}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:600, color:T.ink }}>
                    {s.company}
                    <span style={{ fontWeight:400, color:T.low, fontSize:11 }}> · {s.domain}</span>
                  </div>
                  <div style={{ fontSize:11.5, color:T.mid, marginTop:2 }}>{s.signal}</div>
                </div>
                <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:20, fontWeight:700, color:s.score>=85?T.green:s.score>=70?T.amber:T.blue, minWidth:36, textAlign:"center" }}>{s.score}</div>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5, flexShrink:0 }}>
                  <span style={{ fontSize:9.5, fontWeight:700, padding:"2px 8px", borderRadius:4, background:hi?T.redL:T.amberL, border:`1px solid ${hi?"rgba(228,68,68,0.25)":"rgba(231,145,9,0.25)"}`, color:hi?T.red:T.amber, fontFamily:"'JetBrains Mono',monospace" }}>{s.strength}</span>
                  <span style={{ fontSize:10, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{s.time}</span>
                </div>
                <Btn variant="blue" sx={{ fontSize:11, padding:"5px 10px", flexShrink:0 }}>Act →</Btn>
              </div>
            );
          })}
        </Card>

        {/* Sidebar */}
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <Card sx={{ padding:18 }}>
            <div style={{ fontWeight:700, fontSize:13.5, color:T.ink, marginBottom:12 }}>Signal Sources</div>
            {DEMO_INTENT_SOURCES.map(s=>(
              <div key={s.label} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:9 }}>
                <span style={{ flex:1, fontSize:12, color:T.mid }}>{s.label}</span>
                <span style={{ fontSize:12.5, fontWeight:700, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{s.count.toLocaleString()}</span>
              </div>
            ))}
          </Card>

          <Card sx={{ padding:18 }}>
            <div style={{ fontWeight:600, fontSize:12.5, color:T.ink, marginBottom:4 }}>Monitor a Company</div>
            <div style={{ fontSize:10.5, color:T.low, marginBottom:10, lineHeight:1.5 }}>Costs {CREDIT_COSTS.intent_scan} credits per domain.</div>
            <Input placeholder="acmecorp.com" value={domain} onChange={e=>setDomain(e.target.value)} style={{ marginBottom:8 }} />
            <Btn variant="primary" sx={{ width:"100%", fontSize:12 }} onClick={addDomain} loading={adding}>
              + Add to Watchlist
            </Btn>
          </Card>

          <Card sx={{ padding:18, background:`linear-gradient(135deg,${T.violetL},${T.blueL}80)` }}>
            <div style={{ fontWeight:700, fontSize:13, color:T.ink, marginBottom:6 }}>🎯 Top Opportunity</div>
            <div style={{ fontSize:12.5, fontWeight:600, color:T.ink }}>Acme Solutions</div>
            <div style={{ fontSize:11.5, color:T.mid, marginTop:3, lineHeight:1.6 }}>Score 94 · 7 competitor visits · Ready to buy</div>
            <div style={{ marginTop:10, display:"flex", gap:6 }}>
              <Btn variant="primary" sx={{ fontSize:11, flex:1 }}>Contact Now</Btn>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  LEAD INTELLIGENCE
// ═══════════════════════════════════════════════════════
function LeadIntelPage({ credits, deductCredits, llmConfig }) {
  const [filters, setFilters] = useState({ keywords:"", industry:"", title:"", location:"", size:"", verified:false });
  const [results,   setResults]   = useState(null);
  const [loading,   setLoading]   = useState(false);
  const [sel,       setSel]       = useState(new Set());
  const [preview,   setPreview]   = useState(null);
  const [enriching, setEnriching] = useState(null);
  const [enriched,  setEnriched]  = useState(new Set());
  const [searchErr, setSearchErr] = useState(null);

  const sf=(k,v)=>setFilters(p=>({...p,[k]:v}));
  const toggleSel=id=>setSel(p=>{const n=new Set(p);n.has(id)?n.delete(id):n.add(id);return n;});

  const doSearch=async()=>{
    setLoading(true); setSearchErr(null); setSel(new Set());
    try {
      const data=await fetch("/api/leads/search",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(filters)}).then(r=>{if(!r.ok)throw new Error(r.statusText);return r.json();});
      setResults(data.leads??[]);
    } catch(e){ setSearchErr(e.message); setResults([]); }
    setLoading(false);
  };

  const doEnrich=async(lead)=>{
    if((credits??0)<CREDIT_COSTS.lead_enrich){alert("Not enough credits.");return;}
    setEnriching(lead.id); deductCredits("lead_enrich");
    try{await fetch(`/api/leads/${lead.id}/enrich`,{method:"POST"}).then(r=>{if(!r.ok)throw new Error(r.statusText);}); setEnriched(p=>new Set([...p,lead.id]));}
    catch(e){alert(`Enrichment failed: ${e.message}`);}
    setEnriching(null);
  };

  const intentMeta={hot:{bg:"rgba(228,68,68,0.07)",border:"rgba(228,68,68,0.2)",c:T.red,icon:"🔥"},warm:{bg:"rgba(231,145,9,0.08)",border:"rgba(231,145,9,0.2)",c:T.amber,icon:"🌡"},cold:{bg:"rgba(75,108,247,0.08)",border:"rgba(75,108,247,0.18)",c:T.blue,icon:"❄"}};

  return (
    <div style={{ display:"flex", height:"100%", overflow:"hidden" }}>
      {/* Filters */}
      <div style={{ width:218, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, padding:16, display:"flex", flexDirection:"column", gap:12, overflowY:"auto" }}>
        <div style={{ fontSize:9.5, fontWeight:700, color:T.low, letterSpacing:"0.12em", textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>Search Filters</div>
        {[["keywords","Keywords","Topic, technology…"],["industry","Industry","SaaS, Healthcare…"],["title","Job Title","CEO, VP, Director…"],["location","Location","City or country…"]].map(([k,l,ph])=>(
          <Field key={k} label={l}><Input value={filters[k]} onChange={e=>sf(k,e.target.value)} placeholder={ph} /></Field>
        ))}
        <div>
          <FLabel>Company Size</FLabel>
          <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
            {["1-10","11-50","51-200","201+"].map(s=>(
              <button key={s} onClick={()=>sf("size",filters.size===s?"":s)} style={{ padding:"4px 9px", borderRadius:6, fontSize:11.5, cursor:"pointer", fontWeight:500, background:filters.size===s?T.blueL:T.card2, border:`1px solid ${filters.size===s?"rgba(75,108,247,0.28)":T.line}`, color:filters.size===s?T.blue:T.mid }}>{s}</button>
            ))}
          </div>
        </div>
        <label style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer" }}>
          <div onClick={()=>sf("verified",!filters.verified)} style={{ width:36, height:20, borderRadius:10, background:filters.verified?"rgba(13,173,116,0.2)":T.card2, border:`1px solid ${filters.verified?"rgba(13,173,116,0.35)":T.line}`, position:"relative", cursor:"pointer", transition:"all 0.2s" }}>
            <div style={{ position:"absolute", top:2.5, left:filters.verified?16:2.5, width:13, height:13, borderRadius:"50%", background:filters.verified?T.green:T.low, transition:"all 0.2s" }} />
          </div>
          <span style={{ fontSize:12, color:T.mid, fontWeight:500 }}>Verified emails only</span>
        </label>
        <button onClick={doSearch} disabled={loading} style={{ padding:"10px", background:loading?T.card2:`linear-gradient(135deg,${T.blue},${T.violet})`, border:`1px solid ${loading?T.line:"none"}`, borderRadius:9, color:loading?T.mid:"#fff", fontSize:13, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
          {loading?<><Spinner size={14}/> Searching…</>:"Search 50M+ Leads"}
        </button>
        <div style={{ padding:14, background:T.blueL, border:`1px solid rgba(75,108,247,0.18)`, borderRadius:10, marginTop:"auto" }}>
          <div style={{ fontSize:9, color:T.blue, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, marginBottom:4 }}>DATABASE</div>
          <div style={{ fontSize:24, fontWeight:800, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>50M+</div>
          <div style={{ fontSize:10.5, color:T.mid, marginTop:3, lineHeight:1.5 }}>verified B2B contacts</div>
        </div>
      </div>

      {/* Results */}
      <div style={{ flex:1, overflow:"auto", display:"flex", flexDirection:"column" }}>
        <div style={{ padding:"11px 16px", borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:10, flexShrink:0, background:T.card, position:"sticky", top:0, zIndex:5 }}>
          <span style={{ fontSize:12.5, color:T.mid }}>
            {results===null?"Configure filters and search":results.length===0?"No leads found":sel.size>0?<b style={{color:T.ink}}>{sel.size} selected</b>:<><b style={{color:T.ink}}>{results.length}</b> leads found</>}
          </span>
          {sel.size>0&&<div style={{ display:"flex", gap:6 }}>
            <Btn variant="primary" sx={{ fontSize:11, padding:"5px 12px" }}>Add to Outreach</Btn>
            <Btn variant="blue" sx={{ fontSize:11, padding:"5px 12px" }}>✦ Enrich All <CreditCost action="lead_enrich" /></Btn>
          </div>}
          <div style={{ marginLeft:"auto" }}><Btn sx={{ fontSize:11, padding:"5px 12px" }}>↓ Export CSV</Btn></div>
        </div>
        {searchErr&&<div style={{ margin:16, padding:14, background:T.redL, border:`1px solid rgba(228,68,68,0.22)`, borderRadius:10, fontSize:12.5, color:T.red }}>Error: {searchErr}</div>}
        {results===null&&!loading&&(
          <EmptyState icon="◎" title="Search 50M+ B2B Contacts"
            desc="Enter keywords, industry, job title, or location then hit search."
            action={<Btn variant="primary" sx={{ fontSize:13, padding:"11px 28px" }} onClick={doSearch}>Run Search</Btn>} />
        )}
        {results?.length===0&&!loading&&<EmptyState icon="◎" title="No leads matched" desc="Try broader filters." />}
        {results?.length>0&&(
          <div style={{ padding:16 }}>
            <div style={{ display:"grid", gridTemplateColumns:"32px 1fr 130px 110px 60px 60px 120px", gap:10, padding:"7px 12px", marginBottom:4 }}>
              {["","Lead","Company","Intent","Score","Size",""].map((h,i)=>(
                <div key={i} style={{ fontSize:9.5, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.08em", fontFamily:"'JetBrains Mono',monospace" }}>{h}</div>
              ))}
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
              {results.map(lead=>{
                const isSel=sel.has(lead.id), isDone=enriched.has(lead.id);
                const im=intentMeta[lead.intent]||intentMeta.cold;
                return (
                  <div key={lead.id} style={{ display:"grid", gridTemplateColumns:"32px 1fr 130px 110px 60px 60px 120px", gap:10, alignItems:"center", padding:"11px 12px", background:isSel?T.blueL:T.card, border:`1px solid ${isSel?"rgba(75,108,247,0.25)":T.line}`, borderRadius:11, cursor:"pointer", transition:"all 0.12s" }}
                    onMouseEnter={e=>{if(!isSel){e.currentTarget.style.background=T.card2;e.currentTarget.style.borderColor=T.lineHi;}}}
                    onMouseLeave={e=>{if(!isSel){e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}}>
                    <div onClick={e=>{e.stopPropagation();toggleSel(lead.id);}} style={{ width:16, height:16, borderRadius:4, border:`1.5px solid ${isSel?"transparent":T.lineHi}`, background:isSel?T.blue:"transparent", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", flexShrink:0 }}>
                      {isSel&&<span style={{ color:"#fff",fontSize:9,fontWeight:700 }}>✓</span>}
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:10, minWidth:0 }} onClick={()=>setPreview(preview?.id===lead.id?null:lead)}>
                      <div style={{ width:34, height:34, borderRadius:"50%", background:`linear-gradient(135deg,${T.blueL},${T.violetL})`, border:`1.5px solid ${T.line}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:T.blue, flexShrink:0 }}>{lead.name?.split(" ").map(n=>n[0]).join("")??"?"}</div>
                      <div style={{ minWidth:0 }}>
                        <div style={{ fontSize:13, fontWeight:600, color:T.ink, display:"flex", alignItems:"center", gap:5 }}>
                          {lead.name}
                          {lead.verified&&<span style={{ fontSize:9,color:T.green,background:T.greenL,padding:"1px 5px",borderRadius:3,border:`1px solid rgba(13,173,116,0.2)` }}>✓</span>}
                          {isDone&&<span style={{ fontSize:9,color:T.violet,background:T.violetL,padding:"1px 5px",borderRadius:3 }}>enriched</span>}
                        </div>
                        <div style={{ fontSize:11, color:T.low, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", marginTop:1 }}>{lead.title} · {lead.email}</div>
                      </div>
                    </div>
                    <div onClick={()=>setPreview(preview?.id===lead.id?null:lead)}>
                      <div style={{ fontSize:12.5, fontWeight:500, color:T.ink }}>{lead.company}</div>
                      <div style={{ fontSize:10.5, color:T.low }}>{lead.industry}</div>
                    </div>
                    <span style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:10.5, fontWeight:600, padding:"3px 9px", borderRadius:5, background:im.bg, border:`1px solid ${im.border}`, color:im.c, textTransform:"uppercase", letterSpacing:"0.04em" }}>{im.icon} {lead.intent}</span>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:18, fontWeight:700, color:lead.score>=85?T.green:lead.score>=70?T.amber:T.blue }}>{lead.score}</div>
                    <div style={{ fontSize:11.5, color:T.mid }}>{lead.size}</div>
                    <div style={{ display:"flex", gap:5 }} onClick={e=>e.stopPropagation()}>
                      <button onClick={()=>setPreview(preview?.id===lead.id?null:lead)} style={{ padding:"4px 8px",background:T.card2,border:`1px solid ${T.line}`,borderRadius:6,color:T.mid,fontSize:10.5,cursor:"pointer" }}>View</button>
                      <button onClick={()=>doEnrich(lead)} disabled={enriching===lead.id||isDone} style={{ padding:"4px 8px",background:isDone?T.greenL:T.violetL,border:`1px solid ${isDone?"rgba(13,173,116,0.22)":"rgba(123,91,251,0.22)"}`,borderRadius:6,color:isDone?T.green:T.violet,fontSize:10.5,cursor:"pointer",fontWeight:600 }}>
                        {enriching===lead.id?<Spinner size={10}/>:isDone?"✓":"✦ AI"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Preview */}
      {preview&&(
        <div className="slidein" style={{ width:264, flexShrink:0, background:T.card, borderLeft:`1px solid ${T.line}`, padding:16, overflowY:"auto", display:"flex", flexDirection:"column", gap:13 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>Lead Profile</span>
            <button onClick={()=>setPreview(null)} style={{ background:"none",border:"none",color:T.low,cursor:"pointer",fontSize:20 }}>×</button>
          </div>
          <div style={{ textAlign:"center" }}>
            <div style={{ width:52, height:52, borderRadius:"50%", background:`linear-gradient(135deg,${T.blue},${T.violet})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, fontWeight:700, color:"#fff", margin:"0 auto 10px", boxShadow:`0 4px 16px ${T.blue}28` }}>{preview.name?.split(" ").map(n=>n[0]).join("")??""}</div>
            <div style={{ fontWeight:700, fontSize:15, color:T.ink }}>{preview.name}</div>
            <div style={{ fontSize:11.5, color:T.mid, marginTop:2 }}>{preview.title}</div>
            <div style={{ fontSize:11, color:T.low }}>{preview.company}</div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:7 }}>
            {[["Score",`${preview.score}/100`],["Email",preview.email],["Industry",preview.industry],["Size",`${preview.size} emp`]].filter(([,v])=>v).map(([l,v])=>(
              <div key={l} style={{ padding:"9px 11px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:9 }}>
                <div style={{ fontSize:9.5, color:T.low, marginBottom:2, textTransform:"uppercase", letterSpacing:"0.06em", fontWeight:600 }}>{l}</div>
                <div style={{ fontSize:12, color:T.mid, wordBreak:"break-all" }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:7, marginTop:"auto" }}>
            <Btn variant="primary" sx={{ fontSize:12 }}>✦ AI Write Email <CreditCost action="ai_email" /></Btn>
            <Btn variant="green" sx={{ fontSize:12 }}>Add to Sequence</Btn>
            <Btn sx={{ fontSize:12 }}>Create Deal</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  AI AGENTS PAGE  — uses callLLM (any provider)
// ═══════════════════════════════════════════════════════
// ── Agent metadata — examples + colors per vertical ──────────────────────────
const AGENT_META = {
  // Track-Med
  "trackmed-scout": {
    vertical:"Track-Med", color:"#0DAD74", icon:"◎",
    examples:[
      "Find 10 solo orthopedic surgeons in Texas who are likely doing prior auth manually",
      "Find pain management clinics with 1–5 providers in Florida that accept UnitedHealthcare",
      "List solo mental health practices in Georgia — high prior auth burden specialty",
      "Find dental oral surgery practices in Illinois with no billing software mentioned online",
      "Find physical therapy clinics in Ohio that posted a billing job in the last 60 days",
    ]
  },
  "trackmed-email": {
    vertical:"Track-Med", color:"#0DAD74", icon:"→",
    examples:[
      "Write a cold email to Dr. Sarah Kim, solo orthopedic surgeon in Dallas, TX — she does 30+ knee replacements/month, likely heavy UHC prior auth burden",
      "Write an email to a solo chiropractor in Atlanta — focus on the denial write-off angle, they accept Aetna and Cigna",
      "Write a cold email to the office manager of a 2-physician pain management clinic in Chicago — they recently posted a prior auth specialist job",
      "Email to Dr. James Osei, DMD oral surgeon in Houston — implant procedures require predetermination, they're on Cigna Dental",
      "Write a mental health practice email — behavioral health has 28% national denial rate, this is a solo LPC in Ohio",
    ]
  },
  "trackmed-denial": {
    vertical:"Track-Med", color:"#0DAD74", icon:"◫",
    examples:[
      "Write a denial appeal for CPT 27447 (total knee replacement) denied by UnitedHealthcare with CO-50 (not medically necessary). Patient has severe OA, BMI 31, failed 6 months of conservative therapy.",
      "Appeal CO-97 (bundled) denial from Aetna for CPT 99213 + 90834 billed together by a psychiatry practice",
      "Appeal prior auth denial for MRI lumbar spine CPT 72148, denied by Cigna, patient has 3 months of low back pain, failed PT",
      "Appeal for CPT 43239 (upper GI endoscopy with biopsy) denied as not medically necessary by BCBS, patient has chronic GERD and Barrett's esophagus",
      "Write appeal for CO-4 modifier denial on CPT 99213-25 with 96127 (psychiatric screening), denied by Humana",
    ]
  },
  "trackmed-audit": {
    vertical:"Track-Med", color:"#0DAD74", icon:"▤",
    examples:[
      "Build a discovery script for a solo orthopedic surgeon — 2 providers, 500 procedures/month, currently using manual fax for prior auth with UHC and Aetna",
      "Create an A/R audit conversation for a 3-dentist oral surgery practice in Texas — does implants and extractions, struggles with Delta Dental predetermination",
      "Discovery script for a pain management clinic — 1 physician, doing 80 injections/month, 22% denial rate mentioned in their Google review",
      "A/R audit for a solo psychiatrist — sees 30 patients/week, bills BCBS and Medicare, complains about documentation requirements",
      "Script for a physical therapy clinic — 2 PTs, Medicare patients, high prior auth burden for ongoing therapy approvals",
    ]
  },
  // NaviMed
  "navimed-scout": {
    vertical:"NaviMed", color:"#4B6CF7", icon:"◈",
    examples:[
      "Find Ministry of Health digital health directors in Niger — we have MOU alignment with their America First Global Health Strategy",
      "List top 5 decision makers at USAID health offices in West Africa who oversee digital health programs",
      "Find US Embassy health attachés in Nigeria, Kenya, and Ghana — I want to align NaviMed with bilateral MOU programs",
      "Identify WHO country representatives in Francophone Africa who are running digital health transformation projects",
      "Find private hospital group CEOs in Lagos and Nairobi with 50+ beds who don't have a modern EHR system",
    ]
  },
  "navimed-email": {
    vertical:"NaviMed", color:"#4B6CF7", icon:"✉",
    examples:[
      "Write an outreach email to the Director of Digital Health at Niger's Ministry of Health — reference the America First MOU and how NaviMed aligns with their digital infrastructure mandate",
      "Write to the USAID Health Officer at the US Embassy in Abuja, Nigeria — NaviMed is US-registered, position it as a bilateral tech partnership under America First",
      "Draft an email to Dr. Aminata Diallo, Director of eHealth at Senegal's Ministry of Health — write in both English and French, reference Plan Sénégal Numérique 2025",
      "Write to the CEO of a 200-bed private hospital in Accra, Ghana — focus on NHIA billing integration and the revenue they're losing to manual claims",
      "Outreach email to a Partners in Health program director in Rwanda — emphasize offline-first capability for rural health posts and the 7-1-7 surveillance standard",
    ]
  },
  "navimed-proposal": {
    vertical:"NaviMed", color:"#4B6CF7", icon:"⬟",
    examples:[
      "Generate a full NaviMed implementation proposal for Niger — reference the America First MOU, focus on epidemic surveillance (7-1-7) and CNAM insurance billing",
      "Country proposal for Kenya — align with Kenya Health Sector Strategic Plan 2023-2030, focus on NHIF billing integration and district hospital EMR rollout",
      "Implementation proposal for a 300-bed teaching hospital in Lagos, Nigeria — EMR, pharmacy, lab management, NHIS billing, and teleconsultation",
      "Proposal for Rwanda — pilot at 5 district hospitals, align with Rwanda Health Financing Strategy, RSSB billing integration",
      "NaviMed proposal for a USAID-funded health project in Côte d'Ivoire — French interface, XOF billing, offline capability for rural health centers",
    ]
  },
  // ARGILETTE Agency
  "argilette-scout": {
    vertical:"ARGILETTE", color:"#7B5BFB", icon:"◉",
    examples:[
      "Find real estate team leaders in St. Louis and Chicago with 5–15 agents who are manually doing lead follow-up — they're losing deals to faster competitors",
      "Find independent insurance brokers in Texas with 2–10 employees who posted a virtual assistant job in the last 90 days",
      "List mortgage broker offices in Florida with 3–10 loan officers — they're manually chasing borrowers for documents and rate updates",
      "Find solo law firms and 2-partner practices in Illinois that do personal injury — high volume of client intake and document collection pain",
      "HVAC and plumbing companies in the Midwest with 5–20 techs — manually doing scheduling, dispatch, invoicing, and review requests",
    ]
  },
  "argilette-email": {
    vertical:"ARGILETTE", color:"#7B5BFB", icon:"→",
    examples:[
      "Write a cold email to Marcus Johnson, owner of a 12-agent real estate team in Dallas — he posted a VA job on Indeed last week, loses deals because follow-up is slow",
      "Email to Sandra Lee, independent insurance broker in Houston with 4 employees — she manually sends renewal reminders and quote follow-ups via spreadsheet",
      "Cold email to a 6-person mortgage brokerage in Miami — they're chasing borrowers for documents by phone/email, taking 3–5 days to collect what we can automate in hours",
      "Write to a solo immigration attorney in Chicago — does high volume consultations, manually doing intake forms, appointment reminders, and document requests",
      "Email to a pest control company owner in St. Louis with 8 technicians — no automation on scheduling, invoicing, or review requests",
    ]
  },
  // Universal
  "reply-analyzer": {
    vertical:"Universal", color:"#0691A1", icon:"⊙",
    examples:[
      `Analyze this reply: "Hi, thanks for reaching out. We've been struggling with prior auth lately. Can you tell me more about how Track-Med works?"`,
      `Reply: "Not interested at this time, we just signed a contract with our current biller last month"`,
      `Reply from MoH Niger: "Thank you for your message. We would be interested in learning more about your digital health platform. Please send a formal proposal to our eHealth directorate."`,
      `Reply: "This sounds interesting but $2,497/month seems high for a business our size. What do smaller clients typically pay?"`,
      `Reply: "Hey I'm the wrong person for this, you should reach out to our practice manager Janet at janet@drsmith.com"`,
    ]
  },
  "linkedin-scout": {
    vertical:"Universal", color:"#0691A1", icon:"⬡",
    examples:[
      "Give me a LinkedIn Sales Navigator search string for solo orthopedic and pain management physicians in Texas, Florida, and Georgia who work at practices with 1–10 employees",
      "Build a LinkedIn prospecting strategy for ARGILETTE Agency targeting real estate team leaders in the Midwest with 5–20 agents",
      "LinkedIn search for Ministry of Health digital health officials in West Africa — Nigeria, Ghana, Senegal, Côte d'Ivoire, Niger",
      "Connection request and follow-up sequence for a Practice Manager at a 3-physician internal medicine clinic in Ohio",
      "LinkedIn outreach sequence for USAID health program officers based in Washington DC or West Africa",
    ]
  },
  "intent-monitor": {
    vertical:"Universal", color:"#0691A1", icon:"◈",
    examples:[
      "Analyze Acme Orthopedics (acme-ortho.com) for buying signals — they're a 2-physician orthopedic clinic in Dallas",
      "What buying signals should I look for that indicate a solo medical practice in the US is about to switch billing companies?",
      "Analyze intent signals for Nigeria's Federal Ministry of Health — are they in a digital health buying cycle right now?",
      "A real estate brokerage owner just posted on LinkedIn: 'We're growing fast and I'm drowning in admin work.' What does this signal and how do I respond?",
      "What job postings and news events indicate a small insurance brokerage is ready to invest in automation tools?",
    ]
  },
  "sequence-builder": {
    vertical:"Universal", color:"#0691A1", icon:"⟳",
    examples:[
      "Build a 5-touch 12-day outreach sequence for a solo pain management physician in Texas — prior auth angle, free A/R audit CTA",
      "Create a Track-Med sequence for a dental oral surgery practice — predetermination pain, practice manager is the contact",
      "Build a NaviMed email + LinkedIn sequence for the Director of eHealth at a West African Ministry of Health — formal tone, reference America First MOU",
      "5-touch sequence for a real estate team leader — automation ROI angle, 15-minute free ROI call CTA",
      "Outreach sequence for a USAID health program officer — NaviMed as a US technology partnership tool for bilateral MOU implementation",
    ]
  },
  "meeting-booker": {
    vertical:"Universal", color:"#0691A1", icon:"◷",
    examples:[
      `They replied: "Yes, I'd be open to learning more about how you handle prior auth for orthopedics." Book the free A/R audit call.`,
      `MoH official replied: "Please send more information about your digital health platform." Convert this to a formal 30-minute NaviMed demo.`,
      `Reply: "We've been thinking about automating our follow-up process. What does your onboarding look like?" — Book the ARGILETTE free ROI call.`,
      `Dentist replied: "Our billing situation is a mess right now. We just lost our biller." Urgent — book the Track-Med audit immediately.`,
      `USAID officer replied: "This looks interesting, are you available for a call next week?" Schedule the NaviMed demo with a country-specific agenda.`,
    ]
  },
};

const VERTICAL_CONFIG = {
  "Track-Med": { color:"#0DAD74", bg:"#E5FAF1", border:"rgba(13,173,116,0.25)", label:"Track-Med / CureMedAuth" },
  "NaviMed":   { color:"#4B6CF7", bg:"#EEF1FF", border:"rgba(75,108,247,0.25)",  label:"NaviMed EHR" },
  "ARGILETTE": { color:"#7B5BFB", bg:"#EDEAFE", border:"rgba(123,91,251,0.25)", label:"ARGILETTE Agency" },
  "Universal": { color:"#0691A1", bg:"#E0F6F8", border:"rgba(6,145,161,0.25)",  label:"Universal" },
};

function AgentsPage({ credits, deductCredits, llmConfig }) {
  const [agents,   setAgents]   = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [selAgent, setSelAgent] = useState(null);
  const [prompt,   setPrompt]   = useState("");
  const [running,  setRunning]  = useState(false);
  const [output,   setOutput]   = useState("");
  const [runErr,   setRunErr]   = useState(null);
  const [history,  setHistory]  = useState([]);
  const [tab,      setTab]      = useState("run");  // run | history
  const outputRef = useRef(null);

  // Fetch agents from backend
  useEffect(() => {
    fetch("/api/agents")
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(d => {
        const list = d.agents ?? [];
        setAgents(list);
        if (list.length) setSelAgent(list[0]);
      })
      .catch(() => {
        // Fallback: show placeholder agents if backend not connected
        const fallback = Object.entries(AGENT_META).map(([id, m]) => ({
          id, name: id.replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
          status: "active", category: m.vertical, description: "Configure backend to load full agent details.",
          runs: 0, rate: 100,
        }));
        setAgents(fallback);
        setSelAgent(fallback[0]);
      })
      .finally(() => setLoading(false));
  }, []);

  const meta    = selAgent ? (AGENT_META[selAgent.id] ?? {}) : {};
  const vConfig = VERTICAL_CONFIG[meta.vertical ?? selAgent?.category] ?? VERTICAL_CONFIG["Universal"];
  const reg     = llmConfig ? LLM_REGISTRY[llmConfig.providerId] : null;

  const run = async () => {
    if (!prompt.trim() || !selAgent) return;
    if (!llmConfig) { setRunErr("No AI provider configured. Go to AI Providers →"); return; }
    if ((credits ?? 0) < CREDIT_COSTS.agent_run) { setRunErr("Not enough credits."); return; }
    setRunning(true); setOutput(""); setRunErr(null); deductCredits("agent_run");
    const startedAt = Date.now();
    try {
      // Call backend — which uses the server-side LLM router
      const res = await fetch(`/api/agents/${selAgent.id}/run`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || res.statusText);
      }
      const data = await res.json();
      setOutput(data.output ?? "");
      setHistory(p => [{ prompt, output: data.output, provider: data.provider, model: data.model, ms: Date.now() - startedAt, time: new Date().toLocaleTimeString() }, ...p.slice(0, 9)]);
    } catch (e) {
      // If backend not available, fall back to direct LLM call
      try {
        const result = await callLLM({ system: selAgent.system ?? meta.system ?? "", userMessage: prompt, maxTokens: 800, providerConfig: llmConfig });
        setOutput(result);
        setHistory(p => [{ prompt, output: result, provider: reg?.name, model: llmConfig.model, ms: Date.now() - startedAt, time: new Date().toLocaleTimeString() }, ...p.slice(0, 9)]);
      } catch (e2) { setRunErr(e2.message); }
    }
    setRunning(false);
    if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight;
  };

  // Group agents by vertical
  const grouped = agents.reduce((acc, ag) => {
    const v = AGENT_META[ag.id]?.vertical ?? ag.category ?? "Universal";
    if (!acc[v]) acc[v] = [];
    acc[v].push(ag);
    return acc;
  }, {});
  const verticalOrder = ["Track-Med", "NaviMed", "ARGILETTE", "Universal"];

  return (
    <div style={{ display:"flex", height:"100%", overflow:"hidden" }}>

      {/* LEFT — Agent list */}
      <div style={{ width:230, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column", overflowY:"auto" }}>
        <div style={{ padding:"13px 14px 10px", borderBottom:`1px solid ${T.line}` }}>
          <div style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>AI Agents</div>
          <div style={{ fontSize:11, color:T.low, marginTop:3 }}>
            {llmConfig ? <><span style={{ color:T.green }}>●</span> {reg?.name} · {llmConfig.model}</> : <span style={{ color:T.amber }}>⚠ No provider set</span>}
          </div>
        </div>

        {loading ? (
          <div style={{ padding:20, display:"flex", justifyContent:"center" }}><Spinner size={20} /></div>
        ) : (
          verticalOrder.filter(v => grouped[v]).map(v => {
            const vc = VERTICAL_CONFIG[v];
            return (
              <div key={v}>
                <div style={{ padding:"10px 14px 4px", fontSize:9, fontWeight:700, color:vc.color, textTransform:"uppercase", letterSpacing:"0.1em", fontFamily:"'JetBrains Mono',monospace" }}>
                  {vc.label}
                </div>
                {grouped[v].map(ag => {
                  const isSel = selAgent?.id === ag.id;
                  const m = AGENT_META[ag.id] ?? {};
                  return (
                    <div key={ag.id} onClick={() => { setSelAgent(ag); setOutput(""); setPrompt(""); setRunErr(null); }}
                      style={{ display:"flex", alignItems:"center", gap:9, padding:"8px 12px", margin:"1px 6px", borderRadius:9, cursor:"pointer", background:isSel ? vc.bg : "transparent", border:`1px solid ${isSel ? vc.border : "transparent"}`, transition:"all 0.12s" }}
                      onMouseEnter={e => { if (!isSel) e.currentTarget.style.background = T.card2; }}
                      onMouseLeave={e => { if (!isSel) e.currentTarget.style.background = "transparent"; }}>
                      <div style={{ width:28, height:28, borderRadius:8, background:isSel ? vc.bg : T.card2, border:`1px solid ${isSel ? vc.border : T.line}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, color:isSel ? vc.color : T.low, flexShrink:0 }}>
                        {m.icon ?? "◉"}
                      </div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:12.5, fontWeight:isSel ? 700 : 500, color:isSel ? T.ink : T.mid, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{ag.name}</div>
                        <div style={{ fontSize:10, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>
                          {ag.runs > 0 ? `${ag.runs} runs · ${ag.rate}%` : "ready"}
                        </div>
                      </div>
                      <Dot color={ag.status === "active" ? T.green : T.amber} size={5} />
                    </div>
                  );
                })}
              </div>
            );
          })
        )}
      </div>

      {/* RIGHT — Console */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>

        {/* Agent header */}
        {selAgent && (
          <div style={{ padding:"12px 18px", borderBottom:`1px solid ${T.line}`, background:T.card, display:"flex", alignItems:"center", gap:12, flexShrink:0 }}>
            <div style={{ width:38, height:38, borderRadius:11, background:vConfig.bg, border:`1px solid ${vConfig.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, color:vConfig.color, flexShrink:0 }}>
              {meta.icon ?? "◉"}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:700, fontSize:14.5, color:T.ink }}>{selAgent.name}</div>
              <div style={{ fontSize:11.5, color:T.mid, marginTop:2 }}>{selAgent.description}</div>
            </div>
            <div style={{ display:"flex", gap:6 }}>
              {["run","history"].map(t => (
                <button key={t} onClick={() => setTab(t)} style={{ padding:"5px 13px", borderRadius:7, fontSize:12, fontWeight:tab===t?600:400, cursor:"pointer", background:tab===t?T.blueL:T.card2, border:`1px solid ${tab===t?"rgba(75,108,247,0.28)":T.line}`, color:tab===t?T.blue:T.mid }}>
                  {t === "run" ? "▶ Run" : `History (${history.length})`}
                </button>
              ))}
              <span style={{ padding:"5px 11px", borderRadius:7, fontSize:11, background:T.amberL, border:`1px solid rgba(231,145,9,0.22)`, color:T.amber, fontFamily:"'JetBrains Mono',monospace", fontWeight:700 }}>{CREDIT_COSTS.agent_run}cr</span>
            </div>
          </div>
        )}

        {tab === "run" && selAgent && (
          <div style={{ flex:1, overflow:"auto", padding:18, display:"flex", flexDirection:"column", gap:14 }}>

            {/* Example prompts */}
            {meta.examples && !prompt && (
              <div>
                <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.08em", fontFamily:"'JetBrains Mono',monospace", marginBottom:8 }}>
                  Example prompts — click to use
                </div>
                <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                  {meta.examples.map((ex, i) => (
                    <div key={i} onClick={() => setPrompt(ex)}
                      style={{ padding:"10px 14px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:9, cursor:"pointer", fontSize:12.5, color:T.mid, lineHeight:1.55, transition:"all 0.12s" }}
                      onMouseEnter={e => { e.currentTarget.style.background = vConfig.bg; e.currentTarget.style.borderColor = vConfig.border; e.currentTarget.style.color = T.ink; }}
                      onMouseLeave={e => { e.currentTarget.style.background = T.card2; e.currentTarget.style.borderColor = T.line; e.currentTarget.style.color = T.mid; }}>
                      <span style={{ color:vConfig.color, fontWeight:600, marginRight:6 }}>→</span>{ex}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:7 }}>
                <FLabel>Your prompt for {selAgent.name}</FLabel>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  {prompt && <button onClick={() => { setPrompt(""); setOutput(""); setRunErr(null); }} style={{ background:"none", border:"none", color:T.low, cursor:"pointer", fontSize:11 }}>✕ Clear</button>}
                  <span style={{ fontSize:11, color:T.low }}>Credits: <b style={{ color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{credits?.toLocaleString()}</b></span>
                </div>
              </div>
              <div style={{ display:"flex", gap:8 }}>
                <textarea value={prompt} onChange={e => setPrompt(e.target.value)}
                  rows={4}
                  placeholder={meta.examples?.[0] ?? `Describe what you want ${selAgent.name} to do…`}
                  style={{ flex:1, background:T.card2, border:`1px solid ${T.line}`, borderRadius:10, padding:"11px 13px", fontSize:13, color:T.ink, outline:"none", resize:"none", lineHeight:1.6 }}
                  onFocus={e => { e.target.style.borderColor = vConfig.border; e.target.style.background = T.card; }}
                  onBlur={e  => { e.target.style.borderColor = T.line; e.target.style.background = T.card2; }}
                  onKeyDown={e => { if (e.metaKey && e.key === "Enter") run(); }}
                />
                <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                  <button onClick={run} disabled={running || !prompt.trim()}
                    style={{ padding:"0 22px", height:72, borderRadius:10, background:running || !prompt.trim() ? T.card2 : `linear-gradient(135deg,${vConfig.color},${T.violet})`, border:running ? `1px solid ${T.line}` : "none", color:running || !prompt.trim() ? T.mid : "#fff", fontSize:13, fontWeight:700, cursor:running || !prompt.trim() ? "not-allowed" : "pointer", flexShrink:0, boxShadow:!running && prompt.trim() ? `0 4px 14px ${vConfig.color}30` : "none", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:5 }}>
                    {running ? <><Spinner size={16} /><span style={{ fontSize:10 }}>Running</span></> : <><span style={{ fontSize:18 }}>▶</span><span style={{ fontSize:10 }}>⌘↵</span></>}
                  </button>
                </div>
              </div>
            </div>

            {/* Output */}
            {(output || running || runErr) && (
              <div>
                <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                  <FLabel>Output</FLabel>
                  {running && <div style={{ display:"flex", alignItems:"center", gap:6, fontSize:11, color:T.mid }}><Spinner size={12} />Calling {reg?.name ?? "LLM"}…</div>}
                  {output && !running && <span style={{ fontSize:10, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>✓ COMPLETE</span>}
                </div>
                <div ref={outputRef}
                  style={{ background:T.card2, border:`1px solid ${output ? vConfig.border : T.line}`, borderRadius:11, padding:16, minHeight:160, maxHeight:400, overflowY:"auto", fontSize:13, lineHeight:1.75, color:T.mid }}>
                  {runErr && <div style={{ color:T.red, fontWeight:500 }}>⚠ {runErr}</div>}
                  {output && <div style={{ whiteSpace:"pre-wrap", color:T.ink }}>{output}</div>}
                </div>
                {output && !running && (
                  <div className="fadein" style={{ display:"flex", gap:8, marginTop:10 }}>
                    <Btn variant="primary" sx={{ fontSize:12 }}>Save to CRM</Btn>
                    <Btn variant="green" sx={{ fontSize:12 }}>Add to Sequence</Btn>
                    <Btn sx={{ fontSize:12 }} onClick={() => navigator.clipboard?.writeText(output)}>Copy</Btn>
                    <Btn variant="danger" sx={{ fontSize:12 }} onClick={() => { setOutput(""); setPrompt(""); setRunErr(null); }}>Clear</Btn>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {tab === "history" && (
          <div style={{ flex:1, overflow:"auto", padding:18 }}>
            {history.length === 0 ? (
              <EmptyState icon="◷" title="No run history yet" desc="Run this agent and your outputs will appear here." />
            ) : (
              <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                {history.map((h, i) => (
                  <Card key={i} sx={{ padding:16 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10 }}>
                      <span style={{ fontSize:11, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{h.time}</span>
                      <span style={{ fontSize:10, color:vConfig.color, background:vConfig.bg, padding:"1px 7px", borderRadius:4, fontWeight:600 }}>{h.provider} · {h.model}</span>
                      <span style={{ fontSize:10, color:T.low, fontFamily:"'JetBrains Mono',monospace", marginLeft:"auto" }}>{h.ms}ms</span>
                    </div>
                    <div style={{ fontSize:12, fontWeight:600, color:T.ink, marginBottom:6, padding:"8px 10px", background:T.card2, borderRadius:7, borderLeft:`3px solid ${vConfig.color}` }}>
                      {h.prompt.slice(0, 120)}{h.prompt.length > 120 ? "…" : ""}
                    </div>
                    <div style={{ fontSize:12, color:T.mid, lineHeight:1.65, whiteSpace:"pre-wrap", maxHeight:160, overflow:"hidden" }}>
                      {h.output.slice(0, 400)}{h.output.length > 400 ? "…" : ""}
                    </div>
                    <div style={{ display:"flex", gap:6, marginTop:10 }}>
                      <Btn sx={{ fontSize:11, padding:"4px 10px" }} onClick={() => { setPrompt(h.prompt); setOutput(h.output); setTab("run"); }}>Reload</Btn>
                      <Btn sx={{ fontSize:11, padding:"4px 10px" }} onClick={() => navigator.clipboard?.writeText(h.output)}>Copy</Btn>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  WORKFLOW BUILDER
// ═══════════════════════════════════════════════════════
function WorkflowPage() {
  const [workflows, setWorkflows] = useState(null);
  const [loading, setLoading]     = useState(true);
  const [activeIdx, setActiveIdx] = useState(0);
  const [selNode, setSelNode]     = useState(null);

  useEffect(()=>{
    fetch("/api/workflows").then(r=>r.ok?r.json():Promise.reject(r.statusText))
      .then(d=>setWorkflows(d.workflows??[]))
      .catch(()=>setWorkflows([]))
      .finally(()=>setLoading(false));
  },[]);

  const active = workflows?.[activeIdx];
  const nodes  = active?.nodes??[];
  const edges  = active?.edges??[];
  const selNodeObj = nodes.find(n=>n.id===selNode);

  const ADD=[["🤖","AI Email"],["⏳","Wait"],["🔀","If / Else"],["🏷","Tag"],["💬","SMS"],["🔔","Notify"],["💰","Deal"],["🔌","Webhook"]];

  return (
    <div style={{ display:"flex", height:"100%", overflow:"hidden" }}>
      <div style={{ width:212, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column" }}>
        <div style={{ padding:"13px 12px 9px", borderBottom:`1px solid ${T.line}` }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:8 }}>
            <span style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.1em", fontFamily:"'JetBrains Mono',monospace" }}>Workflows</span>
            <button style={{ width:22, height:22, borderRadius:6, background:T.blueL, border:`1px solid rgba(75,108,247,0.25)`, color:T.blue, fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700 }}>+</button>
          </div>
          {loading?<Spinner size={18}/>:workflows?.length===0?(
            <div style={{ fontSize:12, color:T.low, padding:"8px 0" }}>No workflows yet. Create one.</div>
          ):workflows.map((wf,i)=>(
            <div key={wf.id} onClick={()=>{setActiveIdx(i);setSelNode(null);}} style={{ padding:"9px 10px", borderRadius:9, marginBottom:4, cursor:"pointer", background:activeIdx===i?T.blueL:"transparent", border:`1px solid ${activeIdx===i?"rgba(75,108,247,0.25)":"transparent"}`, transition:"all 0.12s" }}>
              <div style={{ fontSize:12, fontWeight:activeIdx===i?600:400, color:activeIdx===i?T.blue:T.mid, marginBottom:5 }}>{wf.name}</div>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <span style={{ fontSize:9, fontWeight:700, padding:"2px 6px", borderRadius:4, textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace", background:wf.status==="active"?T.greenL:T.amberL, border:`1px solid ${wf.status==="active"?"rgba(13,173,116,0.22)":"rgba(231,145,9,0.22)"}`, color:wf.status==="active"?T.green:T.amber }}>{wf.status}</span>
                <span style={{ fontSize:10, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{wf.runs?.toLocaleString()??0}</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding:"10px 12px", flex:1, overflowY:"auto" }}>
          <div style={{ fontSize:9.5, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.1em", fontFamily:"'JetBrains Mono',monospace", marginBottom:8 }}>Add Step</div>
          {ADD.map(([ic,lbl])=>(
            <div key={lbl} draggable style={{ display:"flex", alignItems:"center", gap:9, padding:"7px 8px", borderRadius:8, marginBottom:3, cursor:"grab", background:T.card, border:`1px solid ${T.line}`, transition:"all 0.12s" }}
              onMouseEnter={e=>{e.currentTarget.style.background=T.card2;e.currentTarget.style.borderColor=T.lineHi;}}
              onMouseLeave={e=>{e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}>
              <span style={{ fontSize:14 }}>{ic}</span><span style={{ fontSize:12, color:T.mid, fontWeight:500 }}>{lbl}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"10px 16px", borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:10, background:T.card }}>
          <div style={{ flex:1, display:"flex", alignItems:"center", gap:8 }}>
            {active&&<Dot color={active.status==="active"?T.green:T.amber}/>}
            <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>{active?.name??"Select a workflow"}</span>
          </div>
          <Btn sx={{ fontSize:11, padding:"5px 11px" }}>⟳ Test</Btn>
          <Btn variant="blue" sx={{ fontSize:11, padding:"5px 11px" }}>⏸ Pause</Btn>
          <Btn variant="primary" sx={{ fontSize:11, padding:"5px 13px" }}>Save</Btn>
        </div>
        <div style={{ flex:1, overflow:"auto", position:"relative", background:T.bg, backgroundImage:`radial-gradient(${T.lineHi} 1px,transparent 1px)`, backgroundSize:"28px 28px" }}>
          {loading?<div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100%" }}><Spinner size={28}/></div>
           :!active||nodes.length===0?<EmptyState icon="⬟" title="Canvas is empty" desc="Drag steps from the left panel or select a workflow."/>
           :(
            <div style={{ position:"relative", minHeight:900, minWidth:640 }}>
              <svg style={{ position:"absolute", inset:0, width:"100%", height:"100%", pointerEvents:"none", overflow:"visible" }}>
                {edges.map((edge,i)=>{
                  const fn=nodes.find(n=>n.id===edge.from), tn=nodes.find(n=>n.id===edge.to);
                  if(!fn||!tn)return null;
                  const fx=fn.x+96,fy=fn.y+56,tx=tn.x+96,ty=tn.y+2,cy=(fy+ty)/2;
                  return(<g key={i}><path d={`M${fx},${fy} C${fx},${cy} ${tx},${cy} ${tx},${ty}`} stroke="rgba(75,108,247,0.28)" strokeWidth="2" fill="none" strokeDasharray="5 4" style={{ animation:"flowdash 1s linear infinite" }}/><circle cx={tx} cy={ty} r="3" fill={T.blue}/>{edge.label&&<text x={(fx+tx)/2+10} y={cy} fill={T.low} fontSize="10" fontFamily="Plus Jakarta Sans">{edge.label}</text>}</g>);
                })}
              </svg>
              {nodes.map(node=>{
                const isSel=selNode===node.id;
                const bgs={trigger:T.amberL,action:T.card,condition:T.blueL};
                const bds={trigger:isSel?T.amber:"rgba(231,145,9,0.25)",action:isSel?T.blue:T.line,condition:isSel?T.blue:"rgba(75,108,247,0.28)"};
                return(<div key={node.id} onClick={()=>setSelNode(node.id)} style={{ position:"absolute", left:node.x, top:node.y, width:192, background:bgs[node.type]||T.card, border:`1.5px solid ${bds[node.type]||T.line}`, borderRadius:12, padding:"12px 14px", cursor:"pointer", transition:"all 0.15s", boxShadow:isSel?`0 0 0 3px rgba(75,108,247,0.12),0 6px 20px rgba(0,0,0,0.08)`:"0 2px 8px rgba(0,0,0,0.05)" }}>
                  {node.type==="trigger"&&<div style={{ fontSize:9, fontWeight:700, color:T.amber, letterSpacing:"0.1em", marginBottom:5, textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>⚡ TRIGGER</div>}
                  {node.type==="condition"&&<div style={{ fontSize:9, fontWeight:700, color:T.blue, letterSpacing:"0.1em", marginBottom:5, textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>⬡ CONDITION</div>}
                  <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:3 }}>{node.label}</div>
                  <div style={{ fontSize:10.5, color:T.low }}>{node.subtitle}</div>
                </div>);
              })}
            </div>
          )}
        </div>
      </div>

      {selNodeObj&&(
        <div className="slidein" style={{ width:232, flexShrink:0, background:T.card, borderLeft:`1px solid ${T.line}`, padding:16, overflowY:"auto" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>Configure</span>
            <button onClick={()=>setSelNode(null)} style={{ marginLeft:"auto", background:"none", border:"none", color:T.low, cursor:"pointer", fontSize:18 }}>×</button>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            <Field label="Step Name"><Input defaultValue={selNodeObj.label}/></Field>
            {selNodeObj.type==="trigger"&&<Field label="Trigger"><SelectEl opts={["New Lead Found","Intent: Hot","Email Replied","Form Submitted"]} def="New Lead Found"/></Field>}
            {selNodeObj.type==="condition"&&<Field label="Condition"><SelectEl opts={["Score ≥ 75","Score ≥ 85","Email Verified","Reply: Interested"]} def="Score ≥ 75"/></Field>}
            <div style={{ paddingTop:10, borderTop:`1px solid ${T.line}` }}>
              <label style={{ display:"flex", alignItems:"center", gap:7, cursor:"pointer" }}><input type="checkbox" style={{ width:13, height:13 }}/><span style={{ fontSize:11.5, color:T.low }}>Continue on error</span></label>
            </div>
            <Btn variant="primary" sx={{ fontSize:12 }}>Apply</Btn>
            <Btn variant="danger" sx={{ fontSize:12 }}>Remove Step</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  WEBSITE BUILDER (condensed — same as before)
// ═══════════════════════════════════════════════════════
function WebBuilderPage() {
  const [view, setView]   = useState("gallery");
  const [blocks, setBlocks] = useState([
    { id:"b1", type:"hero",     label:"Hero Section",  height:200 },
    { id:"b2", type:"features", label:"Features Grid", height:160 },
    { id:"b3", type:"pricing",  label:"Pricing Table", height:180 },
    { id:"b4", type:"cta",      label:"Call to Action",height:120 },
  ]);
  const [selBlock, setSelBlock] = useState("b1");
  const [tab, setTab]           = useState("sections");
  const [device, setDevice]     = useState("desktop");
  const [hovBlock, setHovBlock] = useState(null);
  const [published, setPublished] = useState(false);

  const WB_TEMPLATES=[{id:"blank",label:"Blank Canvas",emoji:"⬜",desc:"Start from scratch"},{id:"saas",label:"SaaS Landing",emoji:"🚀",desc:"Hero · Features · Pricing · CTA"},{id:"agency",label:"Agency Site",emoji:"💼",desc:"Services · Portfolio · Contact"},{id:"portfolio",label:"Portfolio",emoji:"🎨",desc:"About · Work · Testimonials"},{id:"ecommerce",label:"E-commerce",emoji:"🛍",desc:"Products · Cart · Checkout"},{id:"blog",label:"Blog / Media",emoji:"📰",desc:"Posts · Categories · Newsletter"}];
  const WB_SECTIONS=[{id:"hero",label:"Hero",icon:"⬟",c:T.blue},{id:"features",label:"Features",icon:"◈",c:T.violet},{id:"pricing",label:"Pricing",icon:"◎",c:T.green},{id:"testimonial",label:"Testimonials",icon:"◷",c:T.amber},{id:"cta",label:"CTA",icon:"→",c:T.teal},{id:"contact",label:"Contact Form",icon:"◫",c:T.blue},{id:"faq",label:"FAQ",icon:"⬡",c:T.violet},{id:"gallery",label:"Gallery",icon:"⬟",c:T.amber},{id:"video",label:"Video",icon:"◉",c:T.red},{id:"footer",label:"Footer",icon:"▤",c:T.mid}];
  const WB_ELEMENTS=[{label:"Heading",icon:"T",c:T.ink},{label:"Text",icon:"¶",c:T.mid},{label:"Button",icon:"◻",c:T.blue},{label:"Image",icon:"⬟",c:T.violet},{label:"Video",icon:"▶",c:T.red},{label:"Form",icon:"◫",c:T.teal},{label:"Icon",icon:"⊙",c:T.amber},{label:"Divider",icon:"—",c:T.low},{label:"Columns",icon:"⬡⬡",c:T.violet},{label:"Card",icon:"⬟",c:T.blue},{label:"Code",icon:"</>",c:T.teal},{label:"Spacer",icon:"↕",c:T.low}];

  const moveBlock=(id,dir)=>setBlocks(p=>{const a=[...p],i=a.findIndex(b=>b.id===id);if(dir==="up"&&i===0||dir==="dn"&&i===a.length-1)return p;const ti=dir==="up"?i-1:i+1;[a[i],a[ti]]=[a[ti],a[i]];return a;});
  const removeBlock=id=>{setBlocks(p=>p.filter(b=>b.id!==id));if(selBlock===id)setSelBlock(null);};
  const addSection=sec=>{const nb={id:`b${Date.now()}`,type:sec.id,label:sec.label,height:150};setBlocks(p=>[...p,nb]);setSelBlock(nb.id);};
  const selBlockObj=blocks.find(b=>b.id===selBlock);

  const Preview=({block})=>{
    const p={
      hero:(<div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:8,padding:"0 20px" }}><div style={{ width:"55%",height:12,background:`linear-gradient(90deg,${T.blue}70,${T.violet}70)`,borderRadius:6 }}/><div style={{ width:"70%",height:7,background:T.card3,borderRadius:4 }}/><div style={{ display:"flex",gap:8,marginTop:6 }}><div style={{ width:72,height:26,background:T.blue,borderRadius:7 }}/><div style={{ width:72,height:26,background:T.card2,border:`1px solid ${T.line}`,borderRadius:7 }}/></div></div>),
      features:(<div style={{ display:"flex",gap:10,padding:"12px 16px",height:"100%",alignItems:"center" }}>{[T.blue,T.violet,T.green].map((c,i)=>(<div key={i} style={{ flex:1,background:T.card2,border:`1px solid ${T.line}`,borderRadius:9,padding:"10px 8px",height:"76%",display:"flex",flexDirection:"column",gap:5 }}><div style={{ width:20,height:20,borderRadius:6,background:`${c}18` }}/><div style={{ height:6,width:"80%",background:T.card3,borderRadius:3 }}/><div style={{ height:4,width:"90%",background:T.card3,borderRadius:3 }}/></div>))}</div>),
      pricing:(<div style={{ display:"flex",gap:10,padding:"12px 16px",height:"100%",alignItems:"center" }}>{[false,true,false].map((hi,i)=>(<div key={i} style={{ flex:1,background:hi?T.blueL:T.card2,border:`1px solid ${hi?"rgba(75,108,247,0.3)":T.line}`,borderRadius:9,padding:"10px 8px",height:"88%",display:"flex",flexDirection:"column",gap:4,position:"relative" }}>{hi&&<div style={{ position:"absolute",top:-8,left:"50%",transform:"translateX(-50%)",background:T.blue,color:"#fff",fontSize:8,padding:"2px 8px",borderRadius:4,fontWeight:700,whiteSpace:"nowrap" }}>POPULAR</div>}<div style={{ height:6,width:"60%",background:T.card3,borderRadius:3 }}/><div style={{ height:12,width:"40%",background:hi?`${T.blue}40`:T.card3,borderRadius:3 }}/><div style={{ flex:1 }}/><div style={{ height:20,background:hi?T.blue:T.card3,borderRadius:5 }}/></div>))}</div>),
      cta:(<div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:8,padding:"0 20px",background:`linear-gradient(135deg,${T.blueL},${T.violetL})` }}><div style={{ width:"50%",height:10,background:`${T.blue}50`,borderRadius:5 }}/><div style={{ width:"65%",height:6,background:T.card3,borderRadius:3 }}/><div style={{ width:90,height:28,background:T.blue,borderRadius:8,marginTop:4 }}/></div>),
    };
    return p[block.type]||<div style={{ display:"flex",alignItems:"center",justifyContent:"center",height:"100%",fontSize:22,opacity:0.15 }}>⬟</div>;
  };

  if(view==="gallery") return (
    <div style={{ padding:24, display:"flex", flexDirection:"column", gap:20 }}>
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between" }}>
        <div><div style={{ fontWeight:800, fontSize:21, color:T.ink }}>Website Builder</div><div style={{ fontSize:13, color:T.mid, marginTop:4, lineHeight:1.65, maxWidth:520 }}>Build landing pages and client sites — no code needed. Connected to CRM, forms, and analytics.</div></div>
        <Btn variant="primary" sx={{ fontSize:12.5 }} onClick={()=>setView("editor")}>Start from Blank</Btn>
      </div>
      <div>
        <div style={{ fontWeight:700, fontSize:16, color:T.ink, marginBottom:14 }}>Templates</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14 }}>
          {WB_TEMPLATES.map(tpl=>(
            <div key={tpl.id} onClick={()=>setView("editor")} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden", cursor:"pointer", transition:"all 0.18s" }}
              onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(75,108,247,0.36)";e.currentTarget.style.boxShadow=`0 8px 28px rgba(75,108,247,0.12)`;e.currentTarget.style.transform="translateY(-2px)";}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=T.line;e.currentTarget.style.boxShadow="none";e.currentTarget.style.transform="none";}}>
              <div style={{ height:140, background:`linear-gradient(135deg,${T.blueL},${T.violetL})`, display:"flex", alignItems:"center", justifyContent:"center" }}><div style={{ fontSize:46, opacity:0.38 }}>{tpl.emoji}</div></div>
              <div style={{ padding:14 }}><div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:4 }}>{tpl.label}</div><div style={{ fontSize:12, color:T.mid }}>{tpl.desc}</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", overflow:"hidden" }}>
      <div style={{ height:50, background:T.card, borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", padding:"0 14px", gap:10, flexShrink:0 }}>
        <button onClick={()=>setView("gallery")} style={{ background:"none", border:"none", color:T.mid, cursor:"pointer", fontSize:13, fontWeight:500 }}>← Sites</button>
        <div style={{ width:1, height:20, background:T.line }}/>
        <input defaultValue="My Site" style={{ background:"none", border:"none", fontSize:13.5, fontWeight:700, color:T.ink, outline:"none", minWidth:120 }}/>
        <div style={{ width:1, height:20, background:T.line }}/>
        <div style={{ display:"flex", gap:2, background:T.card2, border:`1px solid ${T.line}`, borderRadius:8, padding:3 }}>
          {[["desktop","🖥"],["tablet","📱"],["mobile","📲"]].map(([v,ic])=>(
            <button key={v} onClick={()=>setDevice(v)} style={{ padding:"4px 10px", borderRadius:6, fontSize:11.5, cursor:"pointer", background:device===v?T.card:T.card2, border:`1px solid ${device===v?T.line:"transparent"}`, color:device===v?T.ink:T.low }}>{ic}</button>
          ))}
        </div>
        <div style={{ marginLeft:"auto", display:"flex", gap:7 }}>
          <Btn sx={{ fontSize:11.5, padding:"5px 12px" }}>Save</Btn>
          <Btn variant={published?"green":"primary"} sx={{ fontSize:11.5, padding:"5px 14px" }} onClick={()=>setPublished(true)}>{published?"✓ Published":"⬆ Publish"}</Btn>
        </div>
      </div>

      <div style={{ flex:1, display:"flex", overflow:"hidden" }}>
        <div style={{ width:218, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column" }}>
          <div style={{ display:"flex", borderBottom:`1px solid ${T.line}` }}>
            {[["sections","Sections"],["elements","Elements"],["pages","Pages"]].map(([k,l])=>(
              <button key={k} onClick={()=>setTab(k)} style={{ flex:1, padding:"10px 4px", background:"none", border:"none", borderBottom:`2px solid ${tab===k?T.blue:"transparent"}`, color:tab===k?T.blue:T.low, fontSize:12, fontWeight:tab===k?600:400, cursor:"pointer" }}>{l}</button>
            ))}
          </div>
          <div style={{ padding:10, flex:1, overflowY:"auto" }}>
            {tab==="sections"&&<div style={{ display:"flex", flexDirection:"column", gap:5 }}>{WB_SECTIONS.map(s=>(
              <div key={s.id} onClick={()=>addSection(s)} style={{ display:"flex", alignItems:"center", gap:9, padding:"8px 10px", borderRadius:9, cursor:"pointer", background:T.card, border:`1px solid ${T.line}`, transition:"all 0.12s" }}
                onMouseEnter={e=>{e.currentTarget.style.background=T.blueL;e.currentTarget.style.borderColor="rgba(75,108,247,0.25)";}}
                onMouseLeave={e=>{e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}>
                <div style={{ width:26, height:26, borderRadius:7, background:`${s.c}14`, border:`1px solid ${s.c}20`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, color:s.c, flexShrink:0 }}>{s.icon}</div>
                <span style={{ fontSize:12, fontWeight:500, color:T.mid }}>{s.label}</span>
                <span style={{ marginLeft:"auto", fontSize:14, color:T.low }}>+</span>
              </div>
            ))}</div>}
            {tab==="elements"&&<div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6 }}>{WB_ELEMENTS.map(el=>(
              <div key={el.label} draggable style={{ padding:"10px 8px", borderRadius:9, cursor:"grab", background:T.card, border:`1px solid ${T.line}`, textAlign:"center", transition:"all 0.12s" }}
                onMouseEnter={e=>{e.currentTarget.style.background=T.card2;e.currentTarget.style.borderColor=T.lineHi;}}
                onMouseLeave={e=>{e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}>
                <div style={{ fontSize:18, marginBottom:4, color:el.c }}>{el.icon}</div>
                <div style={{ fontSize:10.5, color:T.mid, fontWeight:500 }}>{el.label}</div>
              </div>
            ))}</div>}
            {tab==="pages"&&<div style={{ display:"flex", flexDirection:"column", gap:5 }}>
              {["Home","About","Pricing","Contact"].map(p=>(<div key={p} style={{ display:"flex", alignItems:"center", padding:"9px 11px", borderRadius:9, background:p==="Home"?T.blueL:T.card, border:`1px solid ${p==="Home"?"rgba(75,108,247,0.25)":T.line}`, cursor:"pointer" }}><span style={{ flex:1, fontSize:12.5, fontWeight:p==="Home"?600:400, color:p==="Home"?T.blue:T.mid }}>{p}</span>{p==="Home"&&<span style={{ fontSize:9, color:T.blue, fontFamily:"'JetBrains Mono',monospace", fontWeight:700 }}>ACTIVE</span>}</div>))}
              <button style={{ marginTop:8, padding:"9px", background:T.blueL, border:`1px solid rgba(75,108,247,0.2)`, borderRadius:9, color:T.blue, fontSize:12, fontWeight:600, cursor:"pointer" }}>+ New Page</button>
            </div>}
          </div>
        </div>

        <div style={{ flex:1, overflow:"auto", background:T.bg, display:"flex", alignItems:"flex-start", justifyContent:"center", padding:20 }}>
          <div style={{ width:device==="desktop"?"100%":device==="tablet"?720:375, maxWidth:device==="desktop"?920:undefined, background:T.card, borderRadius:12, boxShadow:"0 8px 40px rgba(50,60,120,0.12)", border:`1px solid ${T.line}`, overflow:"hidden", transition:"all 0.3s ease" }}>
            <div style={{ height:36, background:T.card2, borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", padding:"0 12px", gap:8 }}>
              <div style={{ display:"flex", gap:5 }}>{[T.red,T.amber,T.green].map(c=><div key={c} style={{ width:9, height:9, borderRadius:"50%", background:c, opacity:0.7 }}/>)}</div>
              <div style={{ flex:1, background:T.card, border:`1px solid ${T.line}`, borderRadius:6, padding:"3px 12px", fontSize:11, color:T.low, textAlign:"center", fontFamily:"'JetBrains Mono',monospace" }}>mysite.argiflow.io</div>
            </div>
            {blocks.length===0?(
              <div style={{ padding:60, textAlign:"center", color:T.low }}><div style={{ fontSize:40, opacity:0.1, marginBottom:12 }}>⬟</div><div style={{ fontSize:14, fontWeight:600, color:T.ink, marginBottom:6 }}>Canvas is empty</div><div style={{ fontSize:12 }}>Add sections from the left panel.</div></div>
            ):(
              <div>
                {blocks.map((block,i)=>{
                  const isSel=selBlock===block.id, isHov=hovBlock===block.id;
                  return(<div key={block.id} onClick={()=>setSelBlock(block.id)} onMouseEnter={()=>setHovBlock(block.id)} onMouseLeave={()=>setHovBlock(null)} style={{ position:"relative", height:block.height, border:`2px solid ${isSel?T.blue:isHov?"rgba(75,108,247,0.3)":"transparent"}`, borderBottom:`1px solid ${T.line}`, transition:"border-color 0.14s", cursor:"pointer" }}>
                    <Preview block={block}/>
                    {(isSel||isHov)&&(<div style={{ position:"absolute", top:6, right:6, display:"flex", gap:4 }}>{["↑","↓"].map((d,j)=><button key={d} onClick={e=>{e.stopPropagation();moveBlock(block.id,j===0?"up":"dn");}} style={{ width:24, height:24, borderRadius:6, background:T.card, border:`1px solid ${T.line}`, color:T.mid, cursor:"pointer", fontSize:12, display:"flex", alignItems:"center", justifyContent:"center" }}>{d}</button>)}<button onClick={e=>{e.stopPropagation();removeBlock(block.id);}} style={{ width:24, height:24, borderRadius:6, background:T.redL, border:`1px solid rgba(228,68,68,0.25)`, color:T.red, cursor:"pointer", fontSize:12, display:"flex", alignItems:"center", justifyContent:"center" }}>×</button></div>)}
                    {isSel&&<div style={{ position:"absolute", left:0, top:0, bottom:0, width:3, background:T.blue, borderRadius:"2px 0 0 2px" }}/>}
                    <div style={{ position:"absolute", bottom:7, left:10, fontSize:10, color:isSel?T.blue:T.low, fontWeight:isSel?600:400, background:T.card, padding:"2px 8px", borderRadius:4, border:`1px solid ${isSel?"rgba(75,108,247,0.25)":T.line}` }}>{block.label}</div>
                  </div>);
                })}
                <div style={{ height:72, border:`2px dashed ${T.line}`, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", transition:"all 0.15s" }}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(75,108,247,0.35)";e.currentTarget.style.background=T.blueL;}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor=T.line;e.currentTarget.style.background="transparent";}}
                  onClick={()=>setTab("sections")}>
                  <span style={{ fontSize:13, color:T.low, fontWeight:500 }}>+ Add Section</span>
                </div>
              </div>
            )}
          </div>
        </div>

        <div style={{ width:240, flexShrink:0, background:T.card, borderLeft:`1px solid ${T.line}`, display:"flex", flexDirection:"column", overflowY:"auto" }}>
          <div style={{ padding:"13px 14px", borderBottom:`1px solid ${T.line}` }}><div style={{ fontWeight:700, fontSize:13, color:T.ink }}>Block Settings</div>{selBlockObj&&<div style={{ fontSize:10.5, color:T.low, marginTop:2 }}>{selBlockObj.label}</div>}</div>
          {selBlockObj?(
            <div style={{ padding:14, display:"flex", flexDirection:"column", gap:12 }}>
              <Field label="Name"><Input defaultValue={selBlockObj.label}/></Field>
              <div><FLabel>Background</FLabel><div style={{ display:"flex", gap:5 }}>{[T.card,"#F0F4FF","#F0FFF8","#FFF9F0"].map((bg,i)=><div key={i} style={{ width:28, height:28, borderRadius:6, background:bg, border:`2px solid ${i===0?T.blue:T.line}`, cursor:"pointer" }}/>)}</div></div>
              <Field label="Animation"><SelectEl opts={["None","Fade In","Slide Up","Scale In"]} def="None"/></Field>
              <div style={{ paddingTop:8, borderTop:`1px solid ${T.line}`, display:"flex", flexDirection:"column", gap:6 }}>
                <Btn variant="primary" sx={{ fontSize:12 }}>Edit Content</Btn>
                <Btn variant="danger" sx={{ fontSize:12 }} onClick={()=>removeBlock(selBlockObj.id)}>Remove Section</Btn>
              </div>
            </div>
          ):(
            <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:20, textAlign:"center", opacity:0.4 }}>
              <div style={{ fontSize:32, marginBottom:10 }}>⬟</div>
              <div style={{ fontSize:12, color:T.mid }}>Click any block to configure it</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  CREDITS PAGE
// ═══════════════════════════════════════════════════════
function CreditsPage({ credits, user }) {
  const PLANS=[
    { name:"Starter",  price:"$97/mo",  credits:3000,  cost:"~$12",  margin:"88%" },
    { name:"Growth",   price:"$197/mo", credits:8000,  cost:"~$30",  margin:"85%", popular:true },
    { name:"Agency",   price:"$497/mo", credits:25000, cost:"~$90",  margin:"82%" },
  ];
  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16, maxWidth:860 }}>
      <Card sx={{ padding:28, background:`linear-gradient(135deg,${T.blueL},${T.violetL}60)`, borderColor:"rgba(75,108,247,0.22)" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div>
            <div style={{ fontSize:11, fontWeight:700, color:T.blue, letterSpacing:"0.08em", textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace", marginBottom:8 }}>CURRENT BALANCE</div>
            <div style={{ fontSize:52, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace", letterSpacing:"-0.03em" }}>{credits?.toLocaleString()}</div>
            <div style={{ fontSize:13, color:T.mid, marginTop:6 }}>credits · plan: <b style={{color:T.ink,textTransform:"uppercase"}}>{user?.plan}</b></div>
          </div>
          <Btn variant="primary" sx={{ fontSize:13, padding:"10px 24px" }}>⬆ Top Up Credits</Btn>
        </div>
        <div style={{ marginTop:24, paddingTop:20, borderTop:`1px solid rgba(75,108,247,0.15)` }}>
          <FLabel>Credit cost per action</FLabel>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10, marginTop:10 }}>
            {Object.entries(CREDIT_COSTS).map(([action,cost])=>(
              <div key={action} style={{ padding:"10px 12px", background:T.card, border:`1px solid ${T.line}`, borderRadius:9 }}>
                <div style={{ fontSize:10, color:T.low, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4 }}>{action.replace(/_/g," ")}</div>
                <div style={{ display:"flex", alignItems:"baseline", gap:6 }}><span style={{ fontSize:18, fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{cost}</span><span style={{ fontSize:11, color:T.low }}>credits</span></div>
              </div>
            ))}
          </div>
        </div>
      </Card>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12 }}>
        {PLANS.map(plan=>(
          <Card key={plan.name} sx={{ padding:22, position:"relative", borderColor:plan.popular?"rgba(75,108,247,0.35)":T.line, boxShadow:plan.popular?`0 0 0 3px ${T.blueL}`:undefined }}>
            {plan.popular&&<div style={{ position:"absolute", top:-1, left:"50%", transform:"translateX(-50%)", background:T.blue, color:"#fff", fontSize:9.5, fontWeight:700, padding:"3px 12px", borderRadius:"0 0 6px 6px", letterSpacing:"0.06em" }}>MOST POPULAR</div>}
            <div style={{ marginTop:plan.popular?12:0 }}>
              <div style={{ fontWeight:800, fontSize:16, color:T.ink, marginBottom:4 }}>{plan.name}</div>
              <div style={{ fontSize:28, fontWeight:800, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{plan.price}</div>
              <div style={{ fontSize:12, color:T.mid, marginTop:8 }}>{plan.credits.toLocaleString()} credits/month</div>
              <div style={{ fontSize:11, color:T.low, marginTop:4 }}>API cost: <b>{plan.cost}</b> · Margin: <b style={{color:T.green}}>{plan.margin}</b></div>
              <div style={{ marginTop:16 }}><Btn variant={plan.popular?"primary":"ghost"} sx={{ width:"100%", fontSize:13 }}>{user?.plan===plan.name.toLowerCase()?"Current Plan":"Upgrade"}</Btn></div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  BLANK
// ═══════════════════════════════════════════════════════
function BlankPage({ label }) {
  return <EmptyState icon="◈" title={label??"Coming Soon"} desc="Connect your backend to activate this module." />;
}

// ═══════════════════════════════════════════════════════
//  ANALYTICS DASHBOARD PAGE
// ═══════════════════════════════════════════════════════
function AnalyticsDashPage() {
  const [days, setDays]   = useState(7);
  const [data, setData]   = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/tracker/dashboard?days=${days}`)
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [days]);

  const statCard = (label, value, sub, color = T.blue) => (
    <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"18px 22px", flex:1, minWidth:160 }}>
      <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:8 }}>{label}</div>
      <div style={{ fontSize:28, fontWeight:800, color, fontFamily:"'JetBrains Mono',monospace" }}>{value ?? "—"}</div>
      {sub && <div style={{ fontSize:12, color:T.low, marginTop:4 }}>{sub}</div>}
    </div>
  );

  const periodBtn = (d, lbl) => (
    <button onClick={() => setDays(d)} style={{ padding:"5px 14px", borderRadius:7, fontSize:12, fontWeight:days===d?700:400, cursor:"pointer", background:days===d?T.blue:"transparent", color:days===d?"#fff":T.mid, border:`1px solid ${days===d?T.blue:T.line}`, transition:"all 0.12s" }}>{lbl}</button>
  );

  if (loading) return <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"60vh" }}><Spinner /></div>;

  const v = data?.visitors || {};
  const s = data?.sessions || {};
  const e = data?.email || {};
  const bounce = s.total > 0 ? Math.round((s.bounces / s.total) * 100) : 0;

  return (
    <div style={{ padding:"28px 32px", maxWidth:1100 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Analytics Dashboard</div>
          <div style={{ fontSize:13, color:T.low, marginTop:3 }}>Visitor behavior, sessions, searches, and email performance</div>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          {periodBtn(1,"Today")} {periodBtn(7,"7 days")} {periodBtn(30,"30 days")} {periodBtn(90,"90 days")}
        </div>
      </div>

      {/* Top stat cards */}
      <div style={{ display:"flex", gap:14, marginBottom:24, flexWrap:"wrap" }}>
        {statCard("Total Visitors",    v.total,               `${v.new_visitors ?? 0} new · ${v.returning_visitors ?? 0} returning`, T.blue)}
        {statCard("Sessions",          s.total,               `${s.avg_pages ?? 0} pages avg`, T.violet)}
        {statCard("Avg Session Time",  s.avg_duration ? `${Math.floor(s.avg_duration/60)}m ${s.avg_duration%60}s` : "—", "time on platform", T.green)}
        {statCard("Bounce Rate",       `${bounce}%`,          "single-page sessions", bounce > 60 ? T.red : T.amber)}
        {statCard("Email Open Rate",   `${e.open_rate ?? 0}%`, `${e.sent ?? 0} sent · ${e.opened ?? 0} opened`, T.teal)}
        {statCard("Email CTR",         `${e.ctr ?? 0}%`,       `${e.clicked ?? 0} clicked`, T.amber)}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginBottom:24 }}>
        {/* Top Pages */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:16 }}>Top Pages</div>
          {(data?.top_pages || []).slice(0,8).map((pg, i) => (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
              <div style={{ width:20, fontSize:11, color:T.low, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>{i+1}</div>
              <div style={{ flex:1, fontSize:12, color:T.ink, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={pg.page}>{pg.page}</div>
              <div style={{ fontSize:11, fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{pg.views}</div>
              <div style={{ fontSize:10, color:T.low }}>{pg.unique_visitors} uniq</div>
            </div>
          ))}
          {(!data?.top_pages?.length) && <div style={{ fontSize:12, color:T.low }}>No page data yet</div>}
        </div>

        {/* Top Searches */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:16 }}>Top Search Queries</div>
          {(data?.top_searches || []).slice(0,8).map((s, i) => (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
              <div style={{ width:20, fontSize:11, color:T.low, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>{i+1}</div>
              <div style={{ flex:1, fontSize:12, color:T.ink, fontWeight:500 }}>{s.query}</div>
              <div style={{ fontSize:11, fontWeight:700, color:T.violet, fontFamily:"'JetBrains Mono',monospace" }}>{s.count}×</div>
              <div style={{ fontSize:10, color:T.low }}>{s.avg_results} results</div>
            </div>
          ))}
          {(!data?.top_searches?.length) && <div style={{ fontSize:12, color:T.low }}>No searches yet</div>}
        </div>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:20, marginBottom:24 }}>
        {/* Devices */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:16 }}>Devices</div>
          {(data?.devices || []).map((d, i) => {
            const total = (data?.devices||[]).reduce((a,b)=>a+(+b.count),0);
            const pct   = total ? Math.round((d.count/total)*100) : 0;
            return (
              <div key={i} style={{ marginBottom:10 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:4 }}>
                  <span style={{ color:T.ink }}>{d.device || "Unknown"}</span>
                  <span style={{ fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{pct}%</span>
                </div>
                <div style={{ height:5, background:T.line, borderRadius:3 }}>
                  <div style={{ height:5, width:`${pct}%`, background:T.blue, borderRadius:3 }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Browsers */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:16 }}>Browsers</div>
          {(data?.browsers || []).map((b, i) => {
            const total = (data?.browsers||[]).reduce((a,c)=>a+(+c.count),0);
            const pct   = total ? Math.round((b.count/total)*100) : 0;
            const bc    = [T.blue,T.violet,T.green,T.amber,T.teal][i] || T.low;
            return (
              <div key={i} style={{ marginBottom:10 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:4 }}>
                  <span style={{ color:T.ink }}>{b.browser || "Other"}</span>
                  <span style={{ fontWeight:700, color:bc, fontFamily:"'JetBrains Mono',monospace" }}>{pct}%</span>
                </div>
                <div style={{ height:5, background:T.line, borderRadius:3 }}>
                  <div style={{ height:5, width:`${pct}%`, background:bc, borderRadius:3 }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Rage Clicks */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <div style={{ fontSize:13, fontWeight:700, color:T.ink }}>Rage Clicks</div>
            <span style={{ fontSize:10, padding:"2px 7px", borderRadius:5, background:T.redL, color:T.red, fontWeight:700 }}>UX Issues</span>
          </div>
          {(data?.rage_clicks || []).map((r, i) => (
            <div key={i} style={{ marginBottom:10, padding:"8px 10px", background:T.redL, borderRadius:8, border:`1px solid rgba(228,68,68,0.15)` }}>
              <div style={{ fontSize:11, fontWeight:700, color:T.red, marginBottom:2 }}>{r.rage_count}× rage clicks</div>
              <div style={{ fontSize:11, color:T.ink, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{r.element_text || r.element_id || "unknown element"}</div>
              <div style={{ fontSize:10, color:T.low }}>{r.page}</div>
            </div>
          ))}
          {(!data?.rage_clicks?.length) && <div style={{ fontSize:12, color:T.low }}>No rage clicks — UX looks good 👍</div>}
        </div>
      </div>

      {/* Form Abandonment */}
      <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
        <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:16 }}>Form Abandonment</div>
        {(data?.form_abandons || []).length ? (
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Form","Page","Started","Submitted","Abandoned","Abandon Rate"].map(h=>(
                <th key={h} style={{ padding:"8px 12px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.06em", borderBottom:`1px solid ${T.line}` }}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {data.form_abandons.map((f,i)=>(
                <tr key={i} style={{ borderBottom:`1px solid ${T.line}` }}>
                  <td style={{ padding:"10px 12px", fontSize:12, fontWeight:600, color:T.ink }}>{f.form_name}</td>
                  <td style={{ padding:"10px 12px", fontSize:11, color:T.low }}>{f.page}</td>
                  <td style={{ padding:"10px 12px", fontSize:12, fontFamily:"'JetBrains Mono',monospace", color:T.ink }}>{f.started}</td>
                  <td style={{ padding:"10px 12px", fontSize:12, fontFamily:"'JetBrains Mono',monospace", color:T.green }}>{f.submitted}</td>
                  <td style={{ padding:"10px 12px", fontSize:12, fontFamily:"'JetBrains Mono',monospace", color:T.red }}>{f.abandoned}</td>
                  <td style={{ padding:"10px 12px" }}>
                    <span style={{ fontSize:12, fontWeight:700, padding:"2px 8px", borderRadius:6, background:f.abandon_rate>50?T.redL:T.amberL, color:f.abandon_rate>50?T.red:T.amber }}>{f.abandon_rate}%</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : <div style={{ fontSize:12, color:T.low }}>No form data yet. Embed the tracker snippet to start collecting.</div>}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  VISITOR LIST PAGE
// ═══════════════════════════════════════════════════════
function VisitorListPage() {
  const [visitors, setVisitors] = useState([]);
  const [selected, setSelected] = useState(null);
  const [journey,  setJourney]  = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [days, setDays] = useState(7);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/tracker/visitors?days=${days}&limit=50`)
      .then(r=>r.json()).then(d=>{ setVisitors(d.visitors||[]); setLoading(false); })
      .catch(()=>setLoading(false));
  }, [days]);

  const openJourney = (v) => {
    setSelected(v);
    fetch(`/api/tracker/visitor/${v.visitor_id}`)
      .then(r=>r.json()).then(setJourney).catch(()=>{});
  };

  const devIcon = (d="") => d.includes("iOS")||d.includes("iPhone")?"📱":d.includes("Android")?"📱":d.includes("Mac")?"💻":d.includes("Windows")?"🖥️":"💻";

  return (
    <div style={{ display:"flex", height:"calc(100vh - 0px)", overflow:"hidden" }}>
      {/* Visitor list */}
      <div style={{ width:selected?380:"100%", flexShrink:0, borderRight:selected?`1px solid ${T.line}`:"none", overflow:"auto", padding:"24px 28px" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
          <div>
            <div style={{ fontSize:20, fontWeight:800, color:T.ink }}>Visitor Intelligence</div>
            <div style={{ fontSize:12, color:T.low, marginTop:2 }}>{visitors.length} visitors · last {days} days</div>
          </div>
          <div style={{ display:"flex", gap:6 }}>
            {[1,7,30].map(d=>(
              <button key={d} onClick={()=>setDays(d)} style={{ padding:"4px 12px", borderRadius:7, fontSize:12, fontWeight:days===d?700:400, cursor:"pointer", background:days===d?T.blue:"transparent", color:days===d?"#fff":T.mid, border:`1px solid ${days===d?T.blue:T.line}` }}>{d}d</button>
            ))}
          </div>
        </div>

        {loading ? <div style={{ display:"flex", justifyContent:"center", padding:40 }}><Spinner /></div> : (
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {visitors.map(v=>(
              <div key={v.visitor_id} onClick={()=>openJourney(v)}
                style={{ padding:"14px 16px", background:selected?.visitor_id===v.visitor_id?T.blueL:T.card, border:`1px solid ${selected?.visitor_id===v.visitor_id?"rgba(75,108,247,0.3)":T.line}`, borderRadius:12, cursor:"pointer", transition:"all 0.12s" }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <div style={{ width:36, height:36, borderRadius:"50%", background:`linear-gradient(135deg,${T.blue},${T.violet})`, display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontSize:14, fontWeight:700, flexShrink:0 }}>
                    {(v.name||v.company||v.visitor_id).charAt(0).toUpperCase()}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:13, fontWeight:600, color:T.ink, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                      {v.name || v.email || (v.visitor_id.slice(0,8)+"...")}
                    </div>
                    <div style={{ fontSize:11, color:T.low, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                      {v.company || v.email || "Anonymous visitor"}
                    </div>
                  </div>
                  <div style={{ textAlign:"right", flexShrink:0 }}>
                    <div style={{ fontSize:11, fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{v.visit_count}v</div>
                    <div style={{ fontSize:10, color:T.low }}>{devIcon(v.first_device)}</div>
                  </div>
                </div>
                {v.last_search && (
                  <div style={{ marginTop:8, fontSize:11, color:T.violet, background:T.violetL, padding:"3px 8px", borderRadius:5, display:"inline-block" }}>
                    🔍 "{v.last_search}"
                  </div>
                )}
                <div style={{ display:"flex", gap:8, marginTop:8 }}>
                  {v.utm_source && <span style={{ fontSize:10, padding:"2px 6px", borderRadius:4, background:T.greenL, color:T.green, fontWeight:600 }}>utm: {v.utm_source}</span>}
                  <span style={{ fontSize:10, color:T.low }}>{v.total_pageviews} pages</span>
                </div>
              </div>
            ))}
            {!visitors.length && <EmptyState icon="◎" title="No visitors yet" desc="Embed the ArgiFlow tracker snippet on your site to start collecting visitor data." />}
          </div>
        )}
      </div>

      {/* Journey panel */}
      {selected && (
        <div style={{ flex:1, overflow:"auto", padding:"24px 28px" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
            <div>
              <div style={{ fontSize:18, fontWeight:800, color:T.ink }}>
                {selected.name || selected.email || "Anonymous Visitor"}
              </div>
              <div style={{ fontSize:12, color:T.low }}>{selected.company || "Unknown company"} · {selected.first_device}</div>
            </div>
            <button onClick={()=>{setSelected(null);setJourney(null);}} style={{ padding:"6px 14px", borderRadius:8, border:`1px solid ${T.line}`, background:"transparent", cursor:"pointer", fontSize:12, color:T.mid }}>✕ Close</button>
          </div>

          {/* Profile */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:20 }}>
            {[
              ["Visit Count", selected.visit_count, T.blue],
              ["Total Pages", selected.total_pageviews, T.violet],
              ["First Seen", selected.first_seen ? new Date(selected.first_seen).toLocaleDateString() : "—", T.green],
            ].map(([l,v,c])=>(
              <div key={l} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:10, padding:"14px 16px" }}>
                <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:6 }}>{l}</div>
                <div style={{ fontSize:20, fontWeight:800, color:c, fontFamily:"'JetBrains Mono',monospace" }}>{v}</div>
              </div>
            ))}
          </div>

          {!journey ? <div style={{ display:"flex", justifyContent:"center", padding:40 }}><Spinner /></div> : (
            <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
              {/* Searches */}
              {journey.searches?.length > 0 && (
                <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"16px 18px" }}>
                  <div style={{ fontSize:12, fontWeight:700, color:T.ink, marginBottom:12 }}>🔍 Searches ({journey.searches.length})</div>
                  {journey.searches.map((s,i)=>(
                    <div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
                      <span style={{ fontSize:12, fontWeight:600, color:T.violet }}>"{s.query}"</span>
                      <span style={{ fontSize:10, color:T.low }}>{s.results_count} results</span>
                      <span style={{ fontSize:10, color:T.low, marginLeft:"auto" }}>{new Date(s.created_at).toLocaleTimeString()}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Page journey timeline */}
              {journey.pageviews?.length > 0 && (
                <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"16px 18px" }}>
                  <div style={{ fontSize:12, fontWeight:700, color:T.ink, marginBottom:12 }}>📄 Page Journey ({journey.pageviews.length} views)</div>
                  {journey.pageviews.slice(0,15).map((pv,i)=>(
                    <div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8, paddingLeft:12, borderLeft:`2px solid ${i===0?T.blue:T.line}` }}>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:12, color:T.ink, fontWeight:i===0?600:400 }}>{pv.page}</div>
                        {pv.title && <div style={{ fontSize:11, color:T.low }}>{pv.title}</div>}
                      </div>
                      <div style={{ fontSize:10, color:T.low, flexShrink:0 }}>{new Date(pv.created_at).toLocaleTimeString()}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Sessions */}
              {journey.sessions?.length > 0 && (
                <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"16px 18px" }}>
                  <div style={{ fontSize:12, fontWeight:700, color:T.ink, marginBottom:12 }}>⏱ Sessions ({journey.sessions.length})</div>
                  {journey.sessions.map((s,i)=>(
                    <div key={i} style={{ display:"flex", alignItems:"center", gap:12, marginBottom:8, padding:"8px 10px", background:T.bg, borderRadius:8 }}>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:12, color:T.ink }}>{s.entry_page} → {s.exit_page || "..."}</div>
                        <div style={{ fontSize:10, color:T.low }}>{s.browser} · {s.device} · {s.page_count} pages</div>
                      </div>
                      <div style={{ fontSize:11, fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace", flexShrink:0 }}>
                        {s.duration_seconds ? `${Math.floor(s.duration_seconds/60)}m ${s.duration_seconds%60}s` : "active"}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Custom events */}
              {journey.events?.length > 0 && (
                <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"16px 18px" }}>
                  <div style={{ fontSize:12, fontWeight:700, color:T.ink, marginBottom:12 }}>⚡ Custom Events ({journey.events.length})</div>
                  {journey.events.map((e,i)=>(
                    <div key={i} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
                      <span style={{ fontSize:11, fontWeight:600, color:T.amber, padding:"2px 8px", background:T.amberL, borderRadius:5 }}>{e.event_name}</span>
                      <span style={{ fontSize:11, color:T.low }}>{e.event_category}</span>
                      <span style={{ fontSize:10, color:T.low, marginLeft:"auto" }}>{new Date(e.created_at).toLocaleTimeString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  REAL-TIME PAGE
// ═══════════════════════════════════════════════════════
function RealtimePage() {
  const [rt, setRt] = useState(null);
  const [history, setHistory] = useState([]);
  const timerRef = useRef(null);

  const refresh = () => {
    fetch("/api/tracker/realtime")
      .then(r=>r.json())
      .then(d => {
        setRt(d);
        if (d.recent_activity?.length) {
          setHistory(prev => {
            const combined = [...d.recent_activity, ...prev];
            const seen = new Set();
            return combined.filter(item => {
              const key = item.visitor_id + item.created_at;
              if (seen.has(key)) return false;
              seen.add(key);
              return true;
            }).slice(0, 50);
          });
        }
      }).catch(()=>{});
  };

  useEffect(() => {
    refresh();
    timerRef.current = setInterval(refresh, 10000);
    return () => clearInterval(timerRef.current);
  }, []);

  const devIcon = (d="") => d.includes("iOS")||d.includes("iPhone")||d.includes("Android")?"📱":"💻";

  return (
    <div style={{ padding:"28px 32px", maxWidth:900 }}>
      <div style={{ display:"flex", alignItems:"center", gap:16, marginBottom:28 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Real-Time Feed</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Live visitor activity · refreshes every 10 seconds</div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 18px", background:T.greenL, border:"1px solid rgba(13,173,116,0.22)", borderRadius:20 }}>
          <div style={{ width:8, height:8, borderRadius:"50%", background:T.green, animation:"pulse 1.5s infinite" }} />
          <span style={{ fontSize:14, fontWeight:800, color:T.green, fontFamily:"'JetBrains Mono',monospace" }}>{rt?.active_visitors ?? 0}</span>
          <span style={{ fontSize:12, color:T.green }}>active now</span>
        </div>
      </div>

      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {history.map((item, i) => (
          <div key={i} style={{ display:"flex", alignItems:"center", gap:14, padding:"12px 16px", background:T.card, border:`1px solid ${T.line}`, borderRadius:12, animation:i===0?"fadein 0.3s ease":undefined }}>
            <div style={{ width:34, height:34, borderRadius:"50%", background:`linear-gradient(135deg,${T.blue},${T.violet})`, display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontSize:13, fontWeight:700, flexShrink:0 }}>
              {(item.name||item.visitor_id||"?").charAt(0).toUpperCase()}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                <span style={{ fontSize:12, fontWeight:600, color:T.ink }}>{item.name || item.company || (item.visitor_id?.slice(0,8)+"...")}</span>
                <span style={{ fontSize:10, color:T.low }}>{devIcon(item.first_device)}</span>
              </div>
              <div style={{ fontSize:12, color:T.blue, marginTop:2 }}>
                <span style={{ color:T.low }}>viewed </span>{item.page}
              </div>
            </div>
            <div style={{ fontSize:11, color:T.low, flexShrink:0 }}>{item.created_at ? new Date(item.created_at).toLocaleTimeString() : "just now"}</div>
          </div>
        ))}
        {!history.length && (
          <div style={{ textAlign:"center", padding:"60px 20px" }}>
            <div style={{ fontSize:40, marginBottom:12 }}>👁</div>
            <div style={{ fontSize:16, fontWeight:700, color:T.ink, marginBottom:8 }}>Waiting for visitors...</div>
            <div style={{ fontSize:13, color:T.low }}>Embed the tracker snippet on your site to see live activity here.</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SEARCH ANALYTICS PAGE
// ═══════════════════════════════════════════════════════
function SearchAnalyticsPage() {
  const [data, setData]   = useState(null);
  const [days, setDays]   = useState(30);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/tracker/dashboard?days=${days}`)
      .then(r=>r.json()).then(d=>{ setData(d); setLoading(false); })
      .catch(()=>setLoading(false));
  }, [days]);

  const searches = data?.top_searches || [];
  const total    = searches.reduce((a,b)=>a+(+b.count),0);

  return (
    <div style={{ padding:"28px 32px", maxWidth:900 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Search Analytics</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>What visitors are searching for on your platform</div>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          {[7,30,90].map(d=>(
            <button key={d} onClick={()=>setDays(d)} style={{ padding:"5px 14px", borderRadius:7, fontSize:12, fontWeight:days===d?700:400, cursor:"pointer", background:days===d?T.violet:"transparent", color:days===d?"#fff":T.mid, border:`1px solid ${days===d?T.violet:T.line}` }}>{d}d</button>
          ))}
        </div>
      </div>

      {loading ? <div style={{ display:"flex", justifyContent:"center", padding:60 }}><Spinner /></div> : (
        <>
          <div style={{ display:"flex", gap:14, marginBottom:24 }}>
            {[
              ["Total Searches", total, T.violet],
              ["Unique Terms", searches.length, T.blue],
              ["Avg Results", searches.length ? Math.round(searches.reduce((a,b)=>a+(+b.avg_results),0)/searches.length) : 0, T.green],
            ].map(([l,v,c])=>(
              <div key={l} style={{ flex:1, background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"18px 22px" }}>
                <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:8 }}>{l}</div>
                <div style={{ fontSize:28, fontWeight:800, color:c, fontFamily:"'JetBrains Mono',monospace" }}>{v}</div>
              </div>
            ))}
          </div>

          <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:T.bg }}>{["#","Search Query","Count","Unique Searchers","Avg Results","Share"].map(h=>(
                  <th key={h} style={{ padding:"10px 16px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.06em", borderBottom:`1px solid ${T.line}` }}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {searches.map((s,i)=>{
                  const share = total ? Math.round((s.count/total)*100) : 0;
                  return (
                    <tr key={i} style={{ borderBottom:`1px solid ${T.line}` }}>
                      <td style={{ padding:"12px 16px", fontSize:11, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{i+1}</td>
                      <td style={{ padding:"12px 16px", fontSize:13, fontWeight:600, color:T.ink }}>{s.query}</td>
                      <td style={{ padding:"12px 16px", fontSize:13, fontWeight:700, color:T.violet, fontFamily:"'JetBrains Mono',monospace" }}>{s.count}</td>
                      <td style={{ padding:"12px 16px", fontSize:12, color:T.mid }}>{s.unique_searchers}</td>
                      <td style={{ padding:"12px 16px", fontSize:12, color:s.avg_results===0?T.red:T.mid }}>{s.avg_results} {s.avg_results===0&&<span style={{ fontSize:10, color:T.red, fontWeight:700 }}>NO RESULTS</span>}</td>
                      <td style={{ padding:"12px 16px" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <div style={{ flex:1, height:6, background:T.line, borderRadius:3 }}>
                            <div style={{ height:6, width:`${share}%`, background:T.violet, borderRadius:3 }} />
                          </div>
                          <span style={{ fontSize:11, color:T.low, width:30 }}>{share}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {!searches.length && <div style={{ padding:40, textAlign:"center", fontSize:13, color:T.low }}>No search data yet. The tracker captures all searches automatically.</div>}
          </div>
        </>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  EMAIL TRACKING PAGE
// ═══════════════════════════════════════════════════════
function EmailTrackingPage() {
  const [emails,  setEmails]  = useState([]);
  const [sel,     setSel]     = useState(null);
  const [days,    setDays]    = useState(30);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    setLoading(true);
    fetch(`/api/tracker/emails?days=${days}&limit=100`)
      .then(r=>r.json()).then(d=>{ setEmails(d.emails||[]); setLoading(false); })
      .catch(()=>setLoading(false));
  }, [days]);

  const sent      = emails.length;
  const opened    = emails.filter(e=>e.opens>0).length;
  const clicked   = emails.filter(e=>e.clicks>0).length;
  const openRate  = sent ? Math.round((opened/sent)*100) : 0;
  const ctr       = sent ? Math.round((clicked/sent)*100) : 0;

  const statusBadge = (e) => {
    if (e.clicks > 0)  return { label:"Clicked",  bg:T.greenL,  c:T.green  };
    if (e.opens  > 0)  return { label:"Opened",   bg:T.blueL,   c:T.blue   };
    return                    { label:"Sent",      bg:T.gray,    c:T.low    };
  };

  const devIcon = (d="") => d.includes("iPhone")||d.includes("iOS")||d.includes("Android")?"📱":d.includes("Mac")?"🍎":d.includes("Windows")?"🖥":"💻";

  return (
    <div style={{ padding:"28px 32px" }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Email Tracking</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Open rate, clicks, device, and per-link analytics</div>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          {[7,30,90].map(d=>(
            <button key={d} onClick={()=>setDays(d)} style={{ padding:"5px 14px", borderRadius:7, fontSize:12, fontWeight:days===d?700:400, cursor:"pointer", background:days===d?T.teal:"transparent", color:days===d?"#fff":T.mid, border:`1px solid ${days===d?T.teal:T.line}` }}>{d}d</button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div style={{ display:"flex", gap:14, marginBottom:24 }}>
        {[
          ["Emails Sent", sent, T.ink],
          ["Opened", opened, T.blue],
          ["Clicked", clicked, T.green],
          ["Open Rate", `${openRate}%`, openRate>20?T.green:openRate>10?T.amber:T.red],
          ["Click Rate", `${ctr}%`, ctr>5?T.green:ctr>2?T.amber:T.red],
        ].map(([l,v,c])=>(
          <div key={l} style={{ flex:1, background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"16px 18px" }}>
            <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:8 }}>{l}</div>
            <div style={{ fontSize:24, fontWeight:800, color:c, fontFamily:"'JetBrains Mono',monospace" }}>{v}</div>
          </div>
        ))}
      </div>

      {loading ? <div style={{ display:"flex", justifyContent:"center", padding:60 }}><Spinner /></div> : (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ background:T.bg }}>{["Recipient","Subject","Campaign","Status","Opens","Clicks","Device / Browser","Sent"].map(h=>(
                <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.06em", borderBottom:`1px solid ${T.line}`, whiteSpace:"nowrap" }}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {emails.map((e,i)=>{
                const st = statusBadge(e);
                return (
                  <tr key={i} onClick={()=>setSel(sel?.token===e.token?null:e)}
                    style={{ borderBottom:`1px solid ${T.line}`, cursor:"pointer", background:sel?.token===e.token?T.blueL:"transparent" }}>
                    <td style={{ padding:"11px 14px" }}>
                      <div style={{ fontSize:12, fontWeight:600, color:T.ink }}>{e.recipient_name || "—"}</div>
                      <div style={{ fontSize:11, color:T.low }}>{e.recipient_email}</div>
                    </td>
                    <td style={{ padding:"11px 14px", fontSize:12, color:T.ink, maxWidth:200, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.subject}</td>
                    <td style={{ padding:"11px 14px", fontSize:11, color:T.low }}>{e.campaign || "—"}</td>
                    <td style={{ padding:"11px 14px" }}>
                      <span style={{ fontSize:11, fontWeight:700, padding:"2px 8px", borderRadius:5, background:st.bg, color:st.c }}>{st.label}</span>
                    </td>
                    <td style={{ padding:"11px 14px", fontSize:13, fontWeight:700, color:e.opens>0?T.blue:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{e.opens}</td>
                    <td style={{ padding:"11px 14px", fontSize:13, fontWeight:700, color:e.clicks>0?T.green:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{e.clicks}</td>
                    <td style={{ padding:"11px 14px" }}>
                      {e.open_device ? (
                        <div style={{ fontSize:11, color:T.mid }}>{devIcon(e.open_device)} {e.open_device} · {e.open_browser}</div>
                      ) : <span style={{ fontSize:11, color:T.low }}>—</span>}
                    </td>
                    <td style={{ padding:"11px 14px", fontSize:11, color:T.low, whiteSpace:"nowrap" }}>{new Date(e.created_at).toLocaleDateString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!emails.length && <div style={{ padding:40, textAlign:"center", fontSize:13, color:T.low }}>No tracked emails yet. Use the /api/tracker/email/send endpoint to register emails for tracking.</div>}
        </div>
      )}

      {/* Detail panel */}
      {sel && (
        <div style={{ marginTop:20, background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 24px" }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>Email Detail — {sel.subject}</div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
            {[
              ["Sent to", sel.recipient_email],
              ["First Opened", sel.first_opened_at ? new Date(sel.first_opened_at).toLocaleString() : "Not opened"],
              ["Last Opened", sel.last_opened_at ? new Date(sel.last_opened_at).toLocaleString() : "—"],
              ["First Click", sel.first_clicked_at ? new Date(sel.first_clicked_at).toLocaleString() : "Not clicked"],
              ["Open Device", sel.open_device || "—"],
              ["Open Browser", sel.open_browser || "—"],
              ["Total Opens", sel.opens],
              ["Total Clicks", sel.clicks],
            ].map(([l,v])=>(
              <div key={l} style={{ padding:"10px 14px", background:T.bg, borderRadius:8 }}>
                <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:4 }}>{l}</div>
                <div style={{ fontSize:12, fontWeight:600, color:T.ink }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  FORM ANALYTICS PAGE
// ═══════════════════════════════════════════════════════
function FormAnalyticsPage() {
  const [data,    setData]    = useState(null);
  const [days,    setDays]    = useState(30);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    setLoading(true);
    fetch(`/api/tracker/dashboard?days=${days}`)
      .then(r=>r.json()).then(d=>{ setData(d); setLoading(false); })
      .catch(()=>setLoading(false));
  }, [days]);

  const forms = data?.form_abandons || [];

  return (
    <div style={{ padding:"28px 32px", maxWidth:900 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Form Analytics</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Track where visitors start, stall, and abandon your forms</div>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          {[7,30,90].map(d=>(
            <button key={d} onClick={()=>setDays(d)} style={{ padding:"5px 14px", borderRadius:7, fontSize:12, fontWeight:days===d?700:400, cursor:"pointer", background:days===d?T.amber:"transparent", color:days===d?"#fff":T.mid, border:`1px solid ${days===d?T.amber:T.line}` }}>{d}d</button>
          ))}
        </div>
      </div>

      {loading ? <div style={{ display:"flex", justifyContent:"center", padding:60 }}><Spinner /></div> : (
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          {forms.map((f,i)=>{
            const convRate = f.started>0 ? Math.round((f.submitted/f.started)*100) : 0;
            const abandonRate = +f.abandon_rate || 0;
            return (
              <div key={i} style={{ background:T.card, border:`1px solid ${abandonRate>60?T.red:T.line}`, borderRadius:14, padding:"20px 24px" }}>
                <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
                  <div>
                    <div style={{ fontSize:15, fontWeight:700, color:T.ink }}>{f.form_name}</div>
                    <div style={{ fontSize:12, color:T.low }}>{f.page}</div>
                  </div>
                  <span style={{ fontSize:12, fontWeight:700, padding:"4px 12px", borderRadius:8, background:abandonRate>60?T.redL:abandonRate>30?T.amberL:T.greenL, color:abandonRate>60?T.red:abandonRate>30?T.amber:T.green }}>
                    {abandonRate}% abandon rate
                  </span>
                </div>

                {/* Funnel bars */}
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:16 }}>
                  {[
                    ["Started", f.started, T.blue, "100%"],
                    ["Submitted", f.submitted, T.green, `${convRate}%`],
                    ["Abandoned", f.abandoned, T.red, `${abandonRate}%`],
                  ].map(([l,v,c,pct])=>(
                    <div key={l}>
                      <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:6 }}>
                        <span style={{ color:T.low, fontWeight:600, textTransform:"uppercase", fontSize:10, letterSpacing:"0.06em" }}>{l}</span>
                        <span style={{ fontWeight:800, color:c, fontFamily:"'JetBrains Mono',monospace" }}>{v}</span>
                      </div>
                      <div style={{ height:8, background:T.line, borderRadius:4 }}>
                        <div style={{ height:8, width:pct, background:c, borderRadius:4, transition:"width 0.4s ease" }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {!forms.length && <EmptyState icon="◫" title="No form data yet" desc="Add forms to your site with the ArgiFlow tracker snippet embedded. Form interactions are tracked automatically." />}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  HEATMAP PAGE (click density visualization)
// ═══════════════════════════════════════════════════════
function HeatmapPage() {
  const [clicks, setClicks] = useState([]);
  const [pages,  setPages]  = useState([]);
  const [selPage,setSelPage]= useState("");
  const [days,   setDays]   = useState(7);

  useEffect(()=>{
    fetch(`/api/tracker/dashboard?days=${days}`)
      .then(r=>r.json())
      .then(d=>{
        const pg = (d.top_pages||[]).map(p=>p.page);
        setPages(pg);
        if (pg.length && !selPage) setSelPage(pg[0]);
      });
  }, [days]);

  useEffect(()=>{
    if (!selPage) return;
    fetch(`/api/tracker/visitors?days=${days}&limit=500`)
      .then(r=>r.json()).then(()=>{});
    // Fetch clicks for selected page
    fetch(`/api/tracker/dashboard?days=${days}`)
      .then(r=>r.json())
      .then(d=>{ setClicks(d.rage_clicks||[]); });
  }, [selPage, days]);

  return (
    <div style={{ padding:"28px 32px", maxWidth:1000 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Click Heatmap</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Element-level click density and rage click detection</div>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          {[7,30].map(d=>(
            <button key={d} onClick={()=>setDays(d)} style={{ padding:"5px 14px", borderRadius:7, fontSize:12, fontWeight:days===d?700:400, cursor:"pointer", background:days===d?T.red:"transparent", color:days===d?"#fff":T.mid, border:`1px solid ${days===d?T.red:T.line}` }}>{d}d</button>
          ))}
        </div>
      </div>

      {/* Page selector */}
      {pages.length > 0 && (
        <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
          {pages.slice(0,10).map(pg=>(
            <button key={pg} onClick={()=>setSelPage(pg)} style={{ padding:"5px 12px", borderRadius:7, fontSize:12, fontWeight:selPage===pg?700:400, cursor:"pointer", background:selPage===pg?T.red:"transparent", color:selPage===pg?"#fff":T.mid, border:`1px solid ${selPage===pg?T.red:T.line}` }}>{pg}</button>
          ))}
        </div>
      )}

      {/* Rage clicks list */}
      <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 24px", marginBottom:20 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink }}>Rage Clicks — Frustrated User Elements</div>
          <span style={{ fontSize:11, padding:"2px 8px", borderRadius:5, background:T.redL, color:T.red, fontWeight:700 }}>UX Bugs</span>
        </div>
        {clicks.length ? (
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>{["Page","Element","ID","Rage Count","Action Needed"].map(h=>(
                <th key={h} style={{ padding:"8px 12px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.06em", borderBottom:`1px solid ${T.line}` }}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {clicks.map((r,i)=>(
                <tr key={i} style={{ borderBottom:`1px solid ${T.line}` }}>
                  <td style={{ padding:"10px 12px", fontSize:12, color:T.low }}>{r.page}</td>
                  <td style={{ padding:"10px 12px", fontSize:12, fontWeight:600, color:T.ink }}>{r.element_text||"unknown"}</td>
                  <td style={{ padding:"10px 12px", fontSize:11, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{r.element_id||"—"}</td>
                  <td style={{ padding:"10px 12px" }}>
                    <span style={{ fontSize:13, fontWeight:800, color:T.red, fontFamily:"'JetBrains Mono',monospace" }}>{r.rage_count}×</span>
                  </td>
                  <td style={{ padding:"10px 12px" }}>
                    <span style={{ fontSize:11, color:T.amber }}>
                      {r.rage_count > 10 ? "🔴 Fix immediately" : r.rage_count > 5 ? "🟡 Review this element" : "🟢 Monitor"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div style={{ textAlign:"center", padding:"30px 20px" }}>
            <div style={{ fontSize:13, color:T.green, fontWeight:600 }}>✅ No rage clicks detected — your UI is working well!</div>
            <div style={{ fontSize:12, color:T.low, marginTop:6 }}>Rage clicks appear when users click the same element 3+ times in under 1 second.</div>
          </div>
        )}
      </div>

      {/* Embed instructions */}
      <div style={{ background:T.blueL, border:"1px solid rgba(75,108,247,0.2)", borderRadius:14, padding:"20px 24px" }}>
        <div style={{ fontSize:13, fontWeight:700, color:T.blue, marginBottom:10 }}>📋 Embed Tracker on Any Site</div>
        <div style={{ fontSize:12, color:T.mid, marginBottom:10 }}>Add this one line to the {"<head>"} of any website to start collecting click, scroll, and heatmap data:</div>
        <div style={{ background:T.card, borderRadius:8, padding:"12px 16px", fontFamily:"'JetBrains Mono',monospace", fontSize:12, color:T.ink, border:`1px solid ${T.line}` }}>
          {'<script src="https://your-argiflow.app/argiflow-tracker.js" data-host="https://your-argiflow.app"></script>'}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SETTINGS PAGE
// ═══════════════════════════════════════════════════════
function SettingsPage({ user }) {
  const [saved, setSaved] = useState(false);
  const [name,  setName]  = useState(user?.name || "");
  const [org,   setOrg]   = useState(user?.org  || "");

  const save = () => { setSaved(true); setTimeout(()=>setSaved(false), 2500); };

  return (
    <div style={{ padding:"28px 32px", maxWidth:680 }}>
      <div style={{ fontSize:22, fontWeight:800, color:T.ink, marginBottom:6 }}>Settings</div>
      <div style={{ fontSize:13, color:T.low, marginBottom:28 }}>Manage your account, notifications, and platform preferences</div>

      {/* Profile */}
      <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"22px 24px", marginBottom:18 }}>
        <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>Profile</div>
        {[["Full Name", name, setName, "Your name"],["Organization", org, setOrg, "Your company or brand"]].map(([l,v,set,ph])=>(
          <div key={l} style={{ marginBottom:14 }}>
            <div style={{ fontSize:11, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:6 }}>{l}</div>
            <input value={v} onChange={e=>set(e.target.value)} placeholder={ph}
              style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
          </div>
        ))}
        <button onClick={save} style={{ padding:"9px 22px", borderRadius:9, background:T.blue, color:"#fff", fontSize:13, fontWeight:700, border:"none", cursor:"pointer" }}>
          {saved ? "✓ Saved!" : "Save Changes"}
        </button>
      </div>

      {/* Tracker embed */}
      <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"22px 24px", marginBottom:18 }}>
        <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:8 }}>Tracker Embed Code</div>
        <div style={{ fontSize:12, color:T.low, marginBottom:12 }}>Copy and paste into the {"<head>"} of any website you want to track:</div>
        <div style={{ background:T.bg, border:`1px solid ${T.line}`, borderRadius:8, padding:"12px 16px", fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:T.ink, wordBreak:"break-all" }}>
          {'<script src="https://your-argiflow.app/argiflow-tracker.js" data-host="https://your-argiflow.app"></script>'}
        </div>
      </div>

      {/* Danger zone */}
      <div style={{ background:T.redL, border:`1px solid rgba(228,68,68,0.2)`, borderRadius:14, padding:"22px 24px" }}>
        <div style={{ fontSize:14, fontWeight:700, color:T.red, marginBottom:8 }}>Danger Zone</div>
        <div style={{ fontSize:12, color:T.mid, marginBottom:14 }}>Permanently delete all tracking data or reset your account. These actions cannot be undone.</div>
        <button style={{ padding:"8px 18px", borderRadius:9, background:"transparent", color:T.red, fontSize:13, fontWeight:700, border:`1px solid ${T.red}`, cursor:"pointer" }}>
          Clear Tracking Data
        </button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  ARIA CHAT WIDGET — Floating AI Sales Rep
//  Embeds on argiflow.co — promotes + sells ArgiFlow 24/7
//  Add to any page: <AriaWidget />
// ═══════════════════════════════════════════════════════
export function AriaWidget({ position = "bottom-right" }) {
  const [open,     setOpen]     = useState(false);
  const [messages, setMessages] = useState([]);
  const [input,    setInput]    = useState("");
  const [loading,  setLoading]  = useState(false);
  const [greeting, setGreeting] = useState("");
  const [pulse,    setPulse]    = useState(true);
  const bottomRef = useRef(null);
  const inputRef  = useRef(null);

  // Load greeting on mount
  useEffect(() => {
    fetch("/api/chatbot/greeting")
      .then(r => r.json())
      .then(d => setGreeting(d.greeting || "Hi! I'm Aria, ArgiFlow's AI. How can I help?"))
      .catch(() => setGreeting("Hi! I'm Aria, ArgiFlow's AI. How can I help?"));
    // Stop pulse after 8 seconds
    const t = setTimeout(() => setPulse(false), 8000);
    return () => clearTimeout(t);
  }, []);

  // Auto-add greeting as first message when chat opens
  useEffect(() => {
    if (open && messages.length === 0 && greeting) {
      setMessages([{ role: "assistant", content: greeting, ts: Date.now() }]);
    }
    if (open) setTimeout(() => inputRef.current?.focus(), 100);
  }, [open, greeting]);

  // Scroll to bottom on new message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");

    const newMsg = { role: "user", content: text, ts: Date.now() };
    const updated = [...messages, newMsg];
    setMessages(updated);
    setLoading(true);

    try {
      const res = await fetch("/api/chatbot/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: updated.map(m => ({ role: m.role, content: m.content })) }),
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: "assistant", content: data.reply || "Sorry, I had a hiccup. Try again!", ts: Date.now() }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Connection issue. You can reach us at partnerships@argilette.co", ts: Date.now() }]);
    } finally {
      setLoading(false);
    }
  };

  const pos = position === "bottom-left"
    ? { bottom: 24, left: 24 }
    : { bottom: 24, right: 24 };

  const chatPos = position === "bottom-left"
    ? { bottom: 88, left: 24 }
    : { bottom: 88, right: 24 };

  return (
    <>
      {/* Chat window */}
      {open && (
        <div style={{
          position: "fixed", ...chatPos, zIndex: 9999,
          width: 360, height: 520,
          background: "#fff", borderRadius: 20,
          boxShadow: "0 20px 60px rgba(75,108,247,0.18), 0 4px 16px rgba(0,0,0,0.1)",
          display: "flex", flexDirection: "column",
          border: "1px solid rgba(75,108,247,0.15)",
          animation: "fadein 0.25s ease",
        }}>
          {/* Header */}
          <div style={{
            padding: "14px 18px", borderRadius: "20px 20px 0 0",
            background: "linear-gradient(135deg, #4B6CF7, #7B5BFB)",
            display: "flex", alignItems: "center", gap: 12, flexShrink: 0,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: "50%",
              background: "rgba(255,255,255,0.2)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, flexShrink: 0,
            }}>◉</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>Aria</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.75)" }}>ArgiFlow AI · Online</div>
            </div>
            <button onClick={() => setOpen(false)} style={{
              background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 8,
              color: "#fff", cursor: "pointer", padding: "4px 8px", fontSize: 14,
            }}>✕</button>
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflow: "auto", padding: "16px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
            {messages.map((m, i) => (
              <div key={i} style={{
                display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start",
              }}>
                {m.role === "assistant" && (
                  <div style={{
                    width: 26, height: 26, borderRadius: "50%", flexShrink: 0,
                    background: "linear-gradient(135deg,#4B6CF7,#7B5BFB)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 10, color: "#fff", marginRight: 8, marginTop: 2,
                  }}>A</div>
                )}
                <div style={{
                  maxWidth: "78%", padding: "10px 14px", borderRadius: m.role === "user" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                  background: m.role === "user" ? "linear-gradient(135deg,#4B6CF7,#7B5BFB)" : "#F4F6FB",
                  color: m.role === "user" ? "#fff" : "#161E36",
                  fontSize: 13, lineHeight: 1.5,
                }}>
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 26, height: 26, borderRadius: "50%", background: "linear-gradient(135deg,#4B6CF7,#7B5BFB)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#fff" }}>A</div>
                <div style={{ background: "#F4F6FB", borderRadius: "16px 16px 16px 4px", padding: "10px 16px" }}>
                  <div style={{ display: "flex", gap: 4 }}>
                    {[0, 0.2, 0.4].map((d, i) => (
                      <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#8E9BB8", animation: `pulse 1.2s ${d}s infinite` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Suggested quick replies */}
          {messages.length <= 1 && !loading && (
            <div style={{ padding: "0 14px 10px", display: "flex", gap: 6, flexWrap: "wrap" }}>
              {["How does it work?", "Pricing?", "Demo please", "Compare to GHL"].map(q => (
                <button key={q} onClick={() => { setInput(q); setTimeout(send, 50); }}
                  style={{ padding: "5px 10px", borderRadius: 20, fontSize: 11, cursor: "pointer", background: "#EEF1FF", color: "#4B6CF7", border: "1px solid rgba(75,108,247,0.2)", fontWeight: 600 }}>
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div style={{
            padding: "10px 14px 14px", borderTop: "1px solid rgba(90,110,180,0.12)",
            display: "flex", gap: 8, flexShrink: 0,
          }}>
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && send()}
              placeholder="Ask anything about ArgiFlow..."
              style={{
                flex: 1, padding: "9px 13px", borderRadius: 12,
                border: "1px solid rgba(90,110,180,0.2)", fontSize: 13,
                background: "#F4F6FB", color: "#161E36", outline: "none",
              }}
            />
            <button onClick={send} disabled={loading || !input.trim()}
              style={{
                width: 40, height: 40, borderRadius: 12, border: "none", cursor: "pointer",
                background: input.trim() ? "linear-gradient(135deg,#4B6CF7,#7B5BFB)" : "#E6EAF6",
                color: input.trim() ? "#fff" : "#8E9BB8", fontSize: 16, flexShrink: 0,
                transition: "all 0.15s",
              }}>→</button>
          </div>

          {/* Powered by */}
          <div style={{ textAlign: "center", padding: "0 14px 10px", fontSize: 10, color: "#8E9BB8" }}>
            Powered by <span style={{ fontWeight: 700, color: "#4B6CF7" }}>ArgiFlow AI</span> · argiflow.co
          </div>
        </div>
      )}

      {/* Floating button */}
      <button onClick={() => setOpen(o => !o)} style={{
        position: "fixed", ...pos, zIndex: 10000,
        width: 58, height: 58, borderRadius: "50%", border: "none", cursor: "pointer",
        background: "linear-gradient(135deg, #4B6CF7, #7B5BFB)",
        boxShadow: "0 6px 24px rgba(75,108,247,0.45)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 22, color: "#fff",
        transition: "transform 0.2s ease, box-shadow 0.2s ease",
      }}>
        {open ? "✕" : "◉"}
        {/* Pulse ring when closed */}
        {!open && pulse && (
          <div style={{
            position: "absolute", inset: -4, borderRadius: "50%",
            border: "2px solid rgba(75,108,247,0.5)",
            animation: "pulse 1.8s infinite",
            pointerEvents: "none",
          }} />
        )}
        {/* Unread dot when closed */}
        {!open && (
          <div style={{
            position: "absolute", top: 2, right: 2, width: 14, height: 14,
            borderRadius: "50%", background: "#0DAD74",
            border: "2px solid #fff",
            fontSize: 8, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
            fontWeight: 800,
          }}>1</div>
        )}
      </button>
    </>
  );
}

// ═══════════════════════════════════════════════════════
//  SEQUENCES PAGE  — email drip chains powered by email-writer agent
// ═══════════════════════════════════════════════════════
function SequencesPage({ credits, deductCredits, llmConfig }) {
  const [sequences, setSequences] = useState([
    { id:1, name:"B2B SaaS Outreach", steps:5, active:true,  sent:284, opens:41, replies:18, created:"2025-01-12" },
    { id:2, name:"Agency Follow-Up",  steps:3, active:false, sent:97,  opens:22, replies:9,  created:"2025-01-28" },
    { id:3, name:"African Market — FR",steps:4,active:true,  sent:63,  opens:19, replies:11, created:"2025-02-04" },
  ]);
  const [view, setView]   = useState("list");   // list | builder | preview
  const [sel,  setSel]    = useState(null);
  const [building, setBuilding] = useState(false);

  // builder state
  const [seqName, setSeqName]   = useState("");
  const [industry, setIndustry] = useState("");
  const [offer, setOffer]       = useState("");
  const [steps, setSteps]       = useState(3);
  const [generatedSteps, setGeneratedSteps] = useState([]);
  const [genLoading, setGenLoading] = useState(false);

  const generate = async () => {
    if (!llmConfig) return alert("Configure an AI provider first (Settings → AI Providers)");
    if (!industry || !offer) return alert("Fill in industry and offer first");
    setGenLoading(true);
    try {
      const res = await fetch("/api/agents/email-writer/run", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          prompt: `Create a ${steps}-step cold email sequence for a ${industry} business offering: ${offer}. 
          Format each email as JSON: {subject, body, day, tone}. Return a JSON array only.`,
          context: { industry, offer, steps }
        })
      });
      const data = await res.json();
      if (data.credits_used) deductCredits(data.credits_used);
      try {
        const parsed = JSON.parse(data.result.replace(/```json|```/g, "").trim());
        setGeneratedSteps(Array.isArray(parsed) ? parsed : []);
      } catch { setGeneratedSteps([]); }
    } catch(e) { console.error(e); }
    setGenLoading(false);
  };

  const save = () => {
    const ns = { id: Date.now(), name: seqName || "New Sequence", steps: generatedSteps.length || steps,
      active: false, sent:0, opens:0, replies:0, created: new Date().toISOString().slice(0,10) };
    setSequences(p => [ns, ...p]);
    setView("list"); setGeneratedSteps([]); setSeqName(""); setIndustry(""); setOffer("");
  };

  const metricBadge = (label, val, color) => (
    <div style={{ textAlign:"center" }}>
      <div style={{ fontSize:18, fontWeight:800, color, fontFamily:"'JetBrains Mono',monospace" }}>{val}</div>
      <div style={{ fontSize:10, color:T.low, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.06em" }}>{label}</div>
    </div>
  );

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Email Sequences</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>AI-generated multi-step outreach sequences · powered by Email Writer agent</div>
        </div>
        <Btn variant="blue" onClick={() => setView("builder")}>+ New Sequence</Btn>
      </div>

      {view === "list" && (
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {sequences.map(s => (
            <div key={s.id} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"18px 22px" }}>
              <div style={{ display:"flex", alignItems:"center", gap:14 }}>
                <div style={{ flex:1 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    <span style={{ fontSize:15, fontWeight:700, color:T.ink }}>{s.name}</span>
                    <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:5,
                      background: s.active ? T.greenL : T.gray, color: s.active ? T.green : T.low }}>
                      {s.active ? "ACTIVE" : "PAUSED"}
                    </span>
                  </div>
                  <div style={{ fontSize:12, color:T.low, marginTop:3 }}>{s.steps} steps · created {s.created}</div>
                </div>
                <div style={{ display:"flex", gap:28 }}>
                  {metricBadge("Sent",    s.sent,    T.ink)}
                  {metricBadge("Opens",   `${s.sent ? Math.round(s.opens/s.sent*100) : 0}%`, T.blue)}
                  {metricBadge("Replies", `${s.sent ? Math.round(s.replies/s.sent*100) : 0}%`, T.green)}
                </div>
                <div style={{ display:"flex", gap:8 }}>
                  <Btn sx={{ fontSize:11, padding:"5px 12px" }} onClick={() => { setSel(s); setView("preview"); }}>View</Btn>
                  <Btn variant={s.active?"amber":"blue"} sx={{ fontSize:11, padding:"5px 12px" }}
                    onClick={() => setSequences(p => p.map(x => x.id===s.id ? {...x, active:!x.active} : x))}>
                    {s.active ? "Pause" : "Activate"}
                  </Btn>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {view === "builder" && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"24px 28px" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
            <div style={{ fontSize:16, fontWeight:700, color:T.ink }}>Build New Sequence</div>
            <button onClick={() => setView("list")} style={{ border:"none", background:"transparent", color:T.low, cursor:"pointer", fontSize:13 }}>✕ Cancel</button>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:16 }}>
            {[["Sequence Name", seqName, setSeqName, "e.g. Agency Cold Outreach Q2"],
              ["Target Industry", industry, setIndustry, "e.g. Healthcare, Real Estate, SaaS"],
              ["Your Offer / Value Prop", offer, setOffer, "e.g. AI lead gen platform that replaces ZoomInfo"]
            ].map(([l,v,set,ph]) => (
              <div key={l} style={{ gridColumn: l.includes("Offer") ? "1/-1" : "auto" }}>
                <FLabel>{l}</FLabel>
                <input value={v} onChange={e => set(e.target.value)} placeholder={ph}
                  style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
              </div>
            ))}
          </div>
          <div style={{ marginBottom:20 }}>
            <FLabel>Number of Steps</FLabel>
            <div style={{ display:"flex", gap:8 }}>
              {[3,4,5,7].map(n => (
                <button key={n} onClick={() => setSteps(n)}
                  style={{ padding:"6px 16px", borderRadius:8, border:`1px solid ${steps===n ? T.blue : T.line}`,
                    background: steps===n ? T.blueL : "transparent", color: steps===n ? T.blue : T.mid,
                    fontWeight: steps===n ? 700 : 400, cursor:"pointer", fontSize:13 }}>{n} emails</button>
              ))}
            </div>
          </div>
          <Btn variant="blue" onClick={generate} disabled={genLoading}>
            {genLoading ? <><Spinner size={13} /> Generating...</> : `⚡ Generate ${steps}-Step Sequence with AI`}
          </Btn>

          {generatedSteps.length > 0 && (
            <div style={{ marginTop:24 }}>
              <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:14 }}>Generated Sequence — {generatedSteps.length} emails</div>
              {generatedSteps.map((step, i) => (
                <div key={i} style={{ marginBottom:12, padding:"14px 16px", background:T.bg, borderRadius:10, border:`1px solid ${T.line}` }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
                    <span style={{ fontSize:11, fontWeight:700, color:T.blue, background:T.blueL, padding:"2px 8px", borderRadius:5 }}>Day {step.day || i*3+1}</span>
                    <span style={{ fontSize:13, fontWeight:600, color:T.ink }}>{step.subject}</span>
                    {step.tone && <span style={{ fontSize:10, color:T.low, background:T.gray, padding:"2px 6px", borderRadius:4 }}>{step.tone}</span>}
                  </div>
                  <div style={{ fontSize:12, color:T.mid, lineHeight:1.6, whiteSpace:"pre-wrap" }}>{step.body?.slice(0,200)}{step.body?.length > 200 ? "..." : ""}</div>
                </div>
              ))}
              <div style={{ display:"flex", gap:10, marginTop:16 }}>
                <Btn variant="blue" onClick={save}>Save Sequence</Btn>
                <Btn onClick={generate}>Regenerate</Btn>
              </div>
            </div>
          )}
        </div>
      )}

      {view === "preview" && sel && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"24px 28px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:20 }}>
            <div style={{ fontSize:16, fontWeight:700, color:T.ink }}>{sel.name}</div>
            <button onClick={() => setView("list")} style={{ border:"none", background:"transparent", color:T.low, cursor:"pointer", fontSize:13 }}>← Back</button>
          </div>
          <div style={{ display:"flex", gap:20 }}>
            {[["Total Sent", sel.sent, T.ink], ["Open Rate", `${sel.sent?Math.round(sel.opens/sel.sent*100):0}%`, T.blue],
              ["Reply Rate", `${sel.sent?Math.round(sel.replies/sel.sent*100):0}%`, T.green],
              ["Steps", sel.steps, T.violet]].map(([l,v,c]) => (
              <div key={l} style={{ flex:1, background:T.bg, border:`1px solid ${T.line}`, borderRadius:10, padding:"14px 16px" }}>
                <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:6 }}>{l}</div>
                <div style={{ fontSize:22, fontWeight:800, color:c, fontFamily:"'JetBrains Mono',monospace" }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ marginTop:20 }}>
            {Array.from({length: sel.steps}, (_,i) => (
              <div key={i} style={{ display:"flex", gap:14, marginBottom:14, alignItems:"flex-start" }}>
                <div style={{ width:32, height:32, borderRadius:"50%", background: i<2 ? T.blue : T.line,
                  display:"flex", alignItems:"center", justifyContent:"center", color: i<2 ? "#fff" : T.low,
                  fontSize:13, fontWeight:700, flexShrink:0 }}>{i+1}</div>
                <div style={{ flex:1, padding:"12px 14px", background:T.bg, borderRadius:10, border:`1px solid ${T.line}` }}>
                  <div style={{ fontSize:12, fontWeight:600, color:T.ink }}>Email {i+1} · Day {i===0?1:i*3+1}</div>
                  <div style={{ fontSize:11, color:T.low, marginTop:3 }}>{i===0?"Initial outreach":i===1?"Follow-up (no reply)":i===2?"Value-add touch":i===3?"Case study / proof":"Final breakup"}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  FORUM PROSPECTOR PAGE  — calls forum-prospector agent
// ═══════════════════════════════════════════════════════
function ForumProspectorPage({ credits, deductCredits, llmConfig }) {
  const [platform, setPlatform] = useState("reddit");
  const [niche,    setNiche]    = useState("");
  const [intent,   setIntent]   = useState("");
  const [result,   setResult]   = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [history,  setHistory]  = useState([]);

  const platforms = [
    { id:"reddit",   label:"Reddit",         icon:"🟠" },
    { id:"linkedin", label:"LinkedIn Groups", icon:"🔵" },
    { id:"facebook", label:"Facebook Groups", icon:"🔷" },
    { id:"twitter",  label:"Twitter/X",       icon:"⬛" },
    { id:"slack",    label:"Slack Channels",  icon:"🟣" },
    { id:"discord",  label:"Discord",         icon:"💜" },
  ];

  const run = async () => {
    if (!llmConfig) return alert("Configure an AI provider first");
    if (!niche) return alert("Enter your target niche");
    setLoading(true); setResult(null);
    try {
      const res = await fetch("/api/agents/forum-prospector/run", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ prompt: `Find in-market buyers on ${platform} for: ${niche}. Buyer intent: ${intent || "ready to buy"}`, context: { platform, niche, intent } })
      });
      const data = await res.json();
      if (data.credits_used) deductCredits(data.credits_used);
      setResult(data.result);
      setHistory(p => [{ platform, niche, result: data.result, ts: new Date().toLocaleTimeString() }, ...p.slice(0,9)]);
    } catch(e) { console.error(e); }
    setLoading(false);
  };

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ marginBottom:24 }}>
        <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Forum Prospector</div>
        <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Find in-market buyers in communities — Reddit, LinkedIn Groups, Facebook, Twitter, Slack, Discord</div>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"360px 1fr", gap:20 }}>
        {/* Controls */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ marginBottom:16 }}>
            <FLabel>Platform</FLabel>
            <div style={{ display:"flex", flexWrap:"wrap", gap:7 }}>
              {platforms.map(p => (
                <button key={p.id} onClick={() => setPlatform(p.id)}
                  style={{ padding:"6px 12px", borderRadius:8, border:`1px solid ${platform===p.id ? T.blue : T.line}`,
                    background: platform===p.id ? T.blueL : "transparent",
                    color: platform===p.id ? T.blue : T.mid, fontWeight: platform===p.id ? 700 : 400,
                    cursor:"pointer", fontSize:12 }}>{p.icon} {p.label}</button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom:14 }}>
            <FLabel>Your Niche / Product</FLabel>
            <textarea value={niche} onChange={e => setNiche(e.target.value)} rows={3}
              placeholder="e.g. AI sales automation for B2B SaaS companies"
              style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none", resize:"vertical" }} />
          </div>
          <div style={{ marginBottom:18 }}>
            <FLabel>Buyer Intent Signal</FLabel>
            <input value={intent} onChange={e => setIntent(e.target.value)}
              placeholder="e.g. frustrated with ZoomInfo pricing"
              style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
          </div>
          <Btn variant="blue" onClick={run} disabled={loading} sx={{ width:"100%" }}>
            {loading ? <><Spinner size={13} /> Scanning...</> : "⚡ Find Buyers"}
          </Btn>
          <div style={{ fontSize:11, color:T.low, marginTop:8, textAlign:"center" }}>50 credits per scan</div>

          {/* History */}
          {history.length > 0 && (
            <div style={{ marginTop:20 }}>
              <FLabel>Recent Scans</FLabel>
              {history.map((h,i) => (
                <div key={i} onClick={() => setResult(h.result)}
                  style={{ padding:"8px 10px", background:T.bg, borderRadius:8, marginBottom:6, cursor:"pointer", border:`1px solid ${T.line}` }}>
                  <div style={{ fontSize:12, fontWeight:600, color:T.ink }}>{h.niche.slice(0,40)}{h.niche.length>40?"...":""}</div>
                  <div style={{ fontSize:10, color:T.low }}>{h.platform} · {h.ts}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Results */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px", minHeight:400 }}>
          {loading && <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", height:300, gap:16 }}>
            <Spinner size={32} />
            <div style={{ fontSize:13, color:T.low }}>Scanning {platforms.find(p=>p.id===platform)?.label}...</div>
          </div>}

          {!loading && !result && <EmptyState icon="⬡" title="Ready to prospect"
            desc="Select a platform, describe your niche, and the AI will find communities and posts where your buyers are active." />}

          {result && !loading && (
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
                <span style={{ fontSize:14, fontWeight:700, color:T.ink }}>Results</span>
                <span style={{ fontSize:11, padding:"2px 8px", borderRadius:5, background:T.greenL, color:T.green, fontWeight:700 }}>
                  {platforms.find(p=>p.id===platform)?.icon} {platforms.find(p=>p.id===platform)?.label}
                </span>
                <button onClick={() => navigator.clipboard.writeText(result)}
                  style={{ marginLeft:"auto", padding:"4px 10px", borderRadius:6, border:`1px solid ${T.line}`, background:"transparent", cursor:"pointer", fontSize:11, color:T.mid }}>
                  Copy
                </button>
              </div>
              <div style={{ fontSize:13, color:T.ink, lineHeight:1.8, whiteSpace:"pre-wrap", background:T.bg, borderRadius:10, padding:"16px 18px", border:`1px solid ${T.line}` }}>
                {result}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  LANDING PAGES  — uses /api/sites
// ═══════════════════════════════════════════════════════
function LandingPagesPage() {
  const [sites,   setSites]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [name,    setName]    = useState("");
  const [type,    setType]    = useState("landing");
  const [creating,setCreating]= useState(false);

  useEffect(() => {
    fetch("/api/sites").then(r=>r.json()).then(d => { setSites(d.sites||[]); setLoading(false); }).catch(()=>setLoading(false));
  }, []);

  const create = async () => {
    if (!name) return;
    setCreating(true);
    try {
      const res = await fetch("/api/sites", { method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ name, type, prompt:`Create a ${type} page for ${name}` }) });
      const d = await res.json();
      setSites(p => [d.site||{ id:Date.now(), name, type, status:"draft", created_at:new Date().toISOString() }, ...p]);
      setShowNew(false); setName("");
    } catch(e) {}
    setCreating(false);
  };

  const typeColors = { landing:T.blue, sales:T.violet, squeeze:T.green, webinar:T.amber, portfolio:T.teal };

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Landing Pages</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>AI-generated pages · hosted and published from ArgiFlow</div>
        </div>
        <Btn variant="blue" onClick={() => setShowNew(true)}>+ New Page</Btn>
      </div>

      {showNew && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 24px", marginBottom:20 }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:14 }}>New Landing Page</div>
          <div style={{ display:"flex", gap:12, marginBottom:14 }}>
            <div style={{ flex:1 }}>
              <FLabel>Page Name</FLabel>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. ArgiFlow Free Trial"
                style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
            </div>
            <div style={{ flex:1 }}>
              <FLabel>Page Type</FLabel>
              <select value={type} onChange={e => setType(e.target.value)}
                style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }}>
                {["landing","sales","squeeze","webinar","portfolio","coming-soon"].map(t => (
                  <option key={t} value={t}>{t.charAt(0).toUpperCase()+t.slice(1)} Page</option>
                ))}
              </select>
            </div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <Btn variant="blue" onClick={create} disabled={creating}>{creating ? "Creating..." : "Create Page"}</Btn>
            <Btn onClick={() => setShowNew(false)}>Cancel</Btn>
          </div>
        </div>
      )}

      {loading ? <div style={{ display:"flex", justifyContent:"center", padding:60 }}><Spinner /></div> : (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(280px,1fr))", gap:16 }}>
          {sites.filter(s => s.type !== "full-site").map(s => (
            <div key={s.id} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden" }}>
              <div style={{ height:120, background:`linear-gradient(135deg, ${typeColors[s.type]||T.blue}22, ${T.violet}22)`,
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:32 }}>
                {s.type==="landing"?"🚀":s.type==="sales"?"💰":s.type==="webinar"?"🎥":s.type==="portfolio"?"🎨":"📄"}
              </div>
              <div style={{ padding:"14px 16px" }}>
                <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:4 }}>{s.name}</div>
                <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
                  <span style={{ fontSize:10, fontWeight:700, padding:"2px 7px", borderRadius:4,
                    background: s.status==="published" ? T.greenL : T.amberL,
                    color: s.status==="published" ? T.green : T.amber }}>
                    {(s.status||"draft").toUpperCase()}
                  </span>
                  <span style={{ fontSize:11, color:T.low }}>{s.type}</span>
                </div>
                <div style={{ display:"flex", gap:8 }}>
                  <Btn sx={{ flex:1, fontSize:11, padding:"5px 0" }}>Edit</Btn>
                  <Btn variant="blue" sx={{ flex:1, fontSize:11, padding:"5px 0" }}>Publish</Btn>
                </div>
              </div>
            </div>
          ))}
          {!sites.filter(s=>s.type!=="full-site").length && (
            <EmptyState icon="⟁" title="No landing pages yet" desc="Create your first AI-generated landing page to start capturing leads." />
          )}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  FORMS & SURVEYS  — drag-and-drop builder
// ═══════════════════════════════════════════════════════
function FormsPage() {
  const FIELD_TYPES = [
    { type:"text",     label:"Short Text",    icon:"▢" },
    { type:"email",    label:"Email",          icon:"@" },
    { type:"phone",    label:"Phone",          icon:"☎" },
    { type:"select",   label:"Dropdown",       icon:"▾" },
    { type:"radio",    label:"Multiple Choice",icon:"◎" },
    { type:"textarea", label:"Long Text",      icon:"▤" },
    { type:"number",   label:"Number",         icon:"#" },
    { type:"date",     label:"Date Picker",    icon:"⊙" },
  ];

  const [forms,   setForms]   = useState([
    { id:1, name:"Lead Capture",    fields:4, submissions:47, active:true },
    { id:2, name:"Demo Request",    fields:6, submissions:23, active:true },
    { id:3, name:"NPS Survey",      fields:3, submissions:89, active:false },
  ]);
  const [view,   setView]   = useState("list"); // list | builder
  const [fields, setFields] = useState([
    { id:1, type:"text",  label:"Full Name",    required:true },
    { id:2, type:"email", label:"Email Address",required:true },
    { id:3, type:"text",  label:"Company",      required:false },
  ]);
  const [formName, setFormName] = useState("New Form");
  const [selField, setSelField] = useState(null);

  const addField = (type) => {
    const f = { id: Date.now(), type, label: FIELD_TYPES.find(t=>t.type===type)?.label || "New Field", required:false };
    setFields(p => [...p, f]);
    setSelField(f.id);
  };

  const updateField = (id, key, val) => setFields(p => p.map(f => f.id===id ? {...f, [key]:val} : f));
  const removeField = (id) => { setFields(p => p.filter(f => f.id!==id)); if(selField===id) setSelField(null); };

  const saveForm = () => {
    setForms(p => [{ id:Date.now(), name:formName, fields:fields.length, submissions:0, active:false }, ...p]);
    setView("list");
  };

  return (
    <div style={{ padding:"28px 32px" }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Forms & Surveys</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Build forms, embed anywhere, track every submission and field-level abandonment</div>
        </div>
        <Btn variant="blue" onClick={() => setView("builder")}>+ New Form</Btn>
      </div>

      {view === "list" && (
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {forms.map(f => (
            <div key={f.id} style={{ display:"flex", alignItems:"center", gap:16, background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"16px 20px" }}>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:700, color:T.ink }}>{f.name}</div>
                <div style={{ fontSize:12, color:T.low, marginTop:2 }}>{f.fields} fields · {f.submissions} submissions</div>
              </div>
              <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:5, background:f.active?T.greenL:T.gray, color:f.active?T.green:T.low }}>
                {f.active ? "LIVE" : "DRAFT"}
              </span>
              <div style={{ display:"flex", gap:8 }}>
                <Btn sx={{ fontSize:11, padding:"5px 12px" }} onClick={() => setView("builder")}>Edit</Btn>
                <Btn sx={{ fontSize:11, padding:"5px 12px" }} onClick={() => navigator.clipboard.writeText(`<iframe src="/forms/${f.id}" width="100%" height="500px"></iframe>`)}>Copy Embed</Btn>
              </div>
            </div>
          ))}
        </div>
      )}

      {view === "builder" && (
        <div style={{ display:"grid", gridTemplateColumns:"240px 1fr 260px", gap:16, height:"calc(100vh - 180px)" }}>
          {/* Field palette */}
          <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"16px", overflow:"auto" }}>
            <div style={{ fontSize:12, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:12 }}>Add Fields</div>
            {FIELD_TYPES.map(t => (
              <button key={t.type} onClick={() => addField(t.type)}
                style={{ display:"flex", alignItems:"center", gap:10, width:"100%", padding:"9px 12px", marginBottom:6,
                  borderRadius:8, border:`1px solid ${T.line}`, background:T.bg, cursor:"pointer", fontSize:12, color:T.ink, textAlign:"left" }}>
                <span style={{ color:T.blue, width:16 }}>{t.icon}</span> {t.label}
              </button>
            ))}
          </div>

          {/* Form canvas */}
          <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 24px", overflow:"auto" }}>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
              <input value={formName} onChange={e => setFormName(e.target.value)}
                style={{ fontSize:16, fontWeight:700, border:"none", background:"transparent", color:T.ink, outline:"none", width:300 }} />
              <div style={{ display:"flex", gap:8 }}>
                <Btn onClick={() => setView("list")}>Cancel</Btn>
                <Btn variant="blue" onClick={saveForm}>Save Form</Btn>
              </div>
            </div>
            {fields.map((f, i) => (
              <div key={f.id} onClick={() => setSelField(f.id)}
                style={{ marginBottom:12, padding:"14px 16px", borderRadius:10,
                  border:`1px solid ${selField===f.id ? T.blue : T.line}`,
                  background: selField===f.id ? T.blueL : T.bg, cursor:"pointer" }}>
                <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
                  <div style={{ fontSize:12, fontWeight:600, color:T.ink }}>
                    {f.label} {f.required && <span style={{ color:T.red }}>*</span>}
                  </div>
                  <button onClick={e => { e.stopPropagation(); removeField(f.id); }}
                    style={{ border:"none", background:"transparent", cursor:"pointer", color:T.low, fontSize:14 }}>✕</button>
                </div>
                <div style={{ padding:"8px 10px", background:"#fff", borderRadius:6, border:`1px solid ${T.line}`, fontSize:12, color:T.low }}>
                  {f.type === "textarea" ? <div style={{ height:48 }}>Long text input...</div>
                   : f.type === "select" ? "Dropdown ▾"
                   : f.type === "radio"  ? "○ Option 1  ○ Option 2"
                   : f.type === "date"   ? "MM / DD / YYYY"
                   : `${f.type} input...`}
                </div>
              </div>
            ))}
            <button onClick={() => addField("text")}
              style={{ width:"100%", padding:"12px", borderRadius:10, border:`2px dashed ${T.line}`, background:"transparent",
                color:T.low, cursor:"pointer", fontSize:13, marginTop:4 }}>+ Add Field</button>
          </div>

          {/* Field settings */}
          <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"16px", overflow:"auto" }}>
            <div style={{ fontSize:12, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:12 }}>Field Settings</div>
            {selField ? (() => {
              const f = fields.find(x => x.id === selField);
              if (!f) return null;
              return (
                <div>
                  <div style={{ marginBottom:12 }}>
                    <FLabel>Label</FLabel>
                    <input value={f.label} onChange={e => updateField(f.id, "label", e.target.value)}
                      style={{ width:"100%", padding:"7px 10px", border:`1px solid ${T.line}`, borderRadius:7, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
                  </div>
                  <div style={{ marginBottom:12 }}>
                    <FLabel>Placeholder</FLabel>
                    <input value={f.placeholder||""} onChange={e => updateField(f.id, "placeholder", e.target.value)}
                      style={{ width:"100%", padding:"7px 10px", border:`1px solid ${T.line}`, borderRadius:7, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <input type="checkbox" checked={f.required} onChange={e => updateField(f.id, "required", e.target.checked)} />
                    <span style={{ fontSize:13, color:T.ink }}>Required field</span>
                  </div>
                </div>
              );
            })() : <div style={{ fontSize:12, color:T.low }}>Click a field to configure it</div>}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  CHAT WIDGET PAGE  — configure Aria, get embed code
// ═══════════════════════════════════════════════════════
function ChatWidgetPage() {
  const [position, setPosition]   = useState("bottom-right");
  const [greeting, setGreeting]   = useState("Hey! I'm Aria, ArgiFlow's AI. What kind of business do you run?");
  const [agentName,setAgentName]  = useState("Aria");
  const [color,    setColor]      = useState("#4B6CF7");
  const [saved,    setSaved]      = useState(false);
  const [tab,      setTab]        = useState("config");

  const embed = `<!-- Aria Chat Widget — ArgiFlow -->
<script
  src="https://your-argiflow.app/argiflow-tracker.js"
  data-host="https://your-argiflow.app"
  data-aria="true"
  data-aria-name="${agentName}"
  data-aria-color="${color}"
  data-aria-position="${position}">
</script>`;

  return (
    <div style={{ padding:"28px 32px", maxWidth:900 }}>
      <div style={{ fontSize:22, fontWeight:800, color:T.ink, marginBottom:4 }}>Chat Widget</div>
      <div style={{ fontSize:12, color:T.low, marginBottom:24 }}>Configure and embed Aria — your AI sales rep — on any website</div>

      <div style={{ display:"flex", gap:8, marginBottom:20 }}>
        {[["config","Configuration"], ["embed","Embed Code"], ["logs","Conversations"]].map(([id,lbl]) => (
          <button key={id} onClick={() => setTab(id)}
            style={{ padding:"7px 16px", borderRadius:9, border:`1px solid ${tab===id?T.blue:T.line}`,
              background: tab===id?T.blueL:"transparent", color: tab===id?T.blue:T.mid,
              fontWeight: tab===id?700:400, cursor:"pointer", fontSize:13 }}>{lbl}</button>
        ))}
      </div>

      {tab === "config" && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20 }}>
          <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
            <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>Widget Settings</div>
            {[["Agent Name", agentName, setAgentName, "e.g. Aria, Max, Zoe"]].map(([l,v,set,ph]) => (
              <div key={l} style={{ marginBottom:14 }}>
                <FLabel>{l}</FLabel>
                <input value={v} onChange={e => set(e.target.value)} placeholder={ph}
                  style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
              </div>
            ))}
            <div style={{ marginBottom:14 }}>
              <FLabel>Opening Message</FLabel>
              <textarea value={greeting} onChange={e => setGreeting(e.target.value)} rows={3}
                style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none", resize:"vertical" }} />
            </div>
            <div style={{ marginBottom:14 }}>
              <FLabel>Position</FLabel>
              <div style={{ display:"flex", gap:8 }}>
                {["bottom-right","bottom-left"].map(p => (
                  <button key={p} onClick={() => setPosition(p)}
                    style={{ padding:"6px 14px", borderRadius:8, border:`1px solid ${position===p?T.blue:T.line}`,
                      background: position===p?T.blueL:"transparent", color: position===p?T.blue:T.mid,
                      cursor:"pointer", fontSize:12, fontWeight: position===p?700:400 }}>{p}</button>
                ))}
              </div>
            </div>
            <div style={{ marginBottom:18 }}>
              <FLabel>Widget Color</FLabel>
              <div style={{ display:"flex", gap:8 }}>
                {["#4B6CF7","#7B5BFB","#0DAD74","#E79109","#0691A1","#E44444"].map(c => (
                  <button key={c} onClick={() => setColor(c)}
                    style={{ width:30, height:30, borderRadius:"50%", background:c, border: color===c?"3px solid #161E36":"2px solid transparent", cursor:"pointer" }} />
                ))}
              </div>
            </div>
            <Btn variant="blue" onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }}>
              {saved ? "✓ Saved!" : "Save Settings"}
            </Btn>
          </div>

          {/* Preview */}
          <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
            <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>Live Preview</div>
            <div style={{ background:"#F0F3FA", borderRadius:12, padding:16, position:"relative", minHeight:300 }}>
              {/* Mock chat */}
              <div style={{ background:"#fff", borderRadius:16, overflow:"hidden", boxShadow:"0 4px 20px rgba(0,0,0,0.08)" }}>
                <div style={{ padding:"12px 16px", background:color, display:"flex", alignItems:"center", gap:10 }}>
                  <div style={{ width:30, height:30, borderRadius:"50%", background:"rgba(255,255,255,0.2)", display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontSize:12 }}>◉</div>
                  <div>
                    <div style={{ fontSize:13, fontWeight:700, color:"#fff" }}>{agentName}</div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,0.75)" }}>ArgiFlow AI · Online</div>
                  </div>
                </div>
                <div style={{ padding:14 }}>
                  <div style={{ background:"#F4F6FB", borderRadius:"14px 14px 14px 4px", padding:"10px 14px", fontSize:12, color:"#161E36", maxWidth:"85%", marginBottom:10 }}>
                    {greeting}
                  </div>
                  <div style={{ fontSize:11, color:"#8E9BB8", textAlign:"center" }}>Powered by ArgiFlow AI</div>
                </div>
              </div>
              {/* Fake fab */}
              <div style={{ position:"absolute", bottom:8, right: position==="bottom-right" ? 8 : "auto", left: position==="bottom-left" ? 8 : "auto",
                width:44, height:44, borderRadius:"50%", background:color, display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontSize:18, boxShadow:"0 4px 16px rgba(0,0,0,0.2)" }}>◉</div>
            </div>
          </div>
        </div>
      )}

      {tab === "embed" && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"24px 28px" }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:8 }}>Embed on Any Website</div>
          <div style={{ fontSize:13, color:T.mid, marginBottom:16 }}>Add this one line to the {"<head>"} of any site to activate {agentName}:</div>
          <div style={{ background:"#161E36", borderRadius:10, padding:"16px 18px", fontFamily:"'JetBrains Mono',monospace", fontSize:12, color:"#A5B4FC", lineHeight:1.7, marginBottom:14 }}>
            {embed.split('\n').map((line, i) => (
              <div key={i}>{line || " "}</div>
            ))}
          </div>
          <div style={{ display:"flex", gap:10 }}>
            <Btn variant="blue" onClick={() => navigator.clipboard.writeText(embed)}>Copy Embed Code</Btn>
            <Btn>View Installation Guide</Btn>
          </div>
          <div style={{ marginTop:20, padding:"14px 16px", background:T.blueL, borderRadius:10, border:`1px solid rgba(75,108,247,0.2)`, fontSize:12, color:T.blue }}>
            💡 The widget connects to your ArgiFlow backend and uses your configured AI provider. No additional API key needed on the embedded site.
          </div>
        </div>
      )}

      {tab === "logs" && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"24px 28px" }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>Conversation Logs</div>
          <EmptyState icon="◉" title="No conversations yet" desc="Once Aria is embedded and receiving visitors, all conversations will appear here for review and lead capture." />
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  INVOICING PAGE
// ═══════════════════════════════════════════════════════
function InvoicingPage() {
  const [invoices, setInvoices] = useState([
    { id:"INV-001", client:"Acme Corp",       amount:4950, status:"paid",    due:"2025-01-15", items:[{desc:"ArgiFlow Setup",qty:1,price:4950}] },
    { id:"INV-002", client:"Greenfield LLC",  amount:2497, status:"pending", due:"2025-02-01", items:[{desc:"Monthly Retainer",qty:1,price:2497}] },
    { id:"INV-003", client:"TechVentures Inc",amount:1200, status:"overdue", due:"2025-01-05", items:[{desc:"Lead Gen Audit",qty:3,price:400}] },
    { id:"INV-004", client:"HealthFirst",     amount:6000, status:"draft",   due:"2025-03-01", items:[{desc:"NaviMed Setup",qty:1,price:6000}] },
  ]);
  const [view,   setView]   = useState("list");
  const [newInv, setNewInv] = useState({ client:"", due:"", items:[{ desc:"", qty:1, price:0 }] });

  const total = invoices.reduce((a,b) => a+b.amount, 0);
  const paid  = invoices.filter(i=>i.status==="paid").reduce((a,b)=>a+b.amount,0);
  const owed  = invoices.filter(i=>["pending","overdue"].includes(i.status)).reduce((a,b)=>a+b.amount,0);

  const statusStyle = (s) => ({
    paid:    { bg:T.greenL, c:T.green  },
    pending: { bg:T.blueL,  c:T.blue   },
    overdue: { bg:T.redL,   c:T.red    },
    draft:   { bg:T.gray,   c:T.low    },
  }[s] || { bg:T.gray, c:T.low });

  const addItem   = () => setNewInv(p => ({...p, items:[...p.items,{desc:"",qty:1,price:0}]}));
  const invTotal  = newInv.items.reduce((a,b) => a+(b.qty*b.price), 0);

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Invoicing</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Create, send, and track invoices from one place</div>
        </div>
        <Btn variant="blue" onClick={() => setView("new")}>+ New Invoice</Btn>
      </div>

      {/* Stats */}
      <div style={{ display:"flex", gap:14, marginBottom:24 }}>
        {[["Total Invoiced", `$${total.toLocaleString()}`, T.ink],
          ["Collected", `$${paid.toLocaleString()}`, T.green],
          ["Outstanding", `$${owed.toLocaleString()}`, owed>0?T.red:T.low],
          ["Invoices", invoices.length, T.blue]].map(([l,v,c]) => (
          <div key={l} style={{ flex:1, background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"16px 18px" }}>
            <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:8 }}>{l}</div>
            <div style={{ fontSize:24, fontWeight:800, color:c, fontFamily:"'JetBrains Mono',monospace" }}>{v}</div>
          </div>
        ))}
      </div>

      {view === "list" && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ background:T.bg }}>{["Invoice","Client","Amount","Status","Due Date",""].map(h => (
                <th key={h} style={{ padding:"10px 16px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.06em", borderBottom:`1px solid ${T.line}` }}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {invoices.map(inv => {
                const st = statusStyle(inv.status);
                return (
                  <tr key={inv.id} style={{ borderBottom:`1px solid ${T.line}` }}>
                    <td style={{ padding:"12px 16px", fontSize:13, fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{inv.id}</td>
                    <td style={{ padding:"12px 16px", fontSize:13, color:T.ink, fontWeight:600 }}>{inv.client}</td>
                    <td style={{ padding:"12px 16px", fontSize:14, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>${inv.amount.toLocaleString()}</td>
                    <td style={{ padding:"12px 16px" }}>
                      <span style={{ fontSize:11, fontWeight:700, padding:"3px 9px", borderRadius:5, background:st.bg, color:st.c, textTransform:"uppercase" }}>{inv.status}</span>
                    </td>
                    <td style={{ padding:"12px 16px", fontSize:12, color:inv.status==="overdue"?T.red:T.mid }}>{inv.due}</td>
                    <td style={{ padding:"12px 16px" }}>
                      <div style={{ display:"flex", gap:6 }}>
                        <Btn sx={{ fontSize:11, padding:"4px 10px" }}>View</Btn>
                        {inv.status !== "paid" && <Btn variant="blue" sx={{ fontSize:11, padding:"4px 10px" }}>Send</Btn>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {view === "new" && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"24px 28px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:20 }}>
            <div style={{ fontSize:16, fontWeight:700, color:T.ink }}>New Invoice</div>
            <button onClick={() => setView("list")} style={{ border:"none", background:"transparent", color:T.low, cursor:"pointer" }}>← Back</button>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:20 }}>
            {[["Client Name", "client", "e.g. Acme Corp"], ["Due Date", "due", "2025-03-01"]].map(([l,k,ph]) => (
              <div key={k}>
                <FLabel>{l}</FLabel>
                <input value={newInv[k]} onChange={e => setNewInv(p => ({...p,[k]:e.target.value}))} placeholder={ph}
                  style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
              </div>
            ))}
          </div>
          <div style={{ marginBottom:16 }}>
            <FLabel>Line Items</FLabel>
            {newInv.items.map((item, i) => (
              <div key={i} style={{ display:"grid", gridTemplateColumns:"1fr 80px 100px 36px", gap:8, marginBottom:8 }}>
                <input value={item.desc} onChange={e => setNewInv(p => ({...p, items:p.items.map((x,j)=>j===i?{...x,desc:e.target.value}:x)}))}
                  placeholder="Description"
                  style={{ padding:"8px 11px", border:`1px solid ${T.line}`, borderRadius:7, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
                <input type="number" value={item.qty} onChange={e => setNewInv(p => ({...p, items:p.items.map((x,j)=>j===i?{...x,qty:+e.target.value}:x)}))}
                  placeholder="Qty"
                  style={{ padding:"8px 11px", border:`1px solid ${T.line}`, borderRadius:7, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
                <input type="number" value={item.price} onChange={e => setNewInv(p => ({...p, items:p.items.map((x,j)=>j===i?{...x,price:+e.target.value}:x)}))}
                  placeholder="Price"
                  style={{ padding:"8px 11px", border:`1px solid ${T.line}`, borderRadius:7, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
                <button onClick={() => setNewInv(p => ({...p,items:p.items.filter((_,j)=>j!==i)}))}
                  style={{ border:`1px solid ${T.line}`, borderRadius:7, background:"transparent", cursor:"pointer", color:T.red, fontSize:16 }}>✕</button>
              </div>
            ))}
            <button onClick={addItem} style={{ fontSize:12, color:T.blue, background:"transparent", border:`1px dashed ${T.blue}`, borderRadius:7, padding:"6px 14px", cursor:"pointer", marginTop:4 }}>+ Add Line Item</button>
          </div>
          <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:20 }}>
            <div style={{ fontSize:22, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>Total: ${invTotal.toLocaleString()}</div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <Btn variant="blue" onClick={() => { setInvoices(p=>[{id:`INV-00${p.length+1}`,client:newInv.client,amount:invTotal,status:"draft",due:newInv.due,items:newInv.items},...p]); setView("list"); }}>Save Invoice</Btn>
            <Btn>Preview</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SOCIAL MEDIA PAGE  — AI-powered post scheduler
// ═══════════════════════════════════════════════════════
function SocialMediaPage({ credits, deductCredits, llmConfig }) {
  const PLATFORMS = ["LinkedIn","Twitter/X","Facebook","Instagram"];
  const [platform,  setPlatform]  = useState("LinkedIn");
  const [topic,     setTopic]     = useState("");
  const [tone,      setTone]      = useState("professional");
  const [generated, setGenerated] = useState("");
  const [loading,   setLoading]   = useState(false);
  const [scheduled, setScheduled] = useState([
    { id:1, platform:"LinkedIn",  content:"We just crossed 100 users on ArgiFlow...", status:"published", date:"2025-02-10" },
    { id:2, platform:"Twitter/X", content:"AI lead gen doesn't have to cost $15K/year...",status:"scheduled",date:"2025-03-15" },
    { id:3, platform:"Facebook",  content:"Attention agency owners: ArgiFlow is white-label ready...",status:"draft",date:"" },
  ]);

  const generate = async () => {
    if (!llmConfig) return alert("Configure an AI provider first");
    if (!topic) return alert("Enter a topic or idea");
    setLoading(true);
    try {
      const res = await fetch("/api/agents/email-writer/run", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          prompt:`Write a ${platform} post about: ${topic}. Tone: ${tone}. 
          Platform-specific rules: ${platform==="Twitter/X"?"Keep under 280 chars. Punchy, no fluff.":platform==="LinkedIn"?"Professional but human. Can be longer, use line breaks. Add 3-5 hashtags.":"Conversational, engaging, include a call to action."}
          Return only the post text, no extra commentary.`,
          context: { platform, topic, tone }
        })
      });
      const data = await res.json();
      if (data.credits_used) deductCredits(data.credits_used);
      setGenerated(data.result || "");
    } catch(e) {}
    setLoading(false);
  };

  const schedule = () => {
    if (!generated) return;
    setScheduled(p => [{ id:Date.now(), platform, content:generated, status:"draft", date:"" }, ...p]);
    setGenerated(""); setTopic("");
  };

  const statusStyle = { published:{bg:T.greenL,c:T.green}, scheduled:{bg:T.blueL,c:T.blue}, draft:{bg:T.gray,c:T.low} };

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ fontSize:22, fontWeight:800, color:T.ink, marginBottom:4 }}>Social Media</div>
      <div style={{ fontSize:12, color:T.low, marginBottom:24 }}>AI-generated posts for LinkedIn, Twitter/X, Facebook, and Instagram · schedule and publish</div>

      <div style={{ display:"grid", gridTemplateColumns:"400px 1fr", gap:20 }}>
        {/* Generator */}
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 22px" }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>AI Post Generator</div>
          <div style={{ marginBottom:14 }}>
            <FLabel>Platform</FLabel>
            <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
              {PLATFORMS.map(p => (
                <button key={p} onClick={() => setPlatform(p)}
                  style={{ padding:"5px 12px", borderRadius:7, border:`1px solid ${platform===p?T.blue:T.line}`,
                    background: platform===p?T.blueL:"transparent", color: platform===p?T.blue:T.mid,
                    fontWeight: platform===p?700:400, cursor:"pointer", fontSize:12 }}>{p}</button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom:14 }}>
            <FLabel>Topic / Idea</FLabel>
            <textarea value={topic} onChange={e=>setTopic(e.target.value)} rows={3}
              placeholder="e.g. Why ArgiFlow replaces GoHighLevel for agencies"
              style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none", resize:"vertical" }} />
          </div>
          <div style={{ marginBottom:18 }}>
            <FLabel>Tone</FLabel>
            <div style={{ display:"flex", gap:7 }}>
              {["professional","casual","bold","educational"].map(t => (
                <button key={t} onClick={() => setTone(t)}
                  style={{ padding:"5px 11px", borderRadius:7, border:`1px solid ${tone===t?T.violet:T.line}`,
                    background: tone===t?T.violetL:"transparent", color: tone===t?T.violet:T.mid,
                    fontWeight: tone===t?700:400, cursor:"pointer", fontSize:11 }}>{t}</button>
              ))}
            </div>
          </div>
          <Btn variant="blue" onClick={generate} disabled={loading} sx={{ width:"100%", marginBottom:10 }}>
            {loading ? <><Spinner size={13} /> Writing...</> : "⚡ Generate Post"}
          </Btn>
          {generated && (
            <div style={{ marginTop:14 }}>
              <div style={{ fontSize:12, fontWeight:700, color:T.ink, marginBottom:8 }}>Generated Post</div>
              <textarea value={generated} onChange={e=>setGenerated(e.target.value)} rows={8}
                style={{ width:"100%", padding:"10px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none", resize:"vertical" }} />
              <div style={{ display:"flex", gap:8, marginTop:10 }}>
                <Btn variant="blue" sx={{ flex:1 }} onClick={schedule}>Add to Queue</Btn>
                <Btn sx={{ flex:1 }} onClick={() => navigator.clipboard.writeText(generated)}>Copy</Btn>
              </div>
            </div>
          )}
        </div>

        {/* Queue */}
        <div>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:14 }}>Content Queue</div>
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {scheduled.map(post => {
              const st = statusStyle[post.status] || statusStyle.draft;
              const icon = post.platform==="LinkedIn"?"🔵":post.platform==="Twitter/X"?"⬛":post.platform==="Facebook"?"🔷":"📷";
              return (
                <div key={post.id} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"14px 16px" }}>
                  <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
                    <div style={{ fontSize:20, flexShrink:0, marginTop:2 }}>{icon}</div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                        <span style={{ fontSize:11, fontWeight:700, color:T.mid }}>{post.platform}</span>
                        <span style={{ fontSize:10, fontWeight:700, padding:"2px 7px", borderRadius:4, background:st.bg, color:st.c, textTransform:"uppercase" }}>{post.status}</span>
                        {post.date && <span style={{ fontSize:11, color:T.low }}>{post.date}</span>}
                      </div>
                      <div style={{ fontSize:12, color:T.ink, lineHeight:1.5, overflow:"hidden", display:"-webkit-box", WebkitLineClamp:3, WebkitBoxOrient:"vertical" }}>{post.content}</div>
                    </div>
                    <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                      <Btn sx={{ fontSize:11, padding:"4px 10px" }}>Edit</Btn>
                      {post.status !== "published" && <Btn variant="blue" sx={{ fontSize:11, padding:"4px 10px" }}>Publish</Btn>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  CALENDAR PAGE  — scheduling & appointment manager
// ═══════════════════════════════════════════════════════
function CalendarPage() {
  const [view,   setView]   = useState("month");
  const [month,  setMonth]  = useState(new Date(2025,2,1)); // March 2025
  const [events, setEvents] = useState([
    { id:1, title:"Demo — Acme Corp",     date:"2025-03-05", time:"10:00", type:"demo",    color:T.blue   },
    { id:2, title:"Onboarding — TechCo",  date:"2025-03-10", time:"14:00", type:"meeting", color:T.green  },
    { id:3, title:"Follow-up — HealthFirst",date:"2025-03-14",time:"11:00",type:"call",    color:T.amber  },
    { id:4, title:"Agency Pitch",         date:"2025-03-19", time:"15:30", type:"demo",    color:T.blue   },
    { id:5, title:"Q1 Review",            date:"2025-03-28", time:"09:00", type:"internal",color:T.violet },
  ]);
  const [showNew, setShowNew]   = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDate,  setNewDate]  = useState("");
  const [newTime,  setNewTime]  = useState("10:00");
  const [newType,  setNewType]  = useState("demo");

  const monthName = month.toLocaleString("default", { month:"long", year:"numeric" });
  const firstDay  = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
  const daysInMonth = new Date(month.getFullYear(), month.getMonth()+1, 0).getDate();
  const dateStr = (d) => `${month.getFullYear()}-${String(month.getMonth()+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
  const eventsFor = (d) => events.filter(e => e.date === dateStr(d));

  const addEvent = () => {
    if (!newTitle || !newDate) return;
    setEvents(p => [...p, { id:Date.now(), title:newTitle, date:newDate, time:newTime, type:newType, color:{demo:T.blue,meeting:T.green,call:T.amber,internal:T.violet}[newType] }]);
    setShowNew(false); setNewTitle(""); setNewDate(""); setNewTime("10:00");
  };

  const typeEmoji = { demo:"🎯", meeting:"👥", call:"📞", internal:"⚙️" };

  return (
    <div style={{ padding:"28px 32px" }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Calendar</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Schedule demos, meetings, and follow-up calls</div>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <div style={{ display:"flex", gap:6 }}>
            {["month","week","list"].map(v => (
              <button key={v} onClick={() => setView(v)}
                style={{ padding:"5px 14px", borderRadius:8, border:`1px solid ${view===v?T.blue:T.line}`, background:view===v?T.blueL:"transparent",
                  color:view===v?T.blue:T.mid, fontWeight:view===v?700:400, cursor:"pointer", fontSize:12 }}>
                {v.charAt(0).toUpperCase()+v.slice(1)}
              </button>
            ))}
          </div>
          <Btn variant="blue" onClick={() => setShowNew(true)}>+ Event</Btn>
        </div>
      </div>

      {showNew && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"20px 24px", marginBottom:20, maxWidth:520 }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:14 }}>Add Event</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:14 }}>
            {[["Title", "text", newTitle, setNewTitle, "e.g. Demo Call"],
              ["Date",  "date", newDate,  setNewDate,  ""],
              ["Time",  "time", newTime,  setNewTime,  ""]].map(([l,type,v,set,ph]) => (
              <div key={l}>
                <FLabel>{l}</FLabel>
                <input type={type} value={v} onChange={e=>set(e.target.value)} placeholder={ph}
                  style={{ width:"100%", padding:"8px 11px", border:`1px solid ${T.line}`, borderRadius:7, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
              </div>
            ))}
          </div>
          <div style={{ marginBottom:14 }}>
            <FLabel>Type</FLabel>
            <div style={{ display:"flex", gap:7 }}>
              {Object.entries(typeEmoji).map(([t,e]) => (
                <button key={t} onClick={() => setNewType(t)}
                  style={{ padding:"5px 12px", borderRadius:7, border:`1px solid ${newType===t?T.blue:T.line}`,
                    background:newType===t?T.blueL:"transparent", color:newType===t?T.blue:T.mid, fontWeight:newType===t?700:400, cursor:"pointer", fontSize:12 }}>
                  {e} {t}
                </button>
              ))}
            </div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <Btn variant="blue" onClick={addEvent}>Add Event</Btn>
            <Btn onClick={() => setShowNew(false)}>Cancel</Btn>
          </div>
        </div>
      )}

      {view === "month" && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"16px 20px", borderBottom:`1px solid ${T.line}` }}>
            <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth()-1))}
              style={{ border:`1px solid ${T.line}`, borderRadius:8, background:"transparent", cursor:"pointer", padding:"4px 12px", color:T.mid }}>‹</button>
            <div style={{ fontSize:16, fontWeight:700, color:T.ink }}>{monthName}</div>
            <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth()+1))}
              style={{ border:`1px solid ${T.line}`, borderRadius:8, background:"transparent", cursor:"pointer", padding:"4px 12px", color:T.mid }}>›</button>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)" }}>
            {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d => (
              <div key={d} style={{ padding:"8px 0", textAlign:"center", fontSize:11, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", borderBottom:`1px solid ${T.line}` }}>{d}</div>
            ))}
            {Array.from({length: firstDay}, (_,i) => <div key={`e${i}`} style={{ borderBottom:`1px solid ${T.line}`, borderRight:`1px solid ${T.line}`, minHeight:80 }} />)}
            {Array.from({length: daysInMonth}, (_,i) => {
              const d = i+1;
              const dayEvents = eventsFor(d);
              const isToday = dateStr(d) === new Date().toISOString().slice(0,10);
              return (
                <div key={d} style={{ borderBottom:`1px solid ${T.line}`, borderRight:`1px solid ${T.line}`, minHeight:80, padding:"6px 8px", background: isToday ? T.blueL : "transparent" }}>
                  <div style={{ fontSize:13, fontWeight: isToday?800:400, color: isToday?T.blue:T.ink, marginBottom:4, width:24, height:24, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", background: isToday?T.blue:"transparent", color: isToday?"#fff":T.ink }}>{d}</div>
                  {dayEvents.map(e => (
                    <div key={e.id} style={{ fontSize:10, color:"#fff", background:e.color, borderRadius:4, padding:"2px 5px", marginBottom:2, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                      {typeEmoji[e.type]} {e.title}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {view === "list" && (
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {events.sort((a,b) => a.date.localeCompare(b.date)).map(e => (
            <div key={e.id} style={{ display:"flex", alignItems:"center", gap:14, background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"14px 18px" }}>
              <div style={{ width:40, height:40, borderRadius:10, background:e.color+"22", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>{typeEmoji[e.type]}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:600, color:T.ink }}>{e.title}</div>
                <div style={{ fontSize:12, color:T.low }}>{e.date} at {e.time}</div>
              </div>
              <span style={{ fontSize:11, fontWeight:700, padding:"3px 9px", borderRadius:5, background:e.color+"22", color:e.color }}>{e.type}</span>
              <Btn sx={{ fontSize:11, padding:"5px 12px" }}>Edit</Btn>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  AUTOMATIONS PAGE  — uses /api/workflows
// ═══════════════════════════════════════════════════════
function AutomationsPage() {
  const [automations, setAutomations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState("");
  const [trigger, setTrigger] = useState("new_lead");
  const [action,  setAction]  = useState("send_email");

  useEffect(() => {
    fetch("/api/workflows").then(r=>r.json())
      .then(d => { setAutomations(d.workflows||[]); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const TRIGGERS = [
    { id:"new_lead",      label:"New Lead Added",        icon:"◎" },
    { id:"lead_replied",  label:"Lead Replies",           icon:"→" },
    { id:"form_submit",   label:"Form Submitted",         icon:"◫" },
    { id:"email_opened",  label:"Email Opened 3+ Times",  icon:"⊙" },
    { id:"site_visit",    label:"Visitor Returns",         icon:"◈" },
    { id:"intent_high",   label:"High Intent Detected",    icon:"⚡" },
    { id:"meeting_booked",label:"Meeting Booked",          icon:"⬡" },
    { id:"invoice_paid",  label:"Invoice Paid",            icon:"▤" },
  ];

  const ACTIONS = [
    { id:"send_email",      label:"Send Email",         icon:"→" },
    { id:"run_agent",       label:"Run AI Agent",        icon:"◉" },
    { id:"add_tag",         label:"Tag Contact",         icon:"⬡" },
    { id:"notify_slack",    label:"Slack Notification",  icon:"⟳" },
    { id:"create_task",     label:"Create Task",         icon:"▢" },
    { id:"add_to_sequence", label:"Add to Sequence",     icon:"⟁" },
    { id:"webhook",         label:"Call Webhook",         icon:"◈" },
    { id:"assign_owner",    label:"Assign Owner",         icon:"◎" },
  ];

  const create = async () => {
    if (!newName) return;
    try {
      const res = await fetch("/api/workflows", { method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ name: newName, nodes: [{ id:"t1", type:"trigger", action:trigger }, { id:"a1", type:"action", action }], status:"active" }) });
      const d = await res.json();
      setAutomations(p => [d.workflow||{ id:Date.now(), name:newName, status:"active", trigger, action }, ...p]);
      setShowNew(false); setNewName("");
    } catch(e) {}
  };

  const toggleStatus = async (id, current) => {
    const status = current === "active" ? "paused" : "active";
    setAutomations(p => p.map(a => a.id===id ? {...a, status} : a));
  };

  const TEMPLATES = [
    { name:"Welcome New Lead",     trigger:"new_lead",      action:"send_email",  desc:"Send a welcome email when a lead is added" },
    { name:"Hot Prospect Alert",   trigger:"intent_high",   action:"notify_slack",desc:"Slack alert when intent score spikes" },
    { name:"Form → Sequence",      trigger:"form_submit",   action:"add_to_sequence",desc:"Auto-enroll form submissions into outreach" },
    { name:"Meeting Booked → CRM", trigger:"meeting_booked",action:"add_tag",     desc:"Tag contacts who book a demo" },
    { name:"Email Re-engage",      trigger:"email_opened",  action:"run_agent",   desc:"AI drafts follow-up for hot email opens" },
  ];

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:24 }}>
        <div>
          <div style={{ fontSize:22, fontWeight:800, color:T.ink }}>Automations</div>
          <div style={{ fontSize:12, color:T.low, marginTop:2 }}>Trigger-based workflows · connect leads, agents, emails, and notifications</div>
        </div>
        <Btn variant="blue" onClick={() => setShowNew(true)}>+ New Automation</Btn>
      </div>

      {showNew && (
        <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, padding:"22px 24px", marginBottom:20 }}>
          <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:16 }}>New Automation</div>
          <div style={{ marginBottom:14 }}>
            <FLabel>Automation Name</FLabel>
            <input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="e.g. Reply Handler"
              style={{ width:"100%", padding:"9px 12px", border:`1px solid ${T.line}`, borderRadius:8, fontSize:13, color:T.ink, background:T.bg, outline:"none" }} />
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:16 }}>
            <div>
              <FLabel>When (Trigger)</FLabel>
              <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                {TRIGGERS.map(t => (
                  <button key={t.id} onClick={() => setTrigger(t.id)}
                    style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 11px", borderRadius:8,
                      border:`1px solid ${trigger===t.id?T.blue:T.line}`, background:trigger===t.id?T.blueL:"transparent",
                      color:trigger===t.id?T.blue:T.mid, cursor:"pointer", fontSize:12, fontWeight:trigger===t.id?600:400, textAlign:"left" }}>
                    <span>{t.icon}</span> {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <FLabel>Then (Action)</FLabel>
              <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                {ACTIONS.map(a => (
                  <button key={a.id} onClick={() => setAction(a.id)}
                    style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 11px", borderRadius:8,
                      border:`1px solid ${action===a.id?T.violet:T.line}`, background:action===a.id?T.violetL:"transparent",
                      color:action===a.id?T.violet:T.mid, cursor:"pointer", fontSize:12, fontWeight:action===a.id?600:400, textAlign:"left" }}>
                    <span>{a.icon}</span> {a.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <Btn variant="blue" onClick={create}>Create Automation</Btn>
            <Btn onClick={() => setShowNew(false)}>Cancel</Btn>
          </div>
        </div>
      )}

      {/* Templates */}
      <div style={{ marginBottom:24 }}>
        <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:12 }}>Quick Templates</div>
        <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
          {TEMPLATES.map(t => (
            <div key={t.name} onClick={() => { setNewName(t.name); setTrigger(t.trigger); setAction(t.action); setShowNew(true); }}
              style={{ padding:"10px 14px", background:T.card, border:`1px solid ${T.line}`, borderRadius:10, cursor:"pointer", maxWidth:220 }}>
              <div style={{ fontSize:12, fontWeight:700, color:T.ink, marginBottom:4 }}>{t.name}</div>
              <div style={{ fontSize:11, color:T.low }}>{t.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* List */}
      {loading ? <div style={{ display:"flex", justifyContent:"center", padding:40 }}><Spinner /></div> : (
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {automations.map(a => (
            <div key={a.id} style={{ display:"flex", alignItems:"center", gap:16, background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"14px 18px" }}>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:600, color:T.ink }}>{a.name}</div>
                <div style={{ fontSize:11, color:T.low, marginTop:2 }}>
                  {TRIGGERS.find(t=>t.id===a.trigger)?.label || a.trigger} → {ACTIONS.find(x=>x.id===a.action)?.label || a.action}
                </div>
              </div>
              <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:5,
                background: a.status==="active"?T.greenL:T.gray, color: a.status==="active"?T.green:T.low }}>
                {(a.status||"draft").toUpperCase()}
              </span>
              <Btn sx={{ fontSize:11, padding:"5px 12px" }} onClick={() => toggleStatus(a.id, a.status)}>
                {a.status === "active" ? "Pause" : "Activate"}
              </Btn>
            </div>
          ))}
          {!automations.length && <EmptyState icon="⚡" title="No automations yet" desc="Use a template above or build a custom trigger-action workflow." />}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  CRM INTEGRATIONS PAGE
// ═══════════════════════════════════════════════════════
function CRMIntegrationsPage() {
  const [connections, setConnections] = useState([
    { id:"hubspot",    name:"HubSpot",    logo:"🟠", status:"connected", records:1204, lastSync:"5 min ago" },
    { id:"salesforce", name:"Salesforce", logo:"☁️", status:"connected", records:843,  lastSync:"12 min ago" },
    { id:"ghl",        name:"GoHighLevel",logo:"⚡", status:"disconnected" },
    { id:"pipedrive",  name:"Pipedrive",  logo:"🔵", status:"disconnected" },
    { id:"airtable",   name:"Airtable",   logo:"🔶", status:"disconnected" },
    { id:"notion",     name:"Notion",     logo:"⬛", status:"disconnected" },
    { id:"sheets",     name:"Google Sheets",logo:"🟩",status:"disconnected" },
    { id:"zapier",     name:"Zapier",     logo:"⚡", status:"disconnected" },
    { id:"n8n",        name:"n8n",        logo:"🔁", status:"disconnected" },
    { id:"webhook",    name:"Webhook / API",logo:"🔗",status:"configured" },
    { id:"slack",      name:"Slack",      logo:"🟣", status:"connected", records:0, lastSync:"Active" },
    { id:"whatsapp",   name:"WhatsApp Business",logo:"🟢",status:"disconnected" },
  ]);
  const [apiKey, setApiKey] = useState("");
  const [selCRM, setSelCRM] = useState(null);

  const connect = (id) => {
    setConnections(p => p.map(c => c.id===id ? {...c, status:"connected", records:0, lastSync:"Just now"} : c));
    setSelCRM(null); setApiKey("");
  };

  const disconnect = (id) => setConnections(p => p.map(c => c.id===id ? {...c, status:"disconnected", records:undefined, lastSync:undefined} : c));

  const statusColor = { connected:T.green, disconnected:T.low, configured:T.blue };
  const statusBg    = { connected:T.greenL, disconnected:T.gray, configured:T.blueL };

  const connected = connections.filter(c => c.status !== "disconnected");
  const available = connections.filter(c => c.status === "disconnected");

  return (
    <div style={{ padding:"28px 32px", maxWidth:1050 }}>
      <div style={{ fontSize:22, fontWeight:800, color:T.ink, marginBottom:4 }}>CRM Integrations</div>
      <div style={{ fontSize:12, color:T.low, marginBottom:24 }}>Connect ArgiFlow to your existing CRM, automation tools, and communication platforms</div>

      {/* Connected */}
      {connected.length > 0 && (
        <div style={{ marginBottom:28 }}>
          <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:12 }}>Connected ({connected.length})</div>
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {connected.map(c => (
              <div key={c.id} style={{ display:"flex", alignItems:"center", gap:14, background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"14px 18px" }}>
                <div style={{ fontSize:28, width:44, textAlign:"center", flexShrink:0 }}>{c.logo}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:700, color:T.ink }}>{c.name}</div>
                  <div style={{ fontSize:12, color:T.low, marginTop:2 }}>
                    {c.records !== undefined ? `${c.records.toLocaleString()} records synced` : "Active"} · Last sync: {c.lastSync}
                  </div>
                </div>
                <span style={{ fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:5,
                  background: statusBg[c.status], color: statusColor[c.status], textTransform:"uppercase" }}>{c.status}</span>
                <div style={{ display:"flex", gap:8 }}>
                  <Btn sx={{ fontSize:11, padding:"5px 12px" }}>Sync Now</Btn>
                  <Btn sx={{ fontSize:11, padding:"5px 12px", color:T.red }} onClick={() => disconnect(c.id)}>Disconnect</Btn>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Available */}
      <div>
        <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:12 }}>Available Integrations</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(220px,1fr))", gap:12 }}>
          {available.map(c => (
            <div key={c.id} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:12, padding:"16px 18px" }}>
              <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:12 }}>
                <div style={{ fontSize:28 }}>{c.logo}</div>
                <div style={{ fontSize:14, fontWeight:700, color:T.ink }}>{c.name}</div>
              </div>
              <Btn variant="blue" sx={{ width:"100%", fontSize:12 }} onClick={() => setSelCRM(c.id)}>Connect</Btn>
            </div>
          ))}
        </div>
      </div>

      {/* Connect modal */}
      {selCRM && (() => {
        const crm = connections.find(c => c.id === selCRM);
        return (
          <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.35)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center" }}>
            <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", maxWidth:420, width:"90%" }}>
              <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
                <div style={{ fontSize:36 }}>{crm.logo}</div>
                <div>
                  <div style={{ fontSize:18, fontWeight:800, color:T.ink }}>Connect {crm.name}</div>
                  <div style={{ fontSize:12, color:T.low }}>Enter your API credentials to connect</div>
                </div>
              </div>
              <FLabel>API Key</FLabel>
              <input value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder={`Your ${crm.name} API key`}
                style={{ width:"100%", padding:"10px 13px", border:`1px solid ${T.line}`, borderRadius:9, fontSize:13, color:T.ink, background:T.bg, outline:"none", marginBottom:16 }} />
              <div style={{ display:"flex", gap:8 }}>
                <Btn variant="blue" sx={{ flex:1 }} onClick={() => connect(selCRM)}>Connect {crm.name}</Btn>
                <Btn sx={{ flex:1 }} onClick={() => { setSelCRM(null); setApiKey(""); }}>Cancel</Btn>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
