import { useState, useEffect, useRef, useCallback } from "react";

/*
  ARGIFLOW PLATFORM
  ──────────────────────────────────────────────────────────
  MULTI-LLM ROUTER — switch providers from UI, zero code changes
  Supported: Anthropic · OpenAI · Google Gemini · Mistral
             Groq · Together AI · Any OpenAI-compatible endpoint
  ──────────────────────────────────────────────────────────
*/

// ═══════════════════════════════════════════════════════
//  THEME
// ═══════════════════════════════════════════════════════
const T = {
  bg:"#F4F6FB", card:"#FFFFFF", card2:"#F0F3FA", card3:"#E6EAF6",
  line:"rgba(90,110,180,0.12)", lineHi:"rgba(90,110,180,0.24)",
  ink:"#161E36", mid:"#4E5E82", low:"#8E9BB8",
  blue:"#4B6CF7", blueL:"#EEF1FF",
  green:"#0DAD74", greenL:"#E5FAF1",
  amber:"#E79109", amberL:"#FEF3E0",
  red:"#E44444", redL:"#FEE9E9",
  violet:"#7B5BFB", violetL:"#EDEAFE",
  teal:"#0691A1", tealL:"#E0F6F8",
};

const CREDIT_COSTS = {
  ai_email:8, lead_enrich:15, agent_run:50,
  reply_analyze:10, intent_scan:20, email_sequence:30,
};

// ═══════════════════════════════════════════════════════
//  LLM PROVIDER REGISTRY
//  Each entry describes HOW to call that provider.
//  Users fill in api_key + model via Settings UI.
// ═══════════════════════════════════════════════════════
const LLM_REGISTRY = {
  anthropic: {
    name: "Anthropic",
    logo: "🟠",
    baseUrl: "https://api.anthropic.com",
    defaultModel: "claude-sonnet-4-6",
    modelOptions: ["claude-sonnet-4-6","claude-opus-4-6","claude-haiku-4-5-20251001"],
    format: "anthropic",
    docsUrl: "https://docs.anthropic.com",
    placeholder: "sk-ant-api03-…",
  },
  openai: {
    name: "OpenAI",
    logo: "🟢",
    baseUrl: "https://api.openai.com",
    defaultModel: "gpt-4o",
    modelOptions: ["gpt-4o","gpt-4o-mini","gpt-4-turbo","gpt-3.5-turbo"],
    format: "openai",
    docsUrl: "https://platform.openai.com/docs",
    placeholder: "sk-…",
  },
  gemini: {
    name: "Google Gemini",
    logo: "🔵",
    baseUrl: "https://generativelanguage.googleapis.com",
    defaultModel: "gemini-1.5-pro",
    modelOptions: ["gemini-1.5-pro","gemini-1.5-flash","gemini-2.0-flash"],
    format: "gemini",
    docsUrl: "https://ai.google.dev/docs",
    placeholder: "AIza…",
  },
  mistral: {
    name: "Mistral AI",
    logo: "🟡",
    baseUrl: "https://api.mistral.ai",
    defaultModel: "mistral-large-latest",
    modelOptions: ["mistral-large-latest","mistral-medium-latest","mistral-small-latest","open-mixtral-8x22b"],
    format: "openai",
    docsUrl: "https://docs.mistral.ai",
    placeholder: "…",
  },
  groq: {
    name: "Groq",
    logo: "⚡",
    baseUrl: "https://api.groq.com/openai",
    defaultModel: "llama-3.3-70b-versatile",
    modelOptions: ["llama-3.3-70b-versatile","llama-3.1-8b-instant","mixtral-8x7b-32768","gemma2-9b-it"],
    format: "openai",
    docsUrl: "https://console.groq.com/docs",
    placeholder: "gsk_…",
  },
  together: {
    name: "Together AI",
    logo: "🟣",
    baseUrl: "https://api.together.xyz",
    defaultModel: "meta-llama/Llama-3-70b-chat-hf",
    modelOptions: ["meta-llama/Llama-3-70b-chat-hf","mistralai/Mixtral-8x22B-Instruct-v0.1","Qwen/Qwen2-72B-Instruct"],
    format: "openai",
    docsUrl: "https://docs.together.ai",
    placeholder: "…",
  },
  custom: {
    name: "Custom / Self-hosted",
    logo: "🔧",
    baseUrl: "",
    defaultModel: "",
    modelOptions: [],
    format: "openai",
    docsUrl: "",
    placeholder: "Your API key",
  },
};

// ═══════════════════════════════════════════════════════
//  UNIVERSAL LLM CALLER
//  Reads active provider config from localStorage.
//  Zero code changes needed to switch providers.
// ═══════════════════════════════════════════════════════
async function callLLM({ system, userMessage, maxTokens = 800, providerConfig = null }) {
  // Load config from localStorage if not passed directly
  const cfg = providerConfig ?? JSON.parse(localStorage.getItem("argiflow_llm_config") ?? "null");

  if (!cfg || !cfg.providerId) throw new Error("No LLM provider configured. Go to Settings → AI Providers.");
  if (!cfg.apiKey) throw new Error(`No API key set for ${cfg.providerId}. Go to Settings → AI Providers.`);

  const reg = LLM_REGISTRY[cfg.providerId];
  if (!reg) throw new Error(`Unknown provider: ${cfg.providerId}`);

  const model   = cfg.model || reg.defaultModel;
  const baseUrl = cfg.customBaseUrl || reg.baseUrl;
  const format  = cfg.format || reg.format;

  // ── Anthropic format ──────────────────────────────
  if (format === "anthropic") {
    const res = await fetch(`${baseUrl}/v1/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": cfg.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model, max_tokens: maxTokens,
        system,
        messages: [{ role: "user", content: userMessage }],
      }),
    });
    if (!res.ok) { const e = await res.json().catch(()=>({error:{message:res.statusText}})); throw new Error(e?.error?.message || res.statusText); }
    const data = await res.json();
    return data.content?.[0]?.text ?? "";
  }

  // ── OpenAI-compatible format (OpenAI, Mistral, Groq, Together, Custom) ──
  if (format === "openai") {
    const endpoint = `${baseUrl}/v1/chat/completions`;
    const messages = [];
    if (system) messages.push({ role: "system", content: system });
    messages.push({ role: "user", content: userMessage });
    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({ model, max_tokens: maxTokens, messages }),
    });
    if (!res.ok) { const e = await res.json().catch(()=>({error:{message:res.statusText}})); throw new Error(e?.error?.message || res.statusText); }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? "";
  }

  // ── Google Gemini format ──────────────────────────
  if (format === "gemini") {
    const endpoint = `${baseUrl}/v1beta/models/${model}:generateContent?key=${cfg.apiKey}`;
    const body = {
      contents: [{ parts: [{ text: userMessage }] }],
      generationConfig: { maxOutputTokens: maxTokens },
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) { const e = await res.json().catch(()=>({error:{message:res.statusText}})); throw new Error(e?.error?.message || res.statusText); }
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  }

  throw new Error(`Unsupported format: ${format}`);
}

// ═══════════════════════════════════════════════════════
//  DEMO DATA  (overview + intent — shows your data)
// ═══════════════════════════════════════════════════════
const DEMO_PIPELINE = [
  { label:"Found",     count:12847, pct:100, color:T.blue   },
  { label:"Enriched",  count:9420,  pct:73,  color:"#6366F1" },
  { label:"Contacted", count:3204,  pct:25,  color:T.violet  },
  { label:"Replied",   count:387,   pct:3,   color:T.teal    },
  { label:"Meeting",   count:87,    pct:1,   color:T.green   },
  { label:"Closed",    count:34,    pct:0.3, color:"#059669"  },
];

const DEMO_ACTIVITY = [
  { icon:"✦", type:"agent",    text:"Lead Scout enriched 47 dental prospects in Texas",    time:"2m ago"  },
  { icon:"→", type:"outreach", text:"Outreach Agent sent 124 personalized cold emails",    time:"8m ago"  },
  { icon:"◎", type:"intent",   text:"Intent signal: Acme Solutions researching CRM tools", time:"15m ago" },
  { icon:"⊙", type:"meeting",  text:"Meeting booked: Sarah K. — Thu 2pm via AI reply",    time:"22m ago" },
  { icon:"⚡", type:"alert",   text:"'Hot Lead Alert' fired for 3 new 90+ score leads",   time:"40m ago" },
  { icon:"⬡", type:"agent",    text:"Forum Prospector found 28 new prospects on Reddit",   time:"58m ago" },
];

const DEMO_AGENT_HEALTH = [
  { name:"Lead Scout",        status:"active", runs:4821, rate:98.2 },
  { name:"Cold Email Writer", status:"active", runs:2204, rate:94.7 },
  { name:"Reply Analyzer",    status:"active", runs:891,  rate:99.1 },
  { name:"Intent Monitor",    status:"paused", runs:1240, rate:91.3 },
];

const DEMO_INTENT_SIGNALS = [
  { id:1, company:"Acme Solutions",  domain:"acmesol.com",     signal:"Visited 7 competitor pricing pages in 48h",      strength:"HIGH", score:94, time:"3m ago"  },
  { id:2, company:"TechBridge Corp", domain:"techbridge.io",   signal:"Posted 3 VP Sales roles — scaling team",          strength:"HIGH", score:88, time:"21m ago" },
  { id:3, company:"Global Dynamics", domain:"globaldyn.com",   signal:"Downloaded CRM comparison whitepaper",            strength:"MED",  score:71, time:"38m ago" },
  { id:4, company:"Nexus Partners",  domain:"nexusp.co",       signal:"CEO asking about outbound tools on LinkedIn",      strength:"MED",  score:76, time:"1h ago"  },
  { id:5, company:"BrightScale Inc", domain:"brightscale.com", signal:"$4.2M Series A announced",                       strength:"HIGH", score:91, time:"3h ago"  },
  { id:6, company:"Velocity Health", domain:"velocityh.io",    signal:"Hired RevOps Director last week",                 strength:"MED",  score:68, time:"5h ago"  },
  { id:7, company:"Lagos Ventures",  domain:"lagosv.ng",       signal:"Searching 'sales automation Africa' repeatedly",  strength:"HIGH", score:84, time:"6h ago"  },
];

const DEMO_INTENT_SOURCES = [
  { label:"Job postings",      count:1204 },
  { label:"Pricing page visits",count:384 },
  { label:"Content downloads", count:892  },
  { label:"LinkedIn signals",  count:2104 },
  { label:"News & funding",    count:247  },
  { label:"Forum mentions",    count:563  },
];

// ═══════════════════════════════════════════════════════
//  NAV
// ═══════════════════════════════════════════════════════
const NAV = [
  { section:"Main", items:[
    { id:"overview",          label:"Overview",            icon:"⬡" },
  ]},
  { section:"AI Automation", items:[
    { id:"ai-agents",         label:"AI Agents",           icon:"◉", badge:"LIVE" },
    { id:"sequences",         label:"Sequences",           icon:"⟳" },
  ]},
  { section:"Sales Intelligence", items:[
    { id:"lead-intelligence", label:"Lead Intelligence",   icon:"◎" },
    { id:"intent-data",       label:"Intent Data",         icon:"◈", badge:"NEW" },
    { id:"forum-prospector",  label:"Forum Prospector",    icon:"⬡" },
  ]},
  { section:"Platform", items:[
    { id:"website-builder",   label:"Website Builder",     icon:"⬟", badge:"NEW" },
    { id:"landing-pages",     label:"Landing Pages",       icon:"⟁" },
    { id:"forms",             label:"Forms & Surveys",     icon:"◫" },
    { id:"chat-widget",       label:"Chat Widget",         icon:"◉" },
    { id:"invoicing",         label:"Invoicing",           icon:"▤" },
    { id:"social-media",      label:"Social Media",        icon:"⬡" },
    { id:"calendar",          label:"Calendar",            icon:"⊙" },
  ]},
  { section:"Growth", items:[
    { id:"workflow-builder",  label:"Workflow Builder",    icon:"⬟" },
    { id:"automations",       label:"Automations",         icon:"⚡" },
    { id:"crm-integrations",  label:"CRM Integrations",    icon:"⬡" },
  ]},
  { section:"Account", items:[
    { id:"ai-providers",      label:"AI Providers",        icon:"◈", badge:"NEW" },
    { id:"credits",           label:"Credits & Billing",   icon:"◎" },
    { id:"settings",          label:"Settings",            icon:"⊙" },
  ]},
];

// ═══════════════════════════════════════════════════════
//  PRIMITIVES
// ═══════════════════════════════════════════════════════
const Badge = ({ v }) => {
  const s = {
    NEW:{ bg:T.greenL,  border:"rgba(13,173,116,0.22)", c:T.green },
    LIVE:{ bg:T.blueL, border:"rgba(75,108,247,0.25)", c:T.blue  },
  };
  const st = s[v]||{};
  return <span style={{ fontSize:8.5, fontWeight:700, letterSpacing:"0.07em", padding:"2px 6px", borderRadius:4, fontFamily:"'JetBrains Mono',monospace", background:st.bg, border:`1px solid ${st.border}`, color:st.c }}>{v}</span>;
};

const Card = ({ children, sx={} }) => (
  <div style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, boxShadow:"0 1px 4px rgba(40,55,120,0.05)", ...sx }}>{children}</div>
);

const Btn = ({ children, variant="ghost", onClick, disabled, loading, sx={} }) => {
  const base = { padding:"7px 15px", borderRadius:9, fontSize:12.5, fontWeight:600, cursor:disabled||loading?"not-allowed":"pointer", border:"none", opacity:disabled||loading?0.6:1, transition:"all 0.14s", display:"inline-flex", alignItems:"center", justifyContent:"center", gap:6, ...sx };
  const v = {
    primary:{ background:`linear-gradient(135deg,${T.blue},${T.violet})`, color:"#fff", boxShadow:`0 3px 12px ${T.blue}28` },
    green:  { background:T.green,  color:"#fff" },
    ghost:  { background:T.card,   border:`1px solid ${T.line}`, color:T.mid },
    blue:   { background:T.blueL,  border:`1px solid rgba(75,108,247,0.22)`, color:T.blue },
    danger: { background:T.redL,   border:`1px solid rgba(228,68,68,0.22)`, color:T.red },
    amber:  { background:T.amberL, border:`1px solid rgba(231,145,9,0.22)`, color:T.amber },
    subtle: { background:T.card2,  border:`1px solid ${T.line}`, color:T.mid },
  };
  return <button onClick={onClick} disabled={disabled||loading} style={{...base,...(v[variant]||v.ghost)}}>{loading?"…":children}</button>;
};

const Dot = ({ active=true, color=T.green, size=6 }) => (
  <span style={{ display:"inline-block", width:size, height:size, borderRadius:"50%", background:active?color:T.low, flexShrink:0, boxShadow:active?`0 0 0 2.5px ${color}28`:undefined }} />
);

const Spinner = ({ size=16 }) => (
  <span style={{ display:"inline-block", width:size, height:size, borderRadius:"50%", border:`2px solid ${T.line}`, borderTopColor:T.blue, animation:"spin 0.7s linear infinite", flexShrink:0 }} />
);

const EmptyState = ({ icon="◈", title, desc, action }) => (
  <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"60px 20px", textAlign:"center", gap:16 }}>
    <div style={{ fontSize:44, opacity:0.12 }}>{icon}</div>
    <div>
      <div style={{ fontWeight:700, fontSize:17, color:T.ink, marginBottom:8 }}>{title}</div>
      {desc && <div style={{ fontSize:13, color:T.mid, maxWidth:360, lineHeight:1.7 }}>{desc}</div>}
    </div>
    {action}
  </div>
);

const FLabel = ({ children }) => <div style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:5 }}>{children}</div>;
const Field  = ({ label, children }) => <div><FLabel>{label}</FLabel>{children}</div>;

const Input = (props) => (
  <input {...props} style={{ width:"100%", background:T.card2, border:`1px solid ${T.line}`, borderRadius:8, padding:"8px 11px", fontSize:12.5, color:T.ink, outline:"none", transition:"border-color 0.14s", ...(props.style||{}) }}
    onFocus={e=>{e.target.style.borderColor="rgba(75,108,247,0.45)";e.target.style.background=T.card;}}
    onBlur={e =>{e.target.style.borderColor=T.line;e.target.style.background=T.card2;}}
  />
);

const SelectEl = ({ opts=[], def, value, onChange, style:sx={} }) => (
  <select value={value} onChange={onChange} defaultValue={def}
    style={{ width:"100%", background:T.card2, border:`1px solid ${T.line}`, borderRadius:8, padding:"8px 11px", fontSize:12.5, color:T.ink, outline:"none", ...sx }}>
    {opts.map(o => typeof o==="string"
      ? <option key={o} value={o}>{o}</option>
      : <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>
);

const CreditCost = ({ action }) => (
  <span style={{ fontSize:10, padding:"2px 7px", borderRadius:5, background:T.amberL, border:`1px solid rgba(231,145,9,0.2)`, color:T.amber, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>
    {CREDIT_COSTS[action]}cr
  </span>
);

// ═══════════════════════════════════════════════════════
//  ROOT APP
// ═══════════════════════════════════════════════════════
export default function App() {
  const [page, setPage]       = useState("overview");
  const [collapsed, setCollapsed] = useState(false);
  const [credits, setCredits] = useState(3000);
  const [user]                = useState({ name:"Abel Nkawula", org:"ARGILETTE LLC", plan:"growth" });

  // Active LLM config — loaded from localStorage, updated in AI Providers settings
  const [llmConfig, setLlmConfig] = useState(() => {
    try { return JSON.parse(localStorage.getItem("argiflow_llm_config") ?? "null"); }
    catch { return null; }
  });

  const saveLlmConfig = (cfg) => {
    setLlmConfig(cfg);
    localStorage.setItem("argiflow_llm_config", JSON.stringify(cfg));
  };

  const deductCredits = useCallback((action) => {
    setCredits(p => Math.max(0, p - (CREDIT_COSTS[action]||0)));
  }, []);

  const allItems = NAV.flatMap(s=>s.items);
  const current  = allItems.find(i=>i.id===page);
  const reg = llmConfig ? LLM_REGISTRY[llmConfig.providerId] : null;

  const PAGES = {
    "overview":          <OverviewPage credits={credits} setPage={setPage} />,
    "lead-intelligence": <LeadIntelPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "workflow-builder":  <WorkflowPage />,
    "ai-agents":         <AgentsPage credits={credits} deductCredits={deductCredits} llmConfig={llmConfig} />,
    "intent-data":       <IntentPage credits={credits} deductCredits={deductCredits} />,
    "website-builder":   <WebBuilderPage />,
    "ai-providers":      <AIProvidersPage llmConfig={llmConfig} saveLlmConfig={saveLlmConfig} />,
    "credits":           <CreditsPage credits={credits} user={user} />,
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:${T.bg};color:${T.ink};font-family:'Plus Jakarta Sans',sans-serif;}
        ::-webkit-scrollbar{width:4px;height:4px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:${T.line};border-radius:2px;}
        @keyframes fadein{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
        @keyframes slidein{from{opacity:0;transform:translateX(8px)}to{opacity:1;transform:none}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes flowdash{to{stroke-dashoffset:-14}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.35}}
        .fadein{animation:fadein 0.28s ease both;}
        .slidein{animation:slidein 0.22s ease both;}
        input,select,textarea,button{font-family:'Plus Jakarta Sans',sans-serif;}
      `}</style>

      <div style={{ display:"flex", height:"100vh", overflow:"hidden" }}>

        {/* SIDEBAR */}
        <aside style={{ width:collapsed?52:214, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column", transition:"width 0.2s ease", overflow:"hidden", zIndex:20, boxShadow:"2px 0 14px rgba(75,108,247,0.05)" }}>

          <div style={{ height:54, display:"flex", alignItems:"center", padding:`0 ${collapsed?"13px":"14px"}`, borderBottom:`1px solid ${T.line}`, gap:10, flexShrink:0 }}>
            <div style={{ width:30, height:30, borderRadius:9, background:`linear-gradient(135deg,${T.blue},${T.violet})`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, boxShadow:`0 3px 10px ${T.blue}35` }}>
              <span style={{ color:"#fff", fontWeight:800, fontSize:14 }}>A</span>
            </div>
            {!collapsed && <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontWeight:800, fontSize:14, color:T.ink }}>ArgiFlow</div>
              <div style={{ fontSize:9.5, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>ARGILETTE</div>
            </div>}
            <button onClick={()=>setCollapsed(p=>!p)} style={{ background:"none", border:"none", color:T.low, cursor:"pointer", fontSize:16, lineHeight:1, padding:4, flexShrink:0, marginLeft:"auto" }}>{collapsed?"›":"‹"}</button>
          </div>

          <div style={{ flex:1, overflowY:"auto", padding:"6px 0" }}>
            {NAV.map(section => (
              <div key={section.section}>
                {!collapsed && <div style={{ padding:"10px 14px 3px", fontSize:9, fontWeight:700, color:T.low, letterSpacing:"0.12em", textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>{section.section}</div>}
                {collapsed && <div style={{ height:5 }} />}
                {section.items.map(item => {
                  const active = page===item.id;
                  return (
                    <div key={item.id} onClick={()=>setPage(item.id)} title={collapsed?item.label:""}
                      style={{ display:"flex", alignItems:"center", gap:8, padding:collapsed?"7px 12px":"5px 9px 5px 12px", margin:"1px 6px", borderRadius:8, cursor:"pointer", background:active?T.blueL:"transparent", borderLeft:`2px solid ${active?T.blue:"transparent"}`, transition:"all 0.12s" }}
                      onMouseEnter={e=>{if(!active)e.currentTarget.style.background=T.card2;}}
                      onMouseLeave={e=>{if(!active)e.currentTarget.style.background="transparent";}}>
                      <span style={{ fontSize:12, color:active?T.blue:T.low, flexShrink:0, opacity:active?1:0.7 }}>{item.icon}</span>
                      {!collapsed && <>
                        <span style={{ flex:1, fontSize:12.5, fontWeight:active?600:400, color:active?T.blue:T.mid, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{item.label}</span>
                        {item.badge && <Badge v={item.badge} />}
                      </>}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* LLM indicator */}
          {!collapsed && (
            <div onClick={()=>setPage("ai-providers")} style={{ margin:"4px 10px", padding:"9px 12px", borderRadius:10, background:llmConfig?T.greenL:T.amberL, border:`1px solid ${llmConfig?"rgba(13,173,116,0.22)":"rgba(231,145,9,0.22)"}`, cursor:"pointer" }}>
              <div style={{ fontSize:9, fontWeight:700, color:T.low, fontFamily:"'JetBrains Mono',monospace", marginBottom:3 }}>AI PROVIDER</div>
              {llmConfig ? (
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  <span style={{ fontSize:13 }}>{reg?.logo}</span>
                  <div>
                    <div style={{ fontSize:12, fontWeight:700, color:T.ink }}>{reg?.name}</div>
                    <div style={{ fontSize:9.5, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{llmConfig.model}</div>
                  </div>
                  <Dot color={T.green} size={5} style={{ marginLeft:"auto" }} />
                </div>
              ) : (
                <div style={{ fontSize:11.5, fontWeight:600, color:T.amber }}>⚠ Not configured →</div>
              )}
            </div>
          )}

          {/* Credits */}
          {!collapsed && (
            <div onClick={()=>setPage("credits")} style={{ margin:"4px 10px 8px", padding:"9px 12px", borderRadius:10, background:credits<200?T.amberL:T.blueL, border:`1px solid ${credits<200?"rgba(231,145,9,0.22)":"rgba(75,108,247,0.2)"}`, cursor:"pointer" }}>
              <div style={{ fontSize:9, fontWeight:700, color:T.low, fontFamily:"'JetBrains Mono',monospace", marginBottom:2 }}>CREDITS</div>
              <div style={{ fontSize:20, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{credits.toLocaleString()}</div>
              {credits<200 && <div style={{ fontSize:10, color:T.amber, fontWeight:600 }}>Low — top up →</div>}
            </div>
          )}

          {/* User */}
          {!collapsed && (
            <div style={{ padding:"12px 14px", borderTop:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:9 }}>
              <div style={{ width:30, height:30, borderRadius:"50%", background:`linear-gradient(135deg,${T.green},${T.teal})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:"#fff", flexShrink:0 }}>{user.name[0]}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12.5, fontWeight:600, color:T.ink, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user.name}</div>
                <div style={{ fontSize:10, color:T.low }}>{user.org}</div>
              </div>
              <span style={{ fontSize:9, padding:"2px 7px", borderRadius:5, background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, textTransform:"uppercase" }}>{user.plan}</span>
            </div>
          )}
        </aside>

        {/* MAIN */}
        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          <header style={{ height:54, background:T.card, borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", padding:"0 20px", gap:12, flexShrink:0, zIndex:10 }}>
            <span style={{ fontWeight:700, fontSize:15, color:T.ink, flex:1 }}>{current?.label||"ArgiFlow"}</span>
            <div style={{ display:"flex", gap:4 }}>
              {[["overview","Overview"],["lead-intelligence","Leads"],["intent-data","Intent"],["ai-agents","AI Agents"],["workflow-builder","Flows"],["website-builder","Sites"],["ai-providers","⚡ AI"]].map(([id,lbl])=>(
                <button key={id} onClick={()=>setPage(id)} style={{ padding:"5px 12px", borderRadius:7, fontSize:12, fontWeight:page===id?600:400, cursor:"pointer", background:page===id?T.blueL:"transparent", border:`1px solid ${page===id?"rgba(75,108,247,0.3)":T.line}`, color:page===id?T.blue:T.mid, transition:"all 0.12s" }}>{lbl}</button>
              ))}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:6, padding:"5px 11px", background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, borderRadius:8 }}>
              <Dot size={5} /><span style={{ fontSize:11.5, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>System live</span>
            </div>
          </header>

          <main key={page} className="fadein" style={{ flex:1, overflow:"auto" }}>
            {PAGES[page]||<BlankPage label={current?.label} />}
          </main>
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════
//  AI PROVIDERS PAGE  ← THE KEY NEW PAGE
//  Change your LLM from the UI — zero code changes
// ═══════════════════════════════════════════════════════
function AIProvidersPage({ llmConfig, saveLlmConfig }) {
  const [draft, setDraft]     = useState(llmConfig ?? { providerId:"anthropic", apiKey:"", model:"", customBaseUrl:"" });
  const [testing, setTesting] = useState(false);
  const [testResult, setTest] = useState(null); // null | {ok, msg}
  const [saved, setSaved]     = useState(false);

  const reg = LLM_REGISTRY[draft.providerId];

  const ud = (k,v) => { setDraft(p=>({...p,[k]:v})); setTest(null); setSaved(false); };

  const testConnection = async () => {
    if (!draft.apiKey) { setTest({ok:false,msg:"Enter your API key first."}); return; }
    setTesting(true); setTest(null);
    try {
      const reply = await callLLM({
        system: "You are a test assistant.",
        userMessage: "Reply with exactly: CONNECTION OK",
        maxTokens: 20,
        providerConfig: { ...draft, model: draft.model || reg.defaultModel },
      });
      setTest({ ok:true, msg:`✓ Connected — model replied: "${reply.trim().slice(0,80)}"` });
    } catch (e) {
      setTest({ ok:false, msg:`✗ ${e.message}` });
    }
    setTesting(false);
  };

  const handleSave = () => {
    saveLlmConfig({ ...draft, model: draft.model || reg.defaultModel });
    setSaved(true);
  };

  return (
    <div style={{ padding:24, display:"flex", flexDirection:"column", gap:20, maxWidth:900 }}>

      {/* Header */}
      <div>
        <div style={{ fontWeight:800, fontSize:20, color:T.ink }}>AI Provider Settings</div>
        <div style={{ fontSize:13, color:T.mid, marginTop:4, lineHeight:1.65 }}>
          Switch between any LLM provider without touching code. Your API key is stored in your browser's local storage only — never sent to our servers.
        </div>
      </div>

      {/* Provider picker */}
      <Card sx={{ padding:24 }}>
        <div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:16 }}>
          Choose Provider
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10, marginBottom:24 }}>
          {Object.entries(LLM_REGISTRY).map(([id, r]) => {
            const active = draft.providerId===id;
            return (
              <div key={id} onClick={()=>ud("providerId",id)}
                style={{ padding:"14px 12px", borderRadius:12, cursor:"pointer", border:`2px solid ${active?"rgba(75,108,247,0.5)":T.line}`, background:active?T.blueL:T.card, transition:"all 0.15s", textAlign:"center" }}
                onMouseEnter={e=>{if(!active){e.currentTarget.style.borderColor=T.lineHi;e.currentTarget.style.background=T.card2;}}}
                onMouseLeave={e=>{if(!active){e.currentTarget.style.borderColor=T.line;e.currentTarget.style.background=T.card;}}}>
                <div style={{ fontSize:28, marginBottom:6 }}>{r.logo}</div>
                <div style={{ fontSize:12.5, fontWeight:active?700:500, color:active?T.blue:T.ink }}>{r.name}</div>
                {active && <div style={{ fontSize:9, color:T.blue, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, marginTop:3 }}>ACTIVE</div>}
              </div>
            );
          })}
        </div>

        {/* Config form */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
          <Field label={`API Key (${reg?.name})`}>
            <div style={{ position:"relative" }}>
              <Input type="password" value={draft.apiKey} onChange={e=>ud("apiKey",e.target.value)}
                placeholder={reg?.placeholder ?? "Your API key"} />
              {draft.apiKey && (
                <span style={{ position:"absolute", right:10, top:"50%", transform:"translateY(-50%)", fontSize:10, color:T.green, fontWeight:600 }}>●●●●●</span>
              )}
            </div>
            {reg?.docsUrl && (
              <div style={{ fontSize:10.5, color:T.low, marginTop:5 }}>
                Get yours at <a href={reg.docsUrl} target="_blank" rel="noreferrer"
                  style={{ color:T.blue, textDecoration:"none" }}>{reg.docsUrl.replace("https://","")}</a>
              </div>
            )}
          </Field>

          <Field label="Model">
            <SelectEl
              value={draft.model || (reg?.defaultModel??"")}
              onChange={e=>ud("model",e.target.value)}
              opts={reg?.modelOptions?.length
                ? reg.modelOptions.map(m=>({value:m,label:m}))
                : [{value:draft.model,label:draft.model||"Enter model below"}]}
            />
            {draft.providerId==="custom" && (
              <Input value={draft.model} onChange={e=>ud("model",e.target.value)}
                placeholder="e.g. llama-3-70b" style={{ marginTop:6 }} />
            )}
          </Field>

          {(draft.providerId==="custom" || draft.customBaseUrl) && (
            <Field label="Custom Base URL (optional)">
              <Input value={draft.customBaseUrl??""} onChange={e=>ud("customBaseUrl",e.target.value)}
                placeholder="https://your-endpoint.com" />
              <div style={{ fontSize:10.5, color:T.low, marginTop:5 }}>
                Override the default API endpoint. Use for self-hosted or proxy setups.
              </div>
            </Field>
          )}

          {draft.providerId==="custom" && (
            <Field label="Request Format">
              <SelectEl value={draft.format||"openai"} onChange={e=>ud("format",e.target.value)}
                opts={[{value:"openai",label:"OpenAI-compatible"},{value:"anthropic",label:"Anthropic"},{value:"gemini",label:"Google Gemini"}]} />
            </Field>
          )}
        </div>

        {/* Test + Save */}
        <div style={{ marginTop:20, display:"flex", alignItems:"center", gap:12 }}>
          <Btn variant="subtle" onClick={testConnection} loading={testing} sx={{ fontSize:12.5 }}>
            {testing ? "Testing…" : "⟳ Test Connection"}
          </Btn>
          <Btn variant="primary" onClick={handleSave} sx={{ fontSize:12.5 }}>
            Save & Activate
          </Btn>
          {saved && (
            <span className="fadein" style={{ fontSize:12, color:T.green, fontWeight:600 }}>
              ✓ Saved — ArgiFlow will now use {reg?.name}
            </span>
          )}
        </div>

        {testResult && (
          <div className="fadein" style={{ marginTop:12, padding:"11px 14px", borderRadius:9, background:testResult.ok?T.greenL:T.redL, border:`1px solid ${testResult.ok?"rgba(13,173,116,0.22)":"rgba(228,68,68,0.22)"}`, fontSize:12.5, color:testResult.ok?T.green:T.red }}>
            {testResult.msg}
          </div>
        )}
      </Card>

      {/* How it works */}
      <Card sx={{ padding:22 }}>
        <div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:14 }}>How provider switching works</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14 }}>
          {[
            { step:"1", title:"Pick provider", desc:"Select from Anthropic, OpenAI, Gemini, Mistral, Groq, Together AI, or any custom OpenAI-compatible endpoint." },
            { step:"2", title:"Enter API key", desc:"Your key is saved to browser localStorage only. It's never sent to ArgiFlow servers — only directly to the provider." },
            { step:"3", title:"All AI features update", desc:"Every AI agent, email writer, and enrichment in the platform instantly uses your chosen provider. No code changes." },
          ].map(s=>(
            <div key={s.step} style={{ padding:"16px 14px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:11 }}>
              <div style={{ width:28, height:28, borderRadius:8, background:T.blueL, border:`1px solid rgba(75,108,247,0.22)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:800, color:T.blue, marginBottom:10 }}>{s.step}</div>
              <div style={{ fontWeight:700, fontSize:13, color:T.ink, marginBottom:5 }}>{s.title}</div>
              <div style={{ fontSize:12, color:T.mid, lineHeight:1.65 }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Provider comparison */}
      <Card sx={{ padding:22 }}>
        <div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:14 }}>Provider Comparison</div>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12.5 }}>
            <thead>
              <tr style={{ background:T.card2 }}>
                {["Provider","Best for","Speed","Cost (approx)","Max tokens"].map(h=>(
                  <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.07em", borderBottom:`1px solid ${T.line}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                ["🟠 Anthropic / Claude","Reasoning, writing","Medium","$3–15 / M tokens","200K"],
                ["🟢 OpenAI / GPT-4o","General tasks","Fast","$5–15 / M tokens","128K"],
                ["🔵 Google Gemini","Long context, speed","Fast","$1.25–5 / M tokens","1M"],
                ["🟡 Mistral","European data, cost","Fast","$2–8 / M tokens","128K"],
                ["⚡ Groq","Ultra-fast inference","Very fast","$0.05–0.27 / M tokens","128K"],
                ["🟣 Together AI","Open-source models","Fast","$0.10–0.90 / M tokens","128K"],
              ].map((row,i)=>(
                <tr key={i} style={{ borderBottom:`1px solid ${T.line}` }}>
                  {row.map((cell,j)=>(
                    <td key={j} style={{ padding:"11px 14px", color:j===0?T.ink:T.mid }}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  OVERVIEW PAGE  — with real data populated
// ═══════════════════════════════════════════════════════
function OverviewPage({ credits, setPage }) {
  const [tick, setTick] = useState(0);
  useEffect(() => { const t = setInterval(()=>setTick(p=>(p+1)%6),2800); return ()=>clearInterval(t); }, []);

  const liveCount = [12847,12891,12948,12982,13010,12998][tick];

  const topStats = [
    { label:"Leads in Database", value:liveCount.toLocaleString(), sub:`+${[203,247,312,189,271,228][tick]} added today`,     top:T.blue,   live:true  },
    { label:"Emails Sent (30d)",  value:"4,829",  sub:"94% delivered · 28% open rate",  top:T.teal  },
    { label:"Meetings Booked",   value:"87",     sub:"AI auto-booked 63 of them",       top:T.amber },
    { label:"Pipeline Value",    value:"$247K",  sub:"3 deals closing this week",        top:T.violet},
  ];

  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16 }}>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
        {topStats.map(m=>(
          <Card key={m.label} sx={{ padding:"18px 20px", position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${m.top}00,${m.top}70,${m.top}00)` }} />
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
              <span style={{ fontSize:10.5, color:T.low, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.05em" }}>{m.label}</span>
              {m.live && <Dot size={5} />}
            </div>
            <div style={{ fontSize:28, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace", letterSpacing:"-0.025em", lineHeight:1 }}>{m.value}</div>
            <div style={{ fontSize:11, color:T.low, marginTop:6 }}>{m.sub}</div>
          </Card>
        ))}
      </div>

      {/* Pipeline + Activity */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 320px", gap:12 }}>
        <Card sx={{ padding:22 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:20 }}>
            <div>
              <div style={{ fontWeight:700, fontSize:15, color:T.ink }}>End-to-End Pipeline</div>
              <div style={{ fontSize:11.5, color:T.low, marginTop:3 }}>Lead found → enriched → contacted → meeting</div>
            </div>
            <Btn variant="blue" sx={{ fontSize:11, padding:"5px 12px" }} onClick={()=>setPage("workflow-builder")}>Edit Flow →</Btn>
          </div>
          {DEMO_PIPELINE.map((s,i)=>(
            <div key={s.label} style={{ marginBottom:10 }}>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:5 }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <div style={{ width:6, height:6, borderRadius:"50%", background:s.color, flexShrink:0 }} />
                  <span style={{ fontSize:11.5, color:T.mid, width:72 }}>{s.label}</span>
                  <span style={{ fontSize:15, fontWeight:700, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{s.count.toLocaleString()}</span>
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  {i>0 && <span style={{ fontSize:10, color:T.low }}>↓{((s.count/DEMO_PIPELINE[i-1].count)*100).toFixed(0)}%</span>}
                  <span style={{ fontSize:10.5, color:T.low, fontFamily:"'JetBrains Mono',monospace", width:36, textAlign:"right" }}>{s.pct}%</span>
                </div>
              </div>
              <div style={{ height:6, background:T.card2, borderRadius:3, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${s.pct}%`, background:s.color, borderRadius:3, opacity:0.7, transition:"width 1.4s ease" }} />
              </div>
            </div>
          ))}
          <div style={{ marginTop:18, paddingTop:16, borderTop:`1px solid ${T.line}`, display:"flex", gap:8 }}>
            <Btn variant="primary" sx={{ fontSize:12 }} onClick={()=>setPage("lead-intelligence")}>Find Leads</Btn>
            <Btn sx={{ fontSize:12 }}>Run Sequence</Btn>
            <Btn sx={{ fontSize:12 }}>View Pipeline</Btn>
          </div>
        </Card>

        {/* Activity */}
        <Card sx={{ padding:20, display:"flex", flexDirection:"column" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:14, color:T.ink }}>AI Activity</div>
            <div style={{ display:"flex", alignItems:"center", gap:5 }}><Dot size={5} /><span style={{ fontSize:10, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>LIVE</span></div>
          </div>
          {DEMO_ACTIVITY.map((a,i)=>(
            <div key={i} style={{ display:"flex", gap:10, padding:"9px 0", borderBottom:i<DEMO_ACTIVITY.length-1?`1px solid ${T.line}`:"none" }}>
              <div style={{ width:28, height:28, borderRadius:8, background:`${T.blue}10`, border:`1px solid ${T.blue}18`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, color:T.blue, flexShrink:0 }}>{a.icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:11.5, color:T.mid, lineHeight:1.5 }}>{a.text}</div>
                <div style={{ fontSize:10, color:T.low, marginTop:2, fontFamily:"'JetBrains Mono',monospace" }}>{a.time}</div>
              </div>
            </div>
          ))}
        </Card>
      </div>

      {/* Agents + Next Action */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <Card sx={{ padding:20 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:14, color:T.ink }}>Agent Health</div>
            <Btn variant="blue" sx={{ fontSize:11, padding:"5px 12px" }} onClick={()=>setPage("ai-agents")}>Manage →</Btn>
          </div>
          {DEMO_AGENT_HEALTH.map(ag=>(
            <div key={ag.name} style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 12px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:9, marginBottom:6 }}>
              <Dot color={ag.status==="active"?T.green:T.amber} />
              <span style={{ flex:1, fontSize:12.5, fontWeight:500, color:T.ink }}>{ag.name}</span>
              <span style={{ fontSize:11.5, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{ag.runs.toLocaleString()}</span>
              <span style={{ fontSize:12, fontWeight:700, color:ag.status==="active"?T.green:T.amber, fontFamily:"'JetBrains Mono',monospace" }}>{ag.rate}%</span>
            </div>
          ))}
        </Card>

        <Card sx={{ padding:20, borderColor:"rgba(13,173,116,0.25)", background:`linear-gradient(135deg,${T.card},${T.greenL}50)` }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
            <div style={{ width:34, height:34, borderRadius:10, background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>✦</div>
            <div>
              <div style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>Next Best Action</div>
              <div style={{ fontSize:10.5, color:T.low }}>AI-recommended</div>
            </div>
          </div>
          <div style={{ background:T.greenL, border:`1px solid rgba(13,173,116,0.18)`, borderRadius:10, padding:16 }}>
            <div style={{ fontSize:14, fontWeight:700, color:T.ink, marginBottom:6 }}>4 hot leads haven't been contacted</div>
            <div style={{ fontSize:12, color:T.mid, lineHeight:1.65, marginBottom:14 }}>Acme Solutions, AfriGrow, BrightScale, and Velocity Health scored 88+ in the last 4 hours. A sequence can go out in 90 seconds.</div>
            <div style={{ display:"flex", gap:8 }}>
              <Btn variant="green" sx={{ flex:1, fontSize:12 }}>Launch AI Sequence →</Btn>
              <Btn sx={{ fontSize:12 }} onClick={()=>setPage("lead-intelligence")}>View</Btn>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  INTENT DATA PAGE  — with real data
// ═══════════════════════════════════════════════════════
function IntentPage({ credits, deductCredits }) {
  const [signals, setSignals]   = useState(DEMO_INTENT_SIGNALS);
  const [domain,  setDomain]    = useState("");
  const [adding,  setAdding]    = useState(false);
  const [filterStr, setFilterStr] = useState("ALL");

  const stats = {
    monitored: 3847,
    active:    signals.length,
    hot_today: signals.filter(s=>s.strength==="HIGH").length,
    avg_score: Math.round(signals.reduce((a,s)=>a+s.score,0)/signals.length),
  };

  const addDomain = async () => {
    if (!domain.trim()) return;
    if ((credits??0) < CREDIT_COSTS.intent_scan) { alert("Not enough credits."); return; }
    setAdding(true); deductCredits("intent_scan");
    // Simulate adding — in production: POST /api/intent/monitor
    await new Promise(r=>setTimeout(r,900));
    const newSig = { id:Date.now(), company:domain.split(".")[0].replace(/^\w/,c=>c.toUpperCase()), domain:domain.trim(), signal:"Recently added to watchlist — monitoring started", strength:"MED", score:50, time:"just now" };
    setSignals(p=>[newSig,...p]); setDomain(""); setAdding(false);
  };

  const filtered = filterStr==="ALL" ? signals : signals.filter(s=>s.strength===filterStr);

  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16 }}>
      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
        {[
          { l:"Companies Monitored", v:stats.monitored.toLocaleString(), c:T.blue  },
          { l:"Active Signals",      v:stats.active,                     c:T.amber },
          { l:"Hot Prospects Today", v:stats.hot_today,                  c:T.red   },
          { l:"Avg Signal Score",    v:`${stats.avg_score}/100`,          c:T.green },
        ].map(m=>(
          <Card key={m.l} sx={{ padding:"16px 18px", position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${m.c}00,${m.c}60,${m.c}00)` }} />
            <div style={{ fontSize:10, color:T.low, textTransform:"uppercase", letterSpacing:"0.05em", fontWeight:600, marginBottom:8 }}>{m.l}</div>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:26, fontWeight:800, color:T.ink }}>{m.v}</div>
          </Card>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 228px", gap:12 }}>
        {/* Feed */}
        <Card sx={{ padding:20 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
            <div>
              <div style={{ fontWeight:700, fontSize:14.5, color:T.ink }}>Live Intent Feed</div>
              <div style={{ fontSize:11.5, color:T.low, marginTop:2 }}>Buying signals from {stats.monitored.toLocaleString()} monitored companies</div>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              {/* Filter pills */}
              {["ALL","HIGH","MED"].map(f=>(
                <button key={f} onClick={()=>setFilterStr(f)} style={{ padding:"4px 10px", borderRadius:6, fontSize:11, fontWeight:filterStr===f?700:400, cursor:"pointer", background:filterStr===f?(f==="HIGH"?T.redL:f==="MED"?T.amberL:T.blueL):T.card2, border:`1px solid ${filterStr===f?(f==="HIGH"?"rgba(228,68,68,0.28)":f==="MED"?"rgba(231,145,9,0.28)":"rgba(75,108,247,0.28)"):T.line}`, color:filterStr===f?(f==="HIGH"?T.red:f==="MED"?T.amber:T.blue):T.mid }}>{f}</button>
              ))}
              <div style={{ display:"flex", alignItems:"center", gap:5 }}><Dot size={5} /><span style={{ fontSize:10, color:T.green, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>LIVE</span></div>
            </div>
          </div>

          {filtered.map((s,i)=>{
            const hi=s.strength==="HIGH";
            return (
              <div key={s.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"11px 0", borderBottom:i<filtered.length-1?`1px solid ${T.line}`:"none" }}>
                <div style={{ width:38, height:38, borderRadius:10, background:T.card2, border:`1px solid ${T.line}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:15, fontWeight:700, color:T.mid, flexShrink:0 }}>{s.company[0]}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:13, fontWeight:600, color:T.ink }}>
                    {s.company}
                    <span style={{ fontWeight:400, color:T.low, fontSize:11 }}> · {s.domain}</span>
                  </div>
                  <div style={{ fontSize:11.5, color:T.mid, marginTop:2 }}>{s.signal}</div>
                </div>
                <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:20, fontWeight:700, color:s.score>=85?T.green:s.score>=70?T.amber:T.blue, minWidth:36, textAlign:"center" }}>{s.score}</div>
                <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5, flexShrink:0 }}>
                  <span style={{ fontSize:9.5, fontWeight:700, padding:"2px 8px", borderRadius:4, background:hi?T.redL:T.amberL, border:`1px solid ${hi?"rgba(228,68,68,0.25)":"rgba(231,145,9,0.25)"}`, color:hi?T.red:T.amber, fontFamily:"'JetBrains Mono',monospace" }}>{s.strength}</span>
                  <span style={{ fontSize:10, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{s.time}</span>
                </div>
                <Btn variant="blue" sx={{ fontSize:11, padding:"5px 10px", flexShrink:0 }}>Act →</Btn>
              </div>
            );
          })}
        </Card>

        {/* Sidebar */}
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <Card sx={{ padding:18 }}>
            <div style={{ fontWeight:700, fontSize:13.5, color:T.ink, marginBottom:12 }}>Signal Sources</div>
            {DEMO_INTENT_SOURCES.map(s=>(
              <div key={s.label} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:9 }}>
                <span style={{ flex:1, fontSize:12, color:T.mid }}>{s.label}</span>
                <span style={{ fontSize:12.5, fontWeight:700, color:T.ink, fontFamily:"'JetBrains Mono',monospace" }}>{s.count.toLocaleString()}</span>
              </div>
            ))}
          </Card>

          <Card sx={{ padding:18 }}>
            <div style={{ fontWeight:600, fontSize:12.5, color:T.ink, marginBottom:4 }}>Monitor a Company</div>
            <div style={{ fontSize:10.5, color:T.low, marginBottom:10, lineHeight:1.5 }}>Costs {CREDIT_COSTS.intent_scan} credits per domain.</div>
            <Input placeholder="acmecorp.com" value={domain} onChange={e=>setDomain(e.target.value)} style={{ marginBottom:8 }} />
            <Btn variant="primary" sx={{ width:"100%", fontSize:12 }} onClick={addDomain} loading={adding}>
              + Add to Watchlist
            </Btn>
          </Card>

          <Card sx={{ padding:18, background:`linear-gradient(135deg,${T.violetL},${T.blueL}80)` }}>
            <div style={{ fontWeight:700, fontSize:13, color:T.ink, marginBottom:6 }}>🎯 Top Opportunity</div>
            <div style={{ fontSize:12.5, fontWeight:600, color:T.ink }}>Acme Solutions</div>
            <div style={{ fontSize:11.5, color:T.mid, marginTop:3, lineHeight:1.6 }}>Score 94 · 7 competitor visits · Ready to buy</div>
            <div style={{ marginTop:10, display:"flex", gap:6 }}>
              <Btn variant="primary" sx={{ fontSize:11, flex:1 }}>Contact Now</Btn>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  LEAD INTELLIGENCE
// ═══════════════════════════════════════════════════════
function LeadIntelPage({ credits, deductCredits, llmConfig }) {
  const [filters, setFilters] = useState({ keywords:"", industry:"", title:"", location:"", size:"", verified:false });
  const [results,   setResults]   = useState(null);
  const [loading,   setLoading]   = useState(false);
  const [sel,       setSel]       = useState(new Set());
  const [preview,   setPreview]   = useState(null);
  const [enriching, setEnriching] = useState(null);
  const [enriched,  setEnriched]  = useState(new Set());
  const [searchErr, setSearchErr] = useState(null);

  const sf=(k,v)=>setFilters(p=>({...p,[k]:v}));
  const toggleSel=id=>setSel(p=>{const n=new Set(p);n.has(id)?n.delete(id):n.add(id);return n;});

  const doSearch=async()=>{
    setLoading(true); setSearchErr(null); setSel(new Set());
    try {
      const data=await fetch("/api/leads/search",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(filters)}).then(r=>{if(!r.ok)throw new Error(r.statusText);return r.json();});
      setResults(data.leads??[]);
    } catch(e){ setSearchErr(e.message); setResults([]); }
    setLoading(false);
  };

  const doEnrich=async(lead)=>{
    if((credits??0)<CREDIT_COSTS.lead_enrich){alert("Not enough credits.");return;}
    setEnriching(lead.id); deductCredits("lead_enrich");
    try{await fetch(`/api/leads/${lead.id}/enrich`,{method:"POST"}).then(r=>{if(!r.ok)throw new Error(r.statusText);}); setEnriched(p=>new Set([...p,lead.id]));}
    catch(e){alert(`Enrichment failed: ${e.message}`);}
    setEnriching(null);
  };

  const intentMeta={hot:{bg:"rgba(228,68,68,0.07)",border:"rgba(228,68,68,0.2)",c:T.red,icon:"🔥"},warm:{bg:"rgba(231,145,9,0.08)",border:"rgba(231,145,9,0.2)",c:T.amber,icon:"🌡"},cold:{bg:"rgba(75,108,247,0.08)",border:"rgba(75,108,247,0.18)",c:T.blue,icon:"❄"}};

  return (
    <div style={{ display:"flex", height:"100%", overflow:"hidden" }}>
      {/* Filters */}
      <div style={{ width:218, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, padding:16, display:"flex", flexDirection:"column", gap:12, overflowY:"auto" }}>
        <div style={{ fontSize:9.5, fontWeight:700, color:T.low, letterSpacing:"0.12em", textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>Search Filters</div>
        {[["keywords","Keywords","Topic, technology…"],["industry","Industry","SaaS, Healthcare…"],["title","Job Title","CEO, VP, Director…"],["location","Location","City or country…"]].map(([k,l,ph])=>(
          <Field key={k} label={l}><Input value={filters[k]} onChange={e=>sf(k,e.target.value)} placeholder={ph} /></Field>
        ))}
        <div>
          <FLabel>Company Size</FLabel>
          <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
            {["1-10","11-50","51-200","201+"].map(s=>(
              <button key={s} onClick={()=>sf("size",filters.size===s?"":s)} style={{ padding:"4px 9px", borderRadius:6, fontSize:11.5, cursor:"pointer", fontWeight:500, background:filters.size===s?T.blueL:T.card2, border:`1px solid ${filters.size===s?"rgba(75,108,247,0.28)":T.line}`, color:filters.size===s?T.blue:T.mid }}>{s}</button>
            ))}
          </div>
        </div>
        <label style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer" }}>
          <div onClick={()=>sf("verified",!filters.verified)} style={{ width:36, height:20, borderRadius:10, background:filters.verified?"rgba(13,173,116,0.2)":T.card2, border:`1px solid ${filters.verified?"rgba(13,173,116,0.35)":T.line}`, position:"relative", cursor:"pointer", transition:"all 0.2s" }}>
            <div style={{ position:"absolute", top:2.5, left:filters.verified?16:2.5, width:13, height:13, borderRadius:"50%", background:filters.verified?T.green:T.low, transition:"all 0.2s" }} />
          </div>
          <span style={{ fontSize:12, color:T.mid, fontWeight:500 }}>Verified emails only</span>
        </label>
        <button onClick={doSearch} disabled={loading} style={{ padding:"10px", background:loading?T.card2:`linear-gradient(135deg,${T.blue},${T.violet})`, border:`1px solid ${loading?T.line:"none"}`, borderRadius:9, color:loading?T.mid:"#fff", fontSize:13, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
          {loading?<><Spinner size={14}/> Searching…</>:"Search 50M+ Leads"}
        </button>
        <div style={{ padding:14, background:T.blueL, border:`1px solid rgba(75,108,247,0.18)`, borderRadius:10, marginTop:"auto" }}>
          <div style={{ fontSize:9, color:T.blue, fontFamily:"'JetBrains Mono',monospace", fontWeight:700, marginBottom:4 }}>DATABASE</div>
          <div style={{ fontSize:24, fontWeight:800, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>50M+</div>
          <div style={{ fontSize:10.5, color:T.mid, marginTop:3, lineHeight:1.5 }}>verified B2B contacts</div>
        </div>
      </div>

      {/* Results */}
      <div style={{ flex:1, overflow:"auto", display:"flex", flexDirection:"column" }}>
        <div style={{ padding:"11px 16px", borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:10, flexShrink:0, background:T.card, position:"sticky", top:0, zIndex:5 }}>
          <span style={{ fontSize:12.5, color:T.mid }}>
            {results===null?"Configure filters and search":results.length===0?"No leads found":sel.size>0?<b style={{color:T.ink}}>{sel.size} selected</b>:<><b style={{color:T.ink}}>{results.length}</b> leads found</>}
          </span>
          {sel.size>0&&<div style={{ display:"flex", gap:6 }}>
            <Btn variant="primary" sx={{ fontSize:11, padding:"5px 12px" }}>Add to Outreach</Btn>
            <Btn variant="blue" sx={{ fontSize:11, padding:"5px 12px" }}>✦ Enrich All <CreditCost action="lead_enrich" /></Btn>
          </div>}
          <div style={{ marginLeft:"auto" }}><Btn sx={{ fontSize:11, padding:"5px 12px" }}>↓ Export CSV</Btn></div>
        </div>
        {searchErr&&<div style={{ margin:16, padding:14, background:T.redL, border:`1px solid rgba(228,68,68,0.22)`, borderRadius:10, fontSize:12.5, color:T.red }}>Error: {searchErr}</div>}
        {results===null&&!loading&&(
          <EmptyState icon="◎" title="Search 50M+ B2B Contacts"
            desc="Enter keywords, industry, job title, or location then hit search."
            action={<Btn variant="primary" sx={{ fontSize:13, padding:"11px 28px" }} onClick={doSearch}>Run Search</Btn>} />
        )}
        {results?.length===0&&!loading&&<EmptyState icon="◎" title="No leads matched" desc="Try broader filters." />}
        {results?.length>0&&(
          <div style={{ padding:16 }}>
            <div style={{ display:"grid", gridTemplateColumns:"32px 1fr 130px 110px 60px 60px 120px", gap:10, padding:"7px 12px", marginBottom:4 }}>
              {["","Lead","Company","Intent","Score","Size",""].map((h,i)=>(
                <div key={i} style={{ fontSize:9.5, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.08em", fontFamily:"'JetBrains Mono',monospace" }}>{h}</div>
              ))}
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
              {results.map(lead=>{
                const isSel=sel.has(lead.id), isDone=enriched.has(lead.id);
                const im=intentMeta[lead.intent]||intentMeta.cold;
                return (
                  <div key={lead.id} style={{ display:"grid", gridTemplateColumns:"32px 1fr 130px 110px 60px 60px 120px", gap:10, alignItems:"center", padding:"11px 12px", background:isSel?T.blueL:T.card, border:`1px solid ${isSel?"rgba(75,108,247,0.25)":T.line}`, borderRadius:11, cursor:"pointer", transition:"all 0.12s" }}
                    onMouseEnter={e=>{if(!isSel){e.currentTarget.style.background=T.card2;e.currentTarget.style.borderColor=T.lineHi;}}}
                    onMouseLeave={e=>{if(!isSel){e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}}>
                    <div onClick={e=>{e.stopPropagation();toggleSel(lead.id);}} style={{ width:16, height:16, borderRadius:4, border:`1.5px solid ${isSel?"transparent":T.lineHi}`, background:isSel?T.blue:"transparent", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", flexShrink:0 }}>
                      {isSel&&<span style={{ color:"#fff",fontSize:9,fontWeight:700 }}>✓</span>}
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:10, minWidth:0 }} onClick={()=>setPreview(preview?.id===lead.id?null:lead)}>
                      <div style={{ width:34, height:34, borderRadius:"50%", background:`linear-gradient(135deg,${T.blueL},${T.violetL})`, border:`1.5px solid ${T.line}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:T.blue, flexShrink:0 }}>{lead.name?.split(" ").map(n=>n[0]).join("")??"?"}</div>
                      <div style={{ minWidth:0 }}>
                        <div style={{ fontSize:13, fontWeight:600, color:T.ink, display:"flex", alignItems:"center", gap:5 }}>
                          {lead.name}
                          {lead.verified&&<span style={{ fontSize:9,color:T.green,background:T.greenL,padding:"1px 5px",borderRadius:3,border:`1px solid rgba(13,173,116,0.2)` }}>✓</span>}
                          {isDone&&<span style={{ fontSize:9,color:T.violet,background:T.violetL,padding:"1px 5px",borderRadius:3 }}>enriched</span>}
                        </div>
                        <div style={{ fontSize:11, color:T.low, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", marginTop:1 }}>{lead.title} · {lead.email}</div>
                      </div>
                    </div>
                    <div onClick={()=>setPreview(preview?.id===lead.id?null:lead)}>
                      <div style={{ fontSize:12.5, fontWeight:500, color:T.ink }}>{lead.company}</div>
                      <div style={{ fontSize:10.5, color:T.low }}>{lead.industry}</div>
                    </div>
                    <span style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:10.5, fontWeight:600, padding:"3px 9px", borderRadius:5, background:im.bg, border:`1px solid ${im.border}`, color:im.c, textTransform:"uppercase", letterSpacing:"0.04em" }}>{im.icon} {lead.intent}</span>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:18, fontWeight:700, color:lead.score>=85?T.green:lead.score>=70?T.amber:T.blue }}>{lead.score}</div>
                    <div style={{ fontSize:11.5, color:T.mid }}>{lead.size}</div>
                    <div style={{ display:"flex", gap:5 }} onClick={e=>e.stopPropagation()}>
                      <button onClick={()=>setPreview(preview?.id===lead.id?null:lead)} style={{ padding:"4px 8px",background:T.card2,border:`1px solid ${T.line}`,borderRadius:6,color:T.mid,fontSize:10.5,cursor:"pointer" }}>View</button>
                      <button onClick={()=>doEnrich(lead)} disabled={enriching===lead.id||isDone} style={{ padding:"4px 8px",background:isDone?T.greenL:T.violetL,border:`1px solid ${isDone?"rgba(13,173,116,0.22)":"rgba(123,91,251,0.22)"}`,borderRadius:6,color:isDone?T.green:T.violet,fontSize:10.5,cursor:"pointer",fontWeight:600 }}>
                        {enriching===lead.id?<Spinner size={10}/>:isDone?"✓":"✦ AI"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Preview */}
      {preview&&(
        <div className="slidein" style={{ width:264, flexShrink:0, background:T.card, borderLeft:`1px solid ${T.line}`, padding:16, overflowY:"auto", display:"flex", flexDirection:"column", gap:13 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>Lead Profile</span>
            <button onClick={()=>setPreview(null)} style={{ background:"none",border:"none",color:T.low,cursor:"pointer",fontSize:20 }}>×</button>
          </div>
          <div style={{ textAlign:"center" }}>
            <div style={{ width:52, height:52, borderRadius:"50%", background:`linear-gradient(135deg,${T.blue},${T.violet})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, fontWeight:700, color:"#fff", margin:"0 auto 10px", boxShadow:`0 4px 16px ${T.blue}28` }}>{preview.name?.split(" ").map(n=>n[0]).join("")??""}</div>
            <div style={{ fontWeight:700, fontSize:15, color:T.ink }}>{preview.name}</div>
            <div style={{ fontSize:11.5, color:T.mid, marginTop:2 }}>{preview.title}</div>
            <div style={{ fontSize:11, color:T.low }}>{preview.company}</div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:7 }}>
            {[["Score",`${preview.score}/100`],["Email",preview.email],["Industry",preview.industry],["Size",`${preview.size} emp`]].filter(([,v])=>v).map(([l,v])=>(
              <div key={l} style={{ padding:"9px 11px", background:T.card2, border:`1px solid ${T.line}`, borderRadius:9 }}>
                <div style={{ fontSize:9.5, color:T.low, marginBottom:2, textTransform:"uppercase", letterSpacing:"0.06em", fontWeight:600 }}>{l}</div>
                <div style={{ fontSize:12, color:T.mid, wordBreak:"break-all" }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:7, marginTop:"auto" }}>
            <Btn variant="primary" sx={{ fontSize:12 }}>✦ AI Write Email <CreditCost action="ai_email" /></Btn>
            <Btn variant="green" sx={{ fontSize:12 }}>Add to Sequence</Btn>
            <Btn sx={{ fontSize:12 }}>Create Deal</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  AI AGENTS PAGE  — uses callLLM (any provider)
// ═══════════════════════════════════════════════════════
function AgentsPage({ credits, deductCredits, llmConfig }) {
  const BUILT_IN_AGENTS = [
    { id:"scout",   name:"Lead Scout",        status:"active", category:"Intelligence", desc:"Finds and scores B2B leads matching your ICP across 50M+ contacts.",              system:"You are Lead Scout, a B2B lead research specialist. Find, qualify, and score leads step by step. Show your analysis clearly." },
    { id:"writer",  name:"Cold Email Writer", status:"active", category:"Outreach",     desc:"Reads each lead's company and role, then writes a genuinely unique cold email.",   system:"You are a cold email copywriter. Write personalized, non-spammy cold emails that get replies. Be specific and human." },
    { id:"reply",   name:"Reply Analyzer",   status:"active", category:"Outreach",     desc:"Detects intent in every reply and drafts the perfect response automatically.",      system:"You are a sales reply specialist. Analyze email replies, detect buying intent, and draft the ideal response." },
    { id:"intent",  name:"Intent Monitor",   status:"paused", category:"Intelligence", desc:"Monitors companies for buying signals: job postings, pricing visits, news.",        system:"You are an intent data analyst. Identify and explain buying signals from company activity." },
    { id:"booker",  name:"Meeting Booker",   status:"active", category:"CRM",          desc:"When interest is detected, books the meeting and handles scheduling.",              system:"You are a meeting booking specialist. Craft messages that convert interested prospects into booked calls." },
    { id:"forum",   name:"Forum Prospector", status:"active", category:"Intelligence", desc:"Scans Reddit, LinkedIn, and forums for prospects asking about your solution.",      system:"You are a forum prospecting agent. Find people who are asking for solutions you provide and craft outreach." },
  ];

  const [selAgent, setSelAgent] = useState(BUILT_IN_AGENTS[0]);
  const [prompt,   setPrompt]   = useState("");
  const [running,  setRunning]  = useState(false);
  const [output,   setOutput]   = useState("");
  const [runErr,   setRunErr]   = useState(null);
  const outputRef = useRef(null);

  const run = async () => {
    if (!prompt.trim()) return;
    if (!llmConfig) { setRunErr("No AI provider configured. Go to Settings → AI Providers."); return; }
    if ((credits??0) < CREDIT_COSTS.agent_run) { setRunErr("Not enough credits."); return; }
    setRunning(true); setOutput(""); setRunErr(null); deductCredits("agent_run");
    try {
      const result = await callLLM({ system:selAgent.system, userMessage:prompt, maxTokens:800, providerConfig:llmConfig });
      setOutput(result);
    } catch(e) { setRunErr(e.message); }
    setRunning(false);
    if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight;
  };

  const catC={ Intelligence:T.blue, Outreach:T.violet, CRM:T.green };
  const catI={ Intelligence:"◎", Outreach:"→", CRM:"◈" };

  const reg = llmConfig ? LLM_REGISTRY[llmConfig.providerId] : null;

  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16 }}>
      <div>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12 }}>
          <div>
            <div style={{ fontWeight:800, fontSize:15.5, color:T.ink }}>AI Agent Catalog</div>
            <div style={{ fontSize:12, color:T.mid, marginTop:3 }}>
              {llmConfig ? <>Running on <b>{reg?.name}</b> · {llmConfig.model}</> : <span style={{ color:T.amber }}>⚠ No AI provider — configure in AI Providers →</span>}
            </div>
          </div>
          <Btn variant="primary" sx={{ fontSize:12 }}>+ Deploy Custom Agent</Btn>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10 }}>
          {BUILT_IN_AGENTS.map(ag=>{
            const isSel=selAgent.id===ag.id, cc=catC[ag.category]||T.blue;
            return (
              <Card key={ag.id} onClick={()=>setSelAgent(ag)} sx={{ padding:18, cursor:"pointer", transition:"all 0.15s", borderColor:isSel?"rgba(75,108,247,0.35)":T.line, boxShadow:isSel?`0 0 0 3px ${T.blueL},0 4px 16px rgba(75,108,247,0.1)`:undefined, background:isSel?`linear-gradient(135deg,${T.card},${T.blueL}80)`:T.card, position:"relative", overflow:"hidden" }}>
                {isSel&&<div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${cc}00,${cc}70,${cc}00)` }} />}
                <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:10 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <div style={{ width:32, height:32, borderRadius:9, background:`${cc}14`, border:`1px solid ${cc}20`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, color:cc }}>{catI[ag.category]}</div>
                    <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>{ag.name}</span>
                  </div>
                  <Dot color={ag.status==="active"?T.green:T.amber} />
                </div>
                <div style={{ fontSize:12, color:T.mid, lineHeight:1.6, minHeight:48 }}>{ag.desc}</div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Console */}
      <Card>
        <div style={{ background:T.card2, padding:"10px 16px", borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:10 }}>
          <div style={{ display:"flex", gap:6 }}>{[T.red,T.amber,T.green].map(c=><div key={c} style={{ width:11, height:11, borderRadius:"50%", background:c, opacity:0.7 }} />)}</div>
          <div style={{ flex:1, background:T.card, border:`1px solid ${T.line}`, borderRadius:6, padding:"4px 12px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <span style={{ fontSize:11, color:T.mid, fontFamily:"'JetBrains Mono',monospace" }}>
              {selAgent.name} · {llmConfig ? `${reg?.logo} ${llmConfig.model}` : "⚠ no provider"}
            </span>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:9, padding:"2px 7px", borderRadius:4, background:T.amberL, border:`1px solid rgba(231,145,9,0.22)`, color:T.amber, fontFamily:"'JetBrains Mono',monospace", fontWeight:700 }}>{CREDIT_COSTS.agent_run}cr / run</span>
              <span style={{ fontSize:10, color:running?T.green:output?"#059669":T.low, fontFamily:"'JetBrains Mono',monospace", fontWeight:600 }}>{running?"RUNNING":output?"COMPLETE":"READY"}</span>
            </div>
          </div>
          {running&&<Spinner size={16}/>}
        </div>

        <div style={{ padding:16, display:"flex", flexDirection:"column", gap:10 }}>
          <div>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
              <FLabel>Describe what you want this agent to do</FLabel>
              <span style={{ fontSize:11, color:T.low }}>Balance: <b style={{color:T.ink,fontFamily:"'JetBrains Mono',monospace"}}>{credits?.toLocaleString()}</b> credits</span>
            </div>
            <div style={{ display:"flex", gap:8 }}>
              <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={3}
                placeholder={`Tell ${selAgent.name} what to do… e.g. "Find 30 dental practice owners in Texas with verified emails"`}
                style={{ flex:1, background:T.card2, border:`1px solid ${T.line}`, borderRadius:9, padding:"10px 12px", fontSize:13, color:T.ink, outline:"none", resize:"none", lineHeight:1.55 }}
                onFocus={e=>{e.target.style.borderColor="rgba(75,108,247,0.4)";e.target.style.background=T.card;}}
                onBlur={e=>{e.target.style.borderColor=T.line;e.target.style.background=T.card2;}}
              />
              <button onClick={run} disabled={running||!prompt.trim()} style={{ padding:"0 24px", borderRadius:10, background:running||!prompt.trim()?T.card2:`linear-gradient(135deg,${T.violet},${T.blue})`, border:running?`1px solid ${T.line}`:"none", color:running||!prompt.trim()?T.mid:"#fff", fontSize:13, fontWeight:700, cursor:running||!prompt.trim()?"not-allowed":"pointer", flexShrink:0, boxShadow:!running&&prompt.trim()?`0 4px 14px ${T.blue}28`:"none" }}>
                {running?<div style={{display:"flex",gap:6,alignItems:"center"}}><Spinner size={14}/>Running</div>:"▶  Run"}
              </button>
            </div>
          </div>

          <div ref={outputRef} style={{ background:T.card2, border:`1px solid ${T.line}`, borderRadius:10, padding:16, minHeight:180, maxHeight:320, overflowY:"auto", fontSize:13, lineHeight:1.7, color:T.mid }}>
            {!output&&!running&&!runErr&&<span style={{ color:T.low, fontStyle:"italic" }}>Output streams here after you hit Run…</span>}
            {running&&<div style={{ display:"flex", alignItems:"center", gap:10, color:T.mid }}><Spinner size={14}/>Calling {reg?.name} API ({selAgent.name})…</div>}
            {runErr&&<div style={{ color:T.red }}>⚠ {runErr}</div>}
            {output&&<div style={{ whiteSpace:"pre-wrap", color:T.ink }}>{output}</div>}
          </div>

          {output&&!running&&(
            <div className="fadein" style={{ display:"flex", gap:10, alignItems:"center", padding:"12px 16px", background:T.greenL, border:`1px solid rgba(13,173,116,0.22)`, borderRadius:10 }}>
              <div style={{ width:34, height:34, borderRadius:9, background:"rgba(13,173,116,0.15)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontSize:18 }}>✓</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13, fontWeight:700, color:T.green }}>Agent completed</div>
                <div style={{ fontSize:11.5, color:T.mid, marginTop:2 }}>Review the output and take action on the results.</div>
              </div>
              <Btn sx={{ fontSize:11, flexShrink:0 }} onClick={()=>{setOutput("");setPrompt("");}}>Clear</Btn>
              <Btn variant="primary" sx={{ fontSize:11, flexShrink:0 }}>Save to CRM</Btn>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  WORKFLOW BUILDER
// ═══════════════════════════════════════════════════════
function WorkflowPage() {
  const [workflows, setWorkflows] = useState(null);
  const [loading, setLoading]     = useState(true);
  const [activeIdx, setActiveIdx] = useState(0);
  const [selNode, setSelNode]     = useState(null);

  useEffect(()=>{
    fetch("/api/workflows").then(r=>r.ok?r.json():Promise.reject(r.statusText))
      .then(d=>setWorkflows(d.workflows??[]))
      .catch(()=>setWorkflows([]))
      .finally(()=>setLoading(false));
  },[]);

  const active = workflows?.[activeIdx];
  const nodes  = active?.nodes??[];
  const edges  = active?.edges??[];
  const selNodeObj = nodes.find(n=>n.id===selNode);

  const ADD=[["🤖","AI Email"],["⏳","Wait"],["🔀","If / Else"],["🏷","Tag"],["💬","SMS"],["🔔","Notify"],["💰","Deal"],["🔌","Webhook"]];

  return (
    <div style={{ display:"flex", height:"100%", overflow:"hidden" }}>
      <div style={{ width:212, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column" }}>
        <div style={{ padding:"13px 12px 9px", borderBottom:`1px solid ${T.line}` }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:8 }}>
            <span style={{ fontSize:10, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.1em", fontFamily:"'JetBrains Mono',monospace" }}>Workflows</span>
            <button style={{ width:22, height:22, borderRadius:6, background:T.blueL, border:`1px solid rgba(75,108,247,0.25)`, color:T.blue, fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700 }}>+</button>
          </div>
          {loading?<Spinner size={18}/>:workflows?.length===0?(
            <div style={{ fontSize:12, color:T.low, padding:"8px 0" }}>No workflows yet. Create one.</div>
          ):workflows.map((wf,i)=>(
            <div key={wf.id} onClick={()=>{setActiveIdx(i);setSelNode(null);}} style={{ padding:"9px 10px", borderRadius:9, marginBottom:4, cursor:"pointer", background:activeIdx===i?T.blueL:"transparent", border:`1px solid ${activeIdx===i?"rgba(75,108,247,0.25)":"transparent"}`, transition:"all 0.12s" }}>
              <div style={{ fontSize:12, fontWeight:activeIdx===i?600:400, color:activeIdx===i?T.blue:T.mid, marginBottom:5 }}>{wf.name}</div>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <span style={{ fontSize:9, fontWeight:700, padding:"2px 6px", borderRadius:4, textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace", background:wf.status==="active"?T.greenL:T.amberL, border:`1px solid ${wf.status==="active"?"rgba(13,173,116,0.22)":"rgba(231,145,9,0.22)"}`, color:wf.status==="active"?T.green:T.amber }}>{wf.status}</span>
                <span style={{ fontSize:10, color:T.low, fontFamily:"'JetBrains Mono',monospace" }}>{wf.runs?.toLocaleString()??0}</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding:"10px 12px", flex:1, overflowY:"auto" }}>
          <div style={{ fontSize:9.5, fontWeight:700, color:T.low, textTransform:"uppercase", letterSpacing:"0.1em", fontFamily:"'JetBrains Mono',monospace", marginBottom:8 }}>Add Step</div>
          {ADD.map(([ic,lbl])=>(
            <div key={lbl} draggable style={{ display:"flex", alignItems:"center", gap:9, padding:"7px 8px", borderRadius:8, marginBottom:3, cursor:"grab", background:T.card, border:`1px solid ${T.line}`, transition:"all 0.12s" }}
              onMouseEnter={e=>{e.currentTarget.style.background=T.card2;e.currentTarget.style.borderColor=T.lineHi;}}
              onMouseLeave={e=>{e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}>
              <span style={{ fontSize:14 }}>{ic}</span><span style={{ fontSize:12, color:T.mid, fontWeight:500 }}>{lbl}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"10px 16px", borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", gap:10, background:T.card }}>
          <div style={{ flex:1, display:"flex", alignItems:"center", gap:8 }}>
            {active&&<Dot color={active.status==="active"?T.green:T.amber}/>}
            <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>{active?.name??"Select a workflow"}</span>
          </div>
          <Btn sx={{ fontSize:11, padding:"5px 11px" }}>⟳ Test</Btn>
          <Btn variant="blue" sx={{ fontSize:11, padding:"5px 11px" }}>⏸ Pause</Btn>
          <Btn variant="primary" sx={{ fontSize:11, padding:"5px 13px" }}>Save</Btn>
        </div>
        <div style={{ flex:1, overflow:"auto", position:"relative", background:T.bg, backgroundImage:`radial-gradient(${T.lineHi} 1px,transparent 1px)`, backgroundSize:"28px 28px" }}>
          {loading?<div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100%" }}><Spinner size={28}/></div>
           :!active||nodes.length===0?<EmptyState icon="⬟" title="Canvas is empty" desc="Drag steps from the left panel or select a workflow."/>
           :(
            <div style={{ position:"relative", minHeight:900, minWidth:640 }}>
              <svg style={{ position:"absolute", inset:0, width:"100%", height:"100%", pointerEvents:"none", overflow:"visible" }}>
                {edges.map((edge,i)=>{
                  const fn=nodes.find(n=>n.id===edge.from), tn=nodes.find(n=>n.id===edge.to);
                  if(!fn||!tn)return null;
                  const fx=fn.x+96,fy=fn.y+56,tx=tn.x+96,ty=tn.y+2,cy=(fy+ty)/2;
                  return(<g key={i}><path d={`M${fx},${fy} C${fx},${cy} ${tx},${cy} ${tx},${ty}`} stroke="rgba(75,108,247,0.28)" strokeWidth="2" fill="none" strokeDasharray="5 4" style={{ animation:"flowdash 1s linear infinite" }}/><circle cx={tx} cy={ty} r="3" fill={T.blue}/>{edge.label&&<text x={(fx+tx)/2+10} y={cy} fill={T.low} fontSize="10" fontFamily="Plus Jakarta Sans">{edge.label}</text>}</g>);
                })}
              </svg>
              {nodes.map(node=>{
                const isSel=selNode===node.id;
                const bgs={trigger:T.amberL,action:T.card,condition:T.blueL};
                const bds={trigger:isSel?T.amber:"rgba(231,145,9,0.25)",action:isSel?T.blue:T.line,condition:isSel?T.blue:"rgba(75,108,247,0.28)"};
                return(<div key={node.id} onClick={()=>setSelNode(node.id)} style={{ position:"absolute", left:node.x, top:node.y, width:192, background:bgs[node.type]||T.card, border:`1.5px solid ${bds[node.type]||T.line}`, borderRadius:12, padding:"12px 14px", cursor:"pointer", transition:"all 0.15s", boxShadow:isSel?`0 0 0 3px rgba(75,108,247,0.12),0 6px 20px rgba(0,0,0,0.08)`:"0 2px 8px rgba(0,0,0,0.05)" }}>
                  {node.type==="trigger"&&<div style={{ fontSize:9, fontWeight:700, color:T.amber, letterSpacing:"0.1em", marginBottom:5, textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>⚡ TRIGGER</div>}
                  {node.type==="condition"&&<div style={{ fontSize:9, fontWeight:700, color:T.blue, letterSpacing:"0.1em", marginBottom:5, textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace" }}>⬡ CONDITION</div>}
                  <div style={{ fontSize:13, fontWeight:700, color:T.ink, marginBottom:3 }}>{node.label}</div>
                  <div style={{ fontSize:10.5, color:T.low }}>{node.subtitle}</div>
                </div>);
              })}
            </div>
          )}
        </div>
      </div>

      {selNodeObj&&(
        <div className="slidein" style={{ width:232, flexShrink:0, background:T.card, borderLeft:`1px solid ${T.line}`, padding:16, overflowY:"auto" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <span style={{ fontWeight:700, fontSize:13.5, color:T.ink }}>Configure</span>
            <button onClick={()=>setSelNode(null)} style={{ marginLeft:"auto", background:"none", border:"none", color:T.low, cursor:"pointer", fontSize:18 }}>×</button>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            <Field label="Step Name"><Input defaultValue={selNodeObj.label}/></Field>
            {selNodeObj.type==="trigger"&&<Field label="Trigger"><SelectEl opts={["New Lead Found","Intent: Hot","Email Replied","Form Submitted"]} def="New Lead Found"/></Field>}
            {selNodeObj.type==="condition"&&<Field label="Condition"><SelectEl opts={["Score ≥ 75","Score ≥ 85","Email Verified","Reply: Interested"]} def="Score ≥ 75"/></Field>}
            <div style={{ paddingTop:10, borderTop:`1px solid ${T.line}` }}>
              <label style={{ display:"flex", alignItems:"center", gap:7, cursor:"pointer" }}><input type="checkbox" style={{ width:13, height:13 }}/><span style={{ fontSize:11.5, color:T.low }}>Continue on error</span></label>
            </div>
            <Btn variant="primary" sx={{ fontSize:12 }}>Apply</Btn>
            <Btn variant="danger" sx={{ fontSize:12 }}>Remove Step</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  WEBSITE BUILDER (condensed — same as before)
// ═══════════════════════════════════════════════════════
function WebBuilderPage() {
  const [view, setView]   = useState("gallery");
  const [blocks, setBlocks] = useState([
    { id:"b1", type:"hero",     label:"Hero Section",  height:200 },
    { id:"b2", type:"features", label:"Features Grid", height:160 },
    { id:"b3", type:"pricing",  label:"Pricing Table", height:180 },
    { id:"b4", type:"cta",      label:"Call to Action",height:120 },
  ]);
  const [selBlock, setSelBlock] = useState("b1");
  const [tab, setTab]           = useState("sections");
  const [device, setDevice]     = useState("desktop");
  const [hovBlock, setHovBlock] = useState(null);
  const [published, setPublished] = useState(false);

  const WB_TEMPLATES=[{id:"blank",label:"Blank Canvas",emoji:"⬜",desc:"Start from scratch"},{id:"saas",label:"SaaS Landing",emoji:"🚀",desc:"Hero · Features · Pricing · CTA"},{id:"agency",label:"Agency Site",emoji:"💼",desc:"Services · Portfolio · Contact"},{id:"portfolio",label:"Portfolio",emoji:"🎨",desc:"About · Work · Testimonials"},{id:"ecommerce",label:"E-commerce",emoji:"🛍",desc:"Products · Cart · Checkout"},{id:"blog",label:"Blog / Media",emoji:"📰",desc:"Posts · Categories · Newsletter"}];
  const WB_SECTIONS=[{id:"hero",label:"Hero",icon:"⬟",c:T.blue},{id:"features",label:"Features",icon:"◈",c:T.violet},{id:"pricing",label:"Pricing",icon:"◎",c:T.green},{id:"testimonial",label:"Testimonials",icon:"◷",c:T.amber},{id:"cta",label:"CTA",icon:"→",c:T.teal},{id:"contact",label:"Contact Form",icon:"◫",c:T.blue},{id:"faq",label:"FAQ",icon:"⬡",c:T.violet},{id:"gallery",label:"Gallery",icon:"⬟",c:T.amber},{id:"video",label:"Video",icon:"◉",c:T.red},{id:"footer",label:"Footer",icon:"▤",c:T.mid}];
  const WB_ELEMENTS=[{label:"Heading",icon:"T",c:T.ink},{label:"Text",icon:"¶",c:T.mid},{label:"Button",icon:"◻",c:T.blue},{label:"Image",icon:"⬟",c:T.violet},{label:"Video",icon:"▶",c:T.red},{label:"Form",icon:"◫",c:T.teal},{label:"Icon",icon:"⊙",c:T.amber},{label:"Divider",icon:"—",c:T.low},{label:"Columns",icon:"⬡⬡",c:T.violet},{label:"Card",icon:"⬟",c:T.blue},{label:"Code",icon:"</>",c:T.teal},{label:"Spacer",icon:"↕",c:T.low}];

  const moveBlock=(id,dir)=>setBlocks(p=>{const a=[...p],i=a.findIndex(b=>b.id===id);if(dir==="up"&&i===0||dir==="dn"&&i===a.length-1)return p;const ti=dir==="up"?i-1:i+1;[a[i],a[ti]]=[a[ti],a[i]];return a;});
  const removeBlock=id=>{setBlocks(p=>p.filter(b=>b.id!==id));if(selBlock===id)setSelBlock(null);};
  const addSection=sec=>{const nb={id:`b${Date.now()}`,type:sec.id,label:sec.label,height:150};setBlocks(p=>[...p,nb]);setSelBlock(nb.id);};
  const selBlockObj=blocks.find(b=>b.id===selBlock);

  const Preview=({block})=>{
    const p={
      hero:(<div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:8,padding:"0 20px" }}><div style={{ width:"55%",height:12,background:`linear-gradient(90deg,${T.blue}70,${T.violet}70)`,borderRadius:6 }}/><div style={{ width:"70%",height:7,background:T.card3,borderRadius:4 }}/><div style={{ display:"flex",gap:8,marginTop:6 }}><div style={{ width:72,height:26,background:T.blue,borderRadius:7 }}/><div style={{ width:72,height:26,background:T.card2,border:`1px solid ${T.line}`,borderRadius:7 }}/></div></div>),
      features:(<div style={{ display:"flex",gap:10,padding:"12px 16px",height:"100%",alignItems:"center" }}>{[T.blue,T.violet,T.green].map((c,i)=>(<div key={i} style={{ flex:1,background:T.card2,border:`1px solid ${T.line}`,borderRadius:9,padding:"10px 8px",height:"76%",display:"flex",flexDirection:"column",gap:5 }}><div style={{ width:20,height:20,borderRadius:6,background:`${c}18` }}/><div style={{ height:6,width:"80%",background:T.card3,borderRadius:3 }}/><div style={{ height:4,width:"90%",background:T.card3,borderRadius:3 }}/></div>))}</div>),
      pricing:(<div style={{ display:"flex",gap:10,padding:"12px 16px",height:"100%",alignItems:"center" }}>{[false,true,false].map((hi,i)=>(<div key={i} style={{ flex:1,background:hi?T.blueL:T.card2,border:`1px solid ${hi?"rgba(75,108,247,0.3)":T.line}`,borderRadius:9,padding:"10px 8px",height:"88%",display:"flex",flexDirection:"column",gap:4,position:"relative" }}>{hi&&<div style={{ position:"absolute",top:-8,left:"50%",transform:"translateX(-50%)",background:T.blue,color:"#fff",fontSize:8,padding:"2px 8px",borderRadius:4,fontWeight:700,whiteSpace:"nowrap" }}>POPULAR</div>}<div style={{ height:6,width:"60%",background:T.card3,borderRadius:3 }}/><div style={{ height:12,width:"40%",background:hi?`${T.blue}40`:T.card3,borderRadius:3 }}/><div style={{ flex:1 }}/><div style={{ height:20,background:hi?T.blue:T.card3,borderRadius:5 }}/></div>))}</div>),
      cta:(<div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:8,padding:"0 20px",background:`linear-gradient(135deg,${T.blueL},${T.violetL})` }}><div style={{ width:"50%",height:10,background:`${T.blue}50`,borderRadius:5 }}/><div style={{ width:"65%",height:6,background:T.card3,borderRadius:3 }}/><div style={{ width:90,height:28,background:T.blue,borderRadius:8,marginTop:4 }}/></div>),
    };
    return p[block.type]||<div style={{ display:"flex",alignItems:"center",justifyContent:"center",height:"100%",fontSize:22,opacity:0.15 }}>⬟</div>;
  };

  if(view==="gallery") return (
    <div style={{ padding:24, display:"flex", flexDirection:"column", gap:20 }}>
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between" }}>
        <div><div style={{ fontWeight:800, fontSize:21, color:T.ink }}>Website Builder</div><div style={{ fontSize:13, color:T.mid, marginTop:4, lineHeight:1.65, maxWidth:520 }}>Build landing pages and client sites — no code needed. Connected to CRM, forms, and analytics.</div></div>
        <Btn variant="primary" sx={{ fontSize:12.5 }} onClick={()=>setView("editor")}>Start from Blank</Btn>
      </div>
      <div>
        <div style={{ fontWeight:700, fontSize:16, color:T.ink, marginBottom:14 }}>Templates</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14 }}>
          {WB_TEMPLATES.map(tpl=>(
            <div key={tpl.id} onClick={()=>setView("editor")} style={{ background:T.card, border:`1px solid ${T.line}`, borderRadius:14, overflow:"hidden", cursor:"pointer", transition:"all 0.18s" }}
              onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(75,108,247,0.36)";e.currentTarget.style.boxShadow=`0 8px 28px rgba(75,108,247,0.12)`;e.currentTarget.style.transform="translateY(-2px)";}}
              onMouseLeave={e=>{e.currentTarget.style.borderColor=T.line;e.currentTarget.style.boxShadow="none";e.currentTarget.style.transform="none";}}>
              <div style={{ height:140, background:`linear-gradient(135deg,${T.blueL},${T.violetL})`, display:"flex", alignItems:"center", justifyContent:"center" }}><div style={{ fontSize:46, opacity:0.38 }}>{tpl.emoji}</div></div>
              <div style={{ padding:14 }}><div style={{ fontWeight:700, fontSize:14, color:T.ink, marginBottom:4 }}>{tpl.label}</div><div style={{ fontSize:12, color:T.mid }}>{tpl.desc}</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", overflow:"hidden" }}>
      <div style={{ height:50, background:T.card, borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", padding:"0 14px", gap:10, flexShrink:0 }}>
        <button onClick={()=>setView("gallery")} style={{ background:"none", border:"none", color:T.mid, cursor:"pointer", fontSize:13, fontWeight:500 }}>← Sites</button>
        <div style={{ width:1, height:20, background:T.line }}/>
        <input defaultValue="My Site" style={{ background:"none", border:"none", fontSize:13.5, fontWeight:700, color:T.ink, outline:"none", minWidth:120 }}/>
        <div style={{ width:1, height:20, background:T.line }}/>
        <div style={{ display:"flex", gap:2, background:T.card2, border:`1px solid ${T.line}`, borderRadius:8, padding:3 }}>
          {[["desktop","🖥"],["tablet","📱"],["mobile","📲"]].map(([v,ic])=>(
            <button key={v} onClick={()=>setDevice(v)} style={{ padding:"4px 10px", borderRadius:6, fontSize:11.5, cursor:"pointer", background:device===v?T.card:T.card2, border:`1px solid ${device===v?T.line:"transparent"}`, color:device===v?T.ink:T.low }}>{ic}</button>
          ))}
        </div>
        <div style={{ marginLeft:"auto", display:"flex", gap:7 }}>
          <Btn sx={{ fontSize:11.5, padding:"5px 12px" }}>Save</Btn>
          <Btn variant={published?"green":"primary"} sx={{ fontSize:11.5, padding:"5px 14px" }} onClick={()=>setPublished(true)}>{published?"✓ Published":"⬆ Publish"}</Btn>
        </div>
      </div>

      <div style={{ flex:1, display:"flex", overflow:"hidden" }}>
        <div style={{ width:218, flexShrink:0, background:T.card, borderRight:`1px solid ${T.line}`, display:"flex", flexDirection:"column" }}>
          <div style={{ display:"flex", borderBottom:`1px solid ${T.line}` }}>
            {[["sections","Sections"],["elements","Elements"],["pages","Pages"]].map(([k,l])=>(
              <button key={k} onClick={()=>setTab(k)} style={{ flex:1, padding:"10px 4px", background:"none", border:"none", borderBottom:`2px solid ${tab===k?T.blue:"transparent"}`, color:tab===k?T.blue:T.low, fontSize:12, fontWeight:tab===k?600:400, cursor:"pointer" }}>{l}</button>
            ))}
          </div>
          <div style={{ padding:10, flex:1, overflowY:"auto" }}>
            {tab==="sections"&&<div style={{ display:"flex", flexDirection:"column", gap:5 }}>{WB_SECTIONS.map(s=>(
              <div key={s.id} onClick={()=>addSection(s)} style={{ display:"flex", alignItems:"center", gap:9, padding:"8px 10px", borderRadius:9, cursor:"pointer", background:T.card, border:`1px solid ${T.line}`, transition:"all 0.12s" }}
                onMouseEnter={e=>{e.currentTarget.style.background=T.blueL;e.currentTarget.style.borderColor="rgba(75,108,247,0.25)";}}
                onMouseLeave={e=>{e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}>
                <div style={{ width:26, height:26, borderRadius:7, background:`${s.c}14`, border:`1px solid ${s.c}20`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, color:s.c, flexShrink:0 }}>{s.icon}</div>
                <span style={{ fontSize:12, fontWeight:500, color:T.mid }}>{s.label}</span>
                <span style={{ marginLeft:"auto", fontSize:14, color:T.low }}>+</span>
              </div>
            ))}</div>}
            {tab==="elements"&&<div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6 }}>{WB_ELEMENTS.map(el=>(
              <div key={el.label} draggable style={{ padding:"10px 8px", borderRadius:9, cursor:"grab", background:T.card, border:`1px solid ${T.line}`, textAlign:"center", transition:"all 0.12s" }}
                onMouseEnter={e=>{e.currentTarget.style.background=T.card2;e.currentTarget.style.borderColor=T.lineHi;}}
                onMouseLeave={e=>{e.currentTarget.style.background=T.card;e.currentTarget.style.borderColor=T.line;}}>
                <div style={{ fontSize:18, marginBottom:4, color:el.c }}>{el.icon}</div>
                <div style={{ fontSize:10.5, color:T.mid, fontWeight:500 }}>{el.label}</div>
              </div>
            ))}</div>}
            {tab==="pages"&&<div style={{ display:"flex", flexDirection:"column", gap:5 }}>
              {["Home","About","Pricing","Contact"].map(p=>(<div key={p} style={{ display:"flex", alignItems:"center", padding:"9px 11px", borderRadius:9, background:p==="Home"?T.blueL:T.card, border:`1px solid ${p==="Home"?"rgba(75,108,247,0.25)":T.line}`, cursor:"pointer" }}><span style={{ flex:1, fontSize:12.5, fontWeight:p==="Home"?600:400, color:p==="Home"?T.blue:T.mid }}>{p}</span>{p==="Home"&&<span style={{ fontSize:9, color:T.blue, fontFamily:"'JetBrains Mono',monospace", fontWeight:700 }}>ACTIVE</span>}</div>))}
              <button style={{ marginTop:8, padding:"9px", background:T.blueL, border:`1px solid rgba(75,108,247,0.2)`, borderRadius:9, color:T.blue, fontSize:12, fontWeight:600, cursor:"pointer" }}>+ New Page</button>
            </div>}
          </div>
        </div>

        <div style={{ flex:1, overflow:"auto", background:T.bg, display:"flex", alignItems:"flex-start", justifyContent:"center", padding:20 }}>
          <div style={{ width:device==="desktop"?"100%":device==="tablet"?720:375, maxWidth:device==="desktop"?920:undefined, background:T.card, borderRadius:12, boxShadow:"0 8px 40px rgba(50,60,120,0.12)", border:`1px solid ${T.line}`, overflow:"hidden", transition:"all 0.3s ease" }}>
            <div style={{ height:36, background:T.card2, borderBottom:`1px solid ${T.line}`, display:"flex", alignItems:"center", padding:"0 12px", gap:8 }}>
              <div style={{ display:"flex", gap:5 }}>{[T.red,T.amber,T.green].map(c=><div key={c} style={{ width:9, height:9, borderRadius:"50%", background:c, opacity:0.7 }}/>)}</div>
              <div style={{ flex:1, background:T.card, border:`1px solid ${T.line}`, borderRadius:6, padding:"3px 12px", fontSize:11, color:T.low, textAlign:"center", fontFamily:"'JetBrains Mono',monospace" }}>mysite.argiflow.io</div>
            </div>
            {blocks.length===0?(
              <div style={{ padding:60, textAlign:"center", color:T.low }}><div style={{ fontSize:40, opacity:0.1, marginBottom:12 }}>⬟</div><div style={{ fontSize:14, fontWeight:600, color:T.ink, marginBottom:6 }}>Canvas is empty</div><div style={{ fontSize:12 }}>Add sections from the left panel.</div></div>
            ):(
              <div>
                {blocks.map((block,i)=>{
                  const isSel=selBlock===block.id, isHov=hovBlock===block.id;
                  return(<div key={block.id} onClick={()=>setSelBlock(block.id)} onMouseEnter={()=>setHovBlock(block.id)} onMouseLeave={()=>setHovBlock(null)} style={{ position:"relative", height:block.height, border:`2px solid ${isSel?T.blue:isHov?"rgba(75,108,247,0.3)":"transparent"}`, borderBottom:`1px solid ${T.line}`, transition:"border-color 0.14s", cursor:"pointer" }}>
                    <Preview block={block}/>
                    {(isSel||isHov)&&(<div style={{ position:"absolute", top:6, right:6, display:"flex", gap:4 }}>{["↑","↓"].map((d,j)=><button key={d} onClick={e=>{e.stopPropagation();moveBlock(block.id,j===0?"up":"dn");}} style={{ width:24, height:24, borderRadius:6, background:T.card, border:`1px solid ${T.line}`, color:T.mid, cursor:"pointer", fontSize:12, display:"flex", alignItems:"center", justifyContent:"center" }}>{d}</button>)}<button onClick={e=>{e.stopPropagation();removeBlock(block.id);}} style={{ width:24, height:24, borderRadius:6, background:T.redL, border:`1px solid rgba(228,68,68,0.25)`, color:T.red, cursor:"pointer", fontSize:12, display:"flex", alignItems:"center", justifyContent:"center" }}>×</button></div>)}
                    {isSel&&<div style={{ position:"absolute", left:0, top:0, bottom:0, width:3, background:T.blue, borderRadius:"2px 0 0 2px" }}/>}
                    <div style={{ position:"absolute", bottom:7, left:10, fontSize:10, color:isSel?T.blue:T.low, fontWeight:isSel?600:400, background:T.card, padding:"2px 8px", borderRadius:4, border:`1px solid ${isSel?"rgba(75,108,247,0.25)":T.line}` }}>{block.label}</div>
                  </div>);
                })}
                <div style={{ height:72, border:`2px dashed ${T.line}`, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", transition:"all 0.15s" }}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(75,108,247,0.35)";e.currentTarget.style.background=T.blueL;}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor=T.line;e.currentTarget.style.background="transparent";}}
                  onClick={()=>setTab("sections")}>
                  <span style={{ fontSize:13, color:T.low, fontWeight:500 }}>+ Add Section</span>
                </div>
              </div>
            )}
          </div>
        </div>

        <div style={{ width:240, flexShrink:0, background:T.card, borderLeft:`1px solid ${T.line}`, display:"flex", flexDirection:"column", overflowY:"auto" }}>
          <div style={{ padding:"13px 14px", borderBottom:`1px solid ${T.line}` }}><div style={{ fontWeight:700, fontSize:13, color:T.ink }}>Block Settings</div>{selBlockObj&&<div style={{ fontSize:10.5, color:T.low, marginTop:2 }}>{selBlockObj.label}</div>}</div>
          {selBlockObj?(
            <div style={{ padding:14, display:"flex", flexDirection:"column", gap:12 }}>
              <Field label="Name"><Input defaultValue={selBlockObj.label}/></Field>
              <div><FLabel>Background</FLabel><div style={{ display:"flex", gap:5 }}>{[T.card,"#F0F4FF","#F0FFF8","#FFF9F0"].map((bg,i)=><div key={i} style={{ width:28, height:28, borderRadius:6, background:bg, border:`2px solid ${i===0?T.blue:T.line}`, cursor:"pointer" }}/>)}</div></div>
              <Field label="Animation"><SelectEl opts={["None","Fade In","Slide Up","Scale In"]} def="None"/></Field>
              <div style={{ paddingTop:8, borderTop:`1px solid ${T.line}`, display:"flex", flexDirection:"column", gap:6 }}>
                <Btn variant="primary" sx={{ fontSize:12 }}>Edit Content</Btn>
                <Btn variant="danger" sx={{ fontSize:12 }} onClick={()=>removeBlock(selBlockObj.id)}>Remove Section</Btn>
              </div>
            </div>
          ):(
            <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:20, textAlign:"center", opacity:0.4 }}>
              <div style={{ fontSize:32, marginBottom:10 }}>⬟</div>
              <div style={{ fontSize:12, color:T.mid }}>Click any block to configure it</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  CREDITS PAGE
// ═══════════════════════════════════════════════════════
function CreditsPage({ credits, user }) {
  const PLANS=[
    { name:"Starter",  price:"$97/mo",  credits:3000,  cost:"~$12",  margin:"88%" },
    { name:"Growth",   price:"$197/mo", credits:8000,  cost:"~$30",  margin:"85%", popular:true },
    { name:"Agency",   price:"$497/mo", credits:25000, cost:"~$90",  margin:"82%" },
  ];
  return (
    <div style={{ padding:20, display:"flex", flexDirection:"column", gap:16, maxWidth:860 }}>
      <Card sx={{ padding:28, background:`linear-gradient(135deg,${T.blueL},${T.violetL}60)`, borderColor:"rgba(75,108,247,0.22)" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div>
            <div style={{ fontSize:11, fontWeight:700, color:T.blue, letterSpacing:"0.08em", textTransform:"uppercase", fontFamily:"'JetBrains Mono',monospace", marginBottom:8 }}>CURRENT BALANCE</div>
            <div style={{ fontSize:52, fontWeight:800, color:T.ink, fontFamily:"'JetBrains Mono',monospace", letterSpacing:"-0.03em" }}>{credits?.toLocaleString()}</div>
            <div style={{ fontSize:13, color:T.mid, marginTop:6 }}>credits · plan: <b style={{color:T.ink,textTransform:"uppercase"}}>{user?.plan}</b></div>
          </div>
          <Btn variant="primary" sx={{ fontSize:13, padding:"10px 24px" }}>⬆ Top Up Credits</Btn>
        </div>
        <div style={{ marginTop:24, paddingTop:20, borderTop:`1px solid rgba(75,108,247,0.15)` }}>
          <FLabel>Credit cost per action</FLabel>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10, marginTop:10 }}>
            {Object.entries(CREDIT_COSTS).map(([action,cost])=>(
              <div key={action} style={{ padding:"10px 12px", background:T.card, border:`1px solid ${T.line}`, borderRadius:9 }}>
                <div style={{ fontSize:10, color:T.low, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4 }}>{action.replace(/_/g," ")}</div>
                <div style={{ display:"flex", alignItems:"baseline", gap:6 }}><span style={{ fontSize:18, fontWeight:700, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{cost}</span><span style={{ fontSize:11, color:T.low }}>credits</span></div>
              </div>
            ))}
          </div>
        </div>
      </Card>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12 }}>
        {PLANS.map(plan=>(
          <Card key={plan.name} sx={{ padding:22, position:"relative", borderColor:plan.popular?"rgba(75,108,247,0.35)":T.line, boxShadow:plan.popular?`0 0 0 3px ${T.blueL}`:undefined }}>
            {plan.popular&&<div style={{ position:"absolute", top:-1, left:"50%", transform:"translateX(-50%)", background:T.blue, color:"#fff", fontSize:9.5, fontWeight:700, padding:"3px 12px", borderRadius:"0 0 6px 6px", letterSpacing:"0.06em" }}>MOST POPULAR</div>}
            <div style={{ marginTop:plan.popular?12:0 }}>
              <div style={{ fontWeight:800, fontSize:16, color:T.ink, marginBottom:4 }}>{plan.name}</div>
              <div style={{ fontSize:28, fontWeight:800, color:T.blue, fontFamily:"'JetBrains Mono',monospace" }}>{plan.price}</div>
              <div style={{ fontSize:12, color:T.mid, marginTop:8 }}>{plan.credits.toLocaleString()} credits/month</div>
              <div style={{ fontSize:11, color:T.low, marginTop:4 }}>API cost: <b>{plan.cost}</b> · Margin: <b style={{color:T.green}}>{plan.margin}</b></div>
              <div style={{ marginTop:16 }}><Btn variant={plan.popular?"primary":"ghost"} sx={{ width:"100%", fontSize:13 }}>{user?.plan===plan.name.toLowerCase()?"Current Plan":"Upgrade"}</Btn></div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  BLANK
// ═══════════════════════════════════════════════════════
function BlankPage({ label }) {
  return <EmptyState icon="◈" title={label??"Coming Soon"} desc="Connect your backend to activate this module." />;
}
