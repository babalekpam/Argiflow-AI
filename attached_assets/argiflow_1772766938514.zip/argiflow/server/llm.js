// server/llm.js
// ═══════════════════════════════════════════════════════
//  Universal LLM Router
//  Switch providers by changing LLM_PROVIDER in .env
//  Zero code changes needed.
//
//  Supported:
//    anthropic  →  claude-sonnet-4-6, opus-4-6, haiku-4-5
//    openai     →  gpt-4o, gpt-4o-mini, gpt-4-turbo
//    gemini     →  gemini-1.5-pro, gemini-1.5-flash
//    mistral    →  mistral-large-latest, mistral-medium-latest
//    groq       →  llama-3.3-70b-versatile, mixtral-8x7b
//    together   →  meta-llama/Llama-3-70b-chat-hf
// ═══════════════════════════════════════════════════════
import fetch from 'node-fetch';

// Registry — base URLs and formats for each provider
const REGISTRY = {
  anthropic: {
    name: 'Anthropic',
    baseUrl: 'https://api.anthropic.com',
    format: 'anthropic',
    defaultModel: 'claude-sonnet-4-6',
    getKey: () => process.env.ANTHROPIC_API_KEY,
  },
  openai: {
    name: 'OpenAI',
    baseUrl: 'https://api.openai.com',
    format: 'openai',
    defaultModel: 'gpt-4o',
    getKey: () => process.env.OPENAI_API_KEY,
  },
  gemini: {
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com',
    format: 'gemini',
    defaultModel: 'gemini-1.5-pro',
    getKey: () => process.env.GEMINI_API_KEY,
  },
  mistral: {
    name: 'Mistral AI',
    baseUrl: 'https://api.mistral.ai',
    format: 'openai',
    defaultModel: 'mistral-large-latest',
    getKey: () => process.env.MISTRAL_API_KEY,
  },
  groq: {
    name: 'Groq',
    baseUrl: 'https://api.groq.com/openai',
    format: 'openai',
    defaultModel: 'llama-3.3-70b-versatile',
    getKey: () => process.env.GROQ_API_KEY,
  },
  together: {
    name: 'Together AI',
    baseUrl: 'https://api.together.xyz',
    format: 'openai',
    defaultModel: 'meta-llama/Llama-3-70b-chat-hf',
    getKey: () => process.env.TOGETHER_API_KEY,
  },
};

export function getActiveConfig() {
  const providerId = (process.env.LLM_PROVIDER || 'anthropic').toLowerCase();
  const reg = REGISTRY[providerId];
  if (!reg) throw new Error(`Unknown LLM_PROVIDER: ${providerId}`);
  const model = process.env.LLM_MODEL || reg.defaultModel;
  const apiKey = reg.getKey();
  if (!apiKey) throw new Error(`No API key set for provider "${reg.name}". Add ${providerId.toUpperCase()}_API_KEY to .env`);
  return { providerId, model, apiKey, ...reg };
}

export async function callLLM({ system, userMessage, maxTokens = 800 }) {
  const cfg = getActiveConfig();

  // ── Anthropic ──────────────────────────────────────
  if (cfg.format === 'anthropic') {
    const res = await fetch(`${cfg.baseUrl}/v1/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': cfg.apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: cfg.model,
        max_tokens: maxTokens,
        system,
        messages: [{ role: 'user', content: userMessage }],
      }),
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({}));
      throw new Error(e?.error?.message || res.statusText);
    }
    const data = await res.json();
    return { text: data.content?.[0]?.text ?? '', provider: cfg.name, model: cfg.model };
  }

  // ── OpenAI-compatible (OpenAI, Mistral, Groq, Together) ──
  if (cfg.format === 'openai') {
    const messages = [];
    if (system) messages.push({ role: 'system', content: system });
    messages.push({ role: 'user', content: userMessage });
    const res = await fetch(`${cfg.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({ model: cfg.model, max_tokens: maxTokens, messages }),
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({}));
      throw new Error(e?.error?.message || res.statusText);
    }
    const data = await res.json();
    return { text: data.choices?.[0]?.message?.content ?? '', provider: cfg.name, model: cfg.model };
  }

  // ── Google Gemini ──────────────────────────────────
  if (cfg.format === 'gemini') {
    const endpoint = `${cfg.baseUrl}/v1beta/models/${cfg.model}:generateContent?key=${cfg.apiKey}`;
    const body = {
      contents: [{ parts: [{ text: userMessage }] }],
      generationConfig: { maxOutputTokens: maxTokens },
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({}));
      throw new Error(e?.error?.message || res.statusText);
    }
    const data = await res.json();
    return { text: data.candidates?.[0]?.content?.parts?.[0]?.text ?? '', provider: cfg.name, model: cfg.model };
  }

  throw new Error(`Unsupported format: ${cfg.format}`);
}

export { REGISTRY };
