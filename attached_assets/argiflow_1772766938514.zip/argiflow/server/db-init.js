// server/db-init.js
// Run: npm run db:init
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import db from './db.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const sql = readFileSync(join(__dirname, 'schema.sql'), 'utf8');

try {
  await db.query(sql);
  console.log('✅ Database schema created successfully');
  console.log('✅ Demo user seeded: abel@argilette.co');
} catch (err) {
  console.error('❌ Schema error:', err.message);
} finally {
  process.exit(0);
}
