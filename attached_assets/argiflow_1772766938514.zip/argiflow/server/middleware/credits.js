// server/middleware/credits.js
// Deducts credits BEFORE the API call. Refunds on failure.
import db from '../db.js';

export const CREDIT_COSTS = {
  ai_email:       8,
  lead_enrich:    15,
  agent_run:      50,
  reply_analyze:  10,
  intent_scan:    20,
  email_sequence: 30,
};

// Middleware factory — use: requireCredits('agent_run')
export function requireCredits(action) {
  return async (req, res, next) => {
    const cost = CREDIT_COSTS[action];
    if (!cost) return next(); // unknown action, skip

    // Get user_id from req (set by auth middleware or demo header)
    const userId = req.userId || req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Not authenticated' });

    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      // Check + deduct atomically
      const result = await client.query(
        `UPDATE users SET credits = credits - $1
         WHERE id = $2 AND credits >= $1
         RETURNING credits`,
        [cost, userId]
      );

      if (result.rowCount === 0) {
        await client.query('ROLLBACK');
        return res.status(402).json({
          error: 'Insufficient credits',
          required: cost,
          message: 'Top up your credits at /credits',
        });
      }

      // Log the deduction
      await client.query(
        `INSERT INTO credits_ledger (user_id, action, credits_used)
         VALUES ($1, $2, $3)`,
        [userId, action, cost]
      );

      await client.query('COMMIT');
      req.creditAction = action;
      req.creditCost   = cost;
      req.creditsRemaining = result.rows[0].credits;
      next();
    } catch (err) {
      await client.query('ROLLBACK');
      next(err);
    } finally {
      client.release();
    }
  };
}

// Call this if the LLM call fails — returns credits
export async function refundCredits(userId, action) {
  const cost = CREDIT_COSTS[action] || 0;
  if (!cost || !userId) return;
  await db.query(
    `UPDATE users SET credits = credits + $1 WHERE id = $2`,
    [cost, userId]
  );
  await db.query(
    `INSERT INTO credits_ledger (user_id, action, credits_used)
     VALUES ($1, $2, $3)`,
    [userId, `${action}_refund`, -cost]
  );
}
