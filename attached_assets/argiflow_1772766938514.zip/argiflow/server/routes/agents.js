// server/routes/agents.js
import { Router } from 'express';
import db from '../db.js';
import { callLLM } from '../llm.js';
import { requireCredits, refundCredits } from '../middleware/credits.js';

const router = Router();

// Built-in agent definitions — extend or load from DB
const BUILT_IN_AGENTS = [
  {
    id: 'scout',
    name: 'Lead Scout',
    status: 'active',
    category: 'Intelligence',
    description: 'Finds and scores B2B leads matching your ICP across 50M+ contacts.',
    system: `You are Lead Scout, an expert B2B lead research specialist for ARGILETTE LLC.
Your job: find, qualify, and score leads that match the user's ideal customer profile.
Be specific, practical, and structured. Output leads in a clear numbered list with:
- Full name + job title
- Company + estimated size
- Why they're a good fit
- Recommended opening angle
Keep response under 700 words.`,
  },
  {
    id: 'writer',
    name: 'Cold Email Writer',
    status: 'active',
    category: 'Outreach',
    description: 'Writes personalized cold emails that get replies.',
    system: `You are an expert cold email copywriter for ARGILETTE LLC.
Write personalized, non-spammy cold emails that feel human and get replies.
Use the AIDA framework (Attention, Interest, Desire, Action).
Rules: No more than 150 words. One clear CTA. No generic openers like "I hope this email finds you well."
Output the email with Subject line, Body, and a brief note on why this approach works.`,
  },
  {
    id: 'reply',
    name: 'Reply Analyzer',
    status: 'active',
    category: 'Outreach',
    description: 'Detects intent in replies and drafts the perfect response.',
    system: `You are a sales reply intelligence specialist for ARGILETTE LLC.
Analyze the provided email reply and:
1. Classify intent: INTERESTED / OBJECTION / UNSUBSCRIBE / NOT_NOW / REFERRAL
2. Rate warmth: 1–10
3. Draft the ideal response (under 100 words)
4. Suggest next action (book call, send case study, follow up in X days, etc.)
Be direct and practical.`,
  },
  {
    id: 'intent',
    name: 'Intent Monitor',
    status: 'active',
    category: 'Intelligence',
    description: 'Surfaces buying signals from company activity and news.',
    system: `You are a B2B intent data analyst for ARGILETTE LLC.
Given a company name or domain, analyze publicly available signals and explain:
1. Whether they are likely in a buying cycle (HIGH / MED / LOW signal)
2. What specific signals indicate buying intent
3. The best time window to reach out
4. Recommended approach based on intent signals
Be specific and actionable.`,
  },
  {
    id: 'booker',
    name: 'Meeting Booker',
    status: 'active',
    category: 'CRM',
    description: 'Converts interested prospects into booked calls.',
    system: `You are a meeting booking specialist for ARGILETTE LLC.
When a prospect shows interest, craft a reply that:
- Acknowledges their interest specifically
- Proposes 2-3 specific time slots (use placeholder times like "Tuesday 2pm or Wednesday 10am EST")
- Includes a calendar link placeholder [CALENDAR_LINK]
- Is under 80 words and conversational
Also output a subject line for the email.`,
  },
  {
    id: 'forum',
    name: 'Forum Prospector',
    status: 'active',
    category: 'Intelligence',
    description: 'Scans Reddit, LinkedIn, and forums for prospects asking about your solution.',
    system: `You are a forum prospecting specialist for ARGILETTE LLC.
Given a product description or topic, generate:
1. The top 5 subreddits or LinkedIn groups where ideal customers hang out
2. The exact search queries to find people asking for a solution like yours
3. Example forum posts/questions that indicate a good prospect
4. A word-for-word DM template to reach out to these prospects authentically
Focus on being helpful, not salesy.`,
  },
];

// GET /api/agents — list all agents with their stats from DB
router.get('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];

  try {
    // Get run stats per agent from DB
    const statsRes = await db.query(
      `SELECT
         agent_id,
         COUNT(*)::int                                               AS runs,
         ROUND(AVG(CASE WHEN status='completed' THEN 100.0 ELSE 0 END), 1) AS rate,
         MAX(created_at)                                             AS last_run
       FROM agent_runs
       WHERE user_id = $1
       GROUP BY agent_id`,
      [userId]
    );

    const statsMap = {};
    statsRes.rows.forEach(r => { statsMap[r.agent_id] = r; });

    const agents = BUILT_IN_AGENTS.map(a => ({
      id:          a.id,
      name:        a.name,
      status:      a.status,
      category:    a.category,
      description: a.description,
      runs:        statsMap[a.id]?.runs     || 0,
      rate:        statsMap[a.id]?.rate     || 100,
      lastRun:     statsMap[a.id]?.last_run ? timeAgo(statsMap[a.id].last_run) : 'never',
    }));

    res.json({ agents });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/agents/:id/run — run agent with real LLM call
router.post('/:id/run', requireCredits('agent_run'), async (req, res) => {
  const userId   = req.userId || req.headers['x-user-id'];
  const { id }   = req.params;
  const { prompt } = req.body;

  if (!prompt?.trim()) return res.status(400).json({ error: 'prompt is required' });

  const agent = BUILT_IN_AGENTS.find(a => a.id === id);
  if (!agent) return res.status(404).json({ error: `Agent "${id}" not found` });

  let llmResult = null;
  try {
    llmResult = await callLLM({
      system:      agent.system,
      userMessage: prompt,
      maxTokens:   800,
    });
  } catch (llmErr) {
    // Refund on LLM failure
    await refundCredits(userId, 'agent_run');
    return res.status(500).json({ error: `LLM call failed: ${llmErr.message}` });
  }

  // Log run to DB
  try {
    await db.query(
      `INSERT INTO agent_runs (user_id, agent_id, agent_name, prompt, output, provider, model, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'completed')`,
      [userId, agent.id, agent.name, prompt, llmResult.text, llmResult.provider, llmResult.model]
    );

    // Update credits_ledger with provider info
    await db.query(
      `UPDATE credits_ledger SET provider=$1, model=$2
       WHERE user_id=$3 AND action='agent_run'
       ORDER BY created_at DESC LIMIT 1`,
      [llmResult.provider, llmResult.model, userId]
    );
  } catch (dbErr) {
    console.error('DB log error (non-fatal):', dbErr.message);
  }

  res.json({
    output:           llmResult.text,
    provider:         llmResult.provider,
    model:            llmResult.model,
    credits_remaining: req.creditsRemaining,
  });
});

// GET /api/agents/:id/runs — history for a specific agent
router.get('/:id/runs', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT id, prompt, output, provider, model, status, created_at
       FROM agent_runs
       WHERE user_id=$1 AND agent_id=$2
       ORDER BY created_at DESC
       LIMIT 20`,
      [userId, req.params.id]
    );
    res.json({ runs: result.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function timeAgo(date) {
  const s = Math.floor((Date.now() - new Date(date)) / 1000);
  if (s < 60)    return `${s}s ago`;
  if (s < 3600)  return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}

export default router;
