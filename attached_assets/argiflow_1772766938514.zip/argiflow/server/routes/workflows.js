// server/routes/workflows.js
import { Router } from 'express';
import db from '../db.js';

const router = Router();

router.get('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT id, name, status, runs, nodes, edges, created_at, updated_at
       FROM workflows WHERE user_id=$1 ORDER BY updated_at DESC`,
      [userId]
    );
    res.json({ workflows: result.rows });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { name='New Workflow', nodes=[], edges=[] } = req.body;
  try {
    const result = await db.query(
      `INSERT INTO workflows (user_id, name, nodes, edges) VALUES ($1,$2,$3,$4) RETURNING *`,
      [userId, name, JSON.stringify(nodes), JSON.stringify(edges)]
    );
    res.status(201).json({ workflow: result.rows[0] });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/save', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { name, nodes, edges, status } = req.body;
  try {
    await db.query(
      `UPDATE workflows SET name=COALESCE($1,name), nodes=COALESCE($2,nodes),
       edges=COALESCE($3,edges), status=COALESCE($4,status), updated_at=NOW()
       WHERE id=$5 AND user_id=$6`,
      [name, nodes ? JSON.stringify(nodes) : null, edges ? JSON.stringify(edges) : null, status, req.params.id, userId]
    );
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  await db.query(`DELETE FROM workflows WHERE id=$1 AND user_id=$2`, [req.params.id, userId]);
  res.json({ ok: true });
});

export default router;
