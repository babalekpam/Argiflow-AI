// server/routes/leads.js
import { Router } from 'express';
import db from '../db.js';
import { callLLM, getActiveConfig } from '../llm.js';
import { requireCredits, refundCredits } from '../middleware/credits.js';

const router = Router();

// ─────────────────────────────────────────────────────
//  POST /api/leads/search
//  Searches your leads DB first.
//  If connected to Hunter.io / Apollo, also pulls fresh results.
//  Body: { keywords, industry, title, location, size, verified }
// ─────────────────────────────────────────────────────
router.post('/search', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { keywords='', industry='', title='', location='', size='', verified=false } = req.body;

  try {
    // Build dynamic WHERE clause
    const conditions = ['l.user_id = $1'];
    const params = [userId];
    let idx = 2;

    if (keywords) {
      conditions.push(`(l.company ILIKE $${idx} OR l.title ILIKE $${idx} OR l.name ILIKE $${idx})`);
      params.push(`%${keywords}%`);
      idx++;
    }
    if (industry) {
      conditions.push(`l.industry ILIKE $${idx}`);
      params.push(`%${industry}%`);
      idx++;
    }
    if (title) {
      conditions.push(`l.title ILIKE $${idx}`);
      params.push(`%${title}%`);
      idx++;
    }
    if (location) {
      conditions.push(`(l.location ILIKE $${idx} OR l.country ILIKE $${idx})`);
      params.push(`%${location}%`);
      idx++;
    }
    if (verified) {
      conditions.push(`l.verified = TRUE`);
    }
    if (size) {
      conditions.push(`l.size = $${idx}`);
      params.push(size);
      idx++;
    }

    const sql = `
      SELECT id, name, title, company, email, industry, size,
             location, country, score, intent, verified, enriched, created_at
      FROM leads l
      WHERE ${conditions.join(' AND ')}
      ORDER BY score DESC, created_at DESC
      LIMIT 100
    `;

    const result = await db.query(sql, params);

    // ── Optional: also query external lead provider ──
    // Uncomment and fill in your API key to pull fresh leads
    // const externalLeads = await searchHunter({ keywords, industry, title, location });
    // return res.json({ leads: [...result.rows, ...externalLeads], total: result.rowCount });

    res.json({ leads: result.rows, total: result.rowCount });
  } catch (err) {
    console.error('Lead search error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  POST /api/leads/:id/enrich
//  Uses the active LLM to enrich a lead with AI-generated intel
//  Costs: lead_enrich credits (15)
// ─────────────────────────────────────────────────────
router.post('/:id/enrich', requireCredits('lead_enrich'), async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { id } = req.params;

  try {
    // Get lead
    const leadRes = await db.query(
      `SELECT * FROM leads WHERE id = $1 AND user_id = $2`,
      [id, userId]
    );
    if (!leadRes.rows[0]) return res.status(404).json({ error: 'Lead not found' });
    const lead = leadRes.rows[0];

    // Ask LLM to enrich
    let enrichment = null;
    try {
      const { text, provider, model } = await callLLM({
        system: `You are a B2B sales intelligence analyst. Given a lead's basic info, generate a brief but useful enrichment JSON with these fields:
          - pain_points: array of 3 likely business pain points
          - talking_points: array of 3 conversation starters
          - company_summary: 1-sentence company description
          - ideal_approach: recommended outreach approach (1-2 sentences)
          - signal_keywords: array of 5 keywords that indicate buying intent for this company
          Respond ONLY with valid JSON, no markdown.`,
        userMessage: `Lead: ${lead.name}, ${lead.title} at ${lead.company} (${lead.industry}, ${lead.size} employees, ${lead.country})`,
        maxTokens: 400,
      });

      // Parse JSON safely
      const clean = text.replace(/```json|```/g, '').trim();
      enrichment = JSON.parse(clean);

      // Log which provider was used
      await db.query(
        `UPDATE credits_ledger SET provider=$1, model=$2 WHERE user_id=$3 AND action='lead_enrich' ORDER BY created_at DESC LIMIT 1`,
        [provider, model, userId]
      );
    } catch (llmErr) {
      // LLM failed — refund credits and return error
      await refundCredits(userId, 'lead_enrich');
      return res.status(500).json({ error: `AI enrichment failed: ${llmErr.message}` });
    }

    // AI scoring — score the lead based on enrichment
    const score = scoreLead(lead, enrichment);

    // Save enrichment back to DB
    await db.query(
      `UPDATE leads
       SET enriched = TRUE, enrichment = $1, score = $2,
           intent = $3
       WHERE id = $4`,
      [enrichment, score, score >= 80 ? 'hot' : score >= 60 ? 'warm' : 'cold', id]
    );

    res.json({
      ok: true,
      score,
      intent: score >= 80 ? 'hot' : score >= 60 ? 'warm' : 'cold',
      enrichment,
      credits_remaining: req.creditsRemaining,
    });
  } catch (err) {
    console.error('Enrich error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  POST /api/leads  — import / create a lead manually
// ─────────────────────────────────────────────────────
router.post('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { name, title, company, email, industry, size, location, country } = req.body;

  if (!name || !company) return res.status(400).json({ error: 'name and company required' });

  try {
    const result = await db.query(
      `INSERT INTO leads (user_id, name, title, company, email, industry, size, location, country)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING *`,
      [userId, name, title, company, email, industry, size, location, country]
    );
    res.status(201).json({ lead: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────
//  DELETE /api/leads/:id
// ─────────────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  await db.query(`DELETE FROM leads WHERE id=$1 AND user_id=$2`, [req.params.id, userId]);
  res.json({ ok: true });
});

// ── Scoring helper ────────────────────────────────────
function scoreLead(lead, enrichment) {
  let score = 40; // base score
  if (lead.verified)             score += 15;
  if (lead.email)                score += 10;
  if (lead.title?.match(/CEO|CTO|CFO|VP|Director|Owner|Founder/i)) score += 15;
  if (enrichment?.pain_points?.length >= 3) score += 10;
  if (lead.industry?.match(/SaaS|Tech|Software|Health|Finance/i))  score += 5;
  if (lead.size?.match(/11-50|51-200/))     score += 5;
  return Math.min(score, 100);
}

// ── Optional: Hunter.io integration ──────────────────
// async function searchHunter({ keywords, industry, title, location }) {
//   if (!process.env.HUNTER_API_KEY) return [];
//   const params = new URLSearchParams({ api_key: process.env.HUNTER_API_KEY, ... });
//   const res = await fetch(`https://api.hunter.io/v2/domain-search?${params}`);
//   const data = await res.json();
//   return (data.data?.emails || []).map(e => ({ name: e.first_name + ' ' + e.last_name, email: e.value, ... }));
// }

export default router;
