// server/routes/sites.js
import { Router } from 'express';
import db from '../db.js';

const router = Router();

router.get('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT id, name, url, status, visitors, template, created_at, updated_at
       FROM sites WHERE user_id=$1 ORDER BY updated_at DESC`,
      [userId]
    );
    res.json({ sites: result.rows.map(s => ({ ...s, lastEdit: timeAgo(s.updated_at) })) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { template='blank', name='New Site' } = req.body;
  try {
    const result = await db.query(
      `INSERT INTO sites (user_id, name, template) VALUES ($1,$2,$3) RETURNING *`,
      [userId, name, template]
    );
    res.status(201).json({ site: result.rows[0] });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT * FROM sites WHERE id=$1 AND user_id=$2`, [req.params.id, userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Site not found' });
    res.json({ site: result.rows[0] });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/save', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { blocks, name } = req.body;
  try {
    await db.query(
      `UPDATE sites SET blocks=COALESCE($1,blocks), name=COALESCE($2,name), updated_at=NOW()
       WHERE id=$3 AND user_id=$4`,
      [blocks ? JSON.stringify(blocks) : null, name, req.params.id, userId]
    );
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/:id/publish', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    await db.query(
      `UPDATE sites SET status='live', updated_at=NOW() WHERE id=$1 AND user_id=$2`,
      [req.params.id, userId]
    );
    res.json({ ok: true, status: 'live' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

function timeAgo(date) {
  const s = Math.floor((Date.now() - new Date(date)) / 1000);
  if (s < 60)    return `${s}s ago`;
  if (s < 3600)  return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}

export default router;
