// server/routes/dashboard.js
import { Router } from 'express';
import db from '../db.js';
import { getActiveConfig } from '../llm.js';

const router = Router();

// GET /api/dashboard/stats
// Returns all data needed for the Overview page
router.get('/stats', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];

  try {
    // ── Run all queries in parallel ──────────────────
    const [
      userRow,
      leadCounts,
      pipelineRow,
      agentStats,
      recentRuns,
    ] = await Promise.all([
      // User + credits
      db.query(`SELECT name, org, plan, credits FROM users WHERE id = $1`, [userId]),

      // Lead counts by intent
      db.query(
        `SELECT
           COUNT(*)::int                                          AS total,
           COUNT(*) FILTER (WHERE intent = 'hot')::int           AS hot,
           COUNT(*) FILTER (WHERE intent = 'warm')::int          AS warm,
           COUNT(*) FILTER (WHERE enriched = TRUE)::int          AS enriched,
           COUNT(*) FILTER (WHERE verified = TRUE)::int          AS verified
         FROM leads WHERE user_id = $1`,
        [userId]
      ),

      // Latest pipeline snapshot
      db.query(
        `SELECT found, enriched, contacted, replied, meeting, closed
         FROM pipeline_snapshots
         WHERE user_id = $1
         ORDER BY snapped_at DESC LIMIT 1`,
        [userId]
      ),

      // Agent health — runs + success rate per agent
      db.query(
        `SELECT
           agent_id,
           agent_name,
           COUNT(*)::int                                              AS runs,
           ROUND(AVG(CASE WHEN status='completed' THEN 100 ELSE 0 END),1) AS rate,
           MAX(created_at)                                            AS last_run
         FROM agent_runs
         WHERE user_id = $1
         GROUP BY agent_id, agent_name
         ORDER BY runs DESC
         LIMIT 6`,
        [userId]
      ),

      // 8 most recent agent runs for activity feed
      db.query(
        `SELECT agent_name, prompt, output, created_at, status
         FROM agent_runs
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT 8`,
        [userId]
      ),
    ]);

    const user      = userRow.rows[0] || {};
    const leads     = leadCounts.rows[0] || {};
    const pipeline  = pipelineRow.rows[0];
    const agents    = agentStats.rows;
    const runs      = recentRuns.rows;

    // Build pipeline stages from either snapshot or live lead counts
    const totalFound = pipeline?.found || leads.total || 0;
    const pipelineStages = pipeline
      ? [
          { label: 'Found',     count: pipeline.found,     pct: 100,   color: '#4B6CF7' },
          { label: 'Enriched',  count: pipeline.enriched,  pct: totalFound ? Math.round((pipeline.enriched  / pipeline.found)  * 100) : 0, color: '#6366F1' },
          { label: 'Contacted', count: pipeline.contacted, pct: totalFound ? Math.round((pipeline.contacted / pipeline.found)  * 100) : 0, color: '#7B5BFB' },
          { label: 'Replied',   count: pipeline.replied,   pct: totalFound ? Math.round((pipeline.replied   / pipeline.found)  * 100) : 0, color: '#0691A1' },
          { label: 'Meeting',   count: pipeline.meeting,   pct: totalFound ? Math.round((pipeline.meeting   / pipeline.found)  * 100) : 0, color: '#0DAD74' },
          { label: 'Closed',    count: pipeline.closed,    pct: totalFound ? Math.round((pipeline.closed    / pipeline.found)  * 100) : 0, color: '#059669' },
        ]
      : [];   // Empty until first pipeline data exists

    // Build activity feed from agent runs
    const AGENT_ICONS = {
      scout: '✦', writer: '→', reply: '⊙', intent: '◎', booker: '⊙', forum: '⬡',
    };
    const activity = runs.map(r => ({
      icon: AGENT_ICONS[r.agent_id] || '◉',
      text: r.prompt
        ? `${r.agent_name}: "${r.prompt.slice(0, 70)}${r.prompt.length > 70 ? '…' : ''}"`
        : `${r.agent_name} completed`,
      time: timeAgo(r.created_at),
      status: r.status,
    }));

    // Agent health rows
    const agentHealth = agents.map(a => ({
      name:    a.agent_name || a.agent_id,
      status:  'active',
      runs:    a.runs,
      rate:    parseFloat(a.rate) || 0,
      lastRun: a.last_run ? timeAgo(a.last_run) : 'never',
    }));

    // Active LLM provider info
    let llmInfo = null;
    try { llmInfo = getActiveConfig(); } catch {}

    res.json({
      user: {
        name:    user.name || 'User',
        org:     user.org  || '',
        plan:    user.plan || 'starter',
        credits: user.credits || 0,
      },
      leads_total:     leads.total     || 0,
      emails_sent_30d: 0,   // Wire to your email provider stats
      meetings_booked: pipeline?.meeting || 0,
      pipeline_value:  '$0', // Wire to your CRM
      pipeline_stages: pipelineStages,
      activity,
      agent_health:    agentHealth,
      llm_provider: llmInfo
        ? { name: llmInfo.name, model: llmInfo.model }
        : null,
    });
  } catch (err) {
    console.error('Dashboard stats error:', err);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/dashboard/pipeline  — save a pipeline snapshot
router.post('/pipeline', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { found=0, enriched=0, contacted=0, replied=0, meeting=0, closed=0 } = req.body;
  try {
    await db.query(
      `INSERT INTO pipeline_snapshots (user_id, found, enriched, contacted, replied, meeting, closed)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [userId, found, enriched, contacted, replied, meeting, closed]
    );
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── helper ──
function timeAgo(date) {
  const s = Math.floor((Date.now() - new Date(date)) / 1000);
  if (s < 60)   return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400)return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}

export default router;
