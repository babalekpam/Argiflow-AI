// server/routes/intent.js
import { Router } from 'express';
import db from '../db.js';
import { callLLM } from '../llm.js';
import { requireCredits, refundCredits } from '../middleware/credits.js';

const router = Router();

// GET /api/intent/signals — live intent feed
router.get('/signals', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { filter = 'ALL' } = req.query;

  try {
    let sql = `
      SELECT id, company, domain, signal, strength, score, source,
             created_at
      FROM intent_signals
      WHERE user_id = $1
    `;
    const params = [userId];

    if (filter !== 'ALL') {
      sql += ` AND strength = $2`;
      params.push(filter);
    }

    sql += ` ORDER BY created_at DESC LIMIT 50`;

    const result = await db.query(sql, params);
    res.json({
      signals: result.rows.map(s => ({
        ...s,
        time: timeAgo(s.created_at),
      })),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/intent/stats — summary numbers
router.get('/stats', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const [sigStats, domainCount] = await Promise.all([
      db.query(
        `SELECT
           COUNT(*)::int                                          AS active,
           COUNT(*) FILTER (WHERE strength='HIGH')::int          AS high,
           ROUND(AVG(score))::int                                AS avg_score
         FROM intent_signals
         WHERE user_id = $1`,
        [userId]
      ),
      db.query(
        `SELECT COUNT(*)::int AS monitored FROM monitored_domains WHERE user_id=$1 AND active=TRUE`,
        [userId]
      ),
    ]);

    const s = sigStats.rows[0] || {};
    const d = domainCount.rows[0] || {};
    res.json({
      monitored:  d.monitored  || 0,
      active:     s.active     || 0,
      hot_today:  s.high       || 0,
      avg_score:  s.avg_score  || 0,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/intent/sources — signal source breakdown
router.get('/sources', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT source AS label, COUNT(*)::int AS count
       FROM intent_signals
       WHERE user_id = $1
       GROUP BY source
       ORDER BY count DESC`,
      [userId]
    );
    res.json({ sources: result.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/intent/monitor — add domain to watchlist + AI analysis
router.post('/monitor', requireCredits('intent_scan'), async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { domain } = req.body;
  if (!domain) return res.status(400).json({ error: 'domain required' });

  // Add to monitored_domains
  try {
    await db.query(
      `INSERT INTO monitored_domains (user_id, domain) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
      [userId, domain.trim().toLowerCase()]
    );
  } catch (err) {
    await refundCredits(userId, 'intent_scan');
    return res.status(500).json({ error: err.message });
  }

  // Use LLM to generate an initial intent analysis
  let signal = 'Recently added to watchlist — monitoring started';
  let strength = 'MED';
  let score = 50;

  try {
    const { text } = await callLLM({
      system: `You are a B2B intent analyst. Given a company domain, generate a plausible initial intent signal JSON:
        { "signal": "1-sentence description of likely buying signal", "strength": "HIGH|MED|LOW", "score": 0-100 }
        Base this on the domain name and typical company behavior.
        Respond ONLY with valid JSON, no markdown.`,
      userMessage: `Analyze domain: ${domain}`,
      maxTokens: 150,
    });

    const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
    signal   = parsed.signal   || signal;
    strength = parsed.strength || strength;
    score    = parseInt(parsed.score) || score;
  } catch (e) {
    // Non-critical — use defaults
    console.warn('Intent LLM error (non-fatal):', e.message);
  }

  // Get company name from domain
  const company = domain.split('.')[0].replace(/^\w/, c => c.toUpperCase());

  // Save signal
  const insertRes = await db.query(
    `INSERT INTO intent_signals (user_id, company, domain, signal, strength, score, source)
     VALUES ($1, $2, $3, $4, $5, $6, 'watchlist')
     RETURNING *`,
    [userId, company, domain, signal, strength, score]
  );

  res.json({
    ok: true,
    signal: { ...insertRes.rows[0], time: 'just now' },
    credits_remaining: req.creditsRemaining,
  });
});

// POST /api/intent/signals — manually add a signal
router.post('/signals', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  const { company, domain, signal, strength='MED', score=50, source='manual' } = req.body;
  if (!company || !domain || !signal) return res.status(400).json({ error: 'company, domain, signal required' });

  try {
    const result = await db.query(
      `INSERT INTO intent_signals (user_id, company, domain, signal, strength, score, source)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [userId, company, domain, signal, strength, score, source]
    );
    res.status(201).json({ signal: { ...result.rows[0], time: 'just now' } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/intent/signals/:id
router.delete('/signals/:id', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  await db.query(`DELETE FROM intent_signals WHERE id=$1 AND user_id=$2`, [req.params.id, userId]);
  res.json({ ok: true });
});

function timeAgo(date) {
  const s = Math.floor((Date.now() - new Date(date)) / 1000);
  if (s < 60)    return `${s}s ago`;
  if (s < 3600)  return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}

export default router;
