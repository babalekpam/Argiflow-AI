// server/routes/account.js
import { Router } from 'express';
import db from '../db.js';
import { getActiveConfig, REGISTRY } from '../llm.js';

const router = Router();

// GET /api/account — current user info + LLM status
router.get('/', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT id, email, name, org, plan, credits FROM users WHERE id = $1`,
      [userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'User not found' });
    const user = result.rows[0];

    let llm = null;
    try {
      const cfg = getActiveConfig();
      llm = { provider: cfg.name, model: cfg.model, providerId: cfg.providerId };
    } catch {}

    res.json({ ...user, llm });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/account/credits
router.get('/credits', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(`SELECT credits FROM users WHERE id=$1`, [userId]);
    res.json({ credits: result.rows[0]?.credits ?? 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/credits/history
router.get('/credits/history', async (req, res) => {
  const userId = req.userId || req.headers['x-user-id'];
  try {
    const result = await db.query(
      `SELECT action, credits_used AS amount, provider, model, created_at AS date
       FROM credits_ledger
       WHERE user_id=$1
       ORDER BY created_at DESC
       LIMIT 50`,
      [userId]
    );
    res.json({ history: result.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/llm/providers — list available providers + active one
router.get('/llm/providers', async (req, res) => {
  let active = null;
  try { active = getActiveConfig(); } catch {}

  res.json({
    providers: Object.entries(REGISTRY).map(([id, r]) => ({
      id,
      name: r.name,
      defaultModel: r.defaultModel,
      modelOptions: r.modelOptions,
      format: r.format,
    })),
    active: active ? {
      providerId: active.providerId,
      name: active.name,
      model: active.model,
    } : null,
  });
});

export default router;
