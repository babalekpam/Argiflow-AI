-- ═══════════════════════════════════════════════════════
--  ArgiFlow PostgreSQL Schema
--  Run: npm run db:init
-- ═══════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users
CREATE TABLE IF NOT EXISTS users (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email      TEXT UNIQUE NOT NULL,
  name       TEXT NOT NULL,
  org        TEXT,
  plan       TEXT DEFAULT 'starter',
  credits    INTEGER DEFAULT 3000,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Credits ledger
CREATE TABLE IF NOT EXISTS credits_ledger (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  action       TEXT NOT NULL,
  credits_used INTEGER NOT NULL,
  provider     TEXT,
  model        TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Leads
CREATE TABLE IF NOT EXISTS leads (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT,
  title      TEXT,
  company    TEXT,
  email      TEXT,
  industry   TEXT,
  size       TEXT,
  location   TEXT,
  country    TEXT,
  score      INTEGER DEFAULT 0,
  intent     TEXT DEFAULT 'cold',
  verified   BOOLEAN DEFAULT FALSE,
  enriched   BOOLEAN DEFAULT FALSE,
  enrichment JSONB,
  source     TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS leads_user_idx   ON leads(user_id);
CREATE INDEX IF NOT EXISTS leads_intent_idx ON leads(intent);
CREATE INDEX IF NOT EXISTS leads_score_idx  ON leads(score DESC);

-- Agent runs
CREATE TABLE IF NOT EXISTS agent_runs (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  agent_id   TEXT NOT NULL,
  agent_name TEXT,
  prompt     TEXT,
  output     TEXT,
  provider   TEXT,
  model      TEXT,
  status     TEXT DEFAULT 'completed',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Intent signals
CREATE TABLE IF NOT EXISTS intent_signals (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  company    TEXT NOT NULL,
  domain     TEXT NOT NULL,
  signal     TEXT NOT NULL,
  strength   TEXT DEFAULT 'MED',
  score      INTEGER DEFAULT 50,
  source     TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS intent_user_idx ON intent_signals(user_id);

-- Monitored domains
CREATE TABLE IF NOT EXISTS monitored_domains (
  id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id  UUID REFERENCES users(id) ON DELETE CASCADE,
  domain   TEXT NOT NULL,
  company  TEXT,
  active   BOOLEAN DEFAULT TRUE,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, domain)
);

-- Workflows
CREATE TABLE IF NOT EXISTS workflows (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  status     TEXT DEFAULT 'draft',
  runs       INTEGER DEFAULT 0,
  nodes      JSONB DEFAULT '[]',
  edges      JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Sites
CREATE TABLE IF NOT EXISTS sites (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  url        TEXT,
  status     TEXT DEFAULT 'draft',
  visitors   INTEGER DEFAULT 0,
  blocks     JSONB DEFAULT '[]',
  pages      JSONB DEFAULT '["Home"]',
  template   TEXT DEFAULT 'blank',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pipeline snapshots
CREATE TABLE IF NOT EXISTS pipeline_snapshots (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  found      INTEGER DEFAULT 0,
  enriched   INTEGER DEFAULT 0,
  contacted  INTEGER DEFAULT 0,
  replied    INTEGER DEFAULT 0,
  meeting    INTEGER DEFAULT 0,
  closed     INTEGER DEFAULT 0,
  snapped_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed demo user
INSERT INTO users (email, name, org, plan, credits)
VALUES ('abel@argilette.co', 'Abel Nkawula', 'ARGILETTE LLC', 'growth', 8000)
ON CONFLICT (email) DO NOTHING;
