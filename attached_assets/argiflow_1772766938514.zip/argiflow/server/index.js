// server/index.js — ArgiFlow Express Server
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { existsSync } from 'fs';

dotenv.config();

// Routes
import dashboardRouter from './routes/dashboard.js';
import leadsRouter     from './routes/leads.js';
import agentsRouter    from './routes/agents.js';
import intentRouter    from './routes/intent.js';
import accountRouter   from './routes/account.js';
import workflowsRouter from './routes/workflows.js';
import sitesRouter     from './routes/sites.js';

const app  = express();
const PORT = process.env.PORT || 3001;
const __dirname = dirname(fileURLToPath(import.meta.url));

// ── Security ──────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? process.env.FRONTEND_URL || true
    : 'http://localhost:5173',
  credentials: true,
}));

// ── Rate limiting (protect LLM endpoints) ─────────────
const aiLimiter = rateLimit({
  windowMs: 60 * 1000,   // 1 minute
  max: 20,               // 20 AI calls/min per IP
  message: { error: 'Too many requests. Slow down.' },
});

// ── Body parsing ─────────────────────────────────────
app.use(express.json({ limit: '2mb' }));

// ── Demo auth middleware ──────────────────────────────
// In production: replace with real JWT verification
// For now: pass x-user-id header OR use demo user from DB
app.use(async (req, res, next) => {
  // Allow explicit user ID header (dev/demo)
  if (req.headers['x-user-id']) {
    req.userId = req.headers['x-user-id'];
    return next();
  }

  // Default to demo user — find by email
  try {
    const db = (await import('./db.js')).default;
    const result = await db.query(
      `SELECT id FROM users WHERE email = $1`,
      ['abel@argilette.co']
    );
    if (result.rows[0]) {
      req.userId = result.rows[0].id;
    }
  } catch (err) {
    // DB not ready yet — continue anyway
  }
  next();
});

// ── API Routes ────────────────────────────────────────
app.use('/api/dashboard',  dashboardRouter);
app.use('/api/leads',      aiLimiter, leadsRouter);
app.use('/api/agents',     aiLimiter, agentsRouter);
app.use('/api/intent',     intentRouter);
app.use('/api/account',    accountRouter);
app.use('/api/workflows',  workflowsRouter);
app.use('/api/sites',      sitesRouter);

// Convenience routes wired from accountRouter
app.use('/api/credits',    accountRouter);
app.use('/api/llm',        accountRouter);

// ── Health check ─────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    env: process.env.NODE_ENV,
    llm_provider: process.env.LLM_PROVIDER || 'anthropic',
    llm_model:    process.env.LLM_MODEL    || 'claude-sonnet-4-6',
    timestamp:    new Date().toISOString(),
  });
});

// ── Serve built frontend in production ────────────────
const distPath = join(__dirname, '../dist');
if (process.env.NODE_ENV === 'production' && existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(join(distPath, 'index.html'));
  });
}

// ── Error handler ─────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Server error:', err.message);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`
  ╔══════════════════════════════════════╗
  ║  ArgiFlow Server running             ║
  ║  http://localhost:${PORT}               ║
  ║                                      ║
  ║  LLM Provider: ${(process.env.LLM_PROVIDER || 'anthropic').padEnd(20)} ║
  ║  Model:        ${(process.env.LLM_MODEL    || 'claude-sonnet-4-6').padEnd(20)} ║
  ╚══════════════════════════════════════╝
  `);
});
