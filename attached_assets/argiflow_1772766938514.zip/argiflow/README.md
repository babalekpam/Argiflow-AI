# ArgiFlow — AI Sales Automation Platform
**by ARGILETTE LLC**

---

## ⚡ Deploy on Replit in 4 Steps

### Step 1 — Import to Replit
1. Go to [replit.com](https://replit.com) → **Create Repl**
2. Choose **"Import from ZIP"** → upload this file
3. Replit will detect it as a Node.js project

### Step 2 — Add Secrets (Environment Variables)
In your Repl, click the **Secrets** (🔒) panel on the left sidebar and add:

| Secret Key | Value |
|---|---|
| `DATABASE_URL` | Your PostgreSQL connection string (see below) |
| `LLM_PROVIDER` | `anthropic` (or `openai`, `groq`, `gemini`, `mistral`) |
| `LLM_MODEL` | `claude-sonnet-4-6` (or your preferred model) |
| `ANTHROPIC_API_KEY` | Your Anthropic key (if using Anthropic) |
| `OPENAI_API_KEY` | Your OpenAI key (if using OpenAI) |
| `GROQ_API_KEY` | Your Groq key (if using Groq — it's free!) |
| `GEMINI_API_KEY` | Your Google AI key (if using Gemini) |
| `NODE_ENV` | `development` |
| `PORT` | `3001` |

**To switch LLM providers**: just change `LLM_PROVIDER` and set the matching API key. No code changes.

### Step 3 — Set Up PostgreSQL Database

**Option A: Replit built-in PostgreSQL** (recommended)
- In your Repl, click **Database** in the left sidebar
- Click **Create Database** → Replit will auto-populate `DATABASE_URL`

**Option B: Neon.tech (free, external)**
1. Go to [neon.tech](https://neon.tech) → Create free account
2. Create a new project → copy the connection string
3. Paste into Replit Secrets as `DATABASE_URL`

**Option C: Supabase (free, external)**
1. Go to [supabase.com](https://supabase.com) → New Project
2. Settings → Database → copy Connection String (URI mode)
3. Paste into Replit Secrets as `DATABASE_URL`

### Step 4 — Initialize DB + Run
In the Replit Shell tab, run:
```bash
npm install
npm run db:init
npm run dev
```

Your platform will be live at your Replit URL! 🚀

---

## 🔄 Switching LLM Providers

Change **two secrets** — that's it:

```
LLM_PROVIDER = groq          (or anthropic, openai, gemini, mistral, together)
LLM_MODEL    = llama-3.3-70b-versatile
```

| Provider | Key to set | Recommended model | Cost |
|---|---|---|---|
| Anthropic | `ANTHROPIC_API_KEY` | `claude-sonnet-4-6` | $3-15/M tokens |
| OpenAI | `OPENAI_API_KEY` | `gpt-4o` | $5-15/M tokens |
| Groq | `GROQ_API_KEY` | `llama-3.3-70b-versatile` | **Free tier** |
| Google Gemini | `GEMINI_API_KEY` | `gemini-1.5-flash` | $0.075/M tokens |
| Mistral | `MISTRAL_API_KEY` | `mistral-large-latest` | $2-8/M tokens |
| Together AI | `TOGETHER_API_KEY` | `meta-llama/Llama-3-70b-chat-hf` | $0.10-0.90/M tokens |

---

## 📁 Project Structure

```
argiflow/
├── index.html              # App entry point
├── package.json            # Dependencies
├── vite.config.js          # Frontend bundler (proxies /api → backend)
├── .env.example            # Copy to .env and fill in
│
├── src/
│   ├── main.jsx            # React mount
│   └── App.jsx             # Full platform UI (all pages)
│
└── server/
    ├── index.js            # Express server (port 3001)
    ├── db.js               # PostgreSQL connection pool
    ├── db-init.js          # Run once: creates tables + seeds demo user
    ├── schema.sql          # All table definitions
    ├── llm.js              # Universal LLM router (the magic 🔑)
    ├── middleware/
    │   └── credits.js      # Deduct before call, refund on failure
    └── routes/
        ├── dashboard.js    # GET /api/dashboard/stats
        ├── leads.js        # POST /api/leads/search, /:id/enrich
        ├── agents.js       # GET /api/agents, POST /:id/run
        ├── intent.js       # GET /api/intent/signals, POST /monitor
        ├── account.js      # GET /api/account, /credits/history
        ├── workflows.js    # CRUD /api/workflows
        └── sites.js        # CRUD /api/sites
```

---

## 🗄️ Database Tables

| Table | Purpose |
|---|---|
| `users` | Accounts, plan, credit balance |
| `credits_ledger` | Every credit deduction logged |
| `leads` | Your lead database with enrichment data |
| `agent_runs` | History of every AI agent execution |
| `intent_signals` | Buying signals from monitored companies |
| `monitored_domains` | Companies on your watchlist |
| `workflows` | Automation workflow definitions |
| `sites` | Website builder sites + blocks |
| `pipeline_snapshots` | Funnel stats over time |

---

## 💰 Credits System

Every AI call deducts credits **before** the API call. If it fails, credits are refunded.

| Action | Credits | Your API cost | Your revenue |
|---|---|---|---|
| AI Email Write | 8 cr | ~$0.01 | ~$0.027 |
| Lead Enrichment | 15 cr | ~$0.02 | ~$0.05 |
| Agent Run | 50 cr | ~$0.06 | ~$0.17 |
| Reply Analysis | 10 cr | ~$0.01 | ~$0.034 |
| Intent Scan | 20 cr | ~$0.03 | ~$0.068 |

---

## 🔌 Connecting Lead Data Providers (Optional)

To get real lead search results (not just from your own DB):

1. **Hunter.io** (free 25 searches/month) — uncomment in `server/routes/leads.js`
2. **Apollo.io** ($49/mo) — most comprehensive
3. **Proxycurl** (pay-per-call) — best for LinkedIn

Add your API key to `.env`:
```
HUNTER_API_KEY=your_key_here
APOLLO_API_KEY=your_key_here
```

Then uncomment the `searchHunter()` function at the bottom of `server/routes/leads.js`.

---

## 🚀 Production Deployment

```bash
npm run build          # builds React to /dist
NODE_ENV=production npm start   # serves frontend + backend on single port
```

For Replit deployment, set `NODE_ENV=production` in Secrets.

---

Built by **ARGILETTE LLC** · Abel Nkawula
